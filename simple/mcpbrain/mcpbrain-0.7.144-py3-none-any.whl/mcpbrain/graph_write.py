"""Structural write path for the enrichment graph (Phase 1, Task 2).

Ports the Nexus `memory_db` / `bitemporal_writer` write functions, repointed at
a `mcpbrain.store.Store` instance. The single public entry point is `apply()`,
which consumes one thread's extraction JSON and writes entities, relations,
topics, role observations, and the email_context row.

No DDL lives here: every write goes through Store methods or `store._connect()`.
The table DDL is owned by store.py.

Casing seam: the Nexus `_DOMAIN_ORG` map and KNOWN_ORGS use lowercase canonical
org tags ("orgname", "acc"). The mcpbrain contract and `enrich._VALID_ORGS`
use DISPLAY forms ("OrgName", "NCF"). This module adopts display-case as
canonical so org tags match the extraction contract and email_context rows.
"""

import logging
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

from nameparser import HumanName

from mcpbrain import config, orgs, topics
from mcpbrain import source_class as _sc
from mcpbrain.resolve import build_entity_index, write_time_dedup_check, add_to_index, is_role_address
from mcpbrain.chunking import (  # dependency-free; no graph_write -> enrich coupling
    slugify,
    split_aliases,
    _normalise_title_for_dedup,
    action_fingerprint as _compute_fingerprint,
)

log = logging.getLogger("mcpbrain.graph_write")


# ---------------------------------------------------------------------------
# Install-owner identity (config-driven)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class OwnerIdentity:
    """Who this install belongs to, for action attribution and self-exclusion.

    name:      short name written to actions.owner
    entity_id: the owner's entity slug — never upserted as an entity (_is_owner
               filters the owner out of every extracted entity and relation).
               It is a RECOGNISER, not a foreign key: a populated graph's real
               owner node is minted by the email path under a different slug
               (display name, not configured full name). Anything writing a
               relation from the owner must resolve the live id via
               resolve_owner_entity_id() — see the note there.
    aliases:   lowercased name variants treated as the owner
    """
    name: str = ""
    entity_id: str = ""
    aliases: frozenset = field(default_factory=frozenset)


def owner_identity_from_config(home=None) -> OwnerIdentity:
    """Build the owner identity from config.json under `home` (default
    MCPBRAIN_HOME)."""
    home = str(home) if home is not None else str(config.app_dir())
    return OwnerIdentity(
        name=config.owner_name(home),
        entity_id=slugify(config.owner_full_name(home)),
        aliases=config.owner_aliases(home),
    )

# ---------------------------------------------------------------------------
# Org / entity utilities (ported from memory_db.py:1428-1519)
#
# The taxonomy itself now lives in orgs.py (config-driven, DEFAULT_TAXONOMY =
# the historical four orgs). The module-level names below are kept as
# default-taxonomy views for back-compat importers; runtime paths resolve the
# configured taxonomy via orgs.taxonomy_from_config() — apply() resolves once
# per call and threads it down.
# ---------------------------------------------------------------------------

_DOMAIN_ORG = dict(orgs.DEFAULT_TAXONOMY.domain_map)

KNOWN_ORGS: frozenset = frozenset(_DOMAIN_ORG.values())

# Human-readable "domain -> Org" lines for the enrich prompt's org_domain_map
# (default-taxonomy view; prepare reads the configured taxonomy directly).
_DOMAIN_ORG_LINES = list(orgs.DEFAULT_TAXONOMY.domain_lines)

# Free-text org strings → display-case canonical org (default-taxonomy view).
ORG_ALIASES = dict(orgs.DEFAULT_TAXONOMY.aliases)

_JUNK_PATTERNS = [
    re.compile(r"^(Re|Fwd|FW|RE|FWD)\s*:", re.IGNORECASE),
    re.compile(r"https?://"),
    re.compile(r"\w+@\w+\.\w+"),
    re.compile(r"[|{}\[\]<>]"),
]

# Numeric patterns applied to person names ONLY: a 4-digit run (year/amount) or
# a date fragment is almost always junk in a person name, but legitimate in an
# org/project name ("OrgName 2026"). This split mirrors enrich._is_junk_entity
# rather than the Nexus is_junk_entity, which rejected 4-digit runs for orgs too.
_NUMERIC_JUNK = [
    re.compile(r"\d{4}"),
    re.compile(r"\d{2,}/\d{2,}"),
]


def canonical_org(raw: str, taxonomy: "orgs.OrgTaxonomy | None" = None) -> str:
    """Resolve a free-text org string to its display-case canonical form.

    taxonomy=None resolves the configured taxonomy from config (which falls
    back to the historical default on an unconfigured install).
    """
    if taxonomy is None:
        taxonomy = orgs.taxonomy_from_config()
    return taxonomy.canonical(raw)


def org_from_email(email_addr: str, taxonomy: "orgs.OrgTaxonomy | None" = None) -> str:
    """Map an email address to its display-case org via the domain table.

    "" for empty input, "external" for an unrecognised domain.
    """
    if taxonomy is None:
        taxonomy = orgs.taxonomy_from_config()
    return taxonomy.from_email(email_addr)


def strip_title(name: str) -> tuple[str, str]:
    """Return (cleaned_name, original). Strips an honorific via HumanName."""
    original = name.strip()
    parsed = HumanName(original)
    if parsed.title:
        parts = [parsed.first, parsed.middle, parsed.last, parsed.suffix]
        cleaned = " ".join(p for p in parts if p)
        if not cleaned:
            return original, original
        return cleaned, original
    return original, original


# Org-classification TAGS — the org enum values (default-taxonomy view).
# A relation endpoint that is an EXACT (case-insensitive) match to one of these
# is a classification tag, not a real entity, so the relation is rejected. Real
# org names that merely contain a tag word ("Acme Corp") are not tags.
# apply() uses the configured taxonomy's org_tags; this stays for importers.
_ORG_TAGS = orgs.DEFAULT_TAXONOMY.org_tags


# ` from <X>` / ` at <X>` affiliation suffix on a PERSON name. The head group
# is required non-empty (so "from The Lantern Co" is left alone). Surrounding
# spaces and the trailing-word anchor keep "Atherton" / "Bank of Melbourne"
# safe — only the standalone words "from"/"at" trigger.
_AFFILIATION_SUFFIX_RE = re.compile(
    r"^(?P<head>.+?)\s+(?:from|at)\s+\S.*$", re.IGNORECASE)


def strip_affiliation(name: str) -> str:
    """Drop a trailing ` from <X>` / ` at <X>` affiliation from a PERSON name.

    "Priya from The Lantern Co" -> "Priya"; "Tim at TechCorp" -> "Tim". Returns
    the name unchanged when there is no such suffix, when the head would be
    empty, or for ` of `/` with ` (not stripped — org-shaped names use those).
    Only call this on PERSON names; org/project names legitimately carry
    "of"/"at"/"from".
    """
    if not name:
        return name
    stripped = name.strip()
    match = _AFFILIATION_SUFFIX_RE.match(stripped)
    if not match:
        return name
    head = match.group("head").strip()
    return head if head else name


def is_junk_entity(name: str, entity_type: str) -> bool:
    """Reject obviously-bad person/org entities.

    Structural patterns (URL, email, subject prefix, brackets) apply to person
    and org. Numeric patterns (4-digit runs, date fragments) apply to person
    only — org/project names may legitimately carry a year.
    """
    if entity_type not in ("person", "org"):
        return False
    name = name.strip()
    if len(name) < 2 or len(name) > 60:
        return True
    for pattern in _JUNK_PATTERNS:
        if pattern.search(name):
            return True
    if entity_type == "person":
        for pattern in _NUMERIC_JUNK:
            if pattern.search(name):
                return True
    return False


def _today() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


# ---------------------------------------------------------------------------
# Role observations (ported from memory_db.py:895-936, 1100-1143)
# ---------------------------------------------------------------------------

_SOURCE_RANK = {
    "manual": 5,
    "profile_audit": 4,   # audited corrections rank alongside email_signature
    "email_signature": 4,
    "from_header": 3,
    "domain_match": 3,
    "body_mention": 2,
    "enrichment": 2,
    "notion": 2,
    "gdrive": 2,
    "pipeline_snapshot": 1,
    "llm_extraction": 1,
    "session": 1,
}

# Contextual/social roles that are not formal job titles. Rejected at write time.
_JUNK_ROLE_VALUES = {
    "null", "unknown", "", "organiser", "organizer",
    "bbq & serving food", "bbq & serving food team",
    "judge", "scorer", "judges scorer",
    "creator", "pastor's health",
    "volunteer", "helper", "attendee", "participant",
    "worker", "field worker", "cleaners", "cleaner",
    "editor", "auditor", "presenter", "facilitator", "member",
    "guest speaker", "speaker", "panellist", "panelist",
}
# Alias kept for parity with the Nexus name used elsewhere in that module.
_JUNK_ROLES = _JUNK_ROLE_VALUES

# Sources below this rank are blocked from writing a role when an authoritative
# source already covers the entity. Derived from the dict so a rename fails loudly.
_BODY_MENTION_RANK: int = _SOURCE_RANK["body_mention"]


def _source_rank(source) -> int:
    """Source rank, stripping any colon-namespace prefix ("session:abc" -> "session")."""
    if not source:
        return 0
    key = source.split(":", 1)[0]
    return _SOURCE_RANK.get(key, 0)


def fetch_role(store, entity_id: str, *, current_only: bool = True) -> str:
    """Return the most recent non-invalidated 'role' observation, or ''.

    current_only=True (default): also requires valid_to IS NULL, returning only
    observations that are still in effect (used by profile_audit). False: returns
    the most recent observation regardless of valid_to (used by profile_synth).
    Single canonical implementation replacing duplicate _fetch_role helpers in
    profile_synth.py and profile_audit.py (§9C).
    """
    valid_to_clause = "AND (valid_to IS NULL OR valid_to = '')" if current_only else ""
    with store._connect() as db:
        row = db.execute(
            f"""SELECT value FROM entity_observations
               WHERE  entity_id = ?
                 AND  attribute  = 'role'
                 AND  (invalidated_at IS NULL OR invalidated_at = '')
                 AND  COALESCE(derived, 0) = 0
                 {valid_to_clause}
               ORDER  BY valid_from DESC, id DESC
               LIMIT  1""",
            (entity_id,),
        ).fetchone()
    return row["value"] if row else ""


def write_observation(store, entity_id: str, attribute: str, value: str, source: str,
                      valid_from: str, confidence: str, *,
                      source_key: str | None = None, source_class=None) -> None:
    """Write an `attribute` observation with provenance + supersession.

    Generalized from the original role-only `write_role_observation`
    (memory_db.py:1100-1143), repointed at store._connect(). The supersession
    logic — same-source same-attribute re-observation dedup, recency-aware
    valid_to retirement, revival ordering against a newer same-source
    observation — applies to every attribute identically.

    Three guards are semantically specific to job titles (the 'role'
    attribute) and are skipped entirely for any other attribute:
      (a) the 80-char length cap tuned for titles — actually kept
          attribute-agnostic below (a reasonable general data-quality guard,
          with no evidence it's wrong for other attributes);
      (b) the junk-value check against _JUNK_ROLE_VALUES (contextual/social
          words like "volunteer" that aren't real job titles) — role only;
      (c) the source-rank gate (blocks a low-ranked source from writing a
          role when an authoritative role source already exists) — role only.
    A value like an org-move description or a project name should not be
    filtered against a job-title junk-word list or rank-gated the same way.

    source_key / source_class (spec 2026-10-22 §3): observed_count is the
    number of distinct evidence-class sources (observation_sources), SET —
    never +1. A non-evidence source adds no support: an identical current
    observation is left alone, a new one is written derived=1 and retires
    nothing. A digest writes nothing. With no class (profile_audit, legacy
    callers) a re-observation refreshes last_seen only.
    """
    cls_value = _class_value(source_class)
    if not source_key and _is_evidence_class(cls_value):
        cls_value = ""                  # evidence with no key: unknown source
    evidence_write = bool(cls_value) and _is_evidence_class(cls_value)
    derived_write = bool(cls_value) and not evidence_write
    if cls_value == _sc.SourceClass.DIGEST.value:
        return
    if len(value) > 80:
        return
    if attribute == "role" and value.strip().lower() in _JUNK_ROLE_VALUES:
        return

    with store._connect(write=True) as conn:
        if attribute == "role":
            # Skip low-ranked sources when an authoritative observation already exists.
            if _source_rank(source) < _BODY_MENTION_RANK:
                if conn.execute(
                    "SELECT 1 FROM entity_observations "
                    "WHERE entity_id = ? AND attribute = ? AND valid_to IS NULL "
                    "AND COALESCE(derived, 0) = 0 "
                    "AND source IN ('email_signature', 'from_header', 'body_mention')",
                    (entity_id, attribute),
                ).fetchone():
                    return

        # Consolidate identical re-observations ACROSS sources: if this exact
        # (entity, attribute, value) is already current, bump its confirmation
        # count + last_seen instead of inserting another row. This is why an
        # entity no longer ends up with 20 identical 'role' rows — the count on
        # the single row becomes a confidence signal ("confirmed by N sources").
        dup = conn.execute(
            "SELECT id, observed_count, last_seen, valid_from FROM entity_observations "
            "WHERE entity_id = ? AND attribute = ? AND value = ? AND valid_to IS NULL "
            "AND (invalidated_at IS NULL OR invalidated_at = '') ORDER BY id LIMIT 1",
            (entity_id, attribute, value),
        ).fetchone()
        if dup:
            if derived_write:
                return                  # derived content confirms nothing
            cur_last = dup["last_seen"] or dup["valid_from"] or ""
            new_last = valid_from if valid_from > cur_last else cur_last
            conn.execute("UPDATE entity_observations SET last_seen = ? WHERE id = ?",
                         (new_last, dup["id"]))
            if evidence_write:
                record_observation_source(conn, dup["id"], source_key, cls_value)
                _promote_observation(conn, dup["id"])
            return

        existing = conn.execute(
            "SELECT value FROM entity_observations "
            "WHERE entity_id = ? AND attribute = ? AND source = ? AND valid_to IS NULL",
            (entity_id, attribute, source),
        ).fetchone()
        if existing and existing[0] == value:
            return
        if derived_write:
            # Recorded for audit, excluded everywhere; never retires a fact.
            conn.execute(
                "INSERT INTO entity_observations "
                "(entity_id, attribute, value, source, valid_from, confidence_source, "
                " last_seen, derived) VALUES (?, ?, ?, ?, ?, ?, ?, 1)",
                (entity_id, attribute, value, source, valid_from, confidence, valid_from),
            )
            return
        # Recency rule: retire prior same-source observations only if they are
        # older-or-equal (so an older observation arriving late doesn't unseat a
        # newer one). If a NEWER same-source observation is already current, the
        # incoming older one is inserted as historical (valid_to = that newer
        # observation's valid_from).
        conn.execute(
            "UPDATE entity_observations SET valid_to = ? "
            "WHERE entity_id = ? AND attribute = ? AND source = ? "
            "AND valid_to IS NULL AND valid_from <= ?",
            (valid_from, entity_id, attribute, source, valid_from),
        )
        # A derived row is no fact: it never makes this one historical.
        newer = conn.execute(
            "SELECT MIN(valid_from) FROM entity_observations "
            "WHERE entity_id = ? AND attribute = ? AND source = ? "
            "AND valid_to IS NULL AND valid_from > ? AND COALESCE(derived, 0) = 0",
            (entity_id, attribute, source, valid_from),
        ).fetchone()[0]
        oid = conn.execute(
            "INSERT INTO entity_observations "
            "(entity_id, attribute, value, source, valid_from, valid_to, confidence_source, last_seen) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (entity_id, attribute, value, source, valid_from, newer, confidence, valid_from),
        ).lastrowid
        if evidence_write:
            record_observation_source(conn, oid, source_key, cls_value)
            _promote_observation(conn, oid)


def _promote_observation(conn, observation_id) -> None:
    """SET observed_count to the distinct evidence-source count (min 1: the
    row exists because something observed it) and clear derived."""
    conn.execute(
        "UPDATE entity_observations SET observed_count = ?, derived = 0 WHERE id = ?",
        (max(1, observation_support(conn, observation_id)), observation_id))


def write_role_observation(store, entity_id: str, title: str, source: str,
                           valid_from: str, confidence: str, *,
                           source_key: str | None = None, source_class=None) -> None:
    """Write a 'role' observation with provenance + supersession.

    Thin wrapper over write_observation, kept so the two existing call sites
    in apply() (entities loop + write-time-dedup redirect branch) and any
    other callers keep working unchanged.
    """
    write_observation(store, entity_id, "role", title, source, valid_from, confidence,
                      source_key=source_key, source_class=source_class)


def consolidate_observations(store) -> dict:
    """One-shot backfill: collapse pre-existing duplicate observations so stores
    written before write-time consolidation get the same tidy shape.

    For each (entity_id, attribute, value) group of *current* rows (valid_to
    NULL, not invalidated), keep the earliest row, set its observed_count to the
    group size and last_seen to the group's max date, and delete the rest.
    Historical/retired rows are left untouched. Returns counts. Idempotent.

    Independent-source support (spec 2026-10-22 §3): the kept row is the
    earliest NON-derived member when there is one; the deleted members'
    observation_sources rows move onto it first (they would cascade away);
    when the group has any evidence source, observed_count is the kept row's
    distinct evidence-source count rather than the group size."""
    removed = groups = 0
    with store._connect(write=True) as conn:
        rows = conn.execute(
            "SELECT id, entity_id, attribute, value, valid_from, last_seen, "
            "COALESCE(derived, 0) AS derived "
            "FROM entity_observations "
            "WHERE valid_to IS NULL AND (invalidated_at IS NULL OR invalidated_at = '') "
            "ORDER BY entity_id, attribute, value, valid_from, id"
        ).fetchall()
        buckets: dict = {}
        for r in rows:
            buckets.setdefault((r["entity_id"], r["attribute"], r["value"]), []).append(r)
        for members in buckets.values():
            if len(members) < 2:
                continue
            groups += 1
            keep = next((m for m in members if not m["derived"]), members[0])
            last = max((m["last_seen"] or m["valid_from"] or "") for m in members)
            loser_ids = [m["id"] for m in members if m["id"] != keep["id"]]
            for lid in loser_ids:
                conn.execute(
                    "INSERT OR IGNORE INTO observation_sources "
                    "(observation_id, source_key, source_class, first_seen) "
                    "SELECT ?, source_key, source_class, first_seen "
                    "FROM observation_sources WHERE observation_id = ?", (keep["id"], lid))
            support = observation_support(conn, keep["id"])
            conn.execute(
                "UPDATE entity_observations SET observed_count = ?, last_seen = ?, "
                "derived = ? WHERE id = ?",
                (support or (sum(1 for m in members if not m["derived"]) or 1), last,
                 1 if all(m["derived"] for m in members) else 0, keep["id"]),
            )
            conn.executemany(
                "DELETE FROM entity_observations WHERE id = ?",  # admin-delete-ok
                [(i,) for i in loser_ids],
            )
            removed += len(loser_ids)
    return {"groups_consolidated": groups, "rows_removed": removed}


# ---------------------------------------------------------------------------
# Bitemporal relation upsert (ported from bitemporal_writer.py + relation_kinds.py)
# ---------------------------------------------------------------------------

SINGLETON_RELATIONS = frozenset({"reports_to", "works_at"})
ACCUMULATING_RELATIONS = frozenset({
    "manages", "coordinates_with", "mentioned_with", "attended", "involved_in",
    "authored", "instance_of",
})

CONFIDENCE_BUMP = 0.05


def is_singleton_relation(relation: str) -> bool:
    return relation in SINGLETON_RELATIONS


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _find_conflicting_relations(conn, entity_a, relation):
    """All currently-valid rows for (entity_a, relation), regardless of entity_b."""
    return conn.execute(
        "SELECT id, entity_b, valid_from, valid_to, confidence, invalidated_at, "
        "       COALESCE(derived, 0) AS derived "
        "FROM entity_relations "
        "WHERE entity_a = ? AND relation = ? AND invalidated_at IS NULL",
        (entity_a, relation),
    ).fetchall()


def _mark_superseded(conn, relation_id, *, valid_to, invalidated_at, reason,
                     invalidated_by_relation_id):
    conn.execute(
        "UPDATE entity_relations "
        "SET valid_to = ?, invalidated_at = ?, superseded_reason = ?, "
        "    invalidated_by_relation_id = ? "
        "WHERE id = ?",
        (valid_to, invalidated_at, reason, invalidated_by_relation_id, relation_id),
    )


def _bump_observation(conn, relation_id, *, last_seen, confidence_delta):
    """Refresh a re-observed relation's last_seen/confidence.

    strength is NOT touched here any more: it is the count of distinct
    evidence-class sources (relation_strength), SET after a source is
    recorded — never "+1 per sighting", which counted re-extractions of the
    same thread and mcpbrain's own derived notes as independent support."""
    conn.execute(
        "UPDATE entity_relations "
        "SET last_seen = ?, "
        "    confidence = MIN(1.0, MAX(0.0, COALESCE(confidence, 1.0) + ?)) "
        "WHERE id = ?",
        (last_seen, confidence_delta, relation_id),
    )


# ---------------------------------------------------------------------------
# Independent-source support (spec 2026-10-22 §3)
# ---------------------------------------------------------------------------

_EVIDENCE_VALUES = tuple(sorted(c.value for c in _sc.EVIDENCE))
_EVIDENCE_SQL = "(" + ",".join(f"'{v}'" for v in _EVIDENCE_VALUES) + ")"


def _class_value(cls) -> str:
    return str(getattr(cls, "value", cls) or "")


def _is_evidence_class(cls) -> bool:
    return _class_value(cls) in _EVIDENCE_VALUES


def record_relation_source(conn, relation_id, source_key, source_class) -> bool:
    """Record that `source_key` (a logical source: thread / file / note /
    event) supports this relation. INSERT OR IGNORE on (relation_id,
    source_key), so the same source seen again adds nothing. Returns True
    when the row is new."""
    if relation_id is None or not source_key:
        return False
    cur = conn.execute(
        "INSERT OR IGNORE INTO relation_sources "
        "(relation_id, source_key, source_class, first_seen) VALUES (?, ?, ?, ?)",
        (relation_id, str(source_key), _class_value(source_class), _now_iso()))
    return cur.rowcount > 0


def relation_strength(conn, relation_id) -> int:
    """Distinct evidence-class sources supporting a relation. A relation the
    user asserted (brain_graph_correct) counts at least 1 whatever its
    sources."""
    n = conn.execute(
        "SELECT COUNT(*) FROM relation_sources "
        f"WHERE relation_id = ? AND source_class IN {_EVIDENCE_SQL}",
        (relation_id,)).fetchone()[0]
    row = conn.execute(
        "SELECT COALESCE(user_verdict, '') FROM entity_relations WHERE id = ?",
        (relation_id,)).fetchone()
    if row is not None and row[0] == "asserted":
        n = max(n, 1)
    return int(n)


def record_observation_source(conn, observation_id, source_key, source_class) -> bool:
    """observation_sources twin of record_relation_source."""
    if observation_id is None or not source_key:
        return False
    cur = conn.execute(
        "INSERT OR IGNORE INTO observation_sources "
        "(observation_id, source_key, source_class, first_seen) VALUES (?, ?, ?, ?)",
        (observation_id, str(source_key), _class_value(source_class), _now_iso()))
    return cur.rowcount > 0


def observation_support(conn, observation_id) -> int:
    """Distinct evidence-class sources behind an observation (its
    observed_count)."""
    return int(conn.execute(
        "SELECT COUNT(*) FROM observation_sources "
        f"WHERE observation_id = ? AND source_class IN {_EVIDENCE_SQL}",
        (observation_id,)).fetchone()[0])


def decay_relations(store, *, stale_days: int = 365, weak_max: int = 1,
                    as_of: str | None = None) -> dict:
    """Tidy stale, low-signal relations so hub nodes stop being hairballs.

    A relation that is BOTH weak (strength <= weak_max, i.e. seen once or twice)
    AND stale (last_seen older than stale_days) is a one-off co-occurrence that no
    longer earns a graph edge — its strength is zeroed (so graph_canvas, which
    keeps only strength > 0, drops it) and it's marked superseded_reason='decayed'.
    Frequently-seen or recent relations are never touched, however old. Returns a
    count. Reversible from a DB backup; idempotent (zeroed rows won't re-match).

    A relation still supported by at least one evidence-class source
    (relation_sources) is never decayed: strength now counts independent
    primary sources, so most real relations sit at 1 — "weak" no longer means
    "a one-off co-occurrence" for them, only for unsourced (legacy/structural)
    rows. A relation the user asserted (brain_graph_correct) is never
    decayed either — it counts at least 1 by the user's word."""
    from datetime import datetime, timedelta, timezone
    now = datetime.now(timezone.utc) if as_of is None else datetime.fromisoformat(as_of)
    cutoff = (now - timedelta(days=int(stale_days))).strftime("%Y-%m-%d")
    stamp = now.strftime("%Y-%m-%d")
    with store._connect(write=True) as conn:
        cur = conn.execute(
            "UPDATE entity_relations "
            "SET strength = 0, valid_to = COALESCE(valid_to, ?), superseded_reason = 'decayed' "
            "WHERE COALESCE(strength, 1) > 0 AND COALESCE(strength, 1) <= ? "
            "AND COALESCE(last_seen, valid_from, '') <> '' "
            "AND COALESCE(last_seen, valid_from) < ? "
            "AND COALESCE(user_verdict, '') <> 'asserted' "
            "AND NOT EXISTS (SELECT 1 FROM relation_sources rs "
            "                WHERE rs.relation_id = entity_relations.id "
            f"                  AND rs.source_class IN {_EVIDENCE_SQL})",
            (stamp, int(weak_max), cutoff),
        )
        return {"relations_decayed": cur.rowcount}


def _backfill_provenance_if_empty(conn, relation_id, *, source_doc_id, valid_from):
    """Fill source_doc_id/valid_from on an existing relation row ONLY where
    currently empty/unset — never overwrite a real value already present.

    The re-observation branch of upsert_relation (same entity_a/relation/
    entity_b) only ever called _bump_observation, which touches last_seen/
    confidence but not provenance. A row created via a provenance-less path
    (e.g. the legacy _ensure_works_at INSERT OR IGNORE) would then never gain
    source_doc_id/valid_from even when a later, provenance-carrying write for
    the same triple arrives — exactly the gap this closes. COALESCE(col,'')=''
    treats NULL and '' as equally "unset", matching this file's existing
    read-side convention (see _set_org_recency's COALESCE(org,'') checks)
    rather than introducing a NULLIF idiom not used elsewhere in this codebase.
    """
    conn.execute(
        "UPDATE entity_relations "
        "SET source_doc_id = CASE WHEN COALESCE(source_doc_id,'') = '' "
        "                         THEN ? ELSE source_doc_id END, "
        "    valid_from = CASE WHEN COALESCE(valid_from,'') = '' "
        "                      THEN ? ELSE valid_from END "
        "WHERE id = ?",
        (source_doc_id, valid_from, relation_id),
    )


def _increment_degree(conn, entity_a, entity_b):
    """Bump degree on both endpoints. Replaces the Nexus degree triggers, which
    this port does not carry. Only called on a NEW row insert, never on a
    re-observation or supersession."""
    conn.execute(
        "UPDATE entities SET degree = degree + 1 WHERE id IN (?, ?)",
        (entity_a, entity_b),
    )


def _preserve_legacy_strength(conn, relation_id) -> None:
    """Before the FIRST source is recorded on a pre-existing row: a row with
    no relation_sources rows carries a pre-source-counting strength (+1 per
    sighting). Keep it in legacy_strength (first value wins) so the reset to
    the distinct-source count is not data loss — Task 10's backfill and
    the graph view's legacy ordering read it."""
    conn.execute(
        "UPDATE entity_relations SET legacy_strength = COALESCE(legacy_strength, strength) "
        "WHERE id = ? AND COALESCE(strength, 1) > 1 "
        "AND NOT EXISTS (SELECT 1 FROM relation_sources WHERE relation_id = ?)",
        (relation_id, relation_id))


def legacy_relation_sql(alias: str = "", *, has_origin: bool = True) -> str:
    """SQL truth value: this LOCAL relation's strength is NOT a distinct-source
    count — it has no EVIDENCE-class relation_sources row (none at all, or
    only derived-class ones). Such rows never outrank a source-counted one.
    legacy_strength is only the saved prior value, not part of the marker: a
    legacy row that gains a real source is source-counted and its strength is
    honest (ruling I8). An origin='org' row is never legacy (M9): it carries
    no relation_sources by design, and its strength is the curator's
    corroboration count. has_origin=False for a store without the column
    (graph_view reads partial schemas): every row is then local."""
    p = f"{alias}." if alias else "entity_relations."
    local = f"COALESCE({p}origin,'local') = 'local' AND " if has_origin else ""
    return (f"({local}"
            "NOT EXISTS (SELECT 1 FROM relation_sources rs_l "
            f"WHERE rs_l.relation_id = {p}id AND rs_l.source_class IN {_EVIDENCE_SQL}))")


def _promote_to_evidence(conn, relation_id) -> None:
    """After an evidence source was recorded: SET strength to the distinct
    evidence-source count, and turn a derived row (written earlier from a
    non-evidence source, strength 0, degree never counted) into a real one."""
    row = conn.execute(
        "SELECT entity_a, entity_b, COALESCE(derived, 0) AS derived "
        "FROM entity_relations WHERE id = ?", (relation_id,)).fetchone()
    if row is None:
        return
    conn.execute("UPDATE entity_relations SET strength = ?, derived = 0 WHERE id = ?",
                 (relation_strength(conn, relation_id), relation_id))
    if row["derived"]:
        _increment_degree(conn, row["entity_a"], row["entity_b"])


def upsert_relation(store, entity_a, relation, entity_b, *, valid_from,
                    evidence="", confidence=1.0, strength=1,
                    source_doc_id: str | None = None,
                    source_key: str | None = None, source_class=None) -> int:
    """Insert a bi-temporal relation with automatic supersession.

    Ported from bitemporal_writer.upsert_relation_bitemporal, repointed at
    store._connect(). Returns the surviving row id (the new row, or the existing
    row on a re-observation). The Nexus `created_at` column is dropped — the
    mcpbrain entity_relations table has no such column.

    Thin wrapper around upsert_relation_in: opens the write connection and
    delegates. Kept so existing callers (which only ever have a Store, not an
    open connection) don't need to change.
    """
    with store._connect(write=True) as conn:
        return upsert_relation_in(
            conn, entity_a, relation, entity_b, valid_from=valid_from,
            evidence=evidence, confidence=confidence, strength=strength,
            source_doc_id=source_doc_id, source_key=source_key,
            source_class=source_class)


def upsert_relation_in(conn, entity_a, relation, entity_b, *, valid_from,
                       evidence="", confidence=1.0, strength=1,
                       source_doc_id: str | None = None,
                       source_key: str | None = None, source_class=None) -> int:
    """Insert a bi-temporal relation with automatic supersession, on a
    caller-held write connection. This is the body of upsert_relation, split
    out so a caller that already holds a write connection (e.g. a batch
    apply) can drive several relations inside one transaction. Later tasks
    import this name directly.

    The legacy UNIQUE(entity_a,relation,entity_b) does NOT block re-observation:
    a same-target observation bumps the existing row rather than inserting, and
    a same-target observation of a SUPERSEDED row revives that row (the UNIQUE
    spans invalidated rows, so inserting a fresh one is impossible — the
    2026-06-05 drain failures were exactly this). degree is incremented on both
    endpoints only for a NEW row; supersession and revival never touch it.

    A row the user explicitly REJECTED (brain_graph_correct; user_verdict=
    'rejected') is never revived by re-observation: this function returns its
    id unchanged, with no bump, no supersession of rivals, and no field
    touched. A source re-asserting a fact the user has already said is wrong
    must not undo that correction.

    source_doc_id: the originating document id for provenance. Defaults to
    evidence for backward compatibility when not explicitly supplied.

    source_key / source_class: the LOGICAL source of this sighting (spec
    2026-10-22 §3). strength is the count of distinct evidence-class source
    keys, SET from relation_strength after the source is recorded — never
    incremented, so re-extracting the same thread adds nothing and a second,
    independent thread adds one.
      * evidence class: the source is recorded; strength recomputed; a row
        that was derived=1 becomes evidence (derived=0, degree counted).
      * non-evidence class (session/brief/draft/consolidated/duplicate): no
        support row. A missing triple is written derived=1 with strength 0
        (excluded everywhere, never supersedes a rival); an existing one is
        left exactly as it is. A digest writes nothing at all.
      * no class (legacy callers: calendar without a key, curator import,
        brain_graph_correct): a new row takes `strength`; a re-observation
        refreshes last_seen/confidence and leaves strength alone.
    """
    # Self-loops (an entity related to itself) are always noise — drop at the one
    # chokepoint every relation path flows through, regardless of relation type.
    if entity_a == entity_b:
        return None
    if source_doc_id is None:
        source_doc_id = evidence
    if not valid_from:
        raise ValueError("valid_from is required for bi-temporal writes")
    confidence = max(0.0, min(1.0, float(confidence)))
    now = _now_iso()
    cls_value = _class_value(source_class)
    if not source_key and _is_evidence_class(cls_value):
        cls_value = ""                  # evidence with no key: unknown source
    sourced = bool(cls_value)
    evidence_write = sourced and _is_evidence_class(cls_value)
    derived_write = sourced and not evidence_write
    if cls_value == _sc.SourceClass.DIGEST.value:
        return None                     # digests never write relations
    conflicts = _find_conflicting_relations(conn, entity_a, relation)
    same_target = [c for c in conflicts if c["entity_b"] == entity_b]

    if derived_write:
        # Derived content (mcpbrain's own notes, briefs, drafts, duplicates)
        # never strengthens, revives or supersedes anything.
        if same_target:
            return same_target[0]["id"]
        if conn.execute(
                "SELECT 1 FROM entity_relations "
                "WHERE entity_a = ? AND relation = ? AND entity_b = ?",
                (entity_a, relation, entity_b)).fetchone():
            return None
        return conn.execute(
            "INSERT INTO entity_relations "
            "(entity_a, relation, entity_b, valid_from, confidence, evidence, strength, "
            " last_seen, source_doc_id, derived) "
            "VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, 1)",
            (entity_a, relation, entity_b, valid_from, confidence, evidence, now,
             source_doc_id),
        ).lastrowid

    if same_target:
        rid = same_target[0]["id"]
        if evidence_write:
            _preserve_legacy_strength(conn, rid)
            if record_relation_source(conn, rid, source_key, cls_value):
                _bump_observation(conn, rid, last_seen=now,
                                  confidence_delta=CONFIDENCE_BUMP)
            else:
                conn.execute("UPDATE entity_relations SET last_seen = ? WHERE id = ?",
                             (now, rid))
            _promote_to_evidence(conn, rid)
        else:
            _bump_observation(conn, rid, last_seen=now, confidence_delta=CONFIDENCE_BUMP)
        _backfill_provenance_if_empty(
            conn, rid, source_doc_id=source_doc_id, valid_from=valid_from)
        return rid

    # Recency rule for SINGLETON relations (works_at/reports_to): a person has
    # one current value, and the CURRENT one is the newest-dated. Under backfill
    # (arbitrary order) an older fact can arrive after a newer one, so compare
    # valid_from rather than assuming the incoming write is the latest.
    singleton = is_singleton_relation(relation)
    others = [c for c in conflicts if c["entity_b"] != entity_b]
    # A derived rival is no fact to be "older than": only real rows compete
    # for current (a derived one is still retired below when this is current).
    newest_other = max((c for c in others if not c["derived"]),
                       key=lambda c: ((c["valid_from"] or ""), c["id"]),
                       default=None) if singleton else None
    incoming_is_current = (newest_other is None
                           or (valid_from or "") >= (newest_other["valid_from"] or ""))

    # A superseded row for this exact pair blocks INSERT via the legacy UNIQUE.
    # Revive it: the fact is observed again. It becomes current from valid_from
    # UNLESS a newer rival is already current (then it is revived as historical).
    invalidated = conn.execute(
        "SELECT id, COALESCE(user_verdict, '') AS user_verdict FROM entity_relations "
        "WHERE entity_a = ? AND relation = ? AND entity_b = ? "
        "AND invalidated_at IS NOT NULL",
        (entity_a, relation, entity_b),
    ).fetchone()
    if invalidated is not None and invalidated["user_verdict"] == "rejected":
        # The user said this fact is wrong (brain_graph_correct). Re-observing
        # it in a source must not undo that: no revive, no bump, no
        # supersession of rivals.
        return invalidated["id"]
    if invalidated is not None:
        new_id = invalidated["id"]
        _preserve_legacy_strength(conn, new_id)
        conn.execute(
            "UPDATE entity_relations "
            "SET valid_from = ?, valid_to = NULL, invalidated_at = NULL, "
            "    superseded_reason = NULL, invalidated_by_relation_id = NULL, "
            "    confidence = ?, evidence = ?, strength = ?, last_seen = ?, "
            "    source_doc_id = ? "
            "WHERE id = ?",
            (valid_from, confidence, evidence, strength, now, source_doc_id, new_id),
        )
    else:
        new_id = conn.execute(
            "INSERT INTO entity_relations "
            "(entity_a, relation, entity_b, valid_from, confidence, evidence, strength, last_seen, source_doc_id) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (entity_a, relation, entity_b, valid_from, confidence, evidence, strength, now, source_doc_id),
        ).lastrowid
        _increment_degree(conn, entity_a, entity_b)

    if evidence_write:
        record_relation_source(conn, new_id, source_key, cls_value)
        _promote_to_evidence(conn, new_id)

    if singleton and incoming_is_current:
        # Newest fact → it is current; retire the older rivals.
        for c in others:
            _mark_superseded(
                conn, c["id"], valid_to=valid_from, invalidated_at=now,
                reason="superseded_by_newer", invalidated_by_relation_id=new_id,
            )
    elif singleton and not incoming_is_current:
        # An OLDER fact arrived late → record it but keep the newer rival current.
        _mark_superseded(
            conn, new_id, valid_to=newest_other["valid_from"], invalidated_at=now,
            reason="older_than_current", invalidated_by_relation_id=newest_other["id"],
        )
    return new_id


# ---------------------------------------------------------------------------
# Message / sender parsing (ported from enrich_gmail.py:131-142, 396-413)
# ---------------------------------------------------------------------------

SYSTEM_LABELS = {
    "INBOX", "UNREAD", "SENT", "STARRED", "IMPORTANT", "TRASH", "SPAM",
    "CATEGORY_PERSONAL", "CATEGORY_SOCIAL", "CATEGORY_PROMOTIONS",
    "CATEGORY_UPDATES", "CATEGORY_FORUMS",
}

# Relation types the MODEL may emit — the five the enrich prompt documents.
# Mirrors RELATION_TYPES in contract.py (kept identical; test_relation_vocab_in_sync
# guards the pair). `attended` is written only by the deterministic calendar path
# (sync/calendar.py calls upsert_relation directly, bypassing this filter), so it is
# not accepted from the model here. `collaborates_with` was a dead synonym, removed.
VALID_RELATION_TYPES = {
    "works_at", "reports_to", "manages", "coordinates_with", "mentioned_with",
}

# Endpoint-type constraints for the person-centric relations. The LLM over-applies
# these to topics/projects/meetings ("a topic works_at an org"), which is nonsense
# and dilutes the graph — so a relation is dropped when an endpoint's resolved
# entity type isn't allowed. Relations not listed here (mentioned_with, …) accept
# any endpoint type. (source allowed types, target allowed types):
_RELATION_ENDPOINT_TYPES = {
    "works_at":   ({"person"}, {"org"}),
    "reports_to": ({"person"}, {"person"}),
    "manages":    ({"person"}, {"person", "org", "project"}),
}


def _parse_date_iso(date_str: str) -> str:
    """RFC 2822 or ISO date header -> YYYY-MM-DD. '' on failure."""
    if not date_str:
        return ""
    try:
        dt = parsedate_to_datetime(date_str)
        return dt.strftime("%Y-%m-%d")
    except Exception:
        m = re.search(r"(\d{4}-\d{2}-\d{2})", date_str)
        return m.group(1) if m else ""


def _extract_email_addr(header: str) -> str:
    """Bare email from 'Name <email>' or plain 'email'."""
    m = re.search(r"<([^>]+)>", header)
    if m:
        return m.group(1).strip().lower()
    if "@" in header:
        return header.strip().lower().split()[0]
    return ""


# A trailing "(via <service>)" relay marker: Google Drive share notifications
# arrive as '"Dana Okafor (via Google Sheets)" <drive-shares-noreply@google.com>'.
# The person named is the one who shared; the suffix belongs to the relay, and
# left in the name it minted a separate "<name>-via-google-sheets" person that
# then collected the real person's history.
_RELAY_SUFFIX_RE = re.compile(r"\s*\(\s*via\s+[^()]+\)\s*$", re.IGNORECASE)


def _extract_name(header: str) -> str:
    """Display name from 'Name <email>', without a trailing '(via <service>)'."""
    m = re.match(r'^"?([^<"]+)"?\s*<', header)
    if m:
        name = m.group(1).strip().strip('"')
    elif "@" in header and "<" not in header:
        return ""
    else:
        name = header.strip()
    return _RELAY_SUFFIX_RE.sub("", name).strip() or name


def _is_owner(name: str, owner: OwnerIdentity) -> bool:
    """True if the name refers to the install owner.

    Single-word aliases match as whole words ("sam" matches "Sam Chen" and
    "sam.c" but not "Samantha"); multi-word aliases match as substrings.
    Word-level matching matters for short configured names: a plain substring
    test would let an alias like "tom" swallow "Tomlinson".
    """
    low = (name or "").lower()
    if not low:
        return False
    tokens = set(re.split(r"[^a-z0-9]+", low))
    for a in owner.aliases:
        if a == low or (" " not in a and a in tokens) or (" " in a and a in low):
            return True
    return False


# ---------------------------------------------------------------------------
# Action lifecycle helpers (ported from enrich_gmail.py / memory_db.py)
# ---------------------------------------------------------------------------

# Subject prefix patterns that signal an intentional self-task
# (enrich_gmail.py:277).
_SELF_PREFIX_RE = re.compile(
    r"^(TODO|Task|Action|Reminder|Follow\s+up|FU)\s*:\s*", re.IGNORECASE)

# Imperative verbs that signal the install owner owns the action when no
# explicit owner is named (enrich_gmail.py:340-348).
_IMPERATIVE_VERBS = frozenset({
    "email", "send", "review", "update", "check", "prepare", "create", "build",
    "investigate", "follow", "confirm", "complete", "schedule", "coordinate", "write",
    "draft", "call", "contact", "add", "remove", "fix", "test", "deploy", "setup",
    "configure", "run", "submit", "request", "provide", "arrange", "register",
    "migrate", "upload", "document", "implement", "organise", "organize", "present",
    "finalise", "finalize", "publish", "share", "order", "book", "ensure", "meet",
    "discuss", "reply", "respond", "escalate", "approve", "sign", "process",
})

# Deadline phrase patterns scanned in action text then body (enrich_gmail.py:145-172).
_DEADLINE_PATTERNS = [
    r'\bby\s+(next\s+)?(?:Mon(?:day)?|Tue(?:sday)?|Wed(?:nesday)?|Thu(?:rsday)?|Fri(?:day)?|Sat(?:urday)?|Sun(?:day)?)\b',
    r'\bby\s+(?:EOD|COB)\b',
    r'\b(?:EOD|COB)\s+(\w+day|tomorrow|today)\b',
    r'\bby\s+end\s+of\s+(?:the\s+)?(?:week|month|day)\b',
    r'\bend\s+of\s+(?:the\s+)?month\b',
    r'\bEOM\b',
    r'\b(?:this|next)\s+week\b',
    r'\btomorrow\b',
    r'\btoday\b',
    r'\bin\s+\d+\s+(?:days?|weeks?)\b',
    r'\bin\s+(?:a|one|two|three|four|five|six|seven)\s+(?:days?|weeks?)\b',
    r'\bnext\s+(?:Mon(?:day)?|Tue(?:sday)?|Wed(?:nesday)?|Thu(?:rsday)?|Fri(?:day)?|Sat(?:urday)?|Sun(?:day)?)\b',
    r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b',
    r'\b\d{4}-\d{2}-\d{2}\b',
    r'\b(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+\d{1,2}(?:st|nd|rd|th)?\b',
]

# Baseline confidence for an action from a non-self email with a confirmed
# owner, before owner/deadline inference can lower it. Sits between the
# self-email confidences (1.0/0.85) and the inferred-owner ones (0.6/0.5).
_CONFIRMED_EMAIL_ACTION_CONFIDENCE = 0.7

# Within-batch dedup tokenisation (enrich_gmail.py:1339-1348).
_ACTION_STOP = {"the", "a", "an", "and", "or", "to", "of", "for", "with",
                "on", "in", "at", "by"}
_ACTION_PUNCT = re.compile(r"[^\w\s]")

# Near-duplicate fingerprint normalisation (_DEDUP_* constants,
# _normalise_title_for_dedup, _compute_fingerprint) now lives in chunking.py as
# the single source of truth, imported above.


def _norm_action(t: str) -> str:
    """Lowercase, strip punctuation, drop short stopwords (enrich_gmail.py:1342)."""
    s = _ACTION_PUNCT.sub(" ", t.lower())
    return " ".join(w for w in s.split() if w and w not in _ACTION_STOP)


def _infer_owner(is_sender_owner: bool, action_text: str,
                 owner: OwnerIdentity) -> tuple[str, str, float]:
    """Infer the action owner when the LLM returned empty/unclear.

    Ported from enrich_gmail.py:351-366. Returns (owner_name, owner_eid,
    confidence); ('', '', 0.0) when no owner can be assigned.
    """
    if is_sender_owner:
        return (owner.name, owner.entity_id, 0.8)
    text = (action_text or "").strip()
    first_word = text.split()[0].lower().rstrip(".,:") if text else ""
    if first_word in _IMPERATIVE_VERBS:
        return (owner.name, owner.entity_id, 0.6)
    return ("", "", 0.0)


def _infer_deadline(action_text: str, email_body: str, email_date_iso: str) -> str:
    """Parse a deadline from action text or body when the LLM found none.

    Ported from enrich_gmail.py:175-273. Returns an ISO date (YYYY-MM-DD) or ''.
    """
    try:
        import calendar
        from datetime import datetime as _dt, timedelta as _td

        import dateparser

        base_date = None
        if email_date_iso:
            try:
                base_date = _dt.strptime(email_date_iso, "%Y-%m-%d")
            except ValueError:
                pass

        settings = {
            "PREFER_DATES_FROM": "future",
            "DATE_ORDER": "DMY",
            "RETURN_AS_TIMEZONE_AWARE": False,
        }
        if base_date:
            settings["RELATIVE_BASE"] = base_date

        def _try_parse(phrase: str) -> str:
            p = phrase.strip().lower()
            ref = base_date or _dt.today()

            m_iso = re.match(r"(\d{4})-(\d{2})-(\d{2})$", phrase.strip())
            if m_iso:
                try:
                    return _dt(int(m_iso.group(1)), int(m_iso.group(2)),
                              int(m_iso.group(3))).strftime("%Y-%m-%d")
                except ValueError:
                    pass

            m_dmy = re.match(r"(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})$", phrase.strip())
            if m_dmy:
                try:
                    d, mo, y = int(m_dmy.group(1)), int(m_dmy.group(2)), int(m_dmy.group(3))
                    if y < 100:
                        y += 2000
                    return _dt(y, mo, d).strftime("%Y-%m-%d")
                except ValueError:
                    pass

            if p in ("eom", "end of month", "end of the month",
                     "by end of month", "by end of the month"):
                last_day = calendar.monthrange(ref.year, ref.month)[1]
                return _dt(ref.year, ref.month, last_day).strftime("%Y-%m-%d")

            if p in ("eod", "by eod", "cob", "by cob"):
                return ref.strftime("%Y-%m-%d")

            weekdays = {"monday": 0, "tuesday": 1, "wednesday": 2, "thursday": 3,
                        "friday": 4, "saturday": 5, "sunday": 6}
            m_next = re.match(r"(?:by\s+)?next\s+(\w+)", p)
            if m_next:
                day_name = m_next.group(1).rstrip(".")
                if day_name in weekdays:
                    target_dow = weekdays[day_name]
                    days_ahead = (target_dow - ref.weekday() + 7) % 7
                    if days_ahead == 0:
                        days_ahead = 7
                    return (ref + _td(days=days_ahead)).strftime("%Y-%m-%d")

            m_by = re.match(r"by\s+(\w+day)", p)
            if m_by:
                day_name = m_by.group(1).lower()
                full = {"monday": "monday", "tuesday": "tuesday", "wednesday": "wednesday",
                        "thursday": "thursday", "friday": "friday", "saturday": "saturday",
                        "sunday": "sunday", "mon": "monday", "tue": "tuesday",
                        "wed": "wednesday", "thu": "thursday", "fri": "friday",
                        "sat": "saturday", "sun": "sunday"}
                if day_name in full:
                    phrase = full[day_name]

            parsed = dateparser.parse(phrase, settings=settings)
            return parsed.strftime("%Y-%m-%d") if parsed else ""

        for source in (action_text, (email_body or "")[:2000]):
            if not source:
                continue
            for pat in _DEADLINE_PATTERNS:
                m = re.search(pat, source, re.IGNORECASE)
                if m:
                    result = _try_parse(m.group(0))
                    if result:
                        return result
    except Exception:
        pass
    return ""


def _token_jaccard(a: str, b: str) -> float:
    sa, sb = set(a.split()), set(b.split())
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


def _is_self_message(msg: dict, identity: str) -> bool:
    """Phase 1 self-email test: explicit is_self flag, else sender == identity.

    Nexus is_self_email (enrich_gmail.py:369-393) checks sender AND every TO/CC
    recipient against the owner's address list. Phase 1 fixtures carry an explicit
    `is_self` per message, or omit recipients; with no recipient headers we fall
    back to a sender-address match against `identity` (the no-recipient branch of
    is_self_email, which treats a subject-only self-task as self).
    """
    if "is_self" in msg:
        return bool(msg["is_self"])
    sender_addr = _extract_email_addr(msg.get("sender", ""))
    if not sender_addr or sender_addr.lower() != identity.lower():
        return False
    recipient_addrs = []
    for header in (msg.get("to", "") or "", msg.get("cc", "") or ""):
        for part in header.split(","):
            addr = _extract_email_addr(part.strip())
            if addr:
                recipient_addrs.append(addr.lower())
    if not recipient_addrs:
        return True
    return all(a == identity.lower() for a in recipient_addrs)


# Cosine floor for "same action, different words" (bge-small, normalised
# vectors). Global constraint of the 2026-10-22 ingestion-integrity spec §2.
ACTION_SIM_THRESHOLD = 0.88

# Candidate caps per near-duplicate check: the same source (thread / base note
# / file / event) is compared up to this many rows at any age...
_ACTION_SIM_SOURCE_CANDIDATES = 300
# ...and the same-owner 30-day window (other sources) up to this many.
_ACTION_SIM_WINDOW_CANDIDATES = 100

# Owner strings that name no person: the model sometimes credits itself. They
# are written as "unclear", like an owner nobody named, so they stay out of the
# owner's own list (dashboard filters owner IS NULL / '' / owner name).
_NON_PERSON_OWNERS = frozenset({"claude", "claude code", "assistant",
                                "the assistant", "unclear"})
_UNCLEAR_OWNER = "unclear"


def _unit(vec) -> list[float]:
    """L2-normalise a vector (cosine = dot product of unit vectors)."""
    v = [float(x) for x in vec]
    n = sum(x * x for x in v) ** 0.5
    return [x / n for x in v] if n else v


def _embed_texts(embedder, texts, cache) -> bool:
    """Put a unit vector for every text in `texts` into `cache`, embedding only
    the ones not already there (one embed_passages call). Returns False -- and
    caches nothing new -- when the embedder raises or returns the wrong number
    of vectors, so the caller can fall back to the lexical rules. `cache` maps
    text -> unit vector; drain shares one across a whole run."""
    missing = [t for t in dict.fromkeys(texts) if t not in cache]
    if not missing:
        return True
    try:
        vecs = list(embedder.embed_passages(missing))
    except Exception as exc:  # noqa: BLE001 -- dedupe must never abort apply
        log.warning("action dedupe: embedder failed (%s); using lexical "
                    "matching for the rest of this apply", exc)
        return False
    if len(vecs) != len(missing):
        log.warning("action dedupe: embedder returned %d vectors for %d texts; "
                    "using lexical matching for the rest of this apply",
                    len(vecs), len(missing))
        return False
    for t, v in zip(missing, vecs):
        cache[t] = _unit(v)
    return True


def _owner_blank(owner) -> bool:
    return (owner or "").strip().lower() in ("", _UNCLEAR_OWNER)


def _find_near_duplicate_action(conn, text, owner, *, thread_id="", embedder=None,
                                window_days=30, threshold=0.85, today=None,
                                cache=None, status=None,
                                owner_class=None) -> int | None:
    """Return the id of an existing OPEN email action that means the same as
    (text, owner), or None.

    Candidates are open `source='email'` rows whose owner is compatible -- the
    same owner, or either side blank/"unclear" (two named owners never merge) --
    from the SAME logical source (`thread_id`: a Gmail thread, base note id,
    file id or `cal-` event id) at any age, capped at
    _ACTION_SIM_SOURCE_CANDIDATES, plus rows of other sources in the last
    `window_days`, capped at _ACTION_SIM_WINDOW_CANDIDATES. The caller opens
    `conn` per action, so the check runs against the live open list.

    Fast path (no embedding): text_fingerprint or normalised-title equality.
    Slow path: with an `embedder`, cosine >= ACTION_SIM_THRESHOLD between
    unit-normalised embeddings, best candidate wins (vectors kept in `cache`).
    If the embedder fails, `status["embed_failed"]` is set and this check uses
    the lexical rules; so does a call with no embedder (back-compat): token
    subset (length-gated), Jaccard >= threshold, SequenceMatcher >= 0.82.

    `today` (ISO YYYY-MM-DD) is the window baseline; apply() passes its injected
    clock so the cutoff and the rows' created_at come from the same clock.

    `owner_class` (an OwnerClass): when `owner` is the install owner, every row
    whose owner is in the same class -- any name the class carries, or an owner
    id in it -- is the same owner, so a row stored under a variant spelling is
    still a candidate.
    """
    import difflib

    norm = _normalise_title_for_dedup(text)
    if not norm:
        return None

    from datetime import date as _date, timedelta as _timedelta
    baseline = (today or _today())[:10]
    cutoff = (_date.fromisoformat(baseline) - _timedelta(days=window_days)).isoformat()

    # Owner compatibility: equal, or either side blank / "unclear".
    if _owner_blank(owner):
        owner_sql, owner_params = "1=1", []
    elif owner_class is not None and owner_class.is_owner(owner):
        names = sorted(owner_class.names | {owner.strip().lower()})
        ids = sorted(owner_class.ids)
        # A class name counts unless the row's id resolved to another person
        # (ruling I19); an owner id always counts.
        name_sql = (f"(lower(trim(owner)) IN ({','.join('?' * len(names))}) "
                    "AND (COALESCE(owner_entity_id,'') = '' OR owner_entity_id NOT IN "
                    "(SELECT id FROM entities WHERE type='person')))")
        owner_sql = (f"({name_sql} "
                     + (f"OR owner_entity_id IN ({','.join('?' * len(ids))}) "
                        if ids else "")
                     + "OR owner = '' OR owner IS NULL OR owner = ?)")
        owner_params = [*names, *ids, _UNCLEAR_OWNER]
    else:
        owner_sql = "(owner = ? OR owner = '' OR owner IS NULL OR owner = ?)"
        owner_params = [owner, _UNCLEAR_OWNER]
    base = f"status='open' AND source='email' AND {owner_sql}"

    fp = _compute_fingerprint(text)
    if fp:
        if thread_id:
            fp_scope = "(thread_id = ? OR substr(created_at,1,10) >= ?)"
            fp_params = [thread_id, cutoff]
        else:
            fp_scope, fp_params = "substr(created_at,1,10) >= ?", [cutoff]
        fp_row = conn.execute(
            f"SELECT id FROM actions WHERE {base} AND text_fingerprint=? "
            f"AND {fp_scope} LIMIT 1",
            [*owner_params, fp, *fp_params],
        ).fetchone()
        if fp_row:
            return fp_row[0]

    rows: list = []
    if thread_id:
        rows += conn.execute(
            f"SELECT id, text FROM actions WHERE {base} AND thread_id = ? "
            "ORDER BY id DESC LIMIT ?",
            [*owner_params, thread_id, _ACTION_SIM_SOURCE_CANDIDATES]).fetchall()
    other_src, other_params = ("AND (thread_id IS NULL OR thread_id != ?) ",
                               [thread_id]) if thread_id else ("", [])
    rows += conn.execute(
        f"SELECT id, text FROM actions WHERE {base} "
        f"AND substr(created_at,1,10) >= ? {other_src}"
        "ORDER BY id DESC LIMIT ?",
        [*owner_params, cutoff, *other_params,
         _ACTION_SIM_WINDOW_CANDIDATES]).fetchall()

    cands = []
    for row_id, row_text in rows:
        cand = _normalise_title_for_dedup(row_text or "")
        if not cand:
            continue
        if cand == norm:
            return row_id
        cands.append((row_id, row_text, cand))
    if not cands:
        return None

    if embedder is not None:
        cache = {} if cache is None else cache
        if _embed_texts(embedder, [text] + [c[1] for c in cands], cache):
            q = cache[text]
            best_id, best = None, ACTION_SIM_THRESHOLD
            for row_id, row_text, _cand in cands:
                sim = sum(a * b for a, b in zip(q, cache[row_text]))
                if sim >= best:
                    best_id, best = row_id, sim
            return best_id
        if status is not None:
            status["embed_failed"] = True

    for row_id, _row_text, cand in cands:
        len_a, len_b = len(norm), len(cand)
        length_ratio = min(len_a, len_b) / max(len_a, len_b) if max(len_a, len_b) else 0.0
        if length_ratio < 0.6:
            continue
        ta, tb = set(norm.split()), set(cand.split())
        if ta and tb and (ta <= tb or tb <= ta):
            return row_id
        if _token_jaccard(norm, cand) >= threshold:
            return row_id
        if difflib.SequenceMatcher(None, norm, cand).ratio() >= 0.82:
            return row_id
    return None


# ---------------------------------------------------------------------------
# apply() — structural write pass (ported from enrich_gmail.py:1043-1600)
# ---------------------------------------------------------------------------

def extraction_sources(store, doc_ids, *, thread_id="", home=None,
                       rules=None) -> tuple[str, str]:
    """(source_key, source_class value) for one extraction's chunks.

    An extraction is one thread (thread_enrich groups by logical source), so
    every evidence chunk of it shares one source_key; the first evidence
    chunk's key/class is returned — a NON-duplicate one first. A duplicate
    (chunks.dup_of) carries its CANONICAL chunk's key and class (followed
    once), used only when every evidence chunk is a duplicate — it adds no
    support the canonical did not already give. With no evidence chunk the first chunk's
    derived class is returned (session/brief/draft/consolidated/digest/
    duplicate-of-nothing). A doc id with no chunk row is classified from the
    id alone (``enriched-`` → digest, ``note-consolidated-`` → consolidated)
    and keyed on the thread id. No doc ids at all → ("", ""): unknown, the
    legacy path (no support row, no strength change).
    """
    ids = [d for d in dict.fromkeys(doc_ids or []) if d]
    if not ids:
        return "", ""
    if rules is None:
        try:
            rules = _sc.Rules.from_config(
                home if home is not None else str(config.app_dir()),
                generated_label_ids=_sc.cached_generated_label_ids(store))
        except Exception:  # noqa: BLE001 — classification must never block apply
            rules = _sc.Rules()
    import json as _json

    def _rows(q_ids):
        out = {}
        with store._connect() as db:
            for i in range(0, len(q_ids), 500):
                batch = q_ids[i:i + 500]
                qs = ",".join("?" * len(batch))
                for r in db.execute(
                        "SELECT doc_id, metadata, dup_of FROM chunks "
                        f"WHERE doc_id IN ({qs})", batch):
                    try:
                        meta = _json.loads(r["metadata"] or "{}") or {}
                    except (ValueError, TypeError):
                        meta = {}
                    out[r["doc_id"]] = (meta, r["dup_of"] or "")
        return out

    rows = _rows(ids)
    canon_ids = [dup for (_m, dup) in rows.values() if dup and dup not in rows]
    canon = _rows(canon_ids) if canon_ids else {}
    canon.update(rows)

    # An extraction's OWN evidence wins: a non-duplicate evidence chunk keys
    # it on its own source. Only when every evidence chunk is a duplicate is
    # the canonical's key borrowed (it then adds nothing the canonical did not
    # already give). Crediting a mixed extraction to the canonical's source
    # would misattribute this thread's own claims.
    first_dup_evidence = None
    first_derived = None
    for d in ids:
        is_dup = False
        if d in rows:
            meta, dup = rows[d]
            if dup:
                is_dup = True
                if dup not in canon:
                    cls = _sc.SourceClass.DUPLICATE
                    key = _sc.source_key(d, meta)
                else:
                    cmeta, _ = canon[dup]
                    cls = _sc.classify(dup, cmeta, rules)
                    key = _sc.source_key(dup, cmeta)
            else:
                cls = _sc.classify(d, meta, rules)
                key = _sc.source_key(d, meta)
        else:
            cls = _sc.classify(d, {}, rules)
            key = thread_id or d
        if _sc.is_evidence(cls):
            if not is_dup:
                return key, cls.value
            if first_dup_evidence is None:
                first_dup_evidence = (key, cls.value)
        elif first_derived is None:
            first_derived = (key, cls.value)
    return first_dup_evidence or first_derived


def apply(store, extraction, *, doc_ids, identity=None,
          clock=None, embedder=None, owner=None, home=None, entity_index=None,
          embed_cache=None) -> dict:
    """Write one thread's extraction to the graph (structural pass).

    Adapts the Nexus write_to_graph_v2 sequence to mcpbrain: derives the thread
    lead from messages[] (earliest by date), writes the email_context row,
    upserts entities (excluding the install owner), links them to the lead
    message, writes
    role observations, links topics, and writes resolved relations. The action
    LIFECYCLE (owner/deadline inference, age/notification gates, resolve/update)
    is Task 3 — actions are not written here.

    doc_ids: the thread's chunk doc_ids supplied by drain. The first entry
    (``doc_ids[0]``) is stamped as ``source_doc_id`` on every relation written
    here, giving graph edges concrete provenance back to the indexed document.
    Falls back to ``enriched-{thread_id}`` for threads that have no concrete
    lead doc. Still the forward seam for Task 3 (action provenance) and Task 5
    (semantic doc linkage) — leave it required so callers wire it through.

    clock: optional callable returning a `datetime` (the current "now", UTC),
    for deterministic time in tests. Defaults to datetime.now(timezone.utc). It
    drives both the relation valid_from fallback (formatted to YYYY-MM-DD) and
    the action age gate's 60-day boundary.

    embedder: optional embedder (.dim / .embed_passages / .embed_query). The
    semantic layer (Task 5) always writes a synthesised vector doc keyed
    `enriched-{thread_id}` via store.upsert_chunk (embedded=0). When an embedder
    is passed, the doc is embedded inline so it is searchable immediately; when
    None, the doc is left unembedded for the daemon's next index_pending pass.
    The embedder also lets action dedupe match by meaning (drain forwards the
    daemon's embedder).

    embed_cache: optional dict (text -> unit vector) for action dedupe; drain
    shares one across a run so open actions are embedded once per run. None
    means a fresh per-call cache.

    identity: the synced Gmail address, for self-email detection. None
    resolves config.owner_email (which defaults to the historical address).

    owner: optional OwnerIdentity naming the install owner for action
    attribution and self-exclusion. Defaults to owner_identity_from_config()
    (config.json under MCPBRAIN_HOME). Returns an empty identity when the
    install is not yet configured.

    Returns a small summary dict (counts) for the caller / Task 3. When a thread
    lead exists, a `semantic_doc` key carries the enriched doc_id.
    """
    if identity is None:
        identity = config.owner_email(str(config.app_dir()))
    if owner is None:
        owner = owner_identity_from_config()
    now = (clock() if clock else datetime.now(timezone.utc))
    today = now.strftime("%Y-%m-%d")

    # Resolved once and reused everywhere below instead of recomputing this
    # same expression per flag lookup.
    _home = str(home) if home is not None else str(config.app_dir())
    # MUST pass _home explicitly: taxonomy_from_config() with no argument
    # always resolves config.app_dir() regardless of the caller's `home`, so a
    # bare call here silently ignored a caller-supplied home and read whatever
    # taxonomy was cached (or the REAL machine's config.json) instead of this
    # call's own org config -- invisible in production (home always equals
    # app_dir() there) but broke any test/caller that passes a different home.
    taxonomy = orgs.taxonomy_from_config(_home)

    # Org default: the model's own org signal always wins when present. Only
    # when it's empty or the model's own "unknown" sentinel — and the
    # kill-switch resolves True — fall back to org_hint, the deterministic
    # sender-domain guess prepare._thread_block attaches to every thread's
    # payload. org_hint is a fallback only; it never overrides a real model
    # answer, even one that disagrees with it.
    raw_org = (extraction.get("org", "unknown") or "unknown")
    if raw_org in ("", "unknown"):
        if config.enrich_org_default_enabled(_home):
            raw_org = extraction.get("org_hint") or raw_org
    org = canonical_org(raw_org, taxonomy)
    content_type = extraction.get("content_type", "") or ""
    summary = extraction.get("summary", "") or ""
    contextual_summary = extraction.get("contextual_summary", "") or ""
    topics_list = extraction.get("topics", []) or []
    if config.topic_consolidation_enabled(_home):
        topics_list = [topics.normalize_topic(t, _home) for t in topics_list]
        topics_list = list(dict.fromkeys(t for t in topics_list if t))
    topics_str = ", ".join(topics_list)
    entities_list = extraction.get("entities", []) or []
    messages = extraction.get("messages", []) or []
    thread_id = extraction.get("thread_id", "") or ""

    # Provenance: the originating doc for every fact this extraction yields.
    # doc_ids is the thread's chunk doc_ids (drain passes them); fall back to the
    # synthetic enriched-thread id when a thread has no concrete lead doc.
    prov_doc_id = (doc_ids[0] if doc_ids else "") or (f"enriched-{thread_id}" if thread_id else "")

    # Independent-source support (spec 2026-10-22 §3): which LOGICAL source
    # (thread / file / note / event) this extraction is, and whether it is
    # evidence. Evidence adds a support row (strength / observed_count are SET
    # to the distinct-source count); a derived source (digest included)
    # writes nothing at all (ruling I14, below).
    _src_key, _src_cls = extraction_sources(store, doc_ids, thread_id=thread_id,
                                            home=_home)
    _derived = bool(_src_cls) and not _is_evidence_class(_src_cls)
    _digest = _src_cls == _sc.SourceClass.DIGEST.value
    _src_kw = {"source_key": _src_key, "source_class": _src_cls}
    if _derived:
        # Derived sources are never evidence (spec principle 2, ruling I14):
        # no action, entity, link, relation, observation, topic, occurrence,
        # context row or digest. Upstream gates (prepare's derived gate,
        # drain's drop_cold) normally keep such chunks away from here, but a
        # unit built before an upgrade, or any other caller, still reaches
        # apply — so the rule is enforced HERE, not by convention.
        log.info("apply: skipped thread %s: source class %s is not evidence",
                 thread_id, _src_cls)
        return {"entities": 0, "relations": 0, "topics": 0, "email_context": 0,
                "skipped": _src_cls}

    # Thread lead = earliest message by date. Falls back to first listed.
    lead = None
    if messages:
        from mcpbrain.thread_enrich import message_time
        lead = min(messages, key=message_time)
    if lead is None:
        # No provenance — nothing structural to anchor on.
        return {"entities": 0, "relations": 0, "topics": 0, "email_context": 0}

    lead_msg_id = lead.get("message_id", "") or ""
    lead_date_iso = _parse_date_iso(lead.get("date", ""))
    sender_header = lead.get("sender", "") or ""
    sender_email = _extract_email_addr(sender_header)
    sender_name = strip_affiliation(_extract_name(sender_header))

    # Deterministic personal-content backstop: the model can emit "personal"
    # directly (a reserved tag, see orgs.RESERVED_TAGS), but when it instead
    # comes back "unknown" -- the same value a genuine extraction failure
    # gets -- check the thread's own text for a personal-life signal before
    # accepting "unknown". Distinguishes "never going to have a church org"
    # from "the model couldn't classify this", which used to be
    # indistinguishable in the data. Not silent: logged like any other
    # automatic reclassification.
    if org == "unknown" and orgs.signals_personal(
            " ".join([summary, contextual_summary, lead.get("subject", ""),
                      lead.get("body", "")])):
        store.record_change(
            "org_reclassified", ref_id=thread_id,
            summary=f"thread {thread_id}: org unknown -> personal "
                    "(deterministic keyword backstop)",
            source="personal_org_classifier")
        org = "personal"

    # Sender org precedence:
    #   known org by domain        -> use it;
    #   org_from_email == "external" -> external (a definite "not ours" verdict;
    #                                   do NOT inherit the thread org);
    #   no email signal ("") + known thread org -> thread org;
    #   else                        -> external.
    sender_domain_org = org_from_email(sender_email, taxonomy) if sender_email else ""
    if sender_domain_org and sender_domain_org != "external":
        sender_org = sender_domain_org
    elif sender_domain_org == "external":
        sender_org = "external"
    elif org in taxonomy.names:
        sender_org = org
    else:
        sender_org = "external"

    # Labels: strip Gmail system labels, keep custom ones.
    raw_labels = lead.get("labels", "") or ""
    custom_labels = [
        lbl.strip() for lbl in raw_labels.split(",")
        if lbl.strip() and lbl.strip() not in SYSTEM_LABELS
    ]
    labels_str = ", ".join(custom_labels)

    # Sender entity (skip the owner — self-mail anchors nothing in the graph).
    # Guard against empty identity: "" is a substring of every email address,
    # so the exclusion check must only fire when identity is actually set.
    sender_id = ""
    if sender_name and sender_email and not _is_owner(sender_name, owner) \
            and (not identity or identity.lower() not in sender_email.lower()):
        # Do not key a person on a shared/role inbox (office@/info@): distinct people
        # send from it and email-equality dedup would collapse them (C1).
        _sender_email = "" if is_role_address(sender_email) else sender_email
        sender_id = upsert_entity(
            store, derived=_derived, name=sender_name, entity_type="person", org=sender_org,
            email_addr=_sender_email, taxonomy=taxonomy, valid_from=lead_date_iso) or ""

    # email_context row for the lead message.
    store.upsert_email_context(
        lead_msg_id, subject=lead.get("subject", ""), sender=sender_header,
        sender_email=sender_email, sender_id=sender_id,
        date_str=lead.get("date", ""), date_iso=lead_date_iso,
        thread_id=thread_id, org=org, content_type=content_type,
        summary=summary, topics=topics_str, labels=labels_str,
        contextual_summary=contextual_summary,
        reply_needed=extraction.get("reply_needed", False),
        reply_reason=extraction.get("reply_reason", "") or "")

    linked: set = set()
    name_to_id: dict = {}

    def _link(entity_id, role):
        """Link entity_id to the lead message; count it (email_count and
        mentions) only for a NEW primary-source link row."""
        if _digest:
            return False
        new = store.link_email_entity(lead_msg_id, entity_id, role=role,
                                      derived=_derived)
        if new and not _derived:
            _bump_email_count(store, entity_id)
        return new

    # Link + role for the sender. email_count is driven off the link insert so
    # it counts distinct messages, not apply invocations (idempotent on re-run).
    if sender_id:
        _link(sender_id, "sender")
        linked.add(sender_id)
        if sender_name:
            name_to_id[sender_name] = sender_id

    entities_created = 0

    # Header email lookup: every message's sender header (system-attached by
    # drain, Phase 2), not just the lead's. Lets a non-lead sender who also
    # appears in entities[] (e.g. someone who replied later in the thread) get
    # email_addr too — the lead-only sender_id upsert above only covers message
    # 1. First writer wins on a name collision (don't overwrite).
    header_email_by_name: dict = {}
    for msg in messages:
        msg_header = msg.get("sender", "") or ""
        if not msg_header:
            continue
        msg_email = _extract_email_addr(msg_header)
        if not msg_email:
            continue
        msg_name_key = strip_affiliation(_extract_name(msg_header)).strip().lower()
        # Never map a person to a shared/role inbox (office@/info@): it would email-key
        # them and later collapse distinct senders (C1). Skip; they get no header email.
        if msg_name_key and msg_name_key not in header_email_by_name and not is_role_address(msg_email):
            header_email_by_name[msg_name_key] = msg_email

    # Write-time dedup index. Prefer a caller-supplied index (drain builds ONE per
    # run and reuses it — avoids rebuilding the 25k-entity index on every apply);
    # fall back to building it here for direct callers. Near-duplicates redirect to
    # the existing entity rather than fragmenting the graph.
    _dedup_enabled = config.write_time_dedup_enabled(_home)
    _meeting_series = config.meeting_series_enabled(_home)
    _entity_index = entity_index
    if _dedup_enabled and _entity_index is None:
        try:
            _entity_index = build_entity_index(store.entities_for_resolution())
        except Exception:
            log.warning("write_time_dedup: failed to build entity index; skipping dedup this apply()")
            _dedup_enabled = False

    # ── 1. Entities ────────────────────────────────────────────────────────
    for ent in entities_list:
        ename = (ent.get("name") or "").strip()
        etype = (ent.get("type") or "person").strip()
        eorg = (ent.get("org") or "").strip()
        erole = (ent.get("role") or "").strip()

        if etype == "person":
            ename = strip_affiliation(ename)

        if not ename or _is_owner(ename, owner):
            continue
        if etype == "person" and is_junk_entity(ename, "person"):
            continue

        # ── Meeting/event series (Task 5) ─────────────────────────────────
        # A meeting/event is not a name-identity entity; each mention names it
        # differently ('College Meeting 12 May'). Key it on an org-scoped SERIES
        # id and record this mention as an append-only occurrence, so variants
        # converge on one node instead of fragmenting. 'event' folds into the
        # same scheme (stored as type 'meeting').
        if etype in ("meeting", "event") and _meeting_series:
            series = (ent.get("series_name") or ename).strip()
            if not series:
                continue
            m_org = canonical_org(eorg or org, taxonomy)
            eid = _meeting_series_id(series, m_org)
            store.upsert_entity(eid, series, "meeting", m_org, lead_date_iso,
                                bump_mentions=False)
            name_to_id[ename] = eid
            if eid not in linked:
                _link(eid, "about")
                linked.add(eid)
                entities_created += 1
            occ_date = _parse_date_iso(ent.get("occurrence_date") or "") or lead_date_iso or today
            occ_value = (ent.get("source_span") or summary or "")[:200]
            store.append_occurrence(eid, occ_date, occ_value, lead_msg_id or prov_doc_id)
            continue

        # Any message's header email whose sender name matches this entity
        # (e.g. someone who replied later in the thread), not just the lead's.
        eemail = ""
        if etype == "person":
            eemail = header_email_by_name.get(ename.strip().lower(), "")

        # Q3 write-time dedup: redirect near-duplicates to the existing entity.
        if _dedup_enabled:
            existing_id = write_time_dedup_check(ename, etype, _entity_index)
            if existing_id:
                log.debug("write_time_dedup: %r → %s (existing)", ename, existing_id)
                entity_id = existing_id
                name_to_id[ename] = entity_id
                # Merge: if this mention carries a real org and the existing entity
                # has none, fill it (a redirect shouldn't lose new attribution).
                if eorg and eorg not in orgs.RESERVED_TAGS:
                    try:
                        store.update_entity_org_if_empty(entity_id, eorg)
                    except Exception:  # noqa: BLE001
                        pass
                # Same for email: a redirect shouldn't lose a header-sourced
                # address either — otherwise this fix becomes dead code once
                # write_time_dedup defaults on (Task 5.3).
                if eemail:
                    try:
                        store.update_entity_email_if_empty(entity_id, eemail)
                    except Exception:  # noqa: BLE001
                        pass
                if entity_id not in linked:
                    _link(entity_id, "mentioned")
                    linked.add(entity_id)
                if erole and etype == "person":
                    write_role_observation(store, entity_id, erole, "llm_extraction",
                                           lead_date_iso or "2026-01-01", "medium",
                                           **_src_kw)
                continue

        entity_id = upsert_entity(store, derived=_derived, name=ename, entity_type=etype, org=eorg,
                                  email_addr=eemail, taxonomy=taxonomy, valid_from=lead_date_iso)
        if not entity_id:
            continue
        # Keep the index current so a later entity in THIS batch dedups against
        # the one just created (not just against the store snapshot).
        if _dedup_enabled and _entity_index is not None:
            add_to_index(_entity_index, entity_id, ename, etype)

        name_to_id[ename] = entity_id

        if entity_id not in linked:
            _link(entity_id, "mentioned")
            linked.add(entity_id)
            entities_created += 1

        if erole and etype == "person":
            write_role_observation(store, entity_id, erole, "llm_extraction",
                                   lead_date_iso or "2026-01-01", "medium",
                                   **_src_kw)

    # ── 1.5 Rich observations: dated, attributable facts (Task 4.2) ────────
    # observations[] items ({"entity_name", "attribute", "value", "date"})
    # generalize the role field's bi-temporal supersession to typed, dated
    # facts (title changes, org moves, project-membership changes) that don't
    # fit `role` (a current-title snapshot) or the relation types. Resolved
    # against name_to_id ONLY — exact match, no affiliation-stripping
    # fallback — an unresolved entity_name is skipped, never invented.
    if config.enrich_rich_observations_enabled(_home):
        for obs in extraction.get("observations", []) or []:
            obs_entity_name = (obs.get("entity_name") or "").strip()
            obs_attribute = (obs.get("attribute") or "").strip()
            obs_value = (obs.get("value") or "").strip()
            if not obs_entity_name or not obs_attribute or not obs_value:
                continue
            obs_entity_id = name_to_id.get(obs_entity_name)
            if not obs_entity_id:
                continue
            obs_date_raw = (obs.get("date") or "").strip()
            obs_valid_from = (_parse_date_iso(obs_date_raw) or obs_date_raw
                              or lead_date_iso or today)
            write_observation(store, obs_entity_id, obs_attribute, obs_value,
                              "llm_extraction", obs_valid_from, "medium",
                              **_src_kw)

    # ── 2. Topics with min-distinct-orgs gate (Task 2.6) ───────────────────
    # A topic entity is only created once it has appeared in email_context under
    # at least 2 distinct known orgs. The current row is excluded from the count
    # (exclude_message_id=lead_msg_id below), so only PRIOR appearances open the
    # gate. That is why two distinct orgs need three applies: the first two seed
    # the prior rows, and the third sees them and creates the topic.
    topics_created = 0
    for tag in topics_list:
        tag_clean = (tag or "").strip().lower()
        if len(tag_clean) < 2:
            continue
        if _topic_distinct_orgs(store, tag_clean, exclude_message_id=lead_msg_id) < 2:
            continue
        topic_id = store.upsert_topic_entity(tag_clean)
        if topic_id:
            _link(topic_id, "about")
            topics_created += 1

    # ── 2.4 Deterministic sender entities (Task 1.1) ────────────────────────
    # Every message's sender is structured header data — no LLM inference is
    # needed to know a person sent a message. Create a person entity for any
    # sender the model didn't already surface in entities[] (name_to_id), so
    # the 2.5 structural-relations pass below can link them (works_at /
    # mentioned_with) without depending on the model re-listing headers. This
    # frees the model's extraction budget for body-mentioned people only.
    # Junk-guarded and owner-excluded, same as every other entity-creation path.
    if config.enrich_sender_entities(_home):
        for msg in messages:
            hdr = msg.get("sender", "") or ""
            if not hdr:
                continue
            s_name = strip_affiliation(_extract_name(hdr)).strip()
            s_email = _extract_email_addr(hdr)
            # Require a resolvable email, matching the lead-sender guard above
            # (":1008", `sender_name and sender_email`) — a bare display name
            # with no email is not reliable enough structured data to anchor a
            # deterministic entity on. Also mirror the lead-sender identity
            # check (":1008-1009"): _is_owner only matches configured name
            # aliases, so a sender whose header email is the owner's own
            # `identity` but whose display name isn't an alias (signature
            # variant, nickname, different casing) must still be excluded.
            if not s_name or not s_email or _is_owner(s_name, owner) \
                    or is_junk_entity(s_name, "person") \
                    or (identity and identity.lower() in s_email.lower()):
                continue
            if s_name.strip().lower() in {n.strip().lower() for n in name_to_id}:
                continue  # model already surfaced this person
            # Create the person, but do NOT key them on a shared/role inbox — multiple
            # distinct people send from office@/info@ and email-equality dedup would
            # collapse them (C1). A real human on a shared inbox is still captured, just
            # without the misleading shared address as their identity.
            entity_email = "" if is_role_address(s_email) else s_email
            sid = upsert_entity(store, derived=_derived, name=s_name, entity_type="person", org="",
                                email_addr=entity_email, taxonomy=taxonomy, valid_from=lead_date_iso)
            if not sid:
                continue
            name_to_id[s_name] = sid
            if sid not in linked:
                _link(sid, "authored")
                linked.add(sid)

    # ── 2.5 Structural relations: deterministic works_at / mentioned_with ──
    # Runs BEFORE the model's relations loop (Task 3.4). Header participants
    # already resolved to an entity THIS apply() call (via name_to_id — never
    # invented from a bare header the model didn't extract) get a
    # provenance-backed works_at edge when their header-email domain maps to a
    # REAL configured org, and every pair of such senders gets mentioned_with
    # in both directions. This frees the model's extraction budget for the
    # semantic relations (reports_to/manages/coordinates_with) headers can't
    # supply. Guarded by the shared `_home` computed near the top of apply().
    if config.enrich_structural_relations_enabled(_home):
        structural_person_ids: list = []
        for msg in messages:
            msg_header = msg.get("sender", "") or ""
            if not msg_header:
                continue
            msg_email = _extract_email_addr(msg_header)
            if not msg_email:
                continue
            msg_name_key = strip_affiliation(_extract_name(msg_header)).strip().lower()
            if not msg_name_key:
                continue
            # Match against name_to_id's exact-cased keys case-insensitively;
            # skip participants the model never surfaced as an entity this call
            # (no entity_id at all) rather than inventing one.
            person_id = None
            for ename, eid in name_to_id.items():
                if ename.strip().lower() == msg_name_key:
                    person_id = eid
                    break
            if not person_id:
                continue
            if person_id not in structural_person_ids:
                structural_person_ids.append(person_id)

            msg_domain_org = org_from_email(msg_email, taxonomy)
            if not msg_domain_org or msg_domain_org in ("external", "unknown", ""):
                continue
            org_entity_id = upsert_entity(
                store, derived=_derived, name=msg_domain_org, entity_type="org", org=msg_domain_org,
                taxonomy=taxonomy, valid_from=lead_date_iso)
            if not org_entity_id:
                continue
            upsert_relation(store, person_id, "works_at", org_entity_id,
                           valid_from=lead_date_iso or today, evidence=lead_msg_id,
                           source_doc_id=prov_doc_id, **_src_kw)

        # mentioned_with among every distinct pair of resolved senders, both
        # directions — symmetric co-participation fact, directional rows.
        for i, a_id in enumerate(structural_person_ids):
            for b_id in structural_person_ids[i + 1:]:
                upsert_relation(store, a_id, "mentioned_with", b_id,
                                valid_from=lead_date_iso or today, evidence=lead_msg_id,
                                source_doc_id=prov_doc_id, **_src_kw)
                upsert_relation(store, b_id, "mentioned_with", a_id,
                                valid_from=lead_date_iso or today, evidence=lead_msg_id,
                                source_doc_id=prov_doc_id, **_src_kw)

    # ── 3. Relations ────────────────────────────────────────────────────────
    relations_created = 0
    for rel in extraction.get("relations", []) or []:
        source_name = (rel.get("source_name") or "").strip()
        target_name = (rel.get("target_name") or "").strip()
        rel_type = (rel.get("type") or "").strip()

        if not source_name or not target_name or not rel_type:
            continue
        if rel_type not in VALID_RELATION_TYPES:
            continue
        if _is_owner(source_name, owner) or _is_owner(target_name, owner):
            continue

        # Reject endpoints that are org-classification TAGS, not real entities
        # ("external", "contractor", ...). Real org names that merely contain a
        # tag word ("Acme Corp") are an inexact match and pass through.
        # Tag check runs on the raw name before any stripping.
        if source_name.lower() in taxonomy.org_tags or target_name.lower() in taxonomy.org_tags:
            continue

        def _resolve_endpoint(name, *, for_works_at_target=False):
            """Try the original name first; fall back to the affiliation-stripped
            form only when they differ.  This preserves org names that legitimately
            contain ' at ' or ' from ' (e.g. 'Church at the Bay') while still
            resolving person-affiliation suffixes like 'Priya from The Lantern Co'."""
            # Primary attempt: resolve the name as given.
            eid = name_to_id.get(name)
            if not eid:
                hit = store.find_entity(name)
                eid = hit["id"] if hit else None
            if eid:
                return eid, name

            # Secondary attempt: try the stripped form if it differs.
            stripped = strip_affiliation(name)
            if stripped != name:
                eid = name_to_id.get(stripped)
                if not eid:
                    hit = store.find_entity(stripped)
                    eid = hit["id"] if hit else None
                if eid:
                    return eid, stripped

            # works_at targets may be orgs not yet seen — upsert with the
            # original name so a real org like "Church at the Bay" is stored intact.
            if for_works_at_target:
                create_name = name  # prefer original for brand-new org entities
                eid = upsert_entity(store, derived=_derived, name=create_name,
                                    entity_type="org", org=org, taxonomy=taxonomy)
                if eid:
                    return eid, create_name

            return None, name

        source_id, source_name = _resolve_endpoint(source_name)
        if not source_id:
            continue

        target_id, target_name = _resolve_endpoint(
            target_name, for_works_at_target=(rel_type == "works_at")
        )
        if not target_id:
            continue

        if source_id == target_id:
            continue                                  # self-loop (also caught downstream)

        # Endpoint-type guard: drop e.g. "topic works_at org" or "meeting works_at"
        # — the LLM over-applies the person-centric relations to non-person entities.
        constraint = _RELATION_ENDPOINT_TYPES.get(rel_type)
        if constraint:
            src_ok, tgt_ok = constraint
            s_ent, t_ent = store.get_entity(source_id), store.get_entity(target_id)
            if not s_ent or not t_ent:
                continue
            if (s_ent.get("type") not in src_ok) or (t_ent.get("type") not in tgt_ok):
                continue

        if upsert_relation(store, source_id, rel_type, target_id,
                           valid_from=lead_date_iso or today, evidence=lead_msg_id,
                           source_doc_id=prov_doc_id, **_src_kw):
            relations_created += 1

    # ── 4. Action lifecycle (Task 3) ────────────────────────────────────────
    # Runs AFTER the structural pass so owner resolution can use name_to_id and
    # entities written above. is_self / in_inbox come from the thread lead.
    is_self = _is_self_message(lead, identity)
    in_inbox = "INBOX" in [lbl.strip() for lbl in raw_labels.split(",")]
    action_counts = _write_actions(
        store, extraction,
        lead=lead, lead_msg_id=lead_msg_id, lead_date_iso=lead_date_iso,
        content_type=content_type, org=org, sender_id=sender_id,
        sender_name=sender_name, is_self=is_self, in_inbox=in_inbox,
        name_to_id=name_to_id, now=now, thread_id=thread_id, owner=owner,
        embedder=embedder, embed_cache=embed_cache,
        owner_email=config.owner_email(_home))

    # ── 5. Semantic layer (Task 5) ──────────────────────────────────────────
    # One synthesised vector doc per thread, keyed enriched-{thread_id}. Written
    # via upsert_chunk (embedded=0, idempotent on content_hash). When an embedder
    # is injected it is embedded inline; otherwise it is left for the daemon's
    # index_pending pass. Imported here (not at module top) to avoid a
    # semantic -> graph_write -> semantic import cycle.
    from mcpbrain.chunking import content_hash
    from mcpbrain.semantic import build_semantic_doc

    semantic_doc_id = f"enriched-{thread_id}" if thread_id else ""
    if semantic_doc_id:
        semantic_text, semantic_meta = build_semantic_doc(
            extraction, lead, owner=owner, taxonomy=taxonomy,
            date_iso=lead_date_iso or "")
        store.upsert_chunk(
            doc_id=semantic_doc_id, text=semantic_text,
            content_hash=content_hash(semantic_text), metadata=semantic_meta)
        # The semantic doc is enrichment OUTPUT, not input. Mark it enriched=1 so
        # thread_enrich.group_unenriched_threads never re-picks it as backlog
        # (it carries this thread's thread_id). This leaves embedded untouched:
        # 0 in the deferred path (index_pending still embeds it), 1 after the
        # immediate-embed branch below.
        store.mark_enriched([semantic_doc_id])
        if embedder is not None:
            store.embed_doc(semantic_doc_id, embedder, home=_home)

    # ── 6. Thread index (thread_context) ────────────────────────────────────
    # Materialise the per-thread record every enriched thread feeds: subject,
    # org, message count, the headline summary, and participant ids. This is the
    # producer the synthesis pass and prepare's prior_thread_context read from;
    # contextual_summary is deliberately left unset here for the deeper synthesis
    # pass to fill (upsert_thread_context preserves a populated one).
    if thread_id:
        store.upsert_thread_context(
            thread_id,
            subject=lead.get("subject", "") if lead else "",
            org=org,
            email_count=len(messages),
            summary=summary,
            participant_ids=",".join(sorted(linked)),
        )

    return {
        "entities": entities_created,
        "relations": relations_created,
        "topics": topics_created,
        "email_context": 1,
        "actions": action_counts["actions"],
        "resolved": action_counts["resolved"],
        "updated": action_counts["updated"],
        "semantic_doc": semantic_doc_id,
    }


def _write_actions(store, extraction, *, lead, lead_msg_id, lead_date_iso,
                   content_type, org, sender_id, sender_name, is_self, in_inbox,
                   name_to_id, now, thread_id, owner, embedder=None,
                   embed_cache=None, owner_email="") -> dict:
    """Action lifecycle: gates, self-synthesis, dedup, owner/deadline inference,
    routing into the unified actions table, then resolve/update.

    Ported from enrich_gmail.py:1285-1539. The Nexus two-table routing
    (knowledge_actions vs decisions) collapses to a single store.add_unified_action
    call: the not-the-owner / unclear / owner branches differ only in the
    owner/confidence/context_tag written. project_id/area_id pass through from the
    extraction unvalidated (projects/areas tables removed in §9E).

    Gmail label writes (_apply_self_task_label) are intentionally omitted: there
    is no Gmail surface in Phase 1.

    Near-duplicates are matched by meaning when an `embedder` is given (see
    _find_near_duplicate_action); `embed_cache` (text -> unit vector) may be
    shared across a drain run. If the embedder fails, the rest of this apply
    uses the lexical rules. Owner strings are canonicalised: an owner alias
    becomes the configured owner name, and a non-person owner ("Claude",
    "assistant") is written as "unclear", like an owner nobody named.

    Closing an existing action happens ONLY through resolved_action_ids. The
    extractor is told to stay silent about still-valid open actions, so an
    action a re-extraction does not mention is still open, not superseded.
    """
    actions_list = extraction.get("actions", []) or []
    emb_cache: dict = {} if embed_cache is None else embed_cache
    emb_status: dict = {}
    body = lead.get("body", "") or ""

    # Stamp actions from the injected clock so the near-duplicate window and the
    # rows' created_at agree (matters for backfills run with a non-wall clock).
    now_iso = now.strftime("%Y-%m-%dT%H:%M:%SZ")
    today_iso = now_iso[:10]

    # ── Age gate: non-inbox emails more than 60 days old (60 days exactly is
    # exempt) raise no actions. Self-emails bypass (always first-class task
    # sources).
    if not in_inbox and lead_date_iso and not is_self:
        try:
            email_date = datetime.strptime(
                lead_date_iso, "%Y-%m-%d").replace(tzinfo=timezone.utc)
            if (now - email_date).days > 60:
                actions_list = []
        except Exception:
            pass

    # ── Notification gate: automated emails raise no work. Self-emails bypass
    # (Gemini may misclassify "Reminder:" as a notification).
    if content_type == "notification" and actions_list and not is_self:
        actions_list = []

    # ── Self-email synthetic task: every self-email leaves a task trace.
    if is_self and not actions_list:
        subject_clean = _SELF_PREFIX_RE.sub("", lead.get("subject", "")).strip()
        if not subject_clean:
            subject_clean = "(self-email task - no subject)"
        body_words = body.split()
        if len(body_words) >= 20:
            first_sentence = body.split(".")[0].strip()
            if first_sentence:
                subject_clean = f"{subject_clean}. {first_sentence}"
        actions_list = [{
            "description": subject_clean, "owner_name": owner.name,
            "owner_fallback": "", "due_date": "", "_synthetic": True,
        }]

    # ── Within-batch dedup: drop near-identical actions before any DB write.
    deduped_actions: list = []
    seen_norms: list = []
    for action in actions_list:
        desc = (action.get("description") or "").strip()
        n = _norm_action(desc)
        if any(n == s or n in s or s in n or _token_jaccard(n, s) >= 0.75
               for s in seen_norms):
            continue
        deduped_actions.append(action)
        seen_norms.append(n)
    actions_list = deduped_actions

    is_sender_owner = bool(sender_name and _is_owner(sender_name, owner))

    # One owner identity for this apply (resolved once, not per action): the
    # config aliases, the derived id, and the REAL owner node's id, name and
    # aliases. Without the real node, a variant the owner's own node carries
    # ("Dana Okafor" when config says "Dana") was written as a different,
    # "not owner" person and the owner's actions split across name strings.
    oc = (resolve_owner_class(store, owner, owner_email)
          if actions_list else OwnerClass())
    persons = PersonIds(store)

    actions_created = 0
    for action in actions_list:
        description = (action.get("description") or "").strip()
        if not description:
            continue

        owner_name = (action.get("owner_name") or "").strip() or None
        if owner_name and owner_name.lower() in _NON_PERSON_OWNERS:
            owner_name = None  # names no person: infer, else write "unclear"
        owner_fallback = (action.get("owner_fallback") or "").strip() or None
        due_date = (action.get("due_date") or "").strip()

        resolved_owner_name = owner_name
        resolved_owner_eid = ""

        if owner_name:
            if _is_owner_alias(owner_name, owner) or oc.is_owner_name(owner_name):
                resolved_owner_eid = oc.entity_id
                resolved_owner_name = owner.name
            else:
                hit = store.find_entity(owner_name)
                if hit and (hit["type"] == "person" or hit["id"] in oc.ids):
                    resolved_owner_eid = hit["id"]
                elif owner_name in name_to_id:
                    resolved_owner_eid = name_to_id[owner_name]
                # find_entity/name_to_id resolve by the graph's own entity
                # identity (id, slug, or stored display name), which can
                # independently land on the owner's own entity -- derived OR
                # real id -- for a spelling the name check above doesn't cover.
                # That IS the install owner: canonicalised below.
        elif (owner_fallback == "sender" and sender_id
              and sender_id != owner.entity_id):
            resolved_owner_eid = sender_id
            resolved_owner_name = sender_name

        context_tag_for_action = ""

        if is_self:
            # Self-email: owner is definitionally the install owner, bypass inference.
            resolved_owner_name = owner.name
            resolved_owner_eid = oc.entity_id or owner.entity_id
            context_tag_for_action = "self-email"
            synthetic = action.get("_synthetic", False)
            has_prefix = bool(_SELF_PREFIX_RE.match(lead.get("subject", "")))
            action_confidence = (1.0 if has_prefix else 0.85) if synthetic else 1.0
        else:
            action_confidence = _CONFIRMED_EMAIL_ACTION_CONFIDENCE
            if not resolved_owner_name:
                inf_name, inf_eid, inf_conf = _infer_owner(
                    is_sender_owner, description, owner)
                if inf_name:
                    resolved_owner_name = inf_name
                    resolved_owner_eid = inf_eid
                    action_confidence = inf_conf

        # Deadline inference when the LLM returned no deadline.
        deadline_confidence = action_confidence
        if not due_date:
            inferred_d = _infer_deadline(description, body, lead_date_iso)
            if inferred_d:
                due_date = inferred_d
                deadline_confidence = 0.6

        if resolved_owner_name and resolved_owner_name.lower() in _NON_PERSON_OWNERS:
            resolved_owner_name, resolved_owner_eid = None, ""
        # Rule 1 (one owner identity): a config alias, a name the owner's own
        # node carries, or a name that resolved to the derived or real owner id.
        # Ruling I19: an id that resolved to another existing person is never
        # overridden by a name.
        foreign = bool(resolved_owner_eid
                       and resolved_owner_eid not in oc.ids
                       and resolved_owner_eid in persons)
        is_owner_action = bool(resolved_owner_name) and not foreign and (
            _is_owner_alias(resolved_owner_name, owner)
            or oc.is_owner(resolved_owner_name, resolved_owner_eid))
        is_not_owner = bool(resolved_owner_name) and not is_owner_action

        cluster_id = f"msg-{lead_msg_id[:16]}" if lead_msg_id else ""

        # Single-table routing. The three Nexus branches differ only in the
        # owner / confidence / context_tag written into the same actions table.
        if is_not_owner:
            owner_out = resolved_owner_name or ""
            owner_eid_out = resolved_owner_eid
            confidence_out = action_confidence
        elif not resolved_owner_name:
            owner_out = _UNCLEAR_OWNER
            owner_eid_out = ""
            confidence_out = 0.5
        else:
            # resolved_owner_name matched an owner alias (is_not_owner is
            # False) -- write the CANONICAL name, not whatever alias variant
            # the LLM/sender happened to use ("Dana Okafor", "Dana", ...), or
            # every write-path's spelling fragments the owner filter every
            # consumer (brain_actions(owner="") -> config.owner_name()) relies
            # on for an exact match.
            owner_out = owner.name
            owner_eid_out = oc.entity_id or owner.entity_id
            confidence_out = deadline_confidence

        # Near-duplicate guard: skip insert when an open row already means the
        # same thing -- same source at any age, or same owner within the 30-day
        # window (windowed on the injected clock). A fresh read connection per
        # action, so rows written earlier in this apply are seen.
        with store._connect() as conn:
            dup_id = _find_near_duplicate_action(
                conn, description, owner_out, thread_id=thread_id,
                embedder=embedder, today=today_iso, cache=emb_cache,
                status=emb_status, owner_class=oc)
        if emb_status.get("embed_failed"):
            embedder = None  # logged once; lexical for the rest of this apply
        if dup_id is not None:
            continue

        # waiting_on: an action awaiting a reply from a named person. Resolve the
        # awaited entity so the reconciler can match by id, and stamp when the
        # wait began (the email date) so the reconciler's window is anchored.
        waiting_on_name = (action.get("waiting_on") or "").strip()
        waiting_on_eid = ""
        waiting_on_set_at = ""
        if waiting_on_name and not _is_owner(waiting_on_name, owner):
            hit = store.find_entity(waiting_on_name)
            if hit:
                waiting_on_eid = hit["id"]
            elif waiting_on_name in name_to_id:
                waiting_on_eid = name_to_id[waiting_on_name]
            waiting_on_set_at = lead_date_iso or now_iso

        store.add_unified_action(
            text=description, owner=owner_out, owner_entity_id=owner_eid_out,
            status="open", deadline=due_date, org=org,
            project_id=action.get("project_id") or "",
            area_id=action.get("area_id") or "",
            confidence=confidence_out, source="email",
            context_tag=context_tag_for_action, cluster_id=cluster_id,
            source_doc_id=lead_msg_id, thread_id=thread_id,
            text_fingerprint=_compute_fingerprint(description),
            waiting_on=waiting_on_name if waiting_on_name and not _is_owner(waiting_on_name, owner) else "",
            waiting_on_entity_id=waiting_on_eid,
            waiting_on_set_at=waiting_on_set_at,
            created_at=now_iso)
        actions_created += 1

    # ── Close actions resolved by this email. Scoped to this thread's OPEN
    # actions: the extractor only sees this thread's open actions, so a resolve
    # id should never close an already-done action or one from another thread (a
    # hallucinated id then no-ops instead of closing something unrelated).
    resolved_count = 0
    for action_id in (extraction.get("resolved_action_ids") or []):
        if not isinstance(action_id, int) or isinstance(action_id, bool):
            continue
        changed = store.set_action_status(
            action_id, "done", resolved_by=lead_msg_id,
            thread_id=thread_id, only_if_open=True)
        if changed:
            resolved_count += 1
        else:
            log.info("apply: resolved_action_id %s matched no open action in "
                     "thread %s; skipping", action_id, thread_id)

    # ── Update action text where scope/details changed (same thread/open scope).
    updated_count = 0
    for item in (extraction.get("updated_actions") or []):
        if not isinstance(item, dict):
            continue
        action_id = item.get("id")
        new_text = (item.get("new_text") or "").strip()
        if not isinstance(action_id, int) or isinstance(action_id, bool) or not new_text:
            continue
        changed = store.set_action_text(
            action_id, new_text, thread_id=thread_id, only_if_open=True)
        if changed:
            updated_count += 1
        else:
            log.info("apply: updated_action id %s matched no open action in "
                     "thread %s; skipping", action_id, thread_id)

    return {"actions": actions_created, "resolved": resolved_count,
            "updated": updated_count}


def _is_owner_alias(name: str, owner) -> bool:
    """True when `name` is (case-insensitively) the owner's name or an alias."""
    low = (name or "").strip().lower()
    return bool(low) and (low in owner.aliases
                          or (bool(owner.name) and low == owner.name.lower()))


# ---------------------------------------------------------------------------
# Topic gate + action-target validation (Task 2.6)
# ---------------------------------------------------------------------------

def _topic_distinct_orgs(store, tag_clean: str, *, exclude_message_id="") -> int:
    r"""Count distinct known orgs whose email_context rows carry this topic.

    Ported from enrich_gmail.py:1256-1272. topics is stored "tag1, tag2"; the
    query strips the spaces then applies a boundary-anchored LIKE so ",budget,"
    matches but "budgeting" does not. The current message is excluded so the
    gate counts only prior appearances (the row is written before this runs).

    The tag is interpolated into a LIKE pattern, so its %, _ and \ metacharacters
    are escaped and an ESCAPE clause is used. Without it a tag like "q1_budget"
    would let the "_" wildcard-match a different topic such as "q1xbudget".
    """
    tag_escaped = (tag_clean.replace("\\", "\\\\")
                   .replace("%", "\\%").replace("_", "\\_"))
    sql = (
        "SELECT COUNT(DISTINCT org) FROM email_context "
        "WHERE (',' || REPLACE(topics, ', ', ',') || ',') "
        "LIKE '%,' || ? || ',%' ESCAPE '\\' "
        "AND org NOT IN ('', 'unknown')"
    )
    params: tuple = (tag_escaped,)
    if exclude_message_id:
        sql += " AND message_id != ?"
        params = (tag_escaped, exclude_message_id)
    with store._connect() as conn:
        row = conn.execute(sql, params).fetchone()
    return row[0] if row else 0


# ---------------------------------------------------------------------------
# Entity writers (ported from memory_db.py:1164-1174, 1561-1572, 1581-1717)
# ---------------------------------------------------------------------------

def _alias_match_set(value) -> set[str]:
    """Lower-cased aliases for MATCHING, split on both '|' and ','.

    Writers store '|', but legacy values can mix the two ("A, B|C": commas from
    old extraction, a pipe from a later merge). split_aliases picks one separator
    per value and would read "A, B" as a single alias, so a matching read that
    used it would miss "A" and "B" and mint a duplicate. Writes still go through
    split_aliases so a stored value round-trips unchanged."""
    return {a.strip().lower() for a in re.split(r"[|,]", value or "") if a.strip()}


def _append_alias(conn, entity_id: str, new_alias: str) -> None:
    row = conn.execute(
        "SELECT name, aliases FROM entities WHERE id = ?", (entity_id,)).fetchone()
    if not row:
        return
    existing = split_aliases(row["aliases"])
    seen = {a.lower() for a in existing} | _alias_match_set(row["aliases"])
    if row["name"]:
        seen.add(row["name"].lower())
    if new_alias.lower().strip() not in seen:
        existing.append(new_alias.strip())
        conn.execute("UPDATE entities SET aliases = ? WHERE id = ?",
                     ("|".join(existing), entity_id))


def _meeting_series_id(series_name: str, org: str) -> str:
    """Deterministic, org-scoped series id for a meeting/event.

    Org-scoping is the structural guard against the 'Staff Meeting across two
    orgs' collision: distinct orgs -> distinct ids, no heuristic needed.
    """
    return slugify(f"meeting-{org}-{series_name}")


def _bump_email_count(store, entity_id: str) -> None:
    """Increment an entity's email_count and mentions by one, for every
    entity type.

    Called from apply() only when a NEW, non-derived (message_id, entity_id)
    link row was created, so both count distinct primary messages and stay
    stable when a thread is re-applied or a derived source mentions the
    entity (spec 2026-10-22 §3). Source removal takes both back
    (Store._invalidate_sources_in); the clean-up's recount_mentions step
    recounts mentions on the same basis.
    """
    with store._connect(write=True) as conn:
        conn.execute(
            "UPDATE entities SET email_count = email_count + 1, "
            "mentions = COALESCE(mentions, 0) + 1 WHERE id = ?",
            (entity_id,))


def _ensure_works_at(conn, entity_id: str, org: str, *, derived: bool = False) -> None:
    """Auto-create the org entity and a works_at edge. No-op for external/unknown.

    Uses INSERT OR IGNORE on the legacy UNIQUE(entity_a,relation,entity_b)
    triple — the structural pass; bitemporal works_at supersession runs through
    upsert_relation in the relations loop.

    The edge carries no source of its own (it restates the entity's org
    field), so it is inserted at strength 1 with no relation_sources row and
    never touches an existing row's strength. Reached from a derived source
    (derived=True) it is written derived=1 / strength 0 instead, excluded
    everywhere until a primary source asserts it.
    """
    if not org or org in ("external", "unknown", ""):
        return
    org_id = slugify(org)
    if not org_id:
        return
    today = _today()
    existing_org = conn.execute(
        "SELECT id FROM entities WHERE id = ?", (org_id,)).fetchone()
    if not existing_org:
        conn.execute(
            "INSERT INTO entities (id, name, type, org, first_seen, last_seen) "
            "VALUES (?, ?, 'org', ?, ?, ?)",
            (org_id, org, org, today, today))
    conn.execute(
        "INSERT OR IGNORE INTO entity_relations "
        "(entity_a, relation, entity_b, strength, last_seen, derived) "
        "VALUES (?, 'works_at', ?, ?, ?, ?)",
        (entity_id, org_id, 0 if derived else 1, today, 1 if derived else 0))


@dataclass(frozen=True)
class OwnerClass:
    """Everything that IS the install owner, for action attribution (2026-10-22
    ingestion-integrity spec §2, "Owner canonicalisation at write").

    name:      the canonical owner string written to actions.owner
    entity_id: the owner's REAL node id when the graph has one, else the
               derived owner.entity_id
    ids:       every id that is the owner (derived + real)
    names:     lower-cased names that are the owner: the config aliases and
               owner name, plus the real owner node's own MULTI-token name and
               aliases (ruling I18: a single token is the owner only as a
               config alias).

    Only names the owner's OWN node carries count, never a display-name match
    against the graph at large: that is the hazard resolve_owner_entity_id
    documents (a stranger who shares a first name is not the owner).
    """
    name: str = ""
    entity_id: str = ""
    ids: frozenset = field(default_factory=frozenset)
    names: frozenset = field(default_factory=frozenset)

    def is_owner_name(self, name) -> bool:
        low = (name or "").strip().lower()
        return bool(low) and low in self.names

    def is_owner(self, name, entity_id="", persons=()) -> bool:
        """True when (name, entity_id) is the owner: a name in the class, or an
        id in it. A blank or non-person name never is. Ruling I19: an
        entity_id outside the class that names an existing person (`persons`:
        any container answering `id in persons`) is a positive resolution to
        someone else, and a name never overrides it."""
        low = (name or "").strip().lower()
        if not low or low in _NON_PERSON_OWNERS:
            return False
        if entity_id and entity_id in self.ids:
            return True
        if entity_id and entity_id in persons:
            return False
        return low in self.names

    def key(self, name, entity_id="", persons=()) -> str:
        """Owner-compatibility key: '' for blank/unclear/non-person (joins any
        owner), the canonical name for the owner, else the lower-cased name."""
        low = (name or "").strip().lower()
        if not low or low in _NON_PERSON_OWNERS:
            return ""
        if self.is_owner(name, entity_id, persons):
            return (self.name or low).strip().lower()
        return low


class PersonIds:
    """`id in PersonIds(store)` -- True when an entities row of type person
    has that id. Lazy (one point query per id, cached) for the write path."""

    def __init__(self, store):
        self._store, self._seen = store, {}

    def __contains__(self, eid) -> bool:
        if not eid:
            return False
        if eid not in self._seen:
            with self._store._connect() as db:
                self._seen[eid] = db.execute(
                    "SELECT 1 FROM entities WHERE id=? AND type='person'",
                    (eid,)).fetchone() is not None
        return self._seen[eid]


def _owner_class_db(db, owner, owner_email: str = "") -> OwnerClass:
    """resolve_owner_class on an open connection (the clean-up holds one)."""
    name = (getattr(owner, "name", "") or "").strip()
    derived = getattr(owner, "entity_id", "") or ""
    aliases = {a.strip().lower() for a in getattr(owner, "aliases", ()) or ()
               if a and a.strip()}
    if not name and not aliases:
        return OwnerClass()          # unconfigured: nothing is the owner
    names = set(aliases)
    if name:
        names.add(name.lower())
    real = _owner_entity_id_db(db, owner, owner_email)
    if real:
        row = db.execute("SELECT name, aliases FROM entities WHERE id=?",
                         (real,)).fetchone()
        if row:
            # Ruling I18: the node's names count only when MULTI-token. A
            # single token the node carries (a nickname, a handle) is shared
            # with other people in the graph; a single-token name is the owner
            # only when config says so (the aliases above).
            node = {(row[0] or "").strip().lower()} | _alias_match_set(row[1])
            names |= {n for n in node if len(n.split()) > 1}
    names = {n for n in names if n and n not in _NON_PERSON_OWNERS}
    return OwnerClass(name=name, entity_id=real or derived,
                      ids=frozenset(i for i in (derived, real) if i),
                      names=frozenset(names))


def resolve_owner_class(store, owner, owner_email: str = "") -> OwnerClass:
    """The owner's identity class (see OwnerClass). Two queries; resolve it
    once per apply / repair run, not per action."""
    with store._connect() as db:
        return _owner_class_db(db, owner, owner_email)


def resolve_owner_entity_id(store, owner, owner_email: str = "") -> str:
    """The owner's REAL entity id in this graph, or '' if the graph has no
    owner node. NEVER creates one.

    Why this exists: owner.entity_id is DERIVED, slugify(configured full name).
    The owner node that actually exists in a populated graph was minted by the
    EMAIL path from the display name in message headers, so its id is
    slugify(display name) — on the live store 'josh-kemp' (email_count 3378,
    degree 7358), while owner.entity_id resolves to 'joshua-kemp', which has no
    row at all. The calendar attendee pass wrote `attended` edges from that
    second id: 7 dangling rows, exactly the entity_relations orphans the Task 4
    reporter found (and an IntegrityError once foreign_keys=ON).

    Resolution order — id first, then the email address, which is the identity
    upsert_entity itself dedups on:
      1. an entities row whose id IS owner.entity_id,
      2. a person row whose email_addr matches the owner's email — the passed
         one, any alias carrying an '@', or config's owner_email (aliases are
         derived from the NAME fields, so they usually carry no address at all).
    Returning '' (no owner node yet) is a normal outcome on a fresh store; the
    caller must then skip the relation rather than write a dangling edge.
    Deliberately no name/alias fallback: a display-name match on a graph full
    of real people is how you attach the owner's edges to a stranger. The
    email-match path shares that exact hazard when the configured owner
    address is a shared mailbox (office@, info@): every attendee/entity also
    registered under that address would resolve to "the owner", attributing
    someone else's whole meeting history. is_role_address() closes it, same
    as every other identity resolution in this module (0.7.77).
    """
    with store._connect() as db:
        return _owner_entity_id_db(db, owner, owner_email)


def _owner_entity_id_db(db, owner, owner_email: str = "") -> str:
    """resolve_owner_entity_id on an open connection."""
    eid = getattr(owner, "entity_id", "") or ""
    addrs = [a.lower() for a in ([owner_email] if owner_email else [])
             + [a for a in getattr(owner, "aliases", ()) or () if "@" in a]]
    try:
        cfg_email = config.owner_email(str(config.app_dir())).strip().lower()
    except Exception:  # noqa: BLE001 — resolution is best-effort, never fatal
        cfg_email = ""
    if cfg_email and cfg_email not in addrs:
        addrs.append(cfg_email)
    addrs = [a for a in addrs if a and not is_role_address(a)]
    if eid and db.execute("SELECT 1 FROM entities WHERE id=?", (eid,)).fetchone():
        return eid
    for addr in addrs:
        row = db.execute(
            "SELECT id FROM entities WHERE lower(email_addr)=? AND type='person'",
            (addr,)).fetchone()
        if row:
            return row[0]
    return ""


def _set_org_recency(conn, entity_id: str, org: str, valid_from: str) -> None:
    """Write org onto an existing entity, recency-aware. With a valid_from (the
    email date) it overwrites when org is blank OR the stored org_valid_from is
    blank/older — so a job change in a newer email propagates and backfill order
    can't pin a stale org. Without a valid_from it falls back to only-if-blank.

    B4a rule 3: an org-origin row's skeleton (org/org_valid_from) is never
    overwritten by a local write — the WHERE clause excludes origin='org' rows
    regardless of the recency check above.

    A user-corrected org (entity_field_locks) is never overwritten either: a
    correction stamps org_valid_from=today, so without this the first later-
    dated email would silently win it back."""
    if not org:
        return
    if valid_from:
        conn.execute(
            "UPDATE entities SET org = ?, org_valid_from = ? "
            "WHERE id = ? AND COALESCE(origin,'') != 'org' "
            "AND (COALESCE(org,'') = '' OR COALESCE(org_valid_from,'') = '' "
            "OR org_valid_from < ?) "
            "AND id NOT IN (SELECT entity_id FROM entity_field_locks WHERE field='org')",
            (org, valid_from, entity_id, valid_from))
    else:
        conn.execute(
            "UPDATE entities SET org = ? WHERE id = ? AND COALESCE(origin,'') != 'org' "
            "AND (org = '' OR org IS NULL) "
            "AND id NOT IN (SELECT entity_id FROM entity_field_locks WHERE field='org')",
            (org, entity_id))


def upsert_entity(store, *, name, entity_type, org="", email_addr="",
                  aliases="", notes="", taxonomy=None, valid_from="",
                  derived=False):
    """Insert or merge an entity. Returns the surviving entity id, or None.

    Ported from memory_db.py:1581-1717, repointed at store._connect(). Dedup
    order: (1) by email_addr, (2) alias / name
    match, (3) plain id upsert. email_count is bumped only on the email-dedup
    hit (matching Nexus). Title honorifics on person names are stripped and
    recorded as an alias. `valid_from` (the email date) makes org recency-aware —
    a newer-dated observation overwrites a stale org; omit it for only-if-blank.
    """
    if taxonomy is None:
        taxonomy = orgs.taxonomy_from_config()
    org = canonical_org(org, taxonomy)
    name = (name or "").strip()
    if not name:
        return None

    # Canonicalise known org NAMES so every form of a known org converges on one
    # node: "Acme Corp" / "acme corp incorporated" / the "Acme" tag all resolve
    # to the single 'acme' entity. Unknown orgs pass through unchanged. This is
    # what stops the relations loop minting a duplicate node beside the
    # tag-derived node that _ensure_works_at creates.
    if entity_type == "org":
        name = canonical_org(name, taxonomy)

    if is_junk_entity(name, entity_type):
        return None

    title_alias = ""
    if entity_type == "person":
        cleaned, original = strip_title(name)
        if cleaned != original:
            title_alias = original
            name = cleaned

    # (1) email dedup: an existing entity with this email wins, regardless of
    # the candidate display name.
    if email_addr:
        norm_email = email_addr.lower().strip()
        candidate_id = slugify(name)
        with store._connect(write=True) as conn:
            existing_by_email = conn.execute(
                "SELECT id FROM entities WHERE lower(email_addr) = ? AND id != ?",
                (norm_email, candidate_id),
            ).fetchone()
            if existing_by_email:
                winner_id = existing_by_email["id"]
                if org:
                    _set_org_recency(conn, winner_id, org, valid_from)
                    if entity_type == "person":
                        _ensure_works_at(conn, winner_id, org, derived=derived)
                # email_count is driven by message links in apply(), not by the
                # upsert itself — re-upserting the same sender on a re-applied
                # thread must not inflate the count.
                conn.execute(
                    "UPDATE entities SET last_seen = ? WHERE id = ?",
                    (_today(), winner_id))
                if title_alias:
                    _append_alias(conn, winner_id, title_alias)
                return winner_id

    eid = slugify(name)
    if not eid:
        return None
    today = _today()

    with store._connect(write=True) as conn:
        existing = conn.execute(
            "SELECT * FROM entities WHERE id = ?", (eid,)).fetchone()

        if not existing:
            normalised = name.lower().strip()

            # (2) alias / name merge: another entity of the same type whose
            # aliases (or display name) carry this name.
            normalised_original = title_alias.lower().strip() if title_alias else ""
            candidates = conn.execute(
                "SELECT id, aliases FROM entities WHERE aliases != '' AND type = ?",
                (entity_type,)).fetchall()
            alias_matches = []
            for row in candidates:
                alias_list = _alias_match_set(row["aliases"])
                if normalised in alias_list or (normalised_original and normalised_original in alias_list):
                    alias_matches.append(row["id"])

            if not alias_matches:
                name_match = conn.execute(
                    "SELECT id FROM entities WHERE LOWER(name) = ? AND type = ?",
                    (normalised, entity_type)).fetchone()
                if name_match:
                    alias_matches = [name_match["id"]]

            # A single alias/name match is treated exactly like a direct id hit
            # below: re-point eid/existing onto the matched row and fall through,
            # so it gets the same skeleton guard + notes/alias flesh handling
            # instead of a separate, more limited (org/last_seen-only) update.
            if len(alias_matches) == 1:
                eid = alias_matches[0]
                existing = conn.execute(
                    "SELECT * FROM entities WHERE id = ?", (eid,)).fetchone()

        if existing:
            _is_org = ("origin" in existing.keys() and existing["origin"] == "org")
            updates: dict = {"last_seen": today}
            # B4a rule 3: local writes never overwrite an org-origin row's
            # skeleton (org/org_valid_from/email_addr) — only the curator's
            # import path may do that. Flesh (notes, aliases below) is unaffected.
            if org and not _is_org:
                _existing_ovf = (existing["org_valid_from"]
                                 if "org_valid_from" in existing.keys() else "") or ""
                if not existing["org"]:
                    updates["org"] = org                      # blank → fill
                    if valid_from:
                        updates["org_valid_from"] = valid_from
                elif valid_from and (not _existing_ovf or _existing_ovf < valid_from):
                    updates["org"] = org                      # newer-dated → overwrite stale
                    updates["org_valid_from"] = valid_from
            if email_addr and not existing["email_addr"] and not _is_org:
                updates["email_addr"] = email_addr
            # A user-corrected field (brain_graph_correct) is never overwritten
            # by extraction, however newer the email that carries it.
            locked = {r[0] for r in conn.execute(
                "SELECT field FROM entity_field_locks WHERE entity_id = ?", (eid,))}
            if "org" in locked:
                updates.pop("org", None)
                updates.pop("org_valid_from", None)
            if "email" in locked:
                updates.pop("email_addr", None)
            if notes:
                existing_notes = existing["notes"] or ""
                if notes not in existing_notes:
                    updates["notes"] = (existing_notes + "\n" + notes).strip()
            set_clause = ", ".join(f"{k} = ?" for k in updates)
            conn.execute(
                f"UPDATE entities SET {set_clause} WHERE id = ?",  # lock-exempt: locked fields popped from `updates` above
                list(updates.values()) + [eid])
            if title_alias:
                _append_alias(conn, eid, title_alias)
            # Self-heal works_at whenever the caller reports an org, matching
            # the email-match branch above — NOT gated on "org" in updates
            # (whether the skeleton field actually changed this call) or on
            # _is_org (the skeleton-freeze guard protects the entities row's
            # own org/email_addr columns, not a relation): an entity whose
            # stored org is already correct, or is org-origin, can still be
            # missing its works_at edge (e.g. deleted by something else), and
            # every re-observation should keep self-healing it, not only the
            # one call that happens to also change the org field.
            if org and entity_type == "person":
                _ensure_works_at(conn, eid, org, derived=derived)
        else:
            all_aliases = "|".join(split_aliases(aliases) + ([title_alias] if title_alias else []))
            conn.execute(
                "INSERT INTO entities "
                "(id, name, type, org, org_valid_from, email_addr, aliases, first_seen, last_seen, notes) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (eid, name, entity_type, org, (valid_from if org else ""),
                 email_addr, all_aliases, today, today, notes))
            if org and entity_type == "person":
                _ensure_works_at(conn, eid, org, derived=derived)

    return eid

"""One classifier: is a chunk evidence (something that happened) or derived
(something mcpbrain or the owner's automation wrote about it)?

Only evidence may mint or strengthen graph claims. Brief rules are config
(`ingest.*`), never literals here.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from email.utils import getaddresses
from enum import Enum
from pathlib import Path


class SourceClass(str, Enum):
    PRIMARY_MAIL = "primary_mail"
    PRIMARY_DOC = "primary_doc"
    PRIMARY_EVENT = "primary_event"
    SESSION = "session"
    BRIEF = "brief"
    DRAFT = "draft"
    CONSOLIDATED = "consolidated"
    DIGEST = "digest"
    DUPLICATE = "duplicate"


EVIDENCE = frozenset({
    SourceClass.PRIMARY_MAIL, SourceClass.PRIMARY_DOC, SourceClass.PRIMARY_EVENT,
})

_SESSION_TITLE = re.compile(r"^Session [0-9a-f]{8} \d{4}-\d{2}-\d{2}")


@dataclass(frozen=True)
class Rules:
    owner_emails: frozenset = frozenset()
    subject_prefixes: tuple = ()
    drive_folders: tuple = ()
    generated_label_ids: frozenset = frozenset()

    @classmethod
    def from_config(cls, home, *, generated_label_ids=frozenset()) -> "Rules":
        from mcpbrain import config

        emails = set()
        own = (config.owner_email(home) or "").strip().lower()
        if own:
            emails.add(own)
        try:
            side = (Path(home) / "google_account").read_text().strip().lower()
        except (OSError, ValueError):
            side = ""
        if side:
            emails.add(side)
        return cls(
            owner_emails=frozenset(emails),
            subject_prefixes=tuple(config.generated_gmail_subject_prefixes(home)),
            drive_folders=tuple(config.generated_drive_folders(home)),
            generated_label_ids=frozenset(generated_label_ids),
        )


# Store meta key holding the resolved id(s) of the Gmail label NAMED
# GENERATED_LABEL_NAME. Written by sync.gmail.generated_label_ids (which has a
# Gmail service); read here by anything that only has the store (prepare).
GENERATED_LABEL_NAME = "mcpbrain/generated"
GENERATED_LABEL_META_KEY = "gmail_generated_label_id"


def cached_generated_label_ids(store) -> frozenset:
    """The cached `mcpbrain/generated` label id(s), or an empty set.

    Never raises: an absent cache, a malformed value or a store without meta
    support all mean "no marker label known yet" — the subject/folder brief
    rules and every other class still apply."""
    import json
    try:
        raw = store.get_meta(GENERATED_LABEL_META_KEY)
        if not raw:
            return frozenset()
        ids = json.loads(raw).get("ids") or []
        return frozenset(str(i) for i in ids if str(i).strip())
    except Exception:  # noqa: BLE001 — a cache miss must never block prepare
        return frozenset()


def is_evidence(cls: SourceClass) -> bool:
    return cls in EVIDENCE


def _addrs(header) -> list[str]:
    return [a.strip().lower() for _, a in getaddresses([str(header or "")]) if a.strip()]


def _label_ids(meta: dict, key: str = "labels") -> set:
    raw = meta.get(key) or ""
    if isinstance(raw, (list, tuple)):
        return {str(x).strip() for x in raw if str(x).strip()}
    return {x.strip() for x in str(raw).split(",") if x.strip()}


def _in_folder(path: str, folders) -> bool:
    p = (path or "").strip().strip("/")
    for f in folders:
        f = f.strip().strip("/")
        if f and (p == f or p.startswith(f + "/")):
            return True
    return False


def _is_session(doc_id: str, meta: dict) -> bool:
    if not (meta.get("source") == "note" or doc_id.startswith("note-")):
        return False
    if meta.get("claude_session_id"):
        return True
    tags = {t.lower() for t in _label_ids(meta, "tags")}
    if "session" in tags:
        return True
    return bool(_SESSION_TITLE.match(str(meta.get("title") or "")))


def classify(doc_id: str, meta: dict, rules: Rules) -> SourceClass:
    meta = meta or {}
    doc_id = doc_id or ""
    if doc_id.startswith("enriched-"):
        return SourceClass.DIGEST
    if meta.get("dup_of"):
        return SourceClass.DUPLICATE
    if doc_id.startswith("note-consolidated-") or meta.get("observation_type") == "consolidated":
        return SourceClass.CONSOLIDATED
    if _is_session(doc_id, meta):
        return SourceClass.SESSION
    st = meta.get("source_type")
    if st == "gmail":
        labels = _label_ids(meta)
        attach = meta.get("content_type") == "email_attachment"
        if "DRAFT" in labels:
            return SourceClass.DRAFT
        if labels & rules.generated_label_ids:
            return SourceClass.BRIEF
        subject = str(meta.get("subject") or "")
        if rules.subject_prefixes and subject.startswith(tuple(rules.subject_prefixes)):
            senders = _addrs(meta.get("sender"))
            to = _addrs(meta.get("to"))
            cc = _addrs(meta.get("cc"))
            if (senders and to
                    and all(a in rules.owner_emails for a in senders + to + cc)):
                return SourceClass.BRIEF
        return SourceClass.PRIMARY_DOC if attach else SourceClass.PRIMARY_MAIL
    if st == "gdrive":
        if str(meta.get("app_generated")) == "1" or _in_folder(
                meta.get("folder_path"), rules.drive_folders):
            return SourceClass.BRIEF
        return SourceClass.PRIMARY_DOC
    if st == "anarlog":
        return SourceClass.PRIMARY_DOC
    if doc_id.startswith("cal-") or meta.get("event_id") or st == "calendar":
        return SourceClass.PRIMARY_EVENT
    return SourceClass.PRIMARY_DOC


def source_key(doc_id: str, meta: dict) -> str:
    """The LOGICAL source a chunk belongs to — the unit of independent support.

    Strength counts distinct source keys, so every chunk of one email thread,
    one Drive file, one captured note, one calendar event or one anarlog
    meeting must map to the SAME key (re-extracting a part of it, or another
    chunk of it, is the same evidence again, not new evidence). Namespaces
    follow thread_enrich._chunk_key: Gmail thread id, Drive file id,
    ``anarlog-<session_id>`` (before event_id, as there), ``cal-<event_id>``,
    note id. A duplicate's key is its CANONICAL chunk's key — the caller
    resolves ``dup_of`` before asking (see graph_write.extraction_sources).
    """
    meta = meta or {}
    doc_id = doc_id or ""
    st = meta.get("source_type")
    if st == "gmail":
        return str(meta.get("thread_id") or meta.get("message_id") or doc_id)
    if meta.get("file_id"):
        return str(meta["file_id"])
    if meta.get("session_id"):
        return f"anarlog-{meta['session_id']}"
    if meta.get("event_id"):
        return f"cal-{meta['event_id']}"
    if meta.get("note_id"):
        return str(meta["note_id"])
    return str(meta.get("thread_id") or doc_id)

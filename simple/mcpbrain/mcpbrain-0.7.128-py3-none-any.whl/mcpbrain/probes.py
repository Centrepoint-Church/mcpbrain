"""Connection probes: each returns a verified tri-state the UI renders.

A probe answers "is this connection working?" from config + local filesystem
only (no network), so it is cheap enough for the wizard's status poll. State is
one of: "not_started" (never configured), "ok" (configured + verified), or
"needs_action" (configured but broken / incomplete — the UI shows a fix button).
"""
from __future__ import annotations

import json
import time as _time
from datetime import datetime, timedelta, timezone
from pathlib import Path

from mcpbrain import auth, config

_CLAUDE_STALE_DAYS = 14


def _state(state: str, detail: str = "", last_verified=None) -> dict:
    return {"state": state, "detail": detail, "last_verified": last_verified}


def probe_google(home) -> dict:
    """Token present + locally-valid (no network refresh)."""
    token_file = auth.token_path()
    if not token_file.exists():
        return _state("not_started", "Not signed in")
    try:
        from google.oauth2.credentials import Credentials
        creds = Credentials.from_authorized_user_file(str(token_file), auth.SCOPES)
        valid = bool(creds and (creds.valid or creds.refresh_token))
    except Exception:  # noqa: BLE001 — unreadable token => needs re-auth
        return _state("needs_action", "Sign-in expired — reconnect")
    if not valid:
        return _state("needs_action", "Access expired — reconnect")
    return _state("ok", "Connected", last_verified=_mtime(token_file))


def probe_claude(home) -> dict:
    """No heartbeat → not_started; heartbeat present and fresh → ok."""
    p = Path(home) / "mcp_heartbeat.json"
    if not p.exists():
        return _state("not_started", "Plugin not connected — install the mcpbrain plugin")
    try:
        last = json.loads(p.read_text()).get("last_seen")
        if last is None:
            raise ValueError("missing last_seen")
        last_dt = datetime.fromisoformat(last)
        if last_dt.tzinfo is None:
            last_dt = last_dt.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) - last_dt > timedelta(days=_CLAUDE_STALE_DAYS):
            return _state("needs_action", "Not seen recently — open Claude Desktop", last_verified=last)
    except (OSError, ValueError):
        return _state("not_started", "Plugin not connected — install the mcpbrain plugin")
    return _state("ok", "Connected", last_verified=last)


# NOTE: ClickUp is not currently surfaced as a product connection — it was
# removed from all_connections()/verify_connections() (and the setup wizard).
# probe_clickup/_verify_clickup are kept dormant so the integration can be
# re-wired later without rebuilding the probe.
def probe_clickup(home) -> dict:
    key = config.clickup_api_key(home).strip()
    if not key:
        return _state("not_started", "Not connected")
    if not config.clickup_list_id(home).strip():
        return _state("needs_action", "API key set but no list selected")
    if not config.user_timezone(home):
        return _state("needs_action", "Set your timezone (required for deadlines)")
    return _state("ok", "Connected")


def _now_iso() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()


def _verify_clickup(home) -> dict:
    """Real ClickUp check: key+list+tz present AND a test API call resolves the list."""
    base = probe_clickup(home)
    if base["state"] != "ok":
        return base
    try:
        from mcpbrain import clickup
        clickup.list_tasks_full(home, include_closed=False)  # one API call
        return _state("ok", "Verified", last_verified=_now_iso())
    except Exception as exc:  # noqa: BLE001
        return _state("needs_action", f"ClickUp call failed — check the key ({exc.__class__.__name__})")


def _verify_google(home) -> dict:
    """Real Google check: attempt a token refresh (network).

    Distinguishes a GENUINE auth failure from a TRANSIENT network one so a
    momentary blip can't leave a sticky false "Sign-in expired":
      - RefreshError (invalid_grant — the refresh token is revoked/expired):
        real → downgrade to needs_action.
      - any other error (offline, timeout, rate-limit, DNS): transient → fall
        back to the cheap local probe (`base`), which is 'Connected' when the
        token is locally valid, rather than stamping 'expired'.
    Only verifies when the local token already looks ok; a locally-broken token
    (needs_action / not_started) is returned as-is without a pointless network call.
    """
    base = probe_google(home)
    if base["state"] != "ok":
        return base
    from google.auth.exceptions import RefreshError
    try:
        from google.oauth2.credentials import Credentials
        from google.auth.transport.requests import Request
        creds = Credentials.from_authorized_user_file(str(auth.token_path()), auth.SCOPES)
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        return _state("ok", "Verified", last_verified=_now_iso())
    except RefreshError:
        return _state("needs_action", "Sign-in expired — reconnect")
    except Exception:  # noqa: BLE001 — transient (network/timeout/rate-limit): keep local state
        return base


def _write_cache(home, cache: dict) -> None:
    """Atomically write the connections cache to connections.json."""
    import os
    import tempfile
    p = Path(home) / "connections.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(p.parent), prefix=".conn.", suffix=".tmp")
    with os.fdopen(fd, "w") as f:
        f.write(json.dumps(cache))
    os.replace(tmp, p)


def verify_connections(home, store=None) -> dict:
    """Run the expensive (network) checks and cache them to connections.json atomically."""
    verified = {"google": _verify_google(home)}
    _write_cache(home, verified)
    return verified


_BACKUP_DEFAULT_WINDOW = 7 * 86400  # 7 days in seconds
# Tolerate one missed run before flagging; see probe_backup's window comment.
_BACKUP_WINDOW_MULTIPLE = 2


def probe_backup(home) -> dict:
    cfg = config.read_config(home)
    if not cfg.get("backup"):
        return _state("not_started", "Backup off")
    snap = Path(home) / "snapshot.enc"
    if not snap.exists():
        return _state("needs_action", "No backup snapshot found")
    try:
        st = snap.stat()
    except OSError:
        return _state("needs_action", "Cannot read backup snapshot")
    if st.st_size == 0:
        return _state("needs_action", "Backup file is empty")
    # Staleness window: 2x the configured backup interval, else 7 days.
    #
    # Reads `interval_s` — the key backup_setup writes and the daemon's own
    # loader reads. This branch used to read `interval_seconds`, which NOTHING
    # in the repo has ever written, so it was dead from the day it landed
    # (2026-06-10) and the window silently stayed at the 7-day default: 7x more
    # lenient than a configured 86400, meaning a backup could be six days stale
    # and still report "On".
    #
    # 2x, not 1x, deliberately: a single failed run is routine and self-corrects
    # on the next attempt (2026-08-04 saw transient WAL-busy and broken-pipe
    # failures that did), and flagging every one of those trains people to
    # ignore the indicator. Two consecutive misses is the real signal.
    backup_cfg = cfg["backup"]
    window = _BACKUP_DEFAULT_WINDOW
    if isinstance(backup_cfg, dict):
        try:
            configured = float(backup_cfg["interval_s"])
        except (KeyError, TypeError, ValueError):
            configured = 0.0
        if configured > 0:
            window = int(configured * _BACKUP_WINDOW_MULTIPLE)
    import time

    # Prefer the recorded UPLOAD outcome over snapshot.enc's mtime. The artifact
    # is encrypted locally before the upload, so a failed run still leaves a
    # fresh snapshot.enc and the mtime check reads "On" regardless -- it stayed
    # green straight through the 2026-08-03 failure storm (57 failed uploads in
    # a day) because each failure refreshed the very file being probed. Absent
    # the state file (pre-existing installs, or before the first attempt) fall
    # back to the mtime heuristic below.
    bstate = _read_backup_state(home)
    if bstate is not None:
        failures = bstate.get("consecutive_failures") or 0
        # A hand-edited or half-written state file must degrade to the mtime
        # heuristic below, never take the whole status endpoint down with it.
        try:
            last_success = float(bstate["last_success"])
        except (KeyError, TypeError, ValueError):
            last_success = None
        if not last_success:
            return _state("needs_action",
                          f"Backup has never completed ({failures} failed attempts)")
        success_age = time.time() - last_success
        if success_age > window:
            days = int(success_age // 86400)
            return _state("needs_action",
                          f"Backup upload failing — last success {days}d ago "
                          f"({failures} failed attempts)")
        return _state("ok", "On", last_verified=_iso(last_success))

    age_seconds = time.time() - st.st_mtime
    if age_seconds > window:
        age_days = int(age_seconds // 86400)
        return _state("needs_action", f"Backup is stale (last {age_days} days ago)")
    return _state("ok", "On", last_verified=_mtime(snap))


def probe_records(home) -> dict:
    repo = Path(config.records_dir(home))
    if (repo / ".git").is_dir():
        detail = "Ready" if (repo / "CLAUDE.md").exists() else "Created (run Prepare working space)"
        return _state("ok", detail)
    return _state("not_started", "Records repo not created yet")


def probe_enrichment(home) -> dict:
    """Durable signal: the daemon stamps logs/enrich.log whenever it drains an
    enrichment batch (from the hourly enrich task or the backfill loop), so
    'Running' survives regardless of the transient enrich_inbox files it deletes
    on apply. Idle = no batch drained in the last 3 days."""
    log = Path(home) / "logs" / "enrich.log"
    try:
        fresh = (_time.time() - log.stat().st_mtime) < 3 * 86400
    except OSError:
        fresh = False
    if fresh:
        return _state("ok", "Running", last_verified=_mtime(log))
    return _state("needs_action",
                  "Idle — nothing enriched in 3 days; run the hourly enrich task "
                  "(or the backfill skill to catch up on history)")


def _mtime(p: Path):
    try:
        return datetime.fromtimestamp(p.stat().st_mtime, tz=timezone.utc).isoformat()
    except OSError:
        return None


def _iso(epoch: float):
    try:
        return datetime.fromtimestamp(epoch, tz=timezone.utc).isoformat()
    except (OSError, OverflowError, ValueError):
        return None


def _read_backup_state(home) -> dict | None:
    """The daemon's record of the last backup ATTEMPT, or None if absent.

    Written by ``daemon.write_backup_state``. None means "no record yet" —
    callers fall back to the older snapshot.enc-mtime heuristic rather than
    treating a missing file as a failure.
    """
    p = Path(home) / "backup_state.json"
    try:
        state = json.loads(p.read_text())
    except (OSError, ValueError):
        return None
    return state if isinstance(state, dict) else None


def _read_cache(home) -> dict:
    p = Path(home) / "connections.json"
    try:
        return json.loads(p.read_text())
    except (OSError, ValueError):
        return {}


# Cheap (no-network) probes, keyed by connection name. Resolved at call time
# (not captured at import) so tests can monkeypatch an individual probe.
def _cheap_probes() -> dict:
    return {
        "google": probe_google,
        "claude": probe_claude,
        "backup": probe_backup,
        "records": probe_records,
        "enrichment": probe_enrichment,
    }


def all_connections(home, store=None) -> dict:
    """All connection probes keyed by name. `store` reserved for future probes.

    Overlays a cached verified result (written by a separate cadence) on top of
    cheap live probes. The cache wins when present; the live state takes over
    immediately when a connection is removed (not_started).
    """
    cached = _read_cache(home)
    out = {}
    for name, probe in _cheap_probes().items():
        live = probe(home)
        c = cached.get(name)
        # Verified cache wins when the connection is still live (not not_started).
        # If the live probe returns not_started the connection was removed, so the
        # stale cache must not mask that — flip immediately.
        if c and live["state"] != "not_started":
            out[name] = c
        else:
            out[name] = live
    return out


def refresh_connection_cache(home, name: str = "google") -> dict | None:
    """Immediately update one connection's cached status from its cheap local
    probe, merged into connections.json.

    all_connections() lets a cached entry win over the live probe while the
    connection is up (the network 'Verified' result is richer than the cheap
    'Connected' one). That overlay means a stale 'Sign-in expired' cache keeps
    masking a just-completed re-auth until the next network verify runs. Calling
    this right after writing a new token brings the cache current at once (as
    'Connected'); the periodic verify later upgrades it to 'Verified'. No
    network, so it is safe to call inline in an OAuth callback. Returns the new
    entry, or None for an unknown name."""
    probe = _cheap_probes().get(name)
    if probe is None:
        return None
    cache = _read_cache(home)
    cache[name] = probe(home)
    _write_cache(home, cache)
    return cache[name]

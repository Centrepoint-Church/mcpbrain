"""Dashboard data layer for the mcpbrain local dashboard.

Provides:
  - actions_today(store)   — bucketed actions from SQLite
  - calendar_today(home)   — today's Google Calendar events
  - clickup_today(home)    — today's ClickUp tasks due
  - mark_done(store, id)   — close an action
  - snooze(store, id, iso) — hide an open action until a date passes
  - assemble(store, home)  — parallel fan-out returning all three + as_of
"""
from __future__ import annotations

import logging
import sqlite3
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from pathlib import Path

from mcpbrain import clickup, config

log = logging.getLogger(__name__)

_PERTH = timezone(timedelta(hours=8))  # AWST — fixed UTC+8, no DST
_CAP = 20
_NUM_RETRIES = 5  # see mcpbrain.backup._NUM_RETRIES for the full rationale


def _today_perth() -> str:
    """Return today's date in Perth time as YYYY-MM-DD."""
    return datetime.now(_PERTH).date().isoformat()


def _now_iso() -> str:
    """Return current Perth time as a full ISO string."""
    return datetime.now(_PERTH).isoformat()


def _open_ro(path: Path) -> sqlite3.Connection:
    db = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    db.row_factory = sqlite3.Row
    # Match store._open_db: a bounded busy_timeout so a dashboard read during a
    # daemon/draft WAL checkpoint waits briefly instead of failing immediately and
    # blanking the card.
    db.execute("PRAGMA busy_timeout=5000")
    try:
        import sqlite_vec  # noqa: PLC0415
        db.enable_load_extension(True)
        sqlite_vec.load(db)
        db.enable_load_extension(False)
    except Exception:
        pass  # sqlite_vec not installed or unavailable — degrade silently
    return db


def _row_to_action(row: sqlite3.Row) -> dict:
    return {
        "id": row["id"],
        "text": row["text"],
        "deadline": row["deadline"] or "",
        "org": row["org"] or "",
        "project_id": row["project_id"] or "",
        "action_type": row["action_type"] or "next",
        "waiting_on": row["waiting_on"] or "",
        "source": row["source"] or "",
    }


def queue_state(*, queued: int, unenriched_eligible: int) -> str:
    """Distinguish an empty queue from a starved producer.

    prepare_units runs inside run_cycle; when the cycle wedged, no units were
    produced and the dashboard reported 'queue clear' while 64,340 chunks were
    waiting. 'Nothing queued' is not 'nothing to do'.
    """
    if queued > 0:
        return "working"
    return "idle" if unenriched_eligible == 0 else "starved"


def actions_today(store, owner: str | None = None) -> dict:
    """Bucket open actions into overdue / due_today / upcoming / blocked.

    Reads directly from store._path (read-only SQLite URI). Degrades
    gracefully if the actions table doesn't exist yet.

    owner: the dashboard user's name. Actions explicitly owned by someone
    else are excluded; ''/NULL owners are kept (extracted from the user's own
    inbox with no named owner, almost always theirs). None applies no filter.
    """
    today = _today_perth()
    path = store._path if hasattr(store, "_path") else store.path

    overdue: list[dict] = []
    due_today: list[dict] = []
    upcoming: list[dict] = []
    blocked: list[dict] = []

    try:
        db = _open_ro(path)
        try:
            # Check action_type column exists; use COALESCE either way so the
            # query works on older schemas without the column.
            cols = {r["name"] for r in db.execute("PRAGMA table_info(actions)").fetchall()}
            if "action_type" in cols:
                at_expr = "COALESCE(action_type, 'next') AS action_type"
            else:
                at_expr = "'next' AS action_type"
            if "waiting_on" in cols:
                wo_expr = "COALESCE(waiting_on,'') AS waiting_on"
            else:
                wo_expr = "'' AS waiting_on"

            owner_clause, params = "", []
            if owner is not None:
                owner_clause = (
                    " AND (owner IS NULL OR owner='' OR lower(owner)=lower(?))"
                )
                params.append(owner)

            # Hide snoozed actions until their date passes. A snoozed_until that
            # is empty/NULL or already <= today is shown; a future date is
            # filtered out and the action reappears once today catches up. String
            # comparison is correct for the YYYY-MM-DD ISO format. Guarded on the
            # column existing so the read still works on pre-snooze schemas.
            snooze_clause = ""
            if "snoozed_until" in cols:
                snooze_clause = (
                    " AND (snoozed_until IS NULL OR snoozed_until='' "
                    "OR snoozed_until <= ?)"
                )
                params.append(today)

            rows = db.execute(
                f"SELECT id, text, COALESCE(deadline,'') AS deadline, "
                f"COALESCE(org,'') AS org, COALESCE(project_id,'') AS project_id, "
                f"{at_expr}, "
                f"{wo_expr}, COALESCE(source,'') AS source "
                f"FROM actions WHERE status='open'{owner_clause}{snooze_clause}",
                params,
            ).fetchall()
        finally:
            db.close()
    except sqlite3.OperationalError as exc:
        log.warning("actions_today: cannot read actions table: %s", exc)
        return {"overdue": [], "due_today": [], "upcoming": [], "blocked": []}

    for row in rows:
        action = _row_to_action(row)
        dl = action["deadline"]

        # blocked bucket (overlaps with others)
        if action["waiting_on"]:
            blocked.append(action)

        if dl and dl < today:
            overdue.append(action)
        elif dl == today:
            due_today.append(action)
        else:
            upcoming.append(action)

    # Sort and cap
    overdue.sort(key=lambda a: a["deadline"])
    overdue = overdue[:_CAP]

    due_today = due_today[:_CAP]

    # upcoming: sort by deadline ASC, empty deadline last
    upcoming.sort(key=lambda a: (a["deadline"] == "", a["deadline"]))
    upcoming = upcoming[:_CAP]

    blocked = blocked[:_CAP]

    return {
        "overdue": overdue,
        "due_today": due_today,
        "upcoming": upcoming,
        "blocked": blocked,
    }


def calendar_today(home) -> list[dict]:
    """Return today's Google Calendar events, parsed for the dashboard.

    Degrades to [] if calendar scope is missing or any error occurs.
    """
    try:
        # Late import so the module doesn't break if google-api-python-client
        # isn't installed in this environment.
        from mcpbrain import auth  # noqa: PLC0415

        try:
            services = auth.build_google_services(token_file=auth.token_path())
        except Exception as exc:
            log.warning("calendar_today: could not load Google credentials: %s", exc)
            return []

        if "calendar_service" not in services:
            log.info("calendar_today: calendar_service not available (scope missing or token absent)")
            return []

        service = services["calendar_service"]

        # Today's window in UTC. Perth is UTC+8, so midnight Perth = today 16:00 UTC previous day.
        today_perth = datetime.now(_PERTH).date()
        start_perth = datetime(today_perth.year, today_perth.month, today_perth.day,
                               0, 0, 0, tzinfo=_PERTH)
        end_perth = start_perth + timedelta(days=1)
        time_min = start_perth.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        time_max = end_perth.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

        result = (
            service.events()
            .list(
                calendarId="primary",
                timeMin=time_min,
                timeMax=time_max,
                singleEvents=True,
                orderBy="startTime",
                maxResults=_CAP,
            )
            .execute(num_retries=_NUM_RETRIES)
        )

        events = []
        for item in result.get("items", []):
            start_block = item.get("start", {})
            end_block = item.get("end", {})

            all_day = "date" in start_block and "dateTime" not in start_block

            if all_day:
                start_str = ""
                end_str = ""
            else:
                raw_start = start_block.get("dateTime", "")
                raw_end = end_block.get("dateTime", "")
                # Parse to local (Perth) HH:MM
                try:
                    dt_start = datetime.fromisoformat(raw_start)
                    start_str = dt_start.astimezone(_PERTH).strftime("%H:%M")
                except (ValueError, TypeError):
                    start_str = ""
                try:
                    dt_end = datetime.fromisoformat(raw_end)
                    end_str = dt_end.astimezone(_PERTH).strftime("%H:%M")
                except (ValueError, TypeError):
                    end_str = ""

            # Attendee names for meeting-pack prep. Exclude the owner (self) and
            # room/equipment resources — neither is someone to prepare for.
            # displayName is preferred; email is the fallback when it's absent.
            attendees = [
                (att.get("displayName") or att.get("email", "")).strip()
                for att in item.get("attendees", [])
                if not att.get("resource") and not att.get("self")
            ]
            attendees = [a for a in attendees if a]

            events.append({
                "id": item.get("id", ""),
                "title": item.get("summary", "(no title)"),
                "start": start_str,
                "end": end_str,
                "all_day": all_day,
                "location": item.get("location", ""),
                "attendees": attendees,
                "has_pack": False,
            })

        return events

    except Exception as exc:  # noqa: BLE001
        log.warning("calendar_today: unexpected error: %s", exc)
        return []


def clickup_today(home) -> list[dict]:
    """Return ClickUp tasks due today or earlier.

    Returns the search_tasks result directly (already [] on missing config).
    """
    today = _today_perth()
    return clickup.search_tasks(home, due_date_lte=today)


def mark_done(store, action_id: int) -> bool:
    """Mark a unified action as done. Returns True if a row was updated.

    Routes through Store.set_action_status so the write goes through the same
    connection discipline as every other store write (post-Phase-1 review fix:
    the original bare sqlite3.connect predated the store being passed whole
    to ControlServer).
    """
    try:
        return store.set_action_status(
            action_id, "done", resolved_by="dashboard", only_if_open=True) > 0
    except sqlite3.Error as exc:
        log.warning("mark_done: error updating action %s: %s", action_id, exc)
        return False


def snooze(store, action_id: int, until_iso: str) -> bool:
    """Snooze an open action until until_iso. Returns True if a row was updated.

    Routes through Store.snooze_action (same connection discipline as mark_done).
    A missing or closed action returns False; an invalid date string raises
    ValueError, which the control API maps to a 400.
    """
    return store.snooze_action(action_id, until_iso)


def changes_digest(store) -> dict:
    """Recent system writes + open findings for the dashboard Review card.

    Uses the Store methods directly: the dashboard runs in the daemon process
    (same writer), so this is safe; the read-only URI pattern in actions_today
    predates the store being passed in whole.
    """
    try:
        return {"changes": store.recent_changes(limit=20),
                "findings": store.open_findings()[:20]}
    except Exception as exc:  # noqa: BLE001 — degrade, never break the dashboard
        log.warning("changes_digest failed: %s", exc)
        return {"changes": [], "findings": []}


def inbox_today(store, limit: int = 20) -> list[dict]:
    """Return emails needing attention: reply_needed=1 OR request/decision type, last 7 days."""
    cutoff = (datetime.now(_PERTH) - timedelta(days=7)).date().isoformat()
    path = store._path if hasattr(store, "_path") else store.path
    try:
        db = _open_ro(path)
        try:
            cols = {r["name"] for r in db.execute("PRAGMA table_info(email_context)").fetchall()}
            if not cols:
                return []
            rows = db.execute(
                "SELECT message_id, subject, sender, sender_email, date_iso, "
                "org, content_type, summary, "
                "COALESCE(reply_needed,0) AS reply_needed, "
                "COALESCE(reply_reason,'') AS reply_reason "
                "FROM email_context "
                "WHERE (reply_needed=1 OR content_type IN ('request','decision')) "
                "  AND date_iso >= ? "
                "ORDER BY date_iso DESC LIMIT ?",
                (cutoff, limit),
            ).fetchall()
        finally:
            db.close()
    except sqlite3.OperationalError as exc:
        log.warning("inbox_today: cannot read email_context: %s", exc)
        return []
    return [dict(r) for r in rows]


def circles_today(store) -> list[dict]:
    """Detected community clusters (level=0) as a compact list. Degrades to []."""
    try:
        return [
            {"community_id": r["community_id"],
             "title": r.get("title") or f"Circle {r['community_id']}",
             "summary": r.get("summary") or "",
             "member_count": r.get("member_count") or 0,
             "key_entities": r.get("key_entities") or ""}
            for r in store.list_communities()
        ]
    except Exception as exc:  # noqa: BLE001
        log.warning("circles_today failed: %s", exc)
        return []


def _graph_counts(path: Path) -> dict:
    """Row counts for the knowledge-graph + cold-chunk stats, read-only.

    Every table is guarded on existence so a fresh store (or an older schema
    without a table/column) degrades each count to 0 rather than failing the
    whole stats payload. Table names come from a fixed allowlist, never input.
    """
    out = {"entities": 0, "relations": 0, "observations": 0, "cold": 0}
    try:
        db = _open_ro(path)
        try:
            tables = {r[0] for r in db.execute(
                "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}

            def count(table: str) -> int:
                if table not in tables:
                    return 0
                return db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]

            out["entities"] = count("entities")
            out["relations"] = count("entity_relations")
            out["observations"] = count("entity_observations")
            if "chunks" in tables:
                cols = {r["name"] for r in db.execute("PRAGMA table_info(chunks)").fetchall()}
                if "enrich_state" in cols:
                    out["cold"] = db.execute(
                        "SELECT COUNT(*) FROM chunks WHERE enrich_state='cold'").fetchone()[0]
        finally:
            db.close()
    except sqlite3.OperationalError as exc:
        log.warning("_graph_counts: cannot read graph tables: %s", exc)
    return out


_SOURCE_LABELS = {"gmail": "Gmail", "drive": "Drive", "calendar": "Calendar"}
_CONNECTION_LABELS = {
    "google": "Google", "claude": "Claude plugin", "backup": "Backup",
    "records": "Records", "enrichment": "Enrichment",
}


def stats(store, home, status: dict) -> dict:
    """Assemble the daemon/plugin stats payload for the dashboard.

    Pure w.r.t. its inputs: the daemon's status() snapshot supplies index/enrich
    counts, spool depth, per-source backfill, connections, version and paused
    state; the store supplies the graph row-counts and community count. Kept
    testable by taking `status` as an argument rather than reaching for a daemon.
    """
    path = store._path if hasattr(store, "_path") else store.path
    gc = _graph_counts(path)
    try:
        communities = len(store.list_communities())
    except Exception as exc:  # noqa: BLE001 — degrade, never break the payload
        log.warning("stats: list_communities failed: %s", exc)
        communities = 0

    indexed = int(status.get("chunk_count") or 0)
    enriched = int(status.get("enriched_count") or 0)
    entities = gc["entities"]
    relations = gc["relations"]

    backfill = status.get("backfill") or {}
    sources = [
        {"name": s, "label": _SOURCE_LABELS[s],
         "reached": (backfill.get(s) or {}).get("reached"),
         "done": bool((backfill.get(s) or {}).get("done"))}
        for s in ("gmail", "drive", "calendar")
    ]

    conns = status.get("connections") or {}
    connections = [
        {"name": k, "label": _CONNECTION_LABELS.get(k, k.title()),
         "state": (conns.get(k) or {}).get("state", "not_started"),
         "detail": (conns.get(k) or {}).get("detail", "")}
        for k in ("google", "claude", "backup", "records", "enrichment") if k in conns
    ]

    eligible = max(0, indexed - gc["cold"] - enriched)
    queued = status.get("spool", {}).get("pending", 0)

    return {
        "as_of": _now_iso(),
        "index": {
            "indexed": indexed,
            "enriched": enriched,
            "cold": gc["cold"],
            # Measured against ELIGIBLE (warm) chunks, not the whole corpus:
            # cold/low-signal chunks are deliberately never enriched, so
            # including them in the denominator would peg the number low forever
            # and read as "behind" when the pipeline is working as designed.
            "enriched_pct": (
                round(enriched / (indexed - gc["cold"]) * 100)
                if (indexed - gc["cold"]) > 0 else 0
            ),
            "queue": queue_state(queued=queued, unenriched_eligible=eligible),
        },
        "graph": {
            "entities": entities,
            "relations": relations,
            "observations": gc["observations"],
            "communities": communities,
            "links_per_entity": round(relations / entities, 1) if entities else 0.0,
        },
        "sources": sources,
        "spool": status.get("spool") or {"pending": 0, "inbox": 0},
        "connections": connections,
        "daemon": {
            "paused": bool(status.get("paused")),
            "version": status.get("version") or "",
            "enrich_enabled": bool(status.get("enrich_enabled")),
            "open_findings": int(status.get("open_findings") or 0),
        },
    }


def annotate_meeting_packs(store, calendar_events: list[dict]) -> list[dict]:
    """Set has_pack=True on calendar events that have a meeting pack in the store."""
    if not calendar_events:
        return []
    path = store._path if hasattr(store, "_path") else store.path
    packed = set()
    try:
        db = _open_ro(path)
        try:
            tables = {r[0] for r in db.execute(
                "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
            if "meeting_packs" in tables:
                rows = db.execute("SELECT event_id FROM meeting_packs").fetchall()
                packed = {r["event_id"] for r in rows}
        finally:
            db.close()
    except sqlite3.OperationalError as exc:
        log.warning("annotate_meeting_packs: db error: %s", exc)
    result = []
    for ev in calendar_events:
        ev_copy = dict(ev)
        ev_copy["has_pack"] = ev.get("id", "") in packed
        result.append(ev_copy)
    return result


def assemble(store, home) -> dict:
    """Fan-out to all data sources in parallel and return combined payload."""
    owner = config.owner_name(home)
    with ThreadPoolExecutor(max_workers=6) as pool:
        fut_actions = pool.submit(actions_today, store, owner)
        fut_calendar = pool.submit(calendar_today, home)
        fut_clickup = pool.submit(clickup_today, home)
        fut_digest = pool.submit(changes_digest, store)
        fut_inbox = pool.submit(inbox_today, store)
        fut_circles = pool.submit(circles_today, store)

        try:
            actions_result = fut_actions.result()
        except Exception as exc:
            log.warning("assemble: actions_today failed: %s", exc)
            actions_result = {"overdue": [], "due_today": [], "upcoming": [], "blocked": []}

        try:
            calendar_result = fut_calendar.result()
        except Exception as exc:
            log.warning("assemble: calendar_today failed: %s", exc)
            calendar_result = []

        try:
            clickup_result = fut_clickup.result()
        except Exception as exc:
            log.warning("assemble: clickup_today failed: %s", exc)
            clickup_result = []

        try:
            digest_result = fut_digest.result()
        except Exception as exc:
            log.warning("assemble: changes_digest failed: %s", exc)
            digest_result = {"changes": [], "findings": []}

        try:
            inbox_result = fut_inbox.result()
        except Exception as exc:
            log.warning("assemble: inbox_today failed: %s", exc)
            inbox_result = []

        try:
            circles_result = fut_circles.result()
        except Exception as exc:
            log.warning("assemble: circles_today failed: %s", exc)
            circles_result = []

    # Annotate calendar events with meeting pack status (read-only, fast)
    try:
        calendar_result = annotate_meeting_packs(store, calendar_result)
    except Exception as exc:
        log.warning("assemble: annotate_meeting_packs failed: %s", exc)

    return {
        "actions": actions_result,
        "calendar": calendar_result,
        "clickup": clickup_result,
        "inbox": inbox_result,
        "circles": circles_result,
        "changes": digest_result["changes"],
        "findings": digest_result["findings"],
        "as_of": _now_iso(),
    }

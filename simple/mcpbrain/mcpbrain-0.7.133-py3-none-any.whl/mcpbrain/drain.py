"""Drain step: consume enrich_inbox/*.json, apply, mark, resolve, delete.

The daemon runs this. A stateless extractor session writes one batch file per
cycle into MCPBRAIN_HOME/enrich_inbox/<batch>.json. drain reads each file,
validates it against the contract, applies every extraction through Phase 1's
apply(), marks that thread's chunks enriched, feeds merge-review answers into
entity resolution, and deletes the file once every part of it succeeded. A
malformed or contract-violating file is moved to enrich_inbox/bad/ rather than
crashing the daemon. One bad item never aborts the batch.

Home resolution mirrors prepare.py: spool paths resolve under config.app_dir()
(which reads MCPBRAIN_HOME), with an optional home= override taking
precedence.

The apply() seam
----------------
apply is Phase 1's graph_write.apply, injected as a parameter rather than
imported so this module stays importable before Phase 1 lands. The real
signature is:

    apply(store, extraction, *, doc_ids, identity="...", clock=None) -> summary_dict

It upserts entities, relations, role observations, topics and the email_context
row for one clean contract envelope. Idempotency rests on its upsert/dedup, so
re-applying the same extraction is safe.

drain keeps an embedder= parameter because the daemon passes one, but it does
NOT forward it to apply: the structural apply does not consume an embedder
(action/topic embedding is a later Phase 1 task). The parameter is reserved for
when that work lands and drain needs to hand an embedder to a writer that takes
one.
"""

import json
import logging
import os
from contextlib import nullcontext
from pathlib import Path

from mcpbrain import config, orgs, review_apply
from mcpbrain.contract import (
    normalise_org, sanitize_batch, validate_batch_wrapper, validate_extraction,
)
from mcpbrain.store import ENRICH_LOGIC_VERSION, _file_key_from_doc_id

log = logging.getLogger(__name__)

# Q8: max times an extraction covering a chunk may come back empty/invalid before
# we consume the chunk (mark_enriched) instead of re-queuing it forever. Bounds the
# re-extract loop for genuinely content-empty docs without losing transient retries.
_EMPTY_ATTEMPT_CAP = 3

# Capture kinds whose apply path writes the records GIT REPO and never the
# store. drain_captures runs these OUTSIDE its bulk section: they need no lock,
# and an unbounded `git commit` (a stale .git/index.lock blocks forever) holding
# _bulk_lock would starve every gated maintenance pass and the backup.
_RECORDS_KINDS = ("decision", "continuity", "memory")


def _give_up_or_bump(store, doc_ids, summary) -> tuple[bool, int | None]:
    """Bump the empty-attempt counter for these chunks; once it reaches
    _EMPTY_ATTEMPT_CAP, consume them (mark_enriched) so a genuinely
    un-extractable doc stops re-queuing forever. Best-effort — bookkeeping must
    never break a drain run.

    Returns (gave_up, attempts): gave_up is True iff the cap was reached this
    call (and mark_enriched/summary["gave_up"] were applied); attempts is the
    post-bump attempt count, or None if doc_ids was empty or bookkeeping
    raised. Callers that need to log on genuine give-up (only the
    invalid-extraction site does) use this to reproduce the pre-refactor
    log line without making the other call site start logging too."""
    if not doc_ids:
        return False, None
    try:
        attempts = store.bump_enrich_attempts(doc_ids)
        if attempts >= _EMPTY_ATTEMPT_CAP:
            store.mark_enriched(doc_ids)
            summary["gave_up"] = summary.get("gave_up", 0) + 1
            return True, attempts
        return False, attempts
    except Exception as exc:  # noqa: BLE001 — bookkeeping must not break drain
        log.debug("drain: attempt-cap bookkeeping failed: %s", exc)
        return False, None


def _name_grounded(name: str, source_lower: str) -> bool:
    """True if an extracted name is plausibly grounded in the source text.

    Delegates to chunking.name_in_text, which prepare's context scoping also
    uses in the opposite direction.
    """
    from mcpbrain.chunking import name_in_text
    return name_in_text(name, source_lower)


def _grounding_filter(extraction: dict) -> tuple[dict, int]:
    """Remove entities/relations with no lexical anchor in the source text (Q2).

    Deterministic, no LLM (mcpbrain is subscription-only; a per-triple LLM check
    would be the stronger but far costlier option — see #9). An entity is kept if
    its name is grounded (see _name_grounded); a relation is kept if BOTH endpoint
    names are grounded. Returns (filtered_extraction, dropped_count); input is not
    mutated.
    """
    source = " ".join(
        (m.get("text") or m.get("body") or "")
        for m in (extraction.get("messages") or [])
    ).lower().strip()
    if not source:
        # .strip() is load-bearing, not tidying. Pushed payloads carry message
        # METADATA only (message_id/sender/date/subject) — bodies stopped being
        # echoed back by the model in 0.7.72 — so every message contributes "".
        # For a single-message thread " ".join([""]) == "" and this guard fires
        # correctly; for TWO messages it is " ", which is truthy, so the guard
        # was skipped and every name was then judged ungrounded against a lone
        # space. Measured on real pushed payloads: entities 5->0, 6->0, i.e. the
        # whole extraction discarded for any multi-message thread. Stripping
        # makes the no-op uniform.
        #
        # This keeps the flag SAFE, not useful: with no body text there is
        # nothing to ground against, so schema_grounding is inert either way.
        # Making it do real work needs drain to re-hydrate the source text from
        # the store (it has `store` and doc_ids_for_messages right here) before
        # calling this — that is the actual fix, and it is not this one.
        return extraction, 0

    out = dict(extraction)
    dropped = 0

    ents = out.get("entities")
    if isinstance(ents, list):
        kept = [e for e in ents
                if isinstance(e, dict) and _name_grounded(e.get("name") or "", source)]
        dropped += len(ents) - len(kept)
        out["entities"] = kept

    rels = out.get("relations")
    if isinstance(rels, list):
        kept = []
        for r in rels:
            if not isinstance(r, dict):
                kept.append(r)
                continue
            if (_name_grounded(r.get("source_name") or "", source)
                    and _name_grounded(r.get("target_name") or "", source)):
                kept.append(r)
            else:
                dropped += 1
        out["relations"] = kept

    return out, dropped

# Per-key drainers for optional inbox blocks. Each drainer(store, inbox_obj) called
# when the key is present; failures are isolated (log + continue). Registered by
# block modules at import time.
BLOCK_DRAINERS: dict = {}
BLOCK_DRAINERS["review_orphan"] = lambda store, data: review_apply.apply_orphan_verdicts(
    store, data.get("review_orphan") or [],
    cap=config.review_max_apply_per_run(str(config.app_dir()))
)
BLOCK_DRAINERS["review_missing_org"] = lambda store, data: review_apply.apply_missing_org_verdicts(
    store, data.get("review_missing_org") or [],
    cap=config.review_max_apply_per_run(str(config.app_dir()))
)
BLOCK_DRAINERS["review_ownerless"] = lambda store, data: review_apply.apply_ownerless_verdicts(
    store, data.get("review_ownerless") or [],
    cap=config.review_max_apply_per_run(str(config.app_dir()))
)
BLOCK_DRAINERS["review_org"] = lambda store, data: review_apply.apply_org_verdicts(
    store, data.get("review_org") or [],
    cap=config.review_max_apply_per_run(str(config.app_dir()))
)
# Curator fuzzy-merge adjudication (org layer): the subagent's pushed
# 'org_merge_review' answers ({pair_id, same, canonical}) are applied by the
# curator-scoped applier. Registered here so the org merges land on push, same
# as the local merge_answers path and the review_* families.
def _drain_org_merge_review(store, data):
    from mcpbrain import org_curate
    return org_curate.apply_org_merge_answers(
        store, data.get("org_merge_review") or [],
        cap=config.review_max_apply_per_run(str(config.app_dir())))
BLOCK_DRAINERS["org_merge_review"] = _drain_org_merge_review


def _home(home) -> Path:
    """Resolve the spool root: explicit override first, else config.app_dir()."""
    return config.spool_home(home)


def _records_repo(home) -> str:
    """Resolve the records repo path and guarantee it exists (git + scaffold).

    The daemon is the single writer; ensuring here means a freshly-onboarded user
    gets a working repo on the first cycle with no manual seeding.
    """
    from mcpbrain import records
    repo = config.records_dir(str(home))
    name = config.owner_full_name(str(home)) or "mcpbrain"
    email = config.owner_email(str(home)) or "mcpbrain@localhost"
    records.ensure_records_repo(repo, git_name=name, git_email=email)
    return repo


def _iter_inbox(home_dir: Path):
    """Yield enrich_inbox/*.json files, skipping the bad/ quarantine subdir."""
    inbox_dir = home_dir / "enrich_inbox"
    if not inbox_dir.is_dir():
        return
    for path in sorted(inbox_dir.glob("*.json")):
        if path.is_file():
            yield path


def _quarantine(path: Path) -> Path:
    """Move a malformed file to enrich_inbox/bad/, creating the dir as needed."""
    bad_dir = path.parent / "bad"
    bad_dir.mkdir(parents=True, exist_ok=True)
    target = bad_dir / path.name
    # Path.replace overwrites an existing target atomically, which would erase
    # an earlier bad file of the same name (forensic loss). Find the first free
    # -N suffix instead. Deterministic so quarantine tests stay stable; pid is
    # only there to avoid clobbering across concurrent drain processes.
    if target.exists():
        n = 1
        while True:
            candidate = bad_dir / f"{path.stem}-{os.getpid()}-{n}{path.suffix}"
            if not candidate.exists():
                target = candidate
                break
            n += 1
    path.replace(target)
    return target


def _regroup_parts(extractions: list) -> list:
    """Recombine split long threads into one extraction per thread_id.

    The prepare step splits an over-long thread into sub-parts that share a
    thread_id and carry {"part": i, "of": k} (see prepare._split_long_thread).
    This is the inverse: group by thread_id, and for any group with more than
    one part, sort by part and concatenate their messages in order into a single
    extraction. The other fields are taken from the first part, and the part/of
    keys are stripped so apply consumes a clean contract envelope. Order of the
    first appearance of each thread_id is preserved.
    """
    order = []
    groups: dict[str, list] = {}
    for ext in extractions:
        tid = ext.get("thread_id")
        if tid not in groups:
            groups[tid] = []
            order.append(tid)
        groups[tid].append(ext)

    recombined = []
    for tid in order:
        parts = groups[tid]
        if len(parts) == 1 and "part" not in parts[0]:
            recombined.append(parts[0])
            continue
        if any("part" not in p for p in parts):
            # An extractor dropped a part key on at least one member. Sorting
            # would float the no-part member to position 0 and silently misorder
            # the concatenated messages. Apply each member as-is instead;
            # apply() upserts/dedups so separate application is safe.
            log.warning("drain: thread %s has mixed part/no-part extractions; "
                        "applying parts as-is", tid)
            recombined.extend(parts)
            continue
        ordered = sorted(parts, key=lambda e: e.get("part", 0))
        of = ordered[0].get("of")
        if of and len(ordered) != of:
            # A part count that doesn't match `of` is not necessarily evidence of
            # a dropped part: parts split across separate enrich units (each
            # carrying its own part_doc_ids) drain independently and apply fine
            # on their own, one merged-group-per-unit here. Only warn when that
            # is NOT the case for every part present.
            independent = all(p.get("part_doc_ids") for p in ordered)
            (log.info if independent else log.warning)(
                "drain: thread %s received %d parts but declared of=%d; %s",
                tid, len(ordered), of,
                "parts are independently applicable (part_doc_ids present)"
                if independent else "applying incomplete thread")
        merged = dict(ordered[0])
        messages = []
        for p in ordered:
            messages.extend(p.get("messages", []))
        merged["messages"] = messages
        merged.pop("part", None)
        merged.pop("of", None)
        # Union the parts' chunk provenance so the merged extraction marks every
        # chunk its combined text covered. Only parts that landed in the SAME
        # inbox file reach here; parts split across units drain separately and
        # each marks its own chunks, which is correct by construction.
        part_ids = [d for p in ordered for d in (p.get("part_doc_ids") or [])]
        if part_ids:
            merged["part_doc_ids"] = part_ids
        recombined.append(merged)
    return recombined


def _stamp_part_doc_ids(extractions: list, unit_part_ids_by_part: dict) -> None:
    """Stamp each RAW extraction's part_doc_ids from the unit file, in place.

    UNCONDITIONAL — no "only if absent" guard: _unit_payload ships the unit's
    threads[], part_doc_ids included, to the model verbatim as its input context,
    so the model can echo the key back into its output. part_doc_ids decides which
    chunks are marked enriched, so the system's value always wins.

    Keyed by (thread_id, part), not thread_id alone: prepare's packing can put
    SEVERAL parts of one split thread in a single unit, and a thread-only key
    unioned all of them, so a model that merged or dropped a part attached — and
    therefore marked enriched — chunks that extraction never covered. An unsplit
    thread carries no `part` and keys as (thread_id, None), exactly how an
    extraction with no `part` looks itself up.

    `part` is MODEL-ECHOED, so it is verified, not trusted. Per thread, the
    echoed parts must be a clean permutation of the parts the unit actually
    holds; when they are not (a duplicate, or a number the unit has no part
    for) we fall back to POSITIONAL assignment — extractions in order against
    the unit's parts in order, which is how the model is asked to emit them
    (one extraction per threads[] entry).

    The bad echo this guards is not cosmetic. If part 1's extraction claims
    part 2's number, part 2's chunks get marked enriched while only part 1's
    text was ever extracted — silent content loss, and the chunks never
    re-queue. The duplicate case is milder (the un-stamped part simply
    re-queues), but both are corrected the same way.

    A thread with no unit-file entry at all is left alone, so
    _resolve_doc_ids' message-id fallback handles it rather than this
    inventing a resolution.
    """
    by_thread: dict = {}
    for raw in extractions:
        if isinstance(raw, dict) and raw.get("thread_id") is not None:
            by_thread.setdefault(raw["thread_id"], []).append(raw)

    unit_parts: dict = {}
    for (tid, part), ids in unit_part_ids_by_part.items():
        unit_parts.setdefault(tid, []).append((part, ids))
    # Sort by part so positional fallback pairs part 1 with the first
    # extraction. None (an unsplit thread) is the only entry when present.
    for tid in unit_parts:
        unit_parts[tid].sort(key=lambda pi: (pi[0] is not None, pi[0]))

    for tid, raws in by_thread.items():
        parts = unit_parts.get(tid)
        if not parts:
            continue                       # no unit data; leave for the fallback
        echoed = [r.get("part") for r in raws]
        declared = [p for p, _ in parts]
        if sorted(echoed, key=lambda p: (p is not None, p)) == declared:
            lookup = dict(parts)
            for raw in raws:
                raw["part_doc_ids"] = list(lookup[raw.get("part")])
            continue
        log.warning("drain: thread %s echoed parts %r but the unit holds %r; "
                    "assigning part_doc_ids positionally", tid, echoed, declared)
        for raw, (_, ids) in zip(raws, parts):
            raw["part_doc_ids"] = list(ids)


def _resolve_doc_ids(store, extraction: dict, unit_messages_by_thread: dict) -> list[str]:
    """The chunks this extraction covers, cold-filtered, ready for apply/mark.

    Precedence:
      1. `part_doc_ids` — exactly the chunks a seam-split part covered. System-
         owned (prepare writes it into the unit; drain reads it from there, never
         from the model's echo). Required for correctness on Drive documents,
         where doc_ids_for_messages resolves a file_id to EVERY chunk of the file
         — so without this, part 1 marks the whole document and parts 2..N are
         wasted.
      2. the model's message ids.
      3. the unit's canonical message ids, when the model echoed bad ones.

    drop_cold applies to every branch: a file-wide resolve returns cold chunks the
    extraction never covered (the 0.7.103 fix).
    """
    part_ids = extraction.get("part_doc_ids")
    if part_ids:
        # A unit written before a reflow can name ids the reflow deleted (the
        # document now has fewer chunks): resolve them through reflow_map to
        # the chunk holding that text now (spec §3) instead of silently marking
        # nothing. getattr only because unit-test fakes predate the method --
        # the real Store always has it, and tests/test_store_reflow.py proves
        # this path against one.
        resolve = getattr(store, "resolve_reflowed_ids", None)
        if resolve is not None:
            part_ids = resolve(list(part_ids))
        return store.drop_cold(list(part_ids))
    msg_ids = [m.get("message_id") for m in extraction.get("messages", [])
               if m.get("message_id")]
    doc_ids = store.doc_ids_for_messages(msg_ids) if msg_ids else []
    if not doc_ids:
        _u = unit_messages_by_thread.get(extraction.get("thread_id")) or []
        _umids = [m.get("message_id") for m in _u if m.get("message_id")]
        doc_ids = store.doc_ids_for_messages(_umids) if _umids else []
    return store.drop_cold(doc_ids) if doc_ids else []


def _payload_covers(store, extraction: dict, doc_ids: list[str],
                    unit_messages_by_thread: dict) -> list[str]:
    """The chunks an extraction's text was made from (system-owned, never the
    model's echo): its part_doc_ids when the unit was seam-split (doc_ids are
    exactly those), else the unit's per-message chunk_doc_ids -- reassemble_thread
    stamps them on every message and prepare keeps them in the unit file.
    Nothing known -> covers nothing, so the payload is never published as the
    whole file's."""
    if extraction.get("part_doc_ids"):
        return list(doc_ids)
    msgs = unit_messages_by_thread.get(extraction.get("thread_id")) or []
    ids = [d for m in msgs for d in (m.get("chunk_doc_ids") or [])]
    if not ids:
        return []
    resolve = getattr(store, "resolve_reflowed_ids", None)
    if resolve is not None:
        ids = resolve(ids)
    keep = set(ids)
    return [d for d in doc_ids if d in keep]


def drain(store, *, home=None, apply=None, embedder=None, budget=None,
         bulk_section=None) -> dict:
    """Process every inbox file. Returns a summary dict.

    Summary keys: files, applied, marked, merges, quarantined, entities,
    relations.

    For each valid file, every extraction is applied through the injected
    apply() then its thread's chunks are marked enriched. apply runs BEFORE
    mark so a crash leaves the chunks unmarked and the thread is reprocessed
    next cycle. A failure on any extraction is logged and isolated: its chunks
    are not marked and the file is kept (not deleted) so unfinished threads
    retry. A file is only fully successful when every extraction applied.

    Unbounded per cycle (unlike index_pending) for the same reason embedding
    used to be: it processes every inbox file before returning. `budget` (a
    `Budget`, or None for unbounded) is checked once per inbox file; once it
    expires the loop stops and `summary["budget_spent"] = True` — remaining
    files are untouched (not deleted) and retried on the next cycle.

    `bulk_section` (Task 2 duty-cycle fix: a zero-arg context-manager factory,
    default `contextlib.nullcontext`) brackets one WHOLE FILE's processing —
    matching the existing per-file budget-check granularity — so `_bulk_lock`
    is released between files rather than held for the whole drain() call. A
    soak test showed the latter shape starves the maintenance thread's 5s
    acquire almost every time on a sustained backlog even though this call was
    already budget-bounded.
    """
    if bulk_section is None:
        bulk_section = nullcontext
    home_dir = _home(home)
    summary = {"files": 0, "applied": 0, "marked": 0, "merges": 0,
               "quarantined": 0, "entities": 0, "relations": 0,
               "skipped": 0, "dropped_items": 0}

    # Q3: build the write-time dedup index ONCE per drain run (not per apply) when
    # the flag is on, and reuse it across every extraction — avoids rebuilding the
    # 25k-entity index on each apply() and lets dedup see entities created earlier
    # in this same run. None when the flag is off (apply skips dedup entirely).
    _entity_index = None
    if config.write_time_dedup_enabled(str(home_dir)):
        try:
            from mcpbrain.resolve import build_entity_index
            _entity_index = build_entity_index(store.entities_for_resolution())
        except Exception as exc:  # noqa: BLE001
            log.warning("drain: failed to build write-time dedup index: %s", exc)
            _entity_index = None

    for path in _iter_inbox(home_dir):
        if budget is not None and budget.expired():
            summary["budget_spent"] = True
            break
        with bulk_section():
            try:
                data = json.loads(path.read_text())
            except (ValueError, OSError) as exc:
                log.warning("drain: malformed inbox file %s, quarantining: %s", path.name, exc)
                _quarantine(path)
                summary["quarantined"] += 1
                continue

            # Tolerant validation: only wrapper / merge_answers problems (structural,
            # or irreversible-merge risk) quarantine the whole file. A single bad
            # extraction is sanitised (droppable noise removed) and, if still
            # invalid, skipped individually — one malformed relation from the LLM
            # must not discard an entire batch of good extractions.
            problems = validate_batch_wrapper(data)
            if problems:
                log.warning("drain: wrapper contract violation in %s, quarantining: %s",
                            path.name, "; ".join(problems[:5]))
                _quarantine(path)
                summary["quarantined"] += 1
                continue

            data, dropped_noise = sanitize_batch(data)
            if dropped_noise:
                log.warning("drain: dropped %d malformed relation/action item(s) in %s",
                            dropped_noise, path.name)
                summary["dropped_items"] = summary.get("dropped_items", 0) + dropped_noise

            summary["files"] += 1
            file_ok = True

            # Build the system-owned lookups from the unit file (when present)
            # BEFORE anything reads the model's output. Message metadata and
            # part_doc_ids come from prepare._thread_block/_split_long_thread,
            # not the model; we read them back here so drain can inject them.
            #
            # part_doc_ids is keyed by (thread_id, part), NOT by thread_id alone:
            # prepare's packing can put SEVERAL parts of one split thread in a
            # single unit, and a thread-only key unioned all of them, so a model
            # that merged or dropped a part attached — and therefore marked
            # enriched — chunks that extraction never covered. A unit entry for an
            # ordinary unsplit thread carries no `part` and keys as
            # (thread_id, None), which is exactly how an extraction with no `part`
            # key looks itself up.
            unit_messages_by_thread: dict = {}
            unit_part_ids_by_part: dict = {}
            unit_id = data.get("unit_id")
            if unit_id:
                unit_path = home_dir / "enrich_queue" / "units" / f"{unit_id}.json"
                try:
                    unit_data = json.loads(unit_path.read_text())
                    for t in (unit_data.get("threads") or []):
                        tid = t.get("thread_id")
                        msgs = t.get("messages")
                        if tid and isinstance(msgs, list) and msgs:
                            unit_messages_by_thread[tid] = msgs
                        if tid and t.get("part_doc_ids"):
                            unit_part_ids_by_part[(tid, t.get("part"))] = list(
                                t["part_doc_ids"])
                except (OSError, ValueError) as exc:
                    log.debug("drain: could not read unit file for %s: %s", unit_id, exc)

            # Stamp part_doc_ids from the unit file BEFORE _regroup_parts (which
            # unions them) ever reads them. See _stamp_part_doc_ids for why this
            # is unconditional and why the model's `part` is verified, not
            # trusted.
            _stamp_part_doc_ids(data["extractions"], unit_part_ids_by_part)

            extractions = _regroup_parts(data["extractions"])
            taxonomy = orgs.taxonomy_from_config(home)
            # Fail loudly on a misconfigured call rather than letting the per-
            # extraction handler swallow the TypeError, set file_ok=False, keep the
            # file, and loop forever. Raised before the loop so it is never caught.
            if extractions and apply is None:
                raise TypeError("drain() requires an apply callable; inject graph_write.apply")

            for extraction in extractions:
                # Message metadata is system-owned: attach the unit's original messages
                # (built by prepare._thread_block) so graph_write derives lead msg/date/sender
                # from authoritative data, not the model's echo. Injection happens BEFORE
                # validate_extraction so the Q8 attempt-cap logic (which reads messages[])
                # has ids available even when the model omitted messages[] AND the extraction
                # is contract-invalid — without this the chunk re-queues forever on empty
                # content without bumping the attempt counter.
                # part_doc_ids is NOT injected here: it is stamped per (thread_id,
                # part) on the raw extractions above, before _regroup_parts unions
                # them. A thread-only key here attached the union of every packed
                # part's ids to whichever extraction came back.
                if not extraction.get("messages") and unit_messages_by_thread.get(extraction.get("thread_id")):
                    extraction["messages"] = unit_messages_by_thread[extraction["thread_id"]]

                # Per-extraction contract check (post-sanitise). A structurally
                # invalid extraction (missing thread_id, bad messages, unknown
                # content_type…) is dropped and logged, NOT quarantined with the
                # batch — its chunks stay enriched=0 and re-queue next prepare. This
                # does not flip file_ok: the file is still consumed (we did our best
                # with the salvageable extractions).
                ext_problems = validate_extraction(extraction)
                if ext_problems:
                    log.warning("drain: skipping invalid extraction (thread %s) in %s: %s",
                                extraction.get("thread_id", "?"), path.name,
                                "; ".join(ext_problems[:3]))
                    summary["skipped"] = summary.get("skipped", 0) + 1
                    # Q8: bound the re-queue loop. Skipped chunks normally stay
                    # enriched=0 to re-queue, but a genuinely content-empty doc would
                    # then re-extract every cycle forever. After _EMPTY_ATTEMPT_CAP
                    # tries, consume the chunks so the loop terminates (transient
                    # extractor failures still get their retries first).
                    #
                    # The doc_ids resolution is deliberately INSIDE this try, matching
                    # the pre-_give_up_or_bump behaviour: a store lacking/failing
                    # doc_ids_for_messages here must not crash drain(), only skip this
                    # extraction's give-up bookkeeping (regression caught in release
                    # verification — narrowing this to wrap only _give_up_or_bump broke
                    # a real caller whose store didn't implement doc_ids_for_messages).
                    try:
                        _mids = [m.get("message_id") for m in (extraction.get("messages") or [])
                                 if m.get("message_id")]
                        _dids = store.doc_ids_for_messages(_mids) if _mids else []
                        gave_up, attempts = _give_up_or_bump(store, _dids, summary)
                        if gave_up:
                            log.info("drain: giving up on thread %s after %d empty "
                                     "attempts; consuming %d chunk(s)",
                                     extraction.get("thread_id", "?"), attempts, len(_dids))
                    except Exception as exc:  # noqa: BLE001 — bookkeeping must not break drain
                        log.debug("drain: attempt-cap bookkeeping failed: %s", exc)
                    continue
                thread_id = extraction["thread_id"]
                # Org drift gate: canonicalise; coerce an unconfigured org to
                # "unknown" and record it, so repeated sightings of a real org
                # surface as a "add it to config orgs?" finding instead of either
                # quarantining the thread or vanishing silently.
                raw_org = normalise_org(extraction, taxonomy)
                if raw_org is not None:
                    log.info("drain: unconfigured org %r on thread %s coerced to "
                             "'unknown'", raw_org, thread_id)
                    store.record_finding(
                        "org_unrecognised", ref_id=raw_org.strip().lower(),
                        org="unknown",
                        summary=f"Extractor returned unconfigured org '{raw_org}'",
                        detail=f"Last seen on thread {thread_id}; coerced to "
                               f"'unknown'. If this is a real organisation, add it "
                               f"to the orgs list in config.json.",
                        severity="info")
                # Q2 grounding check: drop entities/relations not found in source text.
                if config.schema_grounding_enabled(str(home_dir)):
                    extraction, grounding_dropped = _grounding_filter(extraction)
                    if grounding_dropped:
                        log.debug("drain: grounding filter dropped %d item(s) on thread %s",
                                  grounding_dropped, thread_id)
                        summary["dropped_items"] = summary.get("dropped_items", 0) + grounding_dropped

                # Recover the chunks this extraction covers, part-precise when a
                # seam-split part's part_doc_ids are present, else by message id
                # (NOT by a thread-wide query). Marking only the chunks actually
                # extracted means a late-arriving message (synced after prepare) or a
                # dropped long-thread part stays enriched=0 and re-queues next cycle,
                # instead of being silently marked done without ever being enriched.
                doc_ids = _resolve_doc_ids(store, extraction, unit_messages_by_thread)
                if not doc_ids:
                    # Still nothing: a valid, content-bearing extraction we cannot tie to
                    # ANY chunk (e.g. the model rewrote the thread_id). Applying here would
                    # write un-groundable edges (provenance enriched-{phantom}) AND, because
                    # mark_enriched([]) marks nothing, the real chunks would re-queue every
                    # cycle forever without reaching the Q8 cap. Instead: skip the apply and
                    # bump the cap on the unit's own chunks so the loop terminates. Mirrors
                    # the invalid-extraction skip path.
                    _unit_mids = [m.get("message_id")
                                  for msgs in unit_messages_by_thread.values()
                                  for m in msgs if m.get("message_id")]
                    _unit_dids = store.doc_ids_for_messages(_unit_mids) if _unit_mids else []
                    _give_up_or_bump(store, _unit_dids, summary)
                    log.warning("drain: thread %s extraction matched no chunk in %s; "
                                "skipping apply and bumping the unit's attempt cap",
                                thread_id, path.name)
                    summary["skipped"] = summary.get("skipped", 0) + 1
                    continue
                # Fix #2 (now inside _resolve_doc_ids): a Drive file-wide resolve
                # (the file_id branch of doc_ids_for_messages) returns EVERY chunk
                # of the document, even ones the salience gate has since marked
                # cold -- but the extraction's batch text only ever covered the hot
                # chunks should_enrich() queued. _resolve_doc_ids drops cold chunks
                # on every branch, right before apply/mark_enriched, so a Drive
                # extraction marks only the chunks it actually covered (matching
                # the message-precise email path). No-op for email doc_ids, which
                # aren't cold-gated the same way.
                try:
                    # Pass the run-scoped dedup index only when built (flag on) so an
                    # injected/legacy apply that doesn't accept the kwarg is unaffected.
                    _apply_kw = {"entity_index": _entity_index} if _entity_index is not None else {}
                    res = apply(store, extraction, doc_ids=doc_ids, **_apply_kw)
                except Exception as exc:
                    log.error("drain: apply failed for thread %s in %s: %s",
                              thread_id, path.name, exc)
                    file_ok = False
                    continue
                summary["applied"] += 1
                # Surface apply()'s own counts: entities counts entities LINKED to
                # the thread (including upserts of already-known people), so it is
                # > 0 even when no net store rows are added. (res or {}).get(...)
                # so a minimal apply returning None or a dict without these keys
                # never crashes drain.
                summary["entities"] += (res or {}).get("entities", 0)
                summary["relations"] += (res or {}).get("relations", 0)
                store.mark_enriched(doc_ids)
                summary["marked"] += len(doc_ids)
                # A#4: persist the validated extraction for shared-drive docs so
                # its cache artifact can carry it (importers then skip Haiku).
                # ONE row per file, not per chunk: every chunk of a Drive doc
                # shares this unit's extraction and ingest_cache.publish_file
                # reads exactly one. Writing per doc_id duplicated the whole
                # payload 6.1x on the live store. Drive-only: email payloads
                # never enter a shared cache. `extraction` here has already
                # passed sanitize_batch + validate_extraction + grounding.
                #
                # `covers` records which chunks this extraction was actually made
                # from, so publish_file never ships a partial one as the file's:
                # a file-wide resolve marks EVERY chunk of the file, but after a
                # reflow (or across seam-split units) the unit held only some.
                _file_ids = {k for k in (_file_key_from_doc_id(d) for d in doc_ids) if k}
                if _file_ids:
                    _payload = json.dumps(extraction, sort_keys=True)
                    _covered = _payload_covers(store, extraction, doc_ids,
                                               unit_messages_by_thread)
                    for _f in _file_ids:
                        store.set_enrich_payload(
                            _f, _payload, ENRICH_LOGIC_VERSION,
                            covers=[d for d in _covered
                                    if _file_key_from_doc_id(d) == _f])

            try:
                _merge_result = review_apply.apply_duplicate_verdicts(
                    store, data.get("merge_answers") or [],
                    cap=config.review_max_apply_per_run(str(config.app_dir()))
                )
                summary["merges"] += _merge_result["merged"]
            except Exception as exc:
                log.error("drain: merge-answer processing failed in %s: %s", path.name, exc)
                file_ok = False

            try:
                from mcpbrain.synthesise_threads import drain_synthesis
                synth = drain_synthesis(store, data)
                if synth.get("thread_context_written", 0):
                    summary["synthesis_written"] = summary.get("synthesis_written", 0) + synth["thread_context_written"]
            except Exception as exc:
                log.error("drain: synthesis drain failed in %s: %s", path.name, exc)
                file_ok = False

            for _key, _drainer in BLOCK_DRAINERS.items():
                if _key not in data:
                    continue
                try:
                    res = _drainer(store, data)
                    # Always report the key on success, even for a falsy result, so
                    # the daemon clears its stash for this block (it keys off the
                    # presence of f"{_key}_drained", not its value).
                    summary[f"{_key}_drained"] = sum(
                        v for v in res.values() if isinstance(v, int)) if res else 0
                except Exception as exc:
                    log.error("drain: %s drain failed in %s: %s", _key, path.name, exc)
                    # Retain the file for retry — matches the synthesis-drain failure
                    # path above. Without this the inbox file is deleted with the
                    # block's answers unapplied while the daemon's stash re-attaches
                    # the same requests every cycle (silent infinite retry loop).
                    file_ok = False

            # Delete only when every extraction applied and merge-answers ran. A
            # partial failure leaves the file for retry next cycle. Idempotency on a
            # re-applied extraction rests on apply()'s upsert/dedup (Phase 1); drain
            # itself just does not double-delete -- a gone file is skipped by the
            # glob in _iter_inbox.
            if file_ok:
                try:
                    path.unlink()
                except OSError as exc:
                    log.error("drain: could not delete completed file %s: %s", path.name, exc)

                # Work-queue: the unit this result answers is consumed — remove its unit
                # file and lease claim so it stops being listed.
                unit_id = data.get("unit_id")
                if unit_id:
                    for p in (home_dir / "enrich_queue" / "units" / f"{unit_id}.json",
                              home_dir / "enrich_queue" / "claims" / unit_id):
                        try:
                            p.unlink()
                        except OSError:
                            pass

    return summary


def drain_captures(store, *, home=None, budget=None, bulk_section=None) -> int:
    """Apply every capture_inbox envelope. Returns the number applied.

    validate -> dedupe -> apply -> change_log -> delete. Invalid or unparseable
    envelopes quarantine to capture_inbox/bad/. The daemon calls this each
    cycle; it is the ONLY consumer of the spool the MCP write tools feed.

    This writes to `chunks` (via `store.upsert_chunk` for "ingest" captures) —
    the same table the four gated maintenance passes mutate — so, per the
    Task 2 duty-cycle/race-safety fix, `bulk_section` (a zero-arg
    context-manager factory, default `contextlib.nullcontext`) brackets each
    envelope's writes and `budget` (a `Budget`, or None for unbounded) is
    checked once per envelope. An unprocessed envelope simply stays queued and
    is retried next cycle — the spool is durable, so nothing is lost.

    The section brackets ONLY the store-writing branches, deliberately NOT the
    whole envelope. `decision`/`continuity`/`memory` captures write the records
    GIT REPO (records_write shells out to `git add`/`git commit`) and touch the
    store not at all, so they need no lock — and holding one across them is
    actively harmful: a stale `.git/index.lock` makes git block indefinitely,
    which under the old whole-envelope section would have parked _bulk_lock
    forever and starved every gated maintenance pass and the backup, for a
    capture that never needed the lock in the first place. Envelope parsing,
    validation, quarantine and the final unlink are filesystem-only and sit
    outside the section for the same reason.
    """
    if bulk_section is None:
        bulk_section = nullcontext
    from mcpbrain.chunking import (NOTE_MAX_CHARS, action_fingerprint,
                                   content_hash, split_lossless)
    from mcpbrain.contract import validate_capture

    home_dir = _home(home)
    inbox = home_dir / "capture_inbox"
    if not inbox.exists():
        return 0
    applied = 0
    _records_repo_path: str | None = None
    for path in sorted(inbox.glob("*.json")):
        if budget is not None and budget.expired():
            break
        try:
            env = json.loads(path.read_text())
        except (ValueError, OSError) as exc:
            log.warning("capture: unparseable %s, quarantining: %s", path.name, exc)
            _quarantine(path)
            continue
        problems = validate_capture(env)
        if problems:
            log.warning("capture: invalid %s, quarantining: %s",
                        path.name, "; ".join(problems[:3]))
            _quarantine(path)
            continue
        kind = env["kind"]
        # Records captures commit to the git repo and never touch the store, so
        # they run OUTSIDE the bulk section — see this function's docstring for
        # why holding _bulk_lock across a git commit is the dangerous case.
        section = nullcontext if kind in _RECORDS_KINDS else bulk_section
        file_ok = True
        with section():
            if kind == "ingest":
                text = f"{env['title'].strip()}\n\n{env['content'].strip()}"
                chash = content_hash(text)
                base_doc_id = f"note-{chash[:32]}"
                base_meta = {"source": "note", "title": env["title"],
                             "observation_type": env.get("observation_type", "note"),
                             "tags": env.get("tags", ""),
                             "org": env.get("org", ""),
                             "captured_at": env.get("captured_at", ""),
                             "note_id": base_doc_id}
                try:
                    # Notes used to bypass chunking entirely: one row per note,
                    # up to 133,791 chars, of which only the first ~2,000 were
                    # ever embedded (the BGE window). Same shape as
                    # consolidation.write_consolidated_note: a note that fits one
                    # chunk keeps the BARE id, so the common case needs no
                    # migration. chash stays the FULL-note hash on every piece, so
                    # re-capturing identical content is still a no-op.
                    #
                    # split_lossless, NOT chunk_text. The note path is the one
                    # caller that needs the split to round-trip: note_chunks()
                    # serves the reassembled pieces AS the note, so anything the
                    # split adds or drops becomes the note's text forever.
                    # chunk_text cannot do that for a paragraph larger than the
                    # budget -- it word-splits via para.split(), collapsing
                    # internal whitespace, and duplicates the last `overlap`
                    # words across a boundary. Measured on the live store, that
                    # rejected EVERY one of 930 oversize notes (16,022,678 chars
                    # of tail with no vector), and no overlap setting fixes it:
                    # overlap=0 rescues zero. split_lossless carries each break's
                    # separator on the preceding piece, so "" rejoins it exactly
                    # -- 930/930 round-trip.
                    pieces = split_lossless(text, NOTE_MAX_CHARS)
                    # Kept as a guard, not a gate: it should now be unreachable,
                    # and if a future change to split_lossless breaks the
                    # invariant the note must still be stored whole rather than
                    # split into something that cannot be reassembled.
                    if len(pieces) > 1 and "".join(pieces) != text:
                        log.error("capture: note %s failed the lossless round-trip "
                                  "(%d chars); storing it whole", base_doc_id, len(text))
                        pieces = [text]
                    if len(pieces) > 1:
                        base_meta = {**base_meta, "split": "lossless"}
                    changed = False
                    for i, piece in enumerate(pieces):
                        doc_id = (base_doc_id if len(pieces) == 1
                                  else f"{base_doc_id}-{i}")
                        meta = {**base_meta, "chunk_index": i,
                                "chunk_total": len(pieces)}
                        if store.upsert_chunk(doc_id, piece, chash, meta):
                            changed = True
                    if changed:
                        store.record_change("capture_ingest", ref_id=base_doc_id,
                                            summary=f"Saved note '{env['title'][:60]}'")
                        applied += 1
                except Exception as exc:
                    log.error("capture: ingest failed for %s: %s", path.name, exc)
                    file_ok = False
            elif kind == "action_create":
                try:
                    fp = action_fingerprint(env["text"])
                    if store.find_open_action_by_fingerprint(fp) is not None:
                        log.info("capture: duplicate action skipped: %r", env["text"][:60])
                    else:
                        raw_owner = (env.get("owner") or "").strip()
                        canonical_owner = config.owner_name(str(home_dir))
                        # A caller (MCP tool caller, another agent) may name
                        # the install owner via an alias variant ("Dana",
                        # "Dana Okafor") instead of leaving owner empty or
                        # typing the exact configured name. Canonicalize so
                        # every self-owned action lands under one string --
                        # brain_actions(owner="") matches owner exactly.
                        if not raw_owner:
                            owner = canonical_owner
                        elif raw_owner.lower() in config.owner_aliases(str(home_dir)):
                            owner = canonical_owner
                        else:
                            owner = raw_owner
                        aid = store.add_unified_action(
                            text=env["text"], owner=owner, deadline=env.get("deadline", ""),
                            org=env.get("org", ""), project_id=env.get("project_id", ""),
                            area_id=env.get("area_id", ""), source="capture",
                            text_fingerprint=fp)
                        store.record_change("capture_action", ref_id=str(aid),
                                            summary=f"Created action '{env['text'][:60]}'")
                        applied += 1
                except Exception as exc:
                    log.error("capture: action_create failed for %s: %s", path.name, exc)
                    file_ok = False
            elif kind == "action_update":
                try:
                    changed = store.set_action_status(
                        env["action_id"], env["status"],
                        resolved_by=f"capture:{env.get('source', 'mcp')}",
                        only_if_open=(env["status"] == "done"))
                    if changed:
                        store.record_change(
                            "capture_action_update", ref_id=str(env["action_id"]),
                            summary=f"Action {env['action_id']} -> {env['status']}")
                        applied += 1
                    else:
                        log.info("capture: action_update %s no-op (not open / not found)",
                                 env["action_id"])
                except Exception as exc:
                    log.error("capture: action_update failed for %s: %s", path.name, exc)
                    file_ok = False
            elif kind in _RECORDS_KINDS:
                try:
                    from mcpbrain import records_write as rw
                    if _records_repo_path is None:
                        _records_repo_path = _records_repo(str(home_dir))
                    repo = _records_repo_path
                    if kind == "decision":
                        committed = rw.append_decision(repo, text=env["text"], rationale=env.get("rationale", ""),
                                           owner=env.get("owner", ""), supersedes=env.get("supersedes", ""))
                    elif kind == "continuity":
                        committed = rw.append_continuity(repo, text=env["text"])
                    else:  # memory
                        committed = rw.write_memory(repo, slug=env["slug"], description=env.get("description", ""),
                                        body=env["body"], memory_type=env.get("memory_type", "project"))
                    if committed:
                        applied += 1
                    else:
                        log.info("capture: %s no-op (already applied) for %s", kind, path.name)
                except Exception as exc:
                    log.error("capture: %s write failed for %s: %s", kind, path.name, exc)
                    file_ok = False
        if file_ok:
            path.unlink(missing_ok=True)
    return applied

"""B4 — RAPTOR-style consolidation pass (sleep-time compute).

Clusters recent episodic chunks by topic similarity, then LLM-summarises each
cluster into a cited semantic note stored as a new chunk with
memory_type='semantic' and memory_tier='hot'.

Trigger: accumulated_importance (sum of salience of un-consolidated episodic
chunks) exceeds CONSOLIDATION_THRESHOLD. This is checked nightly.

The LLM call goes through the `claude` CLI (config.find_claude), so no API key
is needed. Skip cleanly when claude is absent.

Public API:
  should_consolidate(store, home) -> bool
  consolidate(store, home, *, cap, threshold) -> dict
"""

from __future__ import annotations

import hashlib
import logging
import re
import subprocess
from datetime import datetime, timezone

log = logging.getLogger("mcpbrain.consolidation")

CONSOLIDATION_THRESHOLD = 50.0   # accumulated salience to trigger a pass
_MAX_CLUSTER_CHARS = 3000        # max text per cluster fed to the LLM
_MIN_CLUSTER_SIZE = 3            # skip tiny clusters (likely noise)
_MAX_CLUSTER_SIZE = 10           # cap per cluster — prevents grab-bag merges when a
                                 # large cohort of similar-source chunks (e.g. one week
                                 # of ops-email) would otherwise collapse into one note
_CONSOLIDATION_CAP = 5           # max clusters per nightly pass


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ---------------------------------------------------------------------------
# Trigger check
# ---------------------------------------------------------------------------

def _unconsolidated_salience(store) -> float:
    """Sum of salience for episodic chunks not yet promoted to hot/core."""
    with store._connect() as db:
        row = db.execute(
            "SELECT COALESCE(SUM(salience), 0.0) FROM chunks "
            "WHERE memory_type = 'episodic' "
            "  AND COALESCE(memory_tier, '') NOT IN ('hot', 'core') "
            "  AND embedded = 1"
        ).fetchone()
    return float(row[0] if row else 0.0)


def should_consolidate(store, home: str) -> bool:
    """True when enough unconsolidated salience has accumulated to run a pass."""
    from mcpbrain import config
    if config.auto_change_mode(home, "consolidation") == "off":
        return False
    return _unconsolidated_salience(store) >= CONSOLIDATION_THRESHOLD


# ---------------------------------------------------------------------------
# Clustering (simple TF-IDF word-overlap — no extra dep needed)
# ---------------------------------------------------------------------------

def _token_set(text: str) -> set[str]:
    import re
    words = re.findall(r"\b[a-z]{4,}\b", (text or "").lower())
    return set(words)


def _similarity(a: set, b: set) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def _cluster_chunks(chunks: list[dict], *, threshold: float = 0.12) -> list[list[dict]]:
    """Greedy single-link clustering by Jaccard overlap on 4-char+ words.

    Two chunks share a cluster if their word overlap exceeds `threshold`.
    Returns a list of clusters (each a list of chunk dicts), largest first.
    """
    token_sets = [_token_set(c.get("text") or "") for c in chunks]
    labels = list(range(len(chunks)))

    for i in range(len(chunks)):
        for j in range(i + 1, len(chunks)):
            if _similarity(token_sets[i], token_sets[j]) >= threshold:
                root_i = labels[i]
                root_j = labels[j]
                if root_i != root_j:
                    # Merge: reassign the smaller label to the larger
                    old, new = max(root_i, root_j), min(root_i, root_j)
                    labels = [new if lb == old else lb for lb in labels]

    by_label: dict[int, list] = {}
    for i, lb in enumerate(labels):
        by_label.setdefault(lb, []).append(chunks[i])

    clusters = sorted(by_label.values(), key=len, reverse=True)
    return [c for c in clusters if len(c) >= _MIN_CLUSTER_SIZE]


# ---------------------------------------------------------------------------
# LLM call (via claude CLI)
# ---------------------------------------------------------------------------

_PROMPT_TEMPLATE = """\
You are a memory consolidator. Below are related email/note excerpts.

Reply with ONE JSON object and nothing else:
{{"title": "...", "description": "...", "note": "...", "standing": true}}

- note: a concise semantic note (3-6 sentences) capturing the key facts, \
decisions and relationships. Cite source IDs using [id] notation.
- title: 3 to 8 words naming the subject, e.g. "Byford hub construction loan".
- description: one sentence, under 150 characters, saying what the note records.
- standing: true only for knowledge worth recalling months from now: how \
something works, who holds which role, a decision, a policy, an ongoing \
project or arrangement. false for one person's application, enquiry, form \
or personal circumstances; a single booking, trip, delivery or event; a \
calendar series; what an attachment or spreadsheet contains; a status \
digest of open items.

Never include email addresses, phone numbers, dates of birth or booking references.

Source IDs and excerpts:
{excerpts}
"""

# The model sometimes opens with commentary on the task despite "no preamble"
# ("This is a memory consolidation task, not a coding task, so I'll write the
# note directly."). The first line becomes the memory slug and description, so
# 17 graduated files were titled after it. A matching line that cites nothing
# is commentary; a line citing a source is note text, however it opens.
_PREAMBLE = re.compile(
    r"^\s*(?:this is a memory consolidation task"
    r"|these excerpts (?:are|don'?t|do not)"
    r"|here(?:'s| is) (?:the|a|my) (?:consolidated |semantic |durable )?note"
    r"|i'?ll write|i will write|writing the (?:consolidated )?note"
    r"|note text only)", re.IGNORECASE)


def _parse_reply(text: str) -> dict:
    """The consolidator's reply as {note, title, description, standing}.

    The structured reply is what lets graduation judge: only a note the model
    marks `standing` becomes a memory file, titled from its own title. Before
    this, every cluster over the source and salience thresholds graduated and
    took its slug from the note's first line, so applicants' forms, calendar
    series and spreadsheet descriptions became standing memory, some titled
    after the model's commentary.

    A reply that is not that JSON object (an older prompt's plain note, or the
    model ignoring the format) is kept as a plain note: written to the store,
    never graduated. note is '' when nothing usable came back."""
    import json as _json
    card = {"note": "", "title": "", "description": "", "standing": False}
    text = (text or "").strip()
    start, end = text.find("{"), text.rfind("}")
    if start != -1 and end > start:
        try:
            obj = _json.loads(text[start:end + 1])
        except ValueError:
            obj = None
        if isinstance(obj, dict) and isinstance(obj.get("note"), str):
            card["note"] = _strip_preamble(obj["note"])
            for k in ("title", "description"):
                v = obj.get(k)
                card[k] = " ".join(v.split()) if isinstance(v, str) else ""
            card["standing"] = obj.get("standing") is True
            return card
    card["note"] = _strip_preamble(text)
    return card


def _strip_preamble(summary: str) -> str:
    """Drop leading commentary lines (and blank lines) from a model summary.
    Returns '' when nothing but commentary remains."""
    lines = summary.strip().splitlines()
    while lines and (not lines[0].strip()
                     or (_PREAMBLE.match(lines[0]) and "[" not in lines[0])):
        lines.pop(0)
    return "\n".join(lines).strip()


def _call_claude(prompt: str, timeout: int = 60) -> str:
    """Call the claude CLI with the given prompt. Returns output text or ''."""
    from mcpbrain import config
    try:
        claude = config.find_claude()
    except RuntimeError:
        log.warning("consolidation: claude CLI not found — skipping LLM summarise")
        return ""
    try:
        result = subprocess.run(
            [claude, "-p", prompt, "--output-format", "text"],
            capture_output=True, text=True, timeout=timeout,
        )
        if result.returncode != 0:
            log.warning("consolidation: claude returned %d: %s",
                        result.returncode, result.stderr[:200])
            return ""
        return (result.stdout or "").strip()
    except subprocess.TimeoutExpired:
        log.warning("consolidation: claude timed out after %ds", timeout)
        return ""
    except Exception as exc:  # noqa: BLE001
        log.warning("consolidation: claude call failed: %s", exc)
        return ""


def _build_prompt(cluster: list[dict]) -> str:
    excerpts = []
    total = 0
    for c in cluster:
        doc_id = c.get("doc_id", "?")
        text = (c.get("text") or "").strip()[:400]
        if total + len(text) > _MAX_CLUSTER_CHARS:
            break
        excerpts.append(f"[{doc_id}]\n{text}")
        total += len(text)
    return _PROMPT_TEMPLATE.format(excerpts="\n\n".join(excerpts))


# ---------------------------------------------------------------------------
# Write consolidated note
# ---------------------------------------------------------------------------

def _write_note(store, cluster: list[dict], summary: str, *,
                written: list | None = None) -> str | None:
    """Write a consolidated semantic note, bounded like every other
    multi-chunk source. Returns the FIRST doc_id written, or None. Every
    doc_id written is appended to `written` when given (undo deletes them).

    The consolidation prompt already asks for "a concise durable semantic
    note (3-6 sentences)" -- and 1,151 existing notes still averaged 18K
    chars anyway. That's why this is a write-time cap, not a prompt fix: an
    LLM instruction is evidence, not a guarantee, and every other bound in
    this codebase is defensive at the write layer for exactly that reason.

    doc_id shape is NOT uniform: a single-chunk note keeps the bare
    `note-consolidated-<hash>` id (no migration needed for the existing,
    common case), but a multi-chunk note gets numeric-suffixed ids
    (`-0`, `-1`, ...) -- including chunk 0, which would have no suffix as a
    lone chunk. No current caller matches/parses the bare pattern (checked),
    so this is inert today, but a future one that does would silently stop
    matching multi-chunk notes. If you're adding such a caller, match on the
    `note-consolidated-<hash>` PREFIX, not the bare id.
    """
    if not summary:
        return None

    from mcpbrain.chunking import chunk_text

    source_ids = [c.get("doc_id", "") for c in cluster]
    ts = _now_iso()
    content_hash_full = hashlib.sha256(summary.encode()).hexdigest()[:16]
    base_doc_id = f"note-consolidated-{content_hash_full}"

    pieces = chunk_text(summary)
    if len(pieces) <= 1:
        doc_id = base_doc_id
        metadata = {
            "observation_type": "consolidated",
            "source_doc_ids": source_ids,
            "captured_at": ts,
            "title": "Consolidated note",
        }
        store.upsert_chunk(doc_id, summary, content_hash_full, metadata)
        store.set_chunk_type(doc_id, "semantic")
        store.set_chunk_tier(doc_id, "hot")
        # A machine summary is never evidence (spec §2): searchable, but cold
        # so it is never re-extracted — and, because top_core_candidates
        # requires enrich_state != 'cold', never promoted into core either.
        store.set_enrich_state([doc_id], "cold")
        if written is not None:
            written.append(doc_id)
        return doc_id

    first_doc_id = None
    for i, piece in enumerate(pieces):
        doc_id = f"{base_doc_id}-{i}"
        if first_doc_id is None:
            first_doc_id = doc_id
        metadata = {
            "observation_type": "consolidated",
            "source_doc_ids": source_ids,
            "captured_at": ts,
            "title": "Consolidated note",
            # store.note_chunks groups on note_id, falling back to doc_id.
            # Without this every piece groups to ITSELF, so one consolidated
            # note surfaces as N separate notes in memory_index and collects N
            # distil verdicts. The capture path stamps it; this one must too.
            "note_id": base_doc_id,
            "chunk_index": i,
            "chunk_total": len(pieces),
        }
        piece_hash = hashlib.sha256(piece.encode()).hexdigest()[:16]
        store.upsert_chunk(doc_id, piece, piece_hash, metadata)
        store.set_chunk_type(doc_id, "semantic")
        store.set_chunk_tier(doc_id, "hot")
        store.set_enrich_state([doc_id], "cold")    # never evidence; see above
        if written is not None:
            written.append(doc_id)
    return first_doc_id


def _make_slug(summary: str) -> str:
    """Filesystem-safe slug from the first words of a summary (max 50 chars)."""
    import re
    first_line = summary.split("\n")[0][:60]
    slug = re.sub(r"[^a-z0-9]+", "-", first_line.lower()).strip("-")
    return slug[:50] or "consolidated-note"


def _infer_memory_type(cluster: list[dict], summary: str) -> str:
    """Pick a records memory_type from the documented vocabulary.

    The records store recognises {project, system, preference} (see the
    "Where Things Go" table in records CLAUDE.md). Hardcoding everything to
    "project" mistypes system facts and preferences, which changes how the
    memory tier recalls/filters them. We infer from the summary plus any tags
    on the source chunks, and default to "project" when the signal is weak.
    """
    text = summary.lower()
    for c in cluster:
        tags = (c.get("metadata") or {}).get("tags") or []
        if isinstance(tags, str):
            tags = [tags]
        text += " " + " ".join(str(t).lower() for t in tags)

    # Preference: explicit standing-rule / style language (checked first so a
    # preference about a tool isn't misread as a system fact).
    if any(kw in text for kw in (
        "preference", "prefer ", "style guide", "tone of voice", "format default",
        "convention", "always ", "never ", "i like ", "house style",
    )):
        return "preference"
    # System: tools, automations, integrations, infrastructure.
    if any(kw in text for kw in (
        "system", "tool", "automation", "integration", "workflow", "pipeline",
        "script", "daemon", "platform", "software",
    )):
        return "system"
    return "project"


def _graduate_note(store, home: str, cluster: list[dict], summary: str, *,
                   graduated: list | None = None, title: str = "",
                   description: str = "") -> bool:
    """Promote a high-confidence consolidated note to a durable memory/*.md file.

    Graduation criteria (all must pass):
      - Source count >= graduation_min_sources (recurrence proxy)
      - Mean source salience >= graduation_min_salience
      - The summary holds no personal identifier (personal_data.find)

    Calls records_write.write_memory() which is no-clobber and commits. Wrapped in
    try/except so a missing records repo (no git) never breaks the consolidation run.
    Returns True if a memory file was written. When the file is new (not a
    pre-existing one write_memory left alone), its repo-relative path is
    appended to `graduated` so undo can take it back.
    """
    from mcpbrain import config
    from mcpbrain import records_write

    min_sources = config.graduation_min_sources(home)
    min_salience = config.graduation_min_salience(home)

    if len(cluster) < min_sources:
        log.debug("consolidation: graduation skipped — %d sources < min %d",
                  len(cluster), min_sources)
        return False

    saliences = [float(c.get("salience") or 0.0) for c in cluster]
    mean_salience = sum(saliences) / len(saliences) if saliences else 0.0
    if mean_salience < min_salience:
        log.debug("consolidation: graduation skipped — mean salience %.2f < min %.2f",
                  mean_salience, min_salience)
        return False

    # Mail about people (applications, volunteer forms, bookings) clusters and
    # scores high, but its identifiers belong in the source email, not in a
    # standing memory every session reads. The note itself stays in the store.
    from mcpbrain import personal_data
    held = personal_data.find(summary)
    if held:
        log.info("consolidation: graduation skipped — the note holds %s",
                 ", ".join(held))
        return False

    slug = _make_slug(title or summary)
    first_sent = description[:150] if description else \
        (summary.split(". ")[0] + ".").strip()[:120]
    memory_type = _infer_memory_type(cluster, summary)
    records_repo = config.records_dir(home)

    from pathlib import Path
    rel = f"memory/{slug}.md"
    existed = (Path(records_repo) / rel).exists()
    try:
        written = records_write.write_memory(
            records_repo,
            slug=slug,
            description=first_sent,
            body=summary,
            memory_type=memory_type,
        )
        if written and not existed and graduated is not None:
            graduated.append(rel)
        if written:
            log.info(
                "consolidation: graduated note → memory/%s.md "
                "(type=%s, sources=%d, mean_salience=%.2f)",
                slug, memory_type, len(cluster), mean_salience,
            )
        return bool(written)
    except Exception as exc:  # noqa: BLE001
        log.warning("consolidation: graduation failed (records repo may not be "
                    "initialized): %s", exc)
        return False


# ---------------------------------------------------------------------------
# Main pass
# ---------------------------------------------------------------------------

def _episodic_chunks_for_consolidation(store, cap: int) -> list[dict]:
    """Fetch high-salience episodic chunks not yet consolidated."""
    import json as _json
    with store._connect() as db:
        rows = db.execute(
            "SELECT doc_id, text, metadata, salience FROM chunks "
            "WHERE memory_type = 'episodic' "
            "  AND COALESCE(memory_tier, '') NOT IN ('hot', 'core') "
            "  AND embedded = 1 "
            "  AND COALESCE(salience, 0.0) > 0.0 "
            "ORDER BY salience DESC "
            "LIMIT ?",
            (cap * 10,),
        ).fetchall()
    result = []
    for r in rows:
        try:
            meta = _json.loads(r["metadata"] or "{}")
        except Exception:
            meta = {}
        result.append({
            "doc_id": r["doc_id"],
            "text": r["text"],
            "metadata": meta,
            "salience": float(r["salience"] or 0.0),
        })
    return result


def _cluster_by_embedding(chunks: list[dict], embedder, *,
                          threshold: float = 0.75) -> list[list[dict]] | None:
    """Cluster chunks by cosine similarity on their bge embeddings (single-link).

    Reuses the same local embedder the store uses, so clusters reflect semantic
    similarity — far better than word-overlap for paraphrases / short notes. bge
    vectors are unit-normalised, so dot product == cosine. Returns None on any
    embedding failure so the caller falls back to the lexical clusterer.

    Threshold raised from 0.55 → 0.75 (Session 3, 2026-06-24): at 0.55 a cohort of
    ops-emails from the same week all merged into a single grab-bag cluster. 0.75
    requires tight topical similarity — loose thematic affinity alone won't merge.
    Clusters exceeding _MAX_CLUSTER_SIZE are split in salience-rank order so each
    note covers a coherent sub-topic rather than a digest of many unrelated events.
    """
    texts = [c.get("text") or "" for c in chunks]
    try:
        vecs = embedder.embed_passages(texts)
    except Exception as exc:  # noqa: BLE001
        log.debug("consolidation: embedding clustering failed (%s); falling back", exc)
        return None
    n = len(chunks)
    labels = list(range(n))
    for i in range(n):
        vi = vecs[i]
        for j in range(i + 1, n):
            if sum(a * b for a, b in zip(vi, vecs[j])) >= threshold:
                ri, rj = labels[i], labels[j]
                if ri != rj:
                    old, new = max(ri, rj), min(ri, rj)
                    labels = [new if lb == old else lb for lb in labels]
    by_label: dict[int, list] = {}
    for i, lb in enumerate(labels):
        by_label.setdefault(lb, []).append(chunks[i])
    raw_clusters = sorted(by_label.values(), key=len, reverse=True)

    # Cap cluster size: split oversized clusters into sub-clusters of _MAX_CLUSTER_SIZE.
    # Chunks within a cluster are already ordered by salience (from the source query),
    # so slicing preserves the highest-salience members in each sub-cluster.
    result = []
    for cluster in raw_clusters:
        if len(cluster) <= _MAX_CLUSTER_SIZE:
            if len(cluster) >= _MIN_CLUSTER_SIZE:
                result.append(cluster)
        else:
            for start in range(0, len(cluster), _MAX_CLUSTER_SIZE):
                sub = cluster[start: start + _MAX_CLUSTER_SIZE]
                if len(sub) >= _MIN_CLUSTER_SIZE:
                    result.append(sub)
    return result


def _cluster(chunks: list[dict], embedder=None) -> list[list[dict]]:
    """Cluster by embeddings when an embedder is available, else lexical Jaccard."""
    if embedder is not None:
        clusters = _cluster_by_embedding(chunks, embedder)
        if clusters is not None:
            return clusters
    return _cluster_chunks(chunks)


def _file_contents(repo: str, rels: list[str]) -> dict[str, str]:
    from pathlib import Path
    out = {}
    for rel in rels:
        fp = Path(repo) / rel
        if fp.exists():
            out[rel] = fp.read_text()
    return out


def _promote_sources(store, cluster: list[dict], prior_tiers: dict[str, str]) -> None:
    """Set each source chunk's tier to 'hot', reading its prior tier on the
    same connection first (first sighting wins, so a chunk in two clusters
    keeps its true original tier)."""
    with store._connect(write=True) as db:
        for c in cluster:
            row = db.execute("SELECT memory_tier FROM chunks WHERE doc_id=?",
                             (c["doc_id"],)).fetchone()
            prior_tiers.setdefault(c["doc_id"], (row["memory_tier"] or "") if row else "")
            db.execute("UPDATE chunks SET memory_tier='hot' WHERE doc_id=?", (c["doc_id"],))


def _apply_cluster(store, home: str, cluster: list[dict], summary: str, *,
                   notes: list, prior_tiers: dict, graduated: list,
                   standing: bool = False, title: str = "",
                   description: str = "") -> bool:
    """Write one cluster's note, promote its sources and, when the consolidator
    judged it `standing` knowledge, graduate it, adding what changed to the
    undo lists. True when a note was written."""
    doc_id = _write_note(store, cluster, summary, written=notes)
    if not doc_id:
        return False
    # Mark source chunks as consolidated (promote to hot tier so they
    # aren't re-clustered next pass).
    _promote_sources(store, cluster, prior_tiers)
    log.info("consolidation: wrote semantic note %s from %d sources",
             doc_id, len(cluster))
    if standing:
        _graduate_note(store, home, cluster, summary, graduated=graduated,
                       title=title, description=description)
    return True


def _record_pass(store, home: str, *, written: int, clusters: int, notes: list,
                 prior_tiers: dict, graduated: list) -> int:
    """Record the pass as one `consolidation_pass` change (undoable when it
    wrote notes). Returns the change_log id."""
    from mcpbrain import config
    revert_ref = ""
    if notes:
        from mcpbrain.change_undo import revert_json
        revert_ref = revert_json(
            {"notes": notes, "tiers": prior_tiers, "graduated": graduated},
            {"notes": notes, "tiers": {d: "hot" for d in prior_tiers},
             "graduated": graduated,
             # What each graduated file held when written, so undo can refuse
             # to delete one edited since.
             "graduated_content": _file_contents(config.records_dir(home), graduated)})
    return store.record_change(
        "consolidation_pass",
        summary=f"Consolidated {written} semantic notes from {clusters} clusters",
        source="consolidation",
        revert_ref=revert_ref,
    )


def chunks_for_proposal(store, doc_ids: list[str]) -> list[dict] | None:
    """The cluster a queued proposal names, re-read from the store. None when
    any source is gone or already consolidated (hot/core) since the proposal."""
    import json as _json
    if not doc_ids:
        return None
    marks = ",".join("?" * len(doc_ids))
    with store._connect() as db:
        rows = {r["doc_id"]: r for r in db.execute(
            f"SELECT doc_id, text, metadata, salience, memory_tier FROM chunks "
            f"WHERE doc_id IN ({marks})", list(doc_ids)).fetchall()}
    cluster = []
    for d in doc_ids:
        r = rows.get(d)
        if r is None or (r["memory_tier"] or "") in ("hot", "core"):
            return None
        try:
            meta = _json.loads(r["metadata"] or "{}")
        except Exception:
            meta = {}
        cluster.append({"doc_id": d, "text": r["text"], "metadata": meta,
                        "salience": float(r["salience"] or 0.0)})
    return cluster


def apply_proposal(store, home: str, doc_ids: list[str], summary: str, *,
                   standing: bool = False, title: str = "",
                   description: str = "") -> int:
    """Write one queued (ask-first) cluster note exactly as apply mode would.
    Returns the consolidation_pass change id, or 0 when the sources changed
    since the proposal or no note was written. A proposal queued before the
    structured reply carries no `standing` and so never graduates."""
    cluster = chunks_for_proposal(store, doc_ids)
    summary = _strip_preamble(summary)  # proposals queued before the strip
    if cluster is None or not summary:
        return 0
    notes: list[str] = []
    prior_tiers: dict[str, str] = {}
    graduated: list[str] = []
    if not _apply_cluster(store, home, cluster, summary, notes=notes,
                          prior_tiers=prior_tiers, graduated=graduated,
                          standing=standing, title=title, description=description):
        return 0
    return _record_pass(store, home, written=1, clusters=1, notes=notes,
                        prior_tiers=prior_tiers, graduated=graduated)


def consolidate(store, home: str, *, cap: int = _CONSOLIDATION_CAP,
                threshold: float = CONSOLIDATION_THRESHOLD, embedder=None) -> dict:
    """Run one consolidation pass.

    embedder (optional): the local bge embedder; when supplied, clustering is
    embedding-based (semantic) rather than lexical word-overlap.

    The "consolidation" automatic-change mode decides what happens: apply
    writes the notes; ask queues one review per note (nothing is written, and
    no new pass runs while one waits); off does nothing.

    Returns {"clusters_found": N, "notes_written": M, "skipped": K}, plus
    "proposed": P in ask mode.
    """
    from mcpbrain import auto_changes, config
    mode = config.auto_change_mode(home, "consolidation")
    if mode == "off":
        return {"clusters_found": 0, "notes_written": 0, "skipped": 0}
    if mode == "ask" and auto_changes.pending_targets(store, "consolidation"):
        # A pass already waits for review: its sources are still unconsolidated,
        # so a new pass would re-cluster them and spend LLM calls on a duplicate.
        log.debug("consolidation: a pass is waiting for review — skipping")
        return {"clusters_found": 0, "notes_written": 0, "skipped": 1, "proposed": 0}

    acc = _unconsolidated_salience(store)
    if acc < threshold:
        log.debug("consolidation: accumulated salience %.1f < %.1f — skipping", acc, threshold)
        return {"clusters_found": 0, "notes_written": 0, "skipped": 1}

    chunks = _episodic_chunks_for_consolidation(store, cap)
    if not chunks:
        return {"clusters_found": 0, "notes_written": 0, "skipped": 0}

    clusters = _cluster(chunks, embedder)
    log.info("consolidation: %d chunks → %d clusters (%s)", len(chunks), len(clusters),
             "embedding" if embedder is not None else "lexical")

    written = 0
    proposed = 0
    # What this pass changes, for undo: the note chunks it adds, each source
    # chunk's tier before promotion, and any memory file it graduates.
    notes: list[str] = []
    prior_tiers: dict[str, str] = {}
    graduated: list[str] = []
    for cluster in clusters[:cap]:
        prompt = _build_prompt(cluster)
        card = _parse_reply(_call_claude(prompt))
        summary = card["note"]
        if not summary:
            continue
        if mode == "ask":
            doc_ids = [c["doc_id"] for c in cluster]
            target = hashlib.sha256("|".join(sorted(doc_ids)).encode()).hexdigest()[:16]
            subject = card["title"] or summary.split("\n")[0].strip()
            keep = " and keep it as standing memory" if card["standing"] else ""
            auto_changes.propose(
                store, "consolidation", target,
                f"Consolidate {len(cluster)} items into a note{keep}: {subject[:100]}",
                {"doc_ids": doc_ids, "summary": summary, "standing": card["standing"],
                 "title": card["title"], "description": card["description"]})
            proposed += 1
            continue
        if _apply_cluster(store, home, cluster, summary, notes=notes,
                          prior_tiers=prior_tiers, graduated=graduated,
                          standing=card["standing"], title=card["title"],
                          description=card["description"]):
            written += 1

    if mode == "ask":
        return {"clusters_found": len(clusters), "notes_written": 0, "skipped": 0,
                "proposed": proposed}
    _record_pass(store, home, written=written, clusters=len(clusters), notes=notes,
                 prior_tiers=prior_tiers, graduated=graduated)
    return {"clusters_found": len(clusters), "notes_written": written, "skipped": 0}

import argparse
import sys
from mcpbrain.daemon import main as _daemon_main
from mcpbrain.auth import main as _auth_main

def _ensure_utf8_stdio() -> None:
    """Windows consoles default to a legacy codepage (cp1252) that can't encode the
    doctor report's ✅/⚠️ glyphs → UnicodeEncodeError. Reconfigure stdio to UTF-8
    (errors='replace' so it degrades instead of crashing). No-op where unsupported."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass

def _mcp_main():
    from mcpbrain.mcp_server import main as m; m()
def _setup_main(argv):    from mcpbrain.setup import main as m; m(argv)
def _connect_main(argv):  from mcpbrain.setup import connect_main as m; m(argv)
def _update_main(argv):   from mcpbrain.update import main as m; m(argv)
def _tray_main(argv):     from mcpbrain.tray import main as m; m(argv)
def _monitor_main():      from mcpbrain.monitor import main as m; m()
def _home_main():
    from mcpbrain.config import app_dir
    print(str(app_dir()))

def main(argv=None):
    _ensure_utf8_stdio()
    argv = list(sys.argv[1:] if argv is None else argv)
    p = argparse.ArgumentParser(prog="mcpbrain")
    sub = p.add_subparsers(dest="cmd", required=True)
    for name in ("daemon","mcp-server","auth","setup","connect","update","tray","home",
                 "records-prune","records-health",
                 "session-start","session-end","pre-compact","user-prompt-submit",
                 "monitor","restore","fleet-report","doctor","enrich-eval","bootstrap",
                 "tenant", "backup", "clean-ingestion"):
        sub.add_parser(name, add_help=(name == "mcp-server"))
    ns, rest = p.parse_known_args(argv)
    def _records_cadence_main(argv):
        from mcpbrain.records_cadences import main as m
        return m(argv)
    return {
        "daemon": lambda: _daemon_main(rest), "mcp-server": _mcp_main,
        "auth": lambda: _auth_main(rest), "setup": lambda: _setup_main(rest),
        "connect": lambda: _connect_main(rest),
        "update": lambda: _update_main(rest),
        "tray": lambda: _tray_main(rest),
        "home": _home_main,
        "records-prune": lambda: _records_cadence_main(["records-prune", *rest]),
        "records-health": lambda: _records_cadence_main(["records-health", *rest]),
        "session-start": lambda: __import__("mcpbrain.session_hooks", fromlist=["session_start_main"]).session_start_main(rest),
        "session-end": lambda: __import__("mcpbrain.session_hooks", fromlist=["session_end_main"]).session_end_main(rest),
        "pre-compact": lambda: __import__("mcpbrain.session_hooks", fromlist=["pre_compact_main"]).pre_compact_main(rest),
        "user-prompt-submit": lambda: __import__("mcpbrain.prompt_recall", fromlist=["user_prompt_submit_main"]).user_prompt_submit_main(rest),
        "monitor": _monitor_main,
        "restore": lambda: __import__("mcpbrain.restore", fromlist=["run_restore_main"]).run_restore_main(rest),
        "fleet-report": lambda: __import__(
            "mcpbrain.fleet_cli", fromlist=["main"]).main(rest),
        "doctor": lambda: __import__("mcpbrain.doctor", fromlist=["run_doctor_main"]).run_doctor_main(rest),
        "enrich-eval": lambda: __import__("mcpbrain.enrich_eval", fromlist=["main"]).main(rest),
        "bootstrap": lambda: __import__(
            "mcpbrain.onboarding", fromlist=["bootstrap_main"]).bootstrap_main(rest),
        "tenant": lambda: __import__(
            "mcpbrain.tenant", fromlist=["cli_main"]).cli_main(rest),
        "backup": lambda: __import__(
            "mcpbrain.backup_now", fromlist=["main"]).main(rest),
        "clean-ingestion": lambda: sys.exit(__import__(
            "mcpbrain.ingestion_cleanup", fromlist=["main"]).main(rest)),
    }[ns.cmd]()

"""Records-hygiene cadences, ported into the product so they run on every OS.

`mcpbrain records-prune`  — drop hot.md entries older than N days, then commit.
`mcpbrain records-health` — read-only checks; exit 1 if any warning.

Both operate on config.records_dir(home); no shell, no records-repo scripts.
"""
from __future__ import annotations

import argparse
import logging
import os
import re
import subprocess
import sys
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from mcpbrain import config, records_write

log = logging.getLogger(__name__)

_PRUNE_DAYS = 14
_WARN_HOT_DAYS = 14
_WARN_BRAIN_MEMORY_DAYS = 7

# Match dated bullet: "- **2026-05-22: Title.**" or "- 2026-05-14: ..." or "  - **2026-05-12 (session)**:"
_DATED_BULLET = re.compile(
    r"^\s*[-*]\s+(?:\*\*\s*)?(\d{4}-\d{2}-\d{2})",
)


# ---------------------------------------------------------------------------
# Block-based parsing helpers (ported from ~/joshbrain/bin/prune_hot_md.py)
# ---------------------------------------------------------------------------

def _parse_blocks(text: str) -> list[str]:
    """Split content into blocks.

    Blocks are separated by blank lines.  Additionally, a new dated bullet
    line always starts a new block even when no blank line precedes it —
    continuation lines (indented / non-bullet non-header lines) stay attached
    to the preceding dated bullet as part of its block.

    Each blank line produces an empty-string sentinel ("") in the list so the
    caller can collapse/strip them.
    """
    blocks: list[str] = []
    current: list[str] = []

    def _is_dated_bullet(line: str) -> bool:
        return bool(_DATED_BULLET.match(line))

    def _flush() -> None:
        if current:
            blocks.append("\n".join(current))
            current.clear()

    for line in text.splitlines():
        if line.strip() == "":
            _flush()
            blocks.append("")  # preserve blank separator
        elif _is_dated_bullet(line) and current:
            # New dated bullet — always start a fresh block without requiring
            # an explicit blank-line separator.
            _flush()
            current.append(line)
        else:
            current.append(line)
    _flush()
    return blocks


def _block_date(block: str) -> date | None:
    """Return the date in the leading bullet of a block, or None."""
    if not block:
        return None
    first_line = block.splitlines()[0]
    m = _DATED_BULLET.match(first_line)
    if not m:
        return None
    try:
        return datetime.strptime(m.group(1), "%Y-%m-%d").date()
    except ValueError:
        return None


def _prune_blocks(
    text: str, cutoff: date
) -> tuple[str, list[tuple[date, str]]]:
    """Return (pruned_text, dropped_list).

    Drops every block whose leading bullet date < cutoff.
    Collapses consecutive blank blocks to one; strips leading/trailing blanks.
    Returned text always ends with a newline.
    """
    blocks = _parse_blocks(text)
    kept: list[str] = []
    dropped: list[tuple[date, str]] = []
    for block in blocks:
        d = _block_date(block)
        if d is not None and d < cutoff:
            snippet = block.splitlines()[0][:120]
            dropped.append((d, snippet))
            continue
        kept.append(block)
    # Collapse consecutive blank blocks to one
    cleaned: list[str] = []
    prev_blank = False
    for b in kept:
        is_blank = b == ""
        if is_blank and prev_blank:
            continue
        cleaned.append(b)
        prev_blank = is_blank
    # Strip leading/trailing blank blocks
    while cleaned and cleaned[0] == "":
        cleaned.pop(0)
    while cleaned and cleaned[-1] == "":
        cleaned.pop()
    return "\n".join(cleaned) + "\n", dropped


def _write_prune_log(dropped: list[tuple[date, str]]) -> None:
    """Append dropped entries to <app_dir>/logs/records_prune.log."""
    if not dropped:
        return
    log_path = config.app_dir() / "logs" / "records_prune.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with log_path.open("a") as f:
        f.write(f"\n=== {now} pruned {len(dropped)} entries ===\n")
        for d, snippet in dropped:
            f.write(f"  [{d}] {snippet}\n")


def prune_hot_md(
    repo: str, *, days: int = _PRUNE_DAYS, now=None, dry_run: bool = False
) -> int:
    """Drop hot.md dated-bullet *blocks* older than `days`. Returns count removed.

    Uses block-based parsing: a dated bullet plus its non-blank continuation
    lines form one block, dropped or kept as a unit.  Consecutive blank lines
    are collapsed; leading/trailing blanks are stripped.

    When dry_run=True the count is computed but the file is NOT written and
    nothing is logged.

    Idempotent. Does not commit (prune_and_commit does). The read and the
    write run under the records lock the daemon's writers share across
    processes, so an entry appended meanwhile is never lost.
    """
    now = now or datetime.now(timezone.utc)
    cutoff = (now - timedelta(days=days)).date()
    p = Path(repo) / "state" / "hot.md"
    with records_write.repo_lock(repo):
        if not p.exists():
            return 0
        text = p.read_text()
        pruned, dropped = _prune_blocks(text, cutoff)
        removed = len(dropped)
        if removed and not dry_run:
            p.write_text(pruned)
    if removed and not dry_run:
        _write_prune_log(dropped)
    return removed


def prune_and_commit(repo: str, *, days: int = _PRUNE_DAYS, dry_run: bool = False) -> int:
    """records-prune: prune hot.md and commit it, read to commit under one
    hold of the records lock. Returns the count removed."""
    with records_write.repo_lock(repo):
        n = prune_hot_md(repo, days=days, dry_run=dry_run)
        if n and not dry_run:
            records_write._commit_file(repo, "state/hot.md", "prune: hot.md")
    return n


def context_health(repo: str, mcpbrain_home: str) -> list[str]:
    """Read-only health checks. Returns list of WARN strings (empty == healthy).

    Three checks:
    1. memory/*.md files holding personal identifiers (personal_data.find)
    2. hot.md stale entries (>14 days)
    3. <mcpbrain_home>/context/memory.md age (>7 days)

    MEMORY.md's length is not checked: nothing truncates it (owner_context
    fetches it whole, by name), so a line count warned weekly for nothing.
    """
    from mcpbrain import personal_data
    warnings: list[str] = []

    memory_dir = Path(repo) / "memory"
    if memory_dir.is_dir():
        for f in sorted(memory_dir.glob("*.md")):
            held = personal_data.find(f.read_text(errors="replace"))
            if held:
                kinds = held[0] if len(held) == 1 else \
                    ", ".join(held[:-1]) + " and " + held[-1]
                warnings.append(
                    f"WARN: memory/{f.name} holds {kinds} (remove the file and "
                    "its MEMORY.md line, or edit them out)")

    hot_md = Path(repo) / "state" / "hot.md"
    if hot_md.exists():
        cutoff = date.today() - timedelta(days=_WARN_HOT_DAYS)
        for line in hot_md.read_text().splitlines():
            m = _DATED_BULLET.match(line)
            if m:
                try:
                    entry_date = date.fromisoformat(m.group(1))
                except ValueError:
                    continue
                if entry_date < cutoff:
                    warnings.append(
                        f"WARN: hot.md entry {m.group(1)} is >{_WARN_HOT_DAYS} days old"
                        " (run records-prune)"
                    )

    brain_memory = Path(mcpbrain_home) / "context" / "memory.md"
    if brain_memory.parent.exists():
        if not brain_memory.exists():
            warnings.append(
                f"WARN: {brain_memory} missing — mcpbrain daemon may not have run"
            )
        else:
            age = (date.today() - date.fromtimestamp(brain_memory.stat().st_mtime)).days
            if age > _WARN_BRAIN_MEMORY_DAYS:
                warnings.append(
                    f"WARN: {brain_memory} not updated in {age} days — check daemon is running"
                )

    return warnings


# Commit message prefixes that belong to autonomous records writes.
_DIGEST_PREFIXES = ("core:", "voice:", "consolidate:", "gardener:")


def _git_log(repo: str, *args: str) -> str:
    """Run git log and return stdout, or '' on error. Locale-stable."""
    env = {**os.environ, "LC_ALL": "C", "LANGUAGE": ""}
    result = subprocess.run(
        ["git", "-C", repo, "log", *args],
        capture_output=True, text=True, env=env,
    )
    return result.stdout if result.returncode == 0 else ""


def build_weekly_digest(repo: str, *, since_days: int = 7) -> str:
    """Return a Markdown digest of autonomous records commits from the last N days.

    Includes only commits whose message starts with one of _DIGEST_PREFIXES.
    Each entry includes a short hash and a revert hint. Returns '' when there
    are no matching commits.
    """
    raw = _git_log(repo, f"--since={since_days} days ago", "--format=%H %s")
    if not raw.strip():
        return ""
    lines = []
    for line in raw.strip().splitlines():
        parts = line.split(" ", 1)
        if len(parts) != 2:
            continue
        sha, msg = parts
        if any(msg.startswith(p) for p in _DIGEST_PREFIXES):
            short = sha[:7]
            lines.append(f"- {short} {msg} (`git revert {short}` to undo)")
    if not lines:
        return ""
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    header = (
        f"## Weekly brain digest — {today}\n\n"
        f"Autonomous changes in the past {since_days} days "
        "(review below; `git revert <hash>` in the records repo to undo any):\n\n"
    )
    return header + "\n".join(lines) + "\n"


def prepend_digest_to_hot(repo: str, *, since_days: int = 7) -> bool:
    """Build the weekly digest and prepend it to state/hot.md under '## Just decided'.

    Returns True if a commit was made, False when there are no autonomous commits
    to report (no-op).
    """
    digest = build_weekly_digest(repo, since_days=since_days)
    if not digest:
        return False
    p = Path(repo) / "state" / "hot.md"
    # Read, write and commit under the records lock (shared across processes).
    with records_write.repo_lock(repo):
        if not p.exists():
            return False
        original = p.read_text()
        anchor = "## Just decided"
        idx = original.find(anchor)
        if idx == -1:
            log.warning("prepend_digest_to_hot: anchor %r not found in hot.md; "
                        "prepending at top of file", anchor)
            insert = 0
        else:
            insert = original.find("\n", idx) + 1
            while insert < len(original) and original[insert] == "\n":
                insert += 1
        p.write_text(original[:insert] + digest + "\n" + original[insert:])
        return records_write._commit_file(repo, "state/hot.md", "gardener: weekly digest")


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    ap = argparse.ArgumentParser(prog="mcpbrain records-cadence")
    ap.add_argument("cmd", choices=["records-prune", "records-health", "records-digest"])
    ap.add_argument("--days", type=int, default=_PRUNE_DAYS)
    ap.add_argument("--dry-run", action="store_true",
                    help="Show what would be pruned without writing")
    ns = ap.parse_args(argv)
    home = str(config.app_dir())
    repo = config.records_dir(home)
    if ns.cmd == "records-prune":
        n = prune_and_commit(repo, days=ns.days, dry_run=ns.dry_run)
        print(f"pruned {n} entries")
        return 0
    if ns.cmd == "records-digest":
        committed = prepend_digest_to_hot(repo, since_days=ns.days)
        print("digest committed" if committed else "no autonomous commits to digest")
        return 0
    warnings = context_health(repo, home)
    for w in warnings:
        print(w, file=sys.stderr)
    return 1 if warnings else 0

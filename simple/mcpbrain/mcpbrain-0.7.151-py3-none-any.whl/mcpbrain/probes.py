"""Connection probes: each returns a verified tri-state the UI renders.

A probe answers "is this connection working?" from config + local filesystem
only (no network), so it is cheap enough for the wizard's status poll. State is
one of: "not_started" (never configured), "ok" (configured + verified), or
"needs_action" (configured but broken / incomplete — the UI shows a fix button).
"""
from __future__ import annotations

import json
import time as _time
from datetime import datetime, timedelta, timezone
from pathlib import Path

from mcpbrain import auth, config

_CLAUDE_STALE_DAYS = 14


def _state(state: str, detail: str = "", last_verified=None) -> dict:
    return {"state": state, "detail": detail, "last_verified": last_verified}


def probe_google(home) -> dict:
    """Token present + locally-valid (no network refresh)."""
    token_file = auth.token_path()
    if not token_file.exists():
        return _state("not_started", "Not signed in")
    try:
        from google.oauth2.credentials import Credentials
        creds = Credentials.from_authorized_user_file(str(token_file), auth.SCOPES)
        valid = bool(creds and (creds.valid or creds.refresh_token))
    except Exception:  # noqa: BLE001 — unreadable token => needs re-auth
        return _state("needs_action", "Sign-in expired — reconnect")
    if not valid:
        return _state("needs_action", "Access expired — reconnect")
    return _state("ok", "Connected", last_verified=_mtime(token_file))


def probe_claude(home) -> dict:
    """No heartbeat → not_started; heartbeat present and fresh → ok."""
    p = Path(home) / "mcp_heartbeat.json"
    if not p.exists():
        return _state("not_started", "Plugin not connected — install the mcpbrain plugin")
    try:
        last = json.loads(p.read_text()).get("last_seen")
        if last is None:
            raise ValueError("missing last_seen")
        last_dt = datetime.fromisoformat(last)
        if last_dt.tzinfo is None:
            last_dt = last_dt.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) - last_dt > timedelta(days=_CLAUDE_STALE_DAYS):
            return _state("needs_action", "Not seen recently — open Claude Desktop", last_verified=last)
    except (OSError, ValueError):
        return _state("not_started", "Plugin not connected — install the mcpbrain plugin")
    return _state("ok", "Connected", last_verified=last)


# NOTE: ClickUp is not currently surfaced as a product connection — it was
# removed from all_connections()/verify_connections() (and the setup wizard).
# probe_clickup/_verify_clickup are kept dormant so the integration can be
# re-wired later without rebuilding the probe.
def probe_clickup(home) -> dict:
    key = config.clickup_api_key(home).strip()
    if not key:
        return _state("not_started", "Not connected")
    if not config.clickup_list_id(home).strip():
        return _state("needs_action", "API key set but no list selected")
    if not config.user_timezone(home):
        return _state("needs_action", "Set your timezone (required for deadlines)")
    return _state("ok", "Connected")


def _now_iso() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()


def _verify_clickup(home) -> dict:
    """Real ClickUp check: key+list+tz present AND a test API call resolves the list."""
    base = probe_clickup(home)
    if base["state"] != "ok":
        return base
    try:
        from mcpbrain import clickup
        clickup.list_tasks_full(home, include_closed=False)  # one API call
        return _state("ok", "Verified", last_verified=_now_iso())
    except Exception as exc:  # noqa: BLE001
        return _state("needs_action", f"ClickUp call failed — check the key ({exc.__class__.__name__})")


def _verify_google(home) -> dict:
    """Real Google check: attempt a token refresh (network).

    Distinguishes a GENUINE auth failure from a TRANSIENT network one so a
    momentary blip can't leave a sticky false "Sign-in expired":
      - RefreshError (invalid_grant — the refresh token is revoked/expired):
        real → downgrade to needs_action.
      - any other error (offline, timeout, rate-limit, DNS): transient → fall
        back to the cheap local probe (`base`), which is 'Connected' when the
        token is locally valid, rather than stamping 'expired'.
    Only verifies when the local token already looks ok; a locally-broken token
    (needs_action / not_started) is returned as-is without a pointless network call.
    """
    base = probe_google(home)
    if base["state"] != "ok":
        return base
    from google.auth.exceptions import RefreshError
    try:
        from google.oauth2.credentials import Credentials
        from google.auth.transport.requests import Request
        creds = Credentials.from_authorized_user_file(str(auth.token_path()), auth.SCOPES)
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        return _state("ok", "Verified", last_verified=_now_iso())
    except RefreshError:
        return _state("needs_action", "Sign-in expired — reconnect")
    except Exception:  # noqa: BLE001 — transient (network/timeout/rate-limit): keep local state
        return base


def _write_cache(home, cache: dict) -> None:
    """Atomically write the connections cache to connections.json."""
    import os
    import tempfile
    p = Path(home) / "connections.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(p.parent), prefix=".conn.", suffix=".tmp")
    with os.fdopen(fd, "w") as f:
        f.write(json.dumps(cache))
    os.replace(tmp, p)


def verify_connections(home, store=None) -> dict:
    """Run the expensive (network) checks and cache them to connections.json atomically."""
    verified = {"google": _verify_google(home)}
    _write_cache(home, verified)
    return verified


# A restore point newer than this is healthy. The daemon captures hourly, so
# two days means many consecutive captures or uploads have not landed.
_BACKUP_HEALTHY_S = 2 * 86400
# Uploads that keep failing for this long are flagged even while the newest
# restore point is still inside the healthy window.
_BACKUP_FAILING_S = 86400


def _ago(seconds: float) -> str:
    seconds = max(0.0, seconds)
    if seconds < 90:
        return "just now"
    if seconds < 5400:
        return f"{int(round(seconds / 60))}m ago"
    if seconds < 2 * 86400:
        return f"{int(round(seconds / 3600))}h ago"
    return f"{int(seconds // 86400)}d ago"


def _mb(n) -> str:
    return f"{(n or 0) / 1_000_000:,.0f} MB"


def _outbox_summary(home, cfg_backup) -> tuple[int, int, bool]:
    """(items waiting, bytes waiting, outbox full). Local reads only."""
    from mcpbrain import backup_outbox
    try:
        n = len(backup_outbox.pending_items(home))
        b = backup_outbox.outbox_bytes(home)
        cap = backup_outbox.Settings.from_config(
            cfg_backup if isinstance(cfg_backup, dict) else {}).outbox_max_bytes
    except Exception:  # noqa: BLE001 -- a probe must never raise
        return 0, 0, False
    return n, b, bool(cap and b >= cap)


def probe_backup(home) -> dict:
    """Backup health from local files only (backup_state.json + the outbox);
    never a Drive call. The newest restore point is the signal: `restore_point`
    (capture time), else `last_success` for a state file from an older daemon."""
    import time

    cfg = config.read_config(home)
    if not cfg.get("backup"):
        return _state("not_started", "Backup off")
    bstate = _read_backup_state(home)
    if bstate is _CORRUPT:
        return _state("needs_action", "Backup state file is unreadable/corrupt")
    if bstate is None:
        return _state("needs_action", "No backup yet")
    now = time.time()
    failures = bstate.get("consecutive_failures") or 0
    try:
        last_success = float(bstate.get("last_success") or 0) or None
    except (TypeError, ValueError):
        last_success = None
    try:
        restore_point = float(bstate.get("restore_point") or 0) or last_success
    except (TypeError, ValueError):
        restore_point = last_success
    pending, pending_bytes, full = _outbox_summary(home, cfg["backup"])
    if full:
        return _state("needs_action",
                      f"capture paused: {_mb(pending_bytes)} waiting to upload")
    if not restore_point:
        return _state("needs_action", "No backup yet"
                      + (f" ({failures} failed attempts)" if failures else ""))
    age = now - restore_point
    detail = f"restore point {_ago(age)}"
    if pending:
        detail += f" · {pending} waiting to upload ({_mb(pending_bytes)})"
    if age > _BACKUP_HEALTHY_S:
        return _state("needs_action",
                      f"Backup is out of date: {detail}"
                      + (f" ({failures} failed attempts)" if failures else ""))
    if failures and (not last_success or now - last_success > _BACKUP_FAILING_S):
        return _state("needs_action",
                      f"Backup upload failing — {detail} ({failures} failed attempts)")
    return _state("ok", detail, last_verified=_iso(restore_point))


def probe_records(home) -> dict:
    repo = Path(config.records_dir(home))
    if (repo / ".git").is_dir():
        detail = "Ready" if (repo / "CLAUDE.md").exists() else "Created (run Prepare working space)"
        return _state("ok", detail)
    return _state("not_started", "Records repo not created yet")


def probe_enrichment(home) -> dict:
    """Durable signal: the daemon stamps logs/enrich.log whenever it drains an
    enrichment batch (from the hourly enrich task or the backfill loop), so
    'Running' survives regardless of the transient enrich_inbox files it deletes
    on apply. Idle = no batch drained in the last 3 days."""
    log = Path(home) / "logs" / "enrich.log"
    try:
        fresh = (_time.time() - log.stat().st_mtime) < 3 * 86400
    except OSError:
        fresh = False
    if fresh:
        return _state("ok", "Running", last_verified=_mtime(log))
    return _state("needs_action",
                  "Idle — nothing enriched in 3 days; run the hourly enrich task "
                  "(or the backfill skill to catch up on history)")


def _mtime(p: Path):
    try:
        return datetime.fromtimestamp(p.stat().st_mtime, tz=timezone.utc).isoformat()
    except OSError:
        return None


def _iso(epoch: float):
    try:
        return datetime.fromtimestamp(epoch, tz=timezone.utc).isoformat()
    except (OSError, OverflowError, ValueError):
        return None


def last_backup_success(home) -> float | None:
    """Epoch seconds of the last SUCCESSFUL backup, or None if unknown.

    backup_state.json's recorded `last_success` only. The daemon no longer
    writes snapshot.enc (an upgraded install's stale one is deleted after the
    first new-layout commit), so a file's mtime says nothing about a backup. A state file that EXISTS but is
    corrupt reads as "not fresh" (None), the same as one recording no success.
    Public so the reflow seed's backup gate need not reach into this module's
    private reader."""
    state = _read_backup_state(home)
    if state is None or state is _CORRUPT:
        return None
    try:
        v = float(state.get("last_success") or 0)
    except (TypeError, ValueError):
        return None
    return v or None


def last_restore_point(home) -> float | None:
    """Epoch seconds of the newest committed restore point's CAPTURE time
    (`restore_point`), falling back to `last_success` for a state file from
    an older daemon; None when no backup is known. A capture taken days ago
    that only commits now is old: gates that promise "a restore point less
    than a day old" must read this, not the commit time."""
    state = _read_backup_state(home)
    if state is None or state is _CORRUPT:
        return None
    for key in ("restore_point", "last_success"):
        try:
            v = float(state.get(key) or 0)
        except (TypeError, ValueError):
            v = 0
        if v:
            return v
    return None


# Sentinel: backup_state.json EXISTS but could not be parsed as a JSON object
# (truncated by a crash mid-write, hand-edited, disk corruption). Distinct
# from "file absent" (a fresh install, or before the first backup): a corrupt
# file must read as "not fresh", never as "no backup yet" or as healthy.
_CORRUPT = object()


def _read_backup_state(home):
    """The daemon's record of the last backup ATTEMPT.

    Written by ``daemon.write_backup_state``. Returns None if the file is
    absent ("no backup yet"), the
    `_CORRUPT` sentinel if it exists but is not a parseable JSON object
    (treat as not fresh), or the parsed dict otherwise.
    """
    p = Path(home) / "backup_state.json"
    try:
        text = p.read_text()
    except OSError:
        return None
    try:
        state = json.loads(text)
    except ValueError:
        return _CORRUPT
    return state if isinstance(state, dict) else _CORRUPT


def _read_cache(home) -> dict:
    p = Path(home) / "connections.json"
    try:
        return json.loads(p.read_text())
    except (OSError, ValueError):
        return {}


# Cheap (no-network) probes, keyed by connection name. Resolved at call time
# (not captured at import) so tests can monkeypatch an individual probe.
def _cheap_probes() -> dict:
    return {
        "google": probe_google,
        "claude": probe_claude,
        "backup": probe_backup,
        "records": probe_records,
        "enrichment": probe_enrichment,
    }


def all_connections(home, store=None) -> dict:
    """All connection probes keyed by name. `store` reserved for future probes.

    Overlays a cached verified result (written by a separate cadence) on top of
    cheap live probes. The cache wins when present; the live state takes over
    immediately when a connection is removed (not_started).
    """
    cached = _read_cache(home)
    out = {}
    for name, probe in _cheap_probes().items():
        live = probe(home)
        c = cached.get(name)
        # Verified cache wins when the connection is still live (not not_started).
        # If the live probe returns not_started the connection was removed, so the
        # stale cache must not mask that — flip immediately.
        if c and live["state"] != "not_started":
            out[name] = c
        else:
            out[name] = live
    return out


def refresh_connection_cache(home, name: str = "google") -> dict | None:
    """Immediately update one connection's cached status from its cheap local
    probe, merged into connections.json.

    all_connections() lets a cached entry win over the live probe while the
    connection is up (the network 'Verified' result is richer than the cheap
    'Connected' one). That overlay means a stale 'Sign-in expired' cache keeps
    masking a just-completed re-auth until the next network verify runs. Calling
    this right after writing a new token brings the cache current at once (as
    'Connected'); the periodic verify later upgrades it to 'Verified'. No
    network, so it is safe to call inline in an OAuth callback. Returns the new
    entry, or None for an unknown name."""
    probe = _cheap_probes().get(name)
    if probe is None:
        return None
    cache = _read_cache(home)
    cache[name] = probe(home)
    _write_cache(home, cache)
    return cache[name]

import contextvars
import hashlib
import json
import re
import sqlite3
import threading
from contextlib import closing, contextmanager, nullcontext
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Iterator

import sqlite_vec

# chunking is dependency-free; no store->enrich coupling. action_fingerprint is
# the single source of truth shared with graph_write so a text rewrite produces
# a fingerprint the near-duplicate guard recognises.
from mcpbrain.chunking import action_fingerprint as _action_fingerprint, slugify, split_aliases


# Enrichment-logic version. Bump when extraction rules/guards/model materially
# improve: chunks enriched under an older version are re-flowed (reflow_outdated_chunks)
# so the existing corpus re-extracts itself under current logic over time. Chunks
# enriched before this stamp existed default to 0, so shipping at 1 schedules a
# one-time gradual re-extraction of the whole already-enriched corpus.
# Deliberately still 1. A 1 -> 2 bump was made on 2026-07-29 and REVERTED on
# 2026-07-30, before its re-extraction finished. Recording why, because the
# reasoning is the useful part:
#
# The bump existed to make spec 2's C2/C3/C4 fixes reach the 22,357 digests
# already stored — build_semantic_doc only runs on re-enrichment, so 0 of them
# carried a date, so importance.recency_decay could not rank the highest-value
# chunks in the store by age (it returned a "neutral" 0.5 then; an undated
# chunk now gets 0.0, no recency boost at all). That problem was real. Forcing the whole
# corpus back through the model was the wrong solution:
#
#   * `source_type` (C4) is 100% derivable from `thread_id`, and `date` (C2) is
#     recoverable from the digest's own "Date:" line for ~70% of them — both with
#     no model call. See mcpbrain/digest_provenance.py and
#     `bin/repair.py digest-provenance`.
#   * 19,934 of 21,029 email digests have had their source chunks pruned by the
#     retention job, so re-enrichment could NOT have recovered a date for the
#     remaining 30% either. The spend bought nothing exactly where the
#     deterministic route falls short.
#   * `message_id` (C3) was the only field genuinely needing re-extraction, and
#     it was removed instead — nothing read it, a thread-level digest carrying
#     one message's id is false precision, and it collided with that message's
#     own raw chunk in thread_enrich._chunk_key.
#
# Net: the bump would have re-enriched ~56.6k chunks through Haiku for a result
# two deterministic passes deliver for free. Reverting restores enriched=1 on
# everything reflow_outdated_chunks had reset; no graph rows or embeddings were
# ever touched by that reset, so nothing was lost in either direction.
#
# Bump this when the enrichment LOGIC changes — when the model's OUTPUT would
# differ. Do not bump it to backfill metadata that is derivable from data already
# in the store.
ENRICH_LOGIC_VERSION = 1


def fts5_supports_contentless() -> bool:
    """True when SQLite is new enough for contentless FTS5 WITH deletes.

    contentless_delete=1 lands in 3.43. Without it a contentless table cannot
    service DELETE, which mcpbrain does on every retention and GC sweep — so
    below the floor we keep the content-storing form. The version comes from
    whichever Python the wheel installed under, and the Windows path pins its
    own x64 interpreter, so this MUST be checked and never assumed.
    """
    parts = tuple(int(x) for x in sqlite3.sqlite_version.split(".")[:2])
    return parts >= (3, 43)


def strict_supported() -> bool:
    """STRICT tables land in SQLite 3.37. Same guard rationale as
    fts5_supports_contentless(): the version comes from whichever Python the
    wheel installed under and MUST be checked at runtime, never assumed.
    Below the floor the tables are created without STRICT — i.e. exactly the
    loose behaviour they have always had.
    """
    parts = tuple(int(x) for x in sqlite3.sqlite_version.split(".")[:2])
    return parts >= (3, 37)


def _strict_suffix() -> str:
    """`) STRICT` vs `)` for a CREATE TABLE, resolved at call time.

    Single source of truth so no table can silently drift out of the STRICT
    set, and so the version guard exists in exactly one place.
    """
    return " STRICT" if strict_supported() else ""


def _meta_extract(path: str) -> str:
    """SQL fragment reading `path` out of chunks.metadata.

    Single source of truth so an expression INDEX and the QUERY that should
    use it can never drift apart — a mismatch silently produces a full table
    scan, which is exactly the 0.7.105 failure mode. Every read site in this
    module that extracts a value from chunks.metadata MUST build its SQL
    through this function rather than hand-writing json_extract.

    Deliberately `json_extract` UNCONDITIONALLY — never `jsonb_extract`, and
    never version-dependent. `CREATE INDEX IF NOT EXISTS` in init() keys on the
    index NAME, not its expression, so an already-built index is NOT replaced
    when this fragment changes. Every real installed store already has these
    five expression indexes built on `json_extract`; SQLite does not consider
    `jsonb_extract(...)` the same expression for index matching, so emitting
    `jsonb_extract` here silently kills those indexes and reinstates the
    0.7.105 full-`SCAN chunks` outage on the whole fleet the moment a daemon
    restarts. Measured cost of staying on json_extract over TEXT-stored JSON:
    15.6ms vs 14.9ms on a 50k-row scan — noise. Version-dependent SQL text is
    only ever safe where it does not have to match a persisted schema object.

    Assumes SCALAR json paths (message_id, file_id, thread_id, event_id, date,
    …) — true of all current call sites. An object/array-valued path would
    behave differently between json_extract and jsonb_extract, so this
    assumption matters to anyone reconsidering JSONB later.
    """
    return f"json_extract(metadata,'{path}')"


def _field_is_locked(db, entity_id: str, field: str) -> bool:
    """True when the user has corrected `field` on `entity_id` (brain_graph_correct).

    Guarded on the table existing so stores/tests predating it keep working.
    """
    if not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' "
                      "AND name='entity_field_locks'").fetchone():
        return False
    return db.execute("SELECT 1 FROM entity_field_locks WHERE entity_id=? AND field=?",
                      (entity_id, field)).fetchone() is not None


# The pending_changes row an approval is applying right now (auto_changes.
# decide sets it around APPLY[kind]). While set, every change recorded here
# also marks that row applied with its change id, in the same transaction as
# the change itself: once the change lands, a later failure can never put the
# row back in the queue to be applied twice.
SETTLING_PENDING: contextvars.ContextVar = contextvars.ContextVar(
    "mcpbrain_settling_pending", default=None)


def _log_change_tx(db, change_type: str, *, ref_id: str = "", summary: str = "",
                   detail: str = "", revert_ref: str = "", source: str = "") -> int:
    """Insert one change_log row on the caller's open connection, so a writer
    can record a change in the same transaction as the write itself."""
    cid = db.execute(
        "INSERT INTO change_log(change_type, ref_id, summary, detail, revert_ref, source) "
        "VALUES(?,?,?,?,?,?)",
        (change_type, ref_id, summary, detail, revert_ref, source)).lastrowid
    pending = SETTLING_PENDING.get()
    if pending is not None:
        db.execute("UPDATE pending_changes SET status='applied', change_log_id=? "
                   "WHERE id=? AND status IN ('deciding', 'applied')", (cid, pending))
    return cid


def _chunk_enrich_snapshot(row, meta: dict) -> dict:
    """The enrichment columns and re-include flag of one chunk row, as the
    chunks_reincluded change records them (and its undo compares them)."""
    return {"enrich_state": row["enrich_state"] or "",
            "enriched": int(row["enriched"] or 0),
            "enriched_version": int(row["enriched_version"] or 0),
            "enrich_attempts": int(row["enrich_attempts"] or 0),
            "force_enrich": meta.get("force_enrich")}


class EntityHidden(Exception):
    """A write that needs a visible entity was asked for a suppressed one."""


def _log_recorded_change(db, change: dict, ref_id, before, after) -> int:
    """Record an undoable change described by `change` ({change_type, summary?,
    detail?, source?, ref_id?}) with a JSON {before, after} revert_ref.

    The new change_log id is also written back into `change["change_log_id"]`,
    so a caller holding the dict (an applier whose mutator returns a bool or a
    count) learns exactly which row its own write recorded."""
    from mcpbrain.change_undo import revert_json
    change["change_log_id"] = _log_change_tx(
        db, change["change_type"], ref_id=str(change.get("ref_id", ref_id)),
        summary=change.get("summary", ""), detail=change.get("detail", ""),
        revert_ref=revert_json(before, after), source=change.get("source", ""))
    return change["change_log_id"]


_MERGE_TOUCHED_COLS = ("name", "type", "org", "aliases", "email_addr", "notes")


def _merge_entities_tx(db, loser_id, winner_id, *, canonical_name=None,
                       method="deterministic") -> dict | None:
    """Fold loser into winner on a caller-held write connection.

    Behaviour is exactly Store.merge_entities' (see its docstring), plus three
    things the graph-corrections work needs: distinct pairs are repointed onto
    the winner, a user rejection on a loser triple is carried onto the surviving
    winner triple, and the function RETURNS a snapshot from which _unmerge_tx
    can restore the pre-merge state exactly. Returns None for a no-op (same id,
    or either entity missing).

    Every value in the snapshot is JSON-native (SQLite returns str/int/float/
    None), because Task 4 stores it as JSON. Every table that ON DELETE
    CASCADEs from entities is captured here; a new cascading table must be
    added the same way as `communities`, or unmerge silently loses its rows."""
    if loser_id == winner_id:
        return None
    loser = db.execute("SELECT * FROM entities WHERE id=?", (loser_id,)).fetchone()
    win = db.execute("SELECT * FROM entities WHERE id=?", (winner_id,)).fetchone()
    if loser is None or win is None:
        return None

    def sub(x):
        return winner_id if x == loser_id else x

    def table_exists(name):
        return db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
                          (name,)).fetchone() is not None

    rels = [dict(r) for r in db.execute(
        "SELECT * FROM entity_relations WHERE entity_a=? OR entity_b=?", (loser_id, loser_id))]
    collisions = []
    for (a, rel, b) in {(sub(r["entity_a"]), r["relation"], sub(r["entity_b"])) for r in rels}:
        row = db.execute("SELECT * FROM entity_relations WHERE entity_a=? AND relation=? "
                         "AND entity_b=?", (a, rel, b)).fetchone()
        if row is not None:
            collisions.append(dict(row))
    # Every pre-existing winner self-loop is swept below, whether or not a loser
    # triple collides with it, so all of them belong in the snapshot.
    seen = {c["id"] for c in collisions}
    collisions += [dict(r) for r in db.execute(
        "SELECT * FROM entity_relations WHERE entity_a=entity_b AND entity_a=?", (winner_id,))
        if r["id"] not in seen]
    # Other relations whose invalidated_by_relation_id points at a loser
    # relation: the merge may DELETE that relation (a collision or a self-loop),
    # and the FK's ON DELETE SET NULL then clears the pointer, so it has to be
    # remembered to be put back.
    # Subqueries, not bound IN-lists: a large entity (10k+ email links exist
    # live) would exceed SQLite's host-parameter limit.
    snap_ids = {r["id"] for r in rels} | {c["id"] for c in collisions}
    pointers = []
    if rels and "invalidated_by_relation_id" in rels[0]:
        pointers = [[r[0], r[1]] for r in db.execute(
            "SELECT id, invalidated_by_relation_id FROM entity_relations "
            "WHERE invalidated_by_relation_id IN (SELECT id FROM entity_relations "
            "WHERE entity_a=? OR entity_b=?)", (loser_id, loser_id)) if r[0] not in snap_ids]
    emails = [dict(r) for r in db.execute(
        "SELECT * FROM email_entities WHERE entity_id=?", (loser_id,))]
    winner_overlap = [r[0] for r in db.execute(
        "SELECT message_id FROM email_entities WHERE entity_id=? AND message_id IN "
        "(SELECT message_id FROM email_entities WHERE entity_id=?)", (winner_id, loser_id))]
    snap = {
        "loser": dict(loser),
        "winner": {c: win[c] for c in (*_MERGE_TOUCHED_COLS, "mentions")},
        "winner_id": winner_id,
        "relations": rels,
        "collisions": collisions,
        "relation_pointers": pointers,
        "observation_ids": [r[0] for r in db.execute(
            "SELECT id FROM entity_observations WHERE entity_id=?", (loser_id,))],
        "emails": emails,
        "winner_email_overlap": winner_overlap,
        "suppression": None,
        "distinct_pairs": [], "winner_distinct_pairs": [],
        "field_locks": [dict(r) for r in db.execute(
            "SELECT * FROM entity_field_locks WHERE entity_id=?", (loser_id,))]
            if table_exists("entity_field_locks") else [],
        "communities": [dict(r) for r in db.execute(
            "SELECT * FROM entity_communities WHERE entity_id=?", (loser_id,))]
            if table_exists("entity_communities") else [],
    }
    has_suppressions = table_exists("entity_suppressions")
    if has_suppressions:
        row = db.execute("SELECT * FROM entity_suppressions WHERE entity_id=?",
                         (loser_id,)).fetchone()
        snap["suppression"] = dict(row) if row else None
    has_pairs = table_exists("entity_distinct_pairs")
    if has_pairs:
        snap["distinct_pairs"] = [dict(r) for r in db.execute(
            "SELECT * FROM entity_distinct_pairs WHERE a=? OR b=?", (loser_id, loser_id))]
        snap["winner_distinct_pairs"] = [dict(r) for r in db.execute(
            "SELECT * FROM entity_distinct_pairs WHERE a=? OR b=?", (winner_id, winner_id))]

    # --- independent-source support follows a collided relation -------------
    # A loser relation whose triple already exists on the winner is DELETED
    # below, and its relation_sources rows cascade with it. Move them onto the
    # surviving winner copy first (spec 2026-10-22 §3), so a merge of {T1} and
    # {T2,T3} supports the edge with 3 sources, not 1. The loser's own source
    # rows are snapshotted (restored with it on unmerge) and the rows this adds
    # to the winner copy are recorded (removed on unmerge); the winner copy's
    # prior strength/derived/legacy_strength is in `collisions` already.
    snap["relation_sources"] = []
    snap["moved_sources"] = []
    has_sources = table_exists("relation_sources")
    if has_sources and rels:
        snap["relation_sources"] = [dict(r) for r in db.execute(
            "SELECT * FROM relation_sources WHERE relation_id IN "
            "(SELECT id FROM entity_relations WHERE entity_a=? OR entity_b=?)",
            (loser_id, loser_id))]
        from mcpbrain import graph_write as _gw
        for r in rels:
            a, b = sub(r["entity_a"]), sub(r["entity_b"])
            if a == b:
                continue                     # becomes a self-loop: swept below
            w = db.execute("SELECT * FROM entity_relations WHERE entity_a=? AND relation=? "
                           "AND entity_b=? AND id != ?", (a, r["relation"], b, r["id"])
                           ).fetchone()
            if w is None:
                continue                     # repointed in place, sources stay
            _gw._preserve_legacy_strength(db, w["id"])
            for src in [x for x in snap["relation_sources"] if x["relation_id"] == r["id"]]:
                cur = db.execute(
                    "INSERT OR IGNORE INTO relation_sources"
                    "(relation_id, source_key, source_class, first_seen) VALUES(?,?,?,?)",
                    (w["id"], src["source_key"], src["source_class"], src["first_seen"]))
                if cur.rowcount:
                    snap["moved_sources"].append([w["id"], src["source_key"]])
            # Prefer a non-derived survivor: the winner's copy was derived
            # (no primary source) and the loser's is real -> the copy takes
            # the loser's standing.
            if (w["derived"] or 0) and not (r.get("derived") or 0):
                db.execute("UPDATE entity_relations SET derived=0, strength=?, "
                           "legacy_strength=? WHERE id=?",
                           (r.get("strength"), r.get("legacy_strength"), w["id"]))
            if db.execute("SELECT 1 FROM relation_sources WHERE relation_id=? AND "
                          f"source_class IN {_gw._EVIDENCE_SQL}", (w["id"],)).fetchone():
                db.execute("UPDATE entity_relations SET strength=?, derived=0 WHERE id=?",
                           (_gw.relation_strength(db, w["id"]), w["id"]))

    # --- the merge itself: the pre-existing statements, unchanged ------------
    # Repoint relations onto the winner; UPDATE OR IGNORE drops rows that
    # would collide with an existing winner triple (the UNIQUE index).
    db.execute("UPDATE OR IGNORE entity_relations SET entity_a=? WHERE entity_a=?",
               (winner_id, loser_id))
    db.execute("UPDATE OR IGNORE entity_relations SET entity_b=? WHERE entity_b=?",
               (winner_id, loser_id))
    # Rows still on the loser are the ignored duplicates -> delete them.
    db.execute("DELETE FROM entity_relations WHERE entity_a=? OR entity_b=?",  # admin-delete-ok
               (loser_id, loser_id))
    # Drop every winner self-loop. Scoped to the winner: the only self-loops a
    # repoint can create have winner on both sides, so this never sweeps
    # unrelated rows. It also removes a winner self-loop that PREDATES the
    # merge; the snapshot captures every such row under `collisions`, so
    # _unmerge_tx restores it.
    db.execute(
        "DELETE FROM entity_relations WHERE entity_a=entity_b AND entity_a=?",  # admin-delete-ok
        (winner_id,),
    )
    # A user rejection on a loser triple survives onto the winner's copy of it.
    for r in rels:
        if r.get("user_verdict") == "rejected":
            db.execute(
                "UPDATE entity_relations SET user_verdict='rejected', "
                "invalidated_at=COALESCE(invalidated_at, ?), superseded_reason='user_rejected' "
                "WHERE entity_a=? AND relation=? AND entity_b=? AND entity_a != entity_b",
                (r.get("invalidated_at") or datetime.now(timezone.utc).isoformat(),
                 sub(r["entity_a"]), r["relation"], sub(r["entity_b"])))

    # Repoint the loser's observations + email links onto the winner so
    # nothing is orphaned when the loser row is deleted below. email_entities
    # has PRIMARY KEY(message_id, entity_id): OR IGNORE drops rows that would
    # collide with an existing winner link, then the leftover loser rows go.
    db.execute("UPDATE entity_observations SET entity_id=? WHERE entity_id=?",
               (winner_id, loser_id))
    db.execute("UPDATE OR IGNORE email_entities SET entity_id=? WHERE entity_id=?",
               (winner_id, loser_id))
    db.execute("DELETE FROM email_entities WHERE entity_id=?", (loser_id,))  # admin-delete-ok
    # Clean up the loser's suppression row (if any) so it doesn't dangle
    # against a deleted id. Deliberately NOT repointed to the winner: the
    # survivor keeps its OWN visibility — merging a hidden junk duplicate
    # into a real, visible entity must not hide the real entity. Guarded so
    # stores predating the suppression feature don't error.
    if has_suppressions:
        db.execute("DELETE FROM entity_suppressions WHERE entity_id=?", (loser_id,))  # admin-delete-ok
    # "These two are different" follows the loser onto the winner: if the user
    # said loser != X, the merged entity is still != X. A pair between loser
    # and winner themselves is dropped (it would be a self-pair).
    if has_pairs:
        for p in snap["distinct_pairs"]:
            other = p["b"] if p["a"] == loser_id else p["a"]
            if other != winner_id:
                db.execute("INSERT OR IGNORE INTO entity_distinct_pairs(a,b) VALUES(?,?)",
                           tuple(sorted((winner_id, other))))
        db.execute("DELETE FROM entity_distinct_pairs WHERE a=? OR b=?",  # admin-delete-ok
                   (loser_id, loser_id))

    new_org = win["org"] if win["org"] not in ("", "unknown") else loser["org"]
    new_type = win["type"] if win["type"] != "unknown" else loser["type"]
    new_name = canonical_name or win["name"]
    new_mentions = (win["mentions"] or 0) + (loser["mentions"] or 0)
    # Carry the loser's name + aliases (and the winner's prior name, if it was
    # renamed) onto the winner as aliases, so a future mention of the
    # merged-away name still resolves here.
    alias_set = set()
    for src in (win["aliases"], loser["aliases"]):
        alias_set.update(split_aliases(src))  # tolerant of legacy comma values
    alias_set.add(win["name"])
    alias_set.add(loser["name"])
    alias_set.discard(new_name)
    alias_set.discard("")
    new_aliases = "|".join(sorted(alias_set))
    db.execute("UPDATE entities SET name=?,type=?,org=?,mentions=?,aliases=? WHERE id=?",  # lock-exempt: automated merges skip entities with user corrections (has_user_corrections); a user merge is itself a correction
               (new_name, new_type, new_org, new_mentions, new_aliases, winner_id))
    # What the merge LEFT on the winner, so _unmerge_tx restores a column only
    # where nothing has changed it since. A caller that writes more winner
    # columns in the same transaction (graph_corrections._apply_merge's
    # best-of email/notes) must update this after its own write.
    snap["winner_after"] = {"name": new_name, "type": new_type, "org": new_org,
                            "aliases": new_aliases, "email_addr": win["email_addr"],
                            "notes": win["notes"]}
    prior_aliases = set(split_aliases(win["aliases"]))
    snap["aliases_added"] = sorted(alias_set - prior_aliases)
    snap["aliases_removed"] = sorted(prior_aliases - alias_set)
    snap["merge_log_id"] = db.execute(
        "INSERT INTO entity_merge_log(winner_id,loser_id,loser_name,method) "
        "VALUES(?,?,?,?)",
        (winner_id, loser_id, loser["name"], method)).lastrowid
    db.execute("DELETE FROM entities WHERE id=?", (loser_id,))  # admin-delete-ok
    return snap


def _insert_row(db, table: str, row: dict, *, or_ignore: bool = False) -> None:
    """INSERT `row` (a column->value dict) into `table` verbatim, ids included."""
    verb = "INSERT OR IGNORE" if or_ignore else "INSERT"
    db.execute(f"{verb} INTO {table}({', '.join(row)}) VALUES({', '.join('?' * len(row))})",
               tuple(row.values()))


def _restore_row(db, table: str, row: dict, key: str = "id") -> None:
    """Put `row` back exactly: UPDATE every column by key, or INSERT it if gone."""
    cols = [c for c in row if c != key]
    cur = db.execute(f"UPDATE {table} SET {', '.join(f'{c}=?' for c in cols)} WHERE {key}=?",
                     (*[row[c] for c in cols], row[key]))
    if cur.rowcount == 0:
        _insert_row(db, table, row)


def _unmerge_tx(db, snap: dict) -> None:
    """Reverse a _merge_entities_tx exactly, or refuse. Raises ValueError naming
    the conflict when anything the merge moved has changed since: a partial
    restore would be worse than none.

    Winner columns, per column, when the snapshot records `winner_after`
    (what the merge left on the winner):
      name/type/org/email_addr/notes -- put back to the pre-merge value only
        if the column still equals the post-merge value; a change since the
        merge (re-enrichment, an org backfill, a synthesis note, a graph-UI
        edit) is kept.
      aliases -- only the aliases the merge added are removed (and any it
        dropped are put back); aliases added since the merge are kept.
      mentions -- the loser's mentions are subtracted, never overwritten, so
        mentions counted on the winner since the merge are kept.
    A snapshot without `winner_after` (written before it existed) falls back
    to restoring the pre-merge scalars wholesale."""
    loser_id, winner_id = snap["loser"]["id"], snap["winner_id"]

    def sub(x):
        return winner_id if x == loser_id else x

    if db.execute("SELECT 1 FROM entities WHERE id=?", (winner_id,)).fetchone() is None:
        raise ValueError(f"cannot undo: {winner_id} no longer exists (it was merged or removed since)")
    if db.execute("SELECT 1 FROM entities WHERE id=?", (loser_id,)).fetchone() is not None:
        raise ValueError(f"cannot undo: an entity with id {loser_id} exists again")
    for oid in snap["observation_ids"]:
        row = db.execute("SELECT entity_id FROM entity_observations WHERE id=?", (oid,)).fetchone()
        if row is not None and row[0] != winner_id:
            raise ValueError(f"cannot undo: observation {oid} has moved to {row[0]}")
    for r in snap["relations"]:
        row = db.execute("SELECT entity_a, entity_b FROM entity_relations WHERE id=?",
                         (r["id"],)).fetchone()
        if row is not None and (row[0], row[1]) != (sub(r["entity_a"]), sub(r["entity_b"])):
            raise ValueError(f"cannot undo: relation {r['id']} has changed since the merge")
    for c in snap["collisions"]:
        # A winner row the merge collided with must still be that same triple:
        # if it was deleted and its triple re-created under a new id, restoring
        # it by id would trip UNIQUE mid-restore.
        # Exception: a pre-existing winner self-loop is itself deleted by the
        # merge's self-loop sweep, so its absence is expected, not a conflict,
        # PROVIDED the triple has not been re-created under another id since
        # (e.g. re-enrichment re-deriving it) -- that would trip UNIQUE too.
        row = db.execute("SELECT entity_a, relation, entity_b FROM entity_relations WHERE id=?",
                         (c["id"],)).fetchone()
        if row is None and c["entity_a"] == c["entity_b"]:
            again = db.execute("SELECT id FROM entity_relations WHERE entity_a=? AND relation=? "
                               "AND entity_b=?",
                               (c["entity_a"], c["relation"], c["entity_b"])).fetchone()
            if again is None:
                continue
            raise ValueError(f"cannot undo: relation {c['entity_a']} {c['relation']} "
                             f"{c['entity_b']} was re-created as relation {again[0]} "
                             f"since the merge")
        if row is None or tuple(row) != (c["entity_a"], c["relation"], c["entity_b"]):
            raise ValueError(f"cannot undo: relation {c['id']} ({c['entity_a']} "
                             f"{c['relation']} {c['entity_b']}) was removed or changed "
                             f"since the merge")

    # Relations restored below can point (invalidated_by_relation_id) at one
    # another in any order; defer FK checks to COMMIT so the order cannot
    # matter. Resets automatically when this transaction ends.
    db.execute("PRAGMA defer_foreign_keys=ON")
    _insert_row(db, "entities", snap["loser"])
    w = snap["winner"]
    after = snap.get("winner_after")
    if after is not None:
        cur = db.execute("SELECT * FROM entities WHERE id=?", (winner_id,)).fetchone()
        w = {c: (w[c] if (cur[c] or "") == (after[c] or "") else cur[c])
             for c in ("name", "type", "org", "email_addr", "notes")}
        added = set(snap.get("aliases_added") or ())
        parts = [a for a in split_aliases(cur["aliases"]) if a not in added]
        parts += [a for a in snap.get("aliases_removed") or () if a not in parts]
        w["aliases"] = "|".join(parts)
    loser_mentions = snap["loser"].get("mentions") or 0
    db.execute(
        "UPDATE entities SET name=?, type=?, org=?, aliases=?, email_addr=?, notes=?, "  # lock-exempt: undoing a merge restores the pre-merge row
        "mentions=MAX(COALESCE(mentions,0)-?, 0) WHERE id=?",
        (w["name"], w["type"], w["org"], w["aliases"], w["email_addr"], w["notes"],
         loser_mentions, winner_id))
    # Collisions first: a loser triple re-inserted by id must not trip the
    # UNIQUE constraint against a winner row not yet put back to its own triple.
    for c in snap["collisions"]:
        _restore_row(db, "entity_relations", c)
    for r in snap["relations"]:
        _restore_row(db, "entity_relations", r)
    for rid, ptr in snap.get("relation_pointers", []):
        db.execute("UPDATE entity_relations SET invalidated_by_relation_id=? WHERE id=?",
                   (ptr, rid))
    # Independent-source rows: drop what the merge added to the winner's
    # copies, put the loser relations' own rows back (they cascaded away with
    # any collided loser relation). Older snapshots have neither key.
    for wid, key in snap.get("moved_sources", []):
        db.execute("DELETE FROM relation_sources WHERE relation_id=? AND source_key=?",  # admin-delete-ok
                   (wid, key))
    for src in snap.get("relation_sources", []):
        _insert_row(db, "relation_sources", src, or_ignore=True)
    for oid in snap["observation_ids"]:
        db.execute("UPDATE entity_observations SET entity_id=? WHERE id=?", (loser_id, oid))
    overlap = set(snap["winner_email_overlap"])
    for e in snap["emails"]:
        if e["message_id"] not in overlap:
            db.execute("DELETE FROM email_entities WHERE message_id=? AND entity_id=?",  # admin-delete-ok
                       (e["message_id"], winner_id))
        _insert_row(db, "email_entities", e, or_ignore=True)
    if snap["suppression"] is not None:
        _insert_row(db, "entity_suppressions", snap["suppression"], or_ignore=True)
    prior_winner_pairs = {(p["a"], p["b"]) for p in snap["winner_distinct_pairs"]}
    for p in snap["distinct_pairs"]:
        other = p["b"] if p["a"] == loser_id else p["a"]
        repointed = tuple(sorted((winner_id, other)))
        if other != winner_id and repointed not in prior_winner_pairs:
            db.execute("DELETE FROM entity_distinct_pairs WHERE a=? AND b=?", repointed)  # admin-delete-ok
        _insert_row(db, "entity_distinct_pairs", p, or_ignore=True)
    for lk in snap["field_locks"]:
        _insert_row(db, "entity_field_locks", lk, or_ignore=True)
    for cm in snap["communities"]:
        _insert_row(db, "entity_communities", cm, or_ignore=True)
    db.execute("DELETE FROM entity_merge_log WHERE id=?", (snap["merge_log_id"],))  # admin-delete-ok


def _fts_match_query(query: str, *, require_all: bool = True) -> str:
    """Turn an arbitrary user string into a safe FTS5 MATCH expression.

    FTS5 treats characters like '-', ':', '"', '*', '(', ')' as query operators,
    so a raw query such as 'VERIFY-CAP-001' is parsed as a column filter and
    raises 'no such column: CAP'. We split on whitespace and wrap each token in
    double quotes (escaping embedded quotes by doubling), turning every token
    into a literal phrase. Tokens that tokenise to nothing (e.g. a lone '-')
    simply match nothing.

    require_all=True (default) joins tokens with whitespace — FTS5's implicit
    AND, requiring every token literally present. require_all=False joins with
    explicit OR — see `fts_search`'s fallback for why a caller would want the
    looser form.

    Returns '' when the query has no usable tokens; callers should treat an
    empty result as "no keyword matches" rather than passing it to MATCH.
    """
    quoted = ['"' + tok.replace('"', '""') + '"' for tok in query.split() if tok]
    return quoted[0] if len(quoted) == 1 else (" " if require_all else " OR ").join(quoted)


def store_dim_from_path(path) -> int | None:
    """Read the vector dim a store was built with from its meta table.

    Returns None when the file does not exist or has no dim row.
    """
    from pathlib import Path as _Path
    import sqlite3 as _sqlite3
    p = _Path(path)
    if not p.exists():
        return None
    try:
        db = _sqlite3.connect(f"file:{p}?mode=ro", uri=True)
        row = db.execute("SELECT v FROM meta WHERE k='dim'").fetchone()
        db.close()
        return int(row[0]) if row else None
    except Exception:  # noqa: BLE001
        return None


DEFAULT_BUSY_TIMEOUT_MS = 5000

# cache_size/mmap_size are PER CONNECTION (SQLite's own private page cache,
# not shared OS-level memory the way an mmap'd file region can be), and the
# daemon opens roughly one connection per call across ~21 threads (PR #25
# finding 5) -- e.g. graph_write.upsert_relation opens one per relation. The
# large tuned values below are sized for a single long-lived, throughput-
# sensitive connection (a rebuild, a full-store snapshot, a multi-thousand-row
# reindex batch); multiplied across many short-lived per-call connections they
# could add on the order of a gigabyte of RSS, and this project gates
# releases on peak RSS (226 MB verified in 0.7.113). Everyday per-call
# connections get the smaller default; `bulk=True` opts a connection into the
# larger values for the specific paths that actually benefit: the rebuild
# tool (bin/optimise_store.py), Store.reindex_fts_batch, and backup's
# VACUUM INTO snapshot.
_DEFAULT_CACHE_KIB = 16384    # 16 MiB
_DEFAULT_MMAP_BYTES = 67108864     # 64 MiB
_BULK_CACHE_KIB = 65536       # 64 MiB
_BULK_MMAP_BYTES = 268435456       # 256 MiB


def _open_db(path, read_only: bool = False, *,
            busy_timeout_ms: int = DEFAULT_BUSY_TIMEOUT_MS,
            bulk: bool = False) -> sqlite3.Connection:
    """Open a connection to the derived store with sqlite-vec loaded.

    read_only=True uses a mode=ro URI (the MCP server's read path); read_only=False
    is the daemon's write path. row_factory is sqlite3.Row and the sqlite-vec
    extension is loaded so vec0 virtual tables resolve on connect. Shared by
    Store._connect and the backup checkpoint path.

    busy_timeout_ms: how long SQLite's own busy handler blocks a single
    statement (e.g. one BEGIN IMMEDIATE attempt) waiting for a lock before
    raising "database is locked". This is the DOMINANT term in how long a
    write can block under contention — cutting retry COUNT alone (see
    RECALL_PATH_BEGIN_RETRIES) does not bound the wait, because even one
    attempt can sit here for the full timeout. Callers on a latency-sensitive
    path pass a smaller value; see RECALL_PATH_BUSY_TIMEOUT_MS.

    bulk: opts into the larger cache_size/mmap_size (see the module-level
    comment above _DEFAULT_CACHE_KIB) for a single long-lived, throughput-
    sensitive connection. Leave False for the common per-call case.
    """
    if read_only:
        db = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    else:
        db = sqlite3.connect(path)
    db.row_factory = sqlite3.Row
    # Explicit busy_timeout so concurrent writers (daemon + MCP draft handle) serialise
    # via WAL with a bounded wait instead of failing immediately on a locked DB. WAL is
    # set once at init() and is a file-level setting, so every connection inherits it.
    db.execute(f"PRAGMA busy_timeout={int(busy_timeout_ms)}")
    # Cap WAL growth. A long-lived reader can otherwise prevent checkpointing
    # and the WAL grows without bound; this makes SQLite truncate it back after
    # a checkpoint instead. Chosen well above normal transaction size.
    db.execute("PRAGMA journal_size_limit=67108864")  # 64 MiB
    # Tuned for a multi-GB, read-heavy derived store. SQLite's own default
    # left this at a 2 MB page cache on a 2.6 GB database -- too small. The
    # much larger `bulk` values are reserved for the few connections that are
    # actually long-lived and throughput-sensitive (see above); every other
    # per-call connection gets this smaller default so ~21 concurrent daemon
    # threads cannot multiply into a gigabyte of RSS between them.
    cache_kib = _BULK_CACHE_KIB if bulk else _DEFAULT_CACHE_KIB
    mmap_bytes = _BULK_MMAP_BYTES if bulk else _DEFAULT_MMAP_BYTES
    db.execute(f"PRAGMA cache_size=-{int(cache_kib)}")
    db.execute(f"PRAGMA mmap_size={int(mmap_bytes)}")
    db.execute("PRAGMA temp_store=2")         # MEMORY: FTS5/ORDER BY temp b-trees
    db.execute("PRAGMA threads=4")            # parallel sort
    db.execute("PRAGMA analysis_limit=400")   # bounds PRAGMA optimize (Task 3)
    # Foreign keys are OFF by default in SQLite, per-connection, so every
    # REFERENCES clause in init() was decoration until this line existed.
    # Unconditional: FK enforcement has been available since 3.6.19, far below
    # any version this codebase can run on (unlike STRICT/JSONB/contentless
    # FTS5, which need runtime guards). Set on read-only connections too —
    # cheap, and it keeps `PRAGMA foreign_key_check` meaningful there.
    db.execute("PRAGMA foreign_keys=ON")
    if not read_only:
        # NORMAL is corruption-safe under WAL and this store is DERIVED —
        # fully re-ingestable from Google. FULL fsyncs every commit for a
        # durability guarantee we do not need.
        db.execute("PRAGMA synchronous=1")
    db.enable_load_extension(True)
    sqlite_vec.load(db)  # vec0 tables need the extension even on a read-only conn
    db.enable_load_extension(False)
    return db


_CAL_INSTANCE_SUFFIX = re.compile(r"_\d{8}T\d{6}Z$")
# Namespace prefix every Calendar-derived identifier carries: chunk doc_ids
# (cal-<event_id>[-<chunk_idx>]), email_entities.message_id, evidence /
# source_doc_id, and the enrichment identity thread_enrich._chunk_key emits.
_CAL_PREFIX = "cal-"
# Namespace prefix every anarlog meeting-derived chunk doc_id carries:
# anarlog-<session_id>-<summary|note|transcript>-<i>. doc_ids_for_messages
# resolves the bare `anarlog-<session_id>` key to every chunk of that meeting.
_ANARLOG_PREFIX = "anarlog-"


def _base_cal_event_id(value: str) -> str:
    """Strip a 'cal-' prefix and any recurring-instance date suffix
    ('_YYYYMMDDTHHMMSSZ') from a Calendar-derived identifier (a chunk doc_id
    or an entity_relations.evidence value), leaving the bare Calendar event id
    shared by every instance of a recurring series.

    NOT for resolving a single event's own chunks — that needs the exact
    per-instance id, so doc_ids_for_messages strips only _CAL_PREFIX.
    """
    if value.startswith(_CAL_PREFIX):
        value = value[len(_CAL_PREFIX):]
    return _CAL_INSTANCE_SUFFIX.sub("", value)


# Drive chunk doc_ids are `gdrive-<file_id>-<idx>`. A Drive file_id uses the
# base64url alphabet and can contain '-', and can end in digits, so ONLY a
# trailing '-<digits>' may be stripped — the greedy `.+` leaves exactly the
# last such group. Splitting on the first or every hyphen would merge the
# payloads of distinct files. The second group captures that trailing index so
# callers that need chunk order (e.g. migrate_enrich_payloads_batch's keeper
# selection) can compare it as an int instead of as a string.
_DRIVE_DOC_ID = re.compile(r"^gdrive-(.+)-(\d+)$")


def _file_key_from_doc_id(doc_id: str) -> str | None:
    """The Drive file_id a chunk doc_id belongs to, or None if it is not a
    Drive chunk doc_id. `enrich_payloads` is keyed on the bare file_id — what
    ingest_cache.publish_file already holds and chunks.metadata.$.file_id
    stores."""
    m = _DRIVE_DOC_ID.match(doc_id or "")
    return m.group(1) if m else None


def _chunk_index_from_doc_id(doc_id: str) -> int | None:
    """The trailing chunk index of a Drive chunk doc_id, as an int, or None if
    it is not a Drive chunk doc_id. Unpadded, so it must be compared as an int
    -- never as the raw doc_id string, which does not sort numerically (e.g.
    "gdrive-F-9" > "gdrive-F-89" lexicographically, even though 9 < 89)."""
    m = _DRIVE_DOC_ID.match(doc_id or "")
    return int(m.group(2)) if m else None


# SQLite's compiled-in host-parameter ceiling is 999 on older builds (32766 on
# newer), so any IN (...) built from a caller-supplied list is split to stay
# under the lower bound rather than depending on which SQLite is linked.
_SQL_VAR_BATCH = 900


def _chunked(seq, size):
    """Yield successive `size`-length slices of `seq`."""
    for i in range(0, len(seq), size):
        yield seq[i:i + size]


_BEGIN_RETRIES = 3
_BEGIN_BASE_SLEEP_S = 0.05

# Retry backoff for sync_queue, in seconds by attempt number. The last value is
# the cap and repeats forever: nothing is ever abandoned, so a permanently
# broken file settles at one retry per day -- bounded cost, permanently visible
# (doctor surfaces attempts >= 3). This closes sync/drive.py's KNOWN GAP, where
# a transient export failure silently dropped a file version because the cursor
# moved past it.
_SYNC_BACKOFF_S = (120, 600, 3600, 21600, 86400)
_SYNC_FAILING_ATTEMPTS = 3

# A smaller retry budget for writes that run inline on the /api/recall path
# (currently decay.update_on_recall -> update_memory_strength_batch). update_on_recall
# is fire-and-forget (its caller already swallows exceptions), so failing fast
# under contention and simply skipping this recall's strength bump is strictly
# better than adding latency to the prompt path for a non-critical bookkeeping
# update.
#
# IMPORTANT: retries alone does not bound the wait. Even ONE failed BEGIN
# IMMEDIATE attempt can block for the connection's full busy_timeout (default
# 5000ms, PRAGMA busy_timeout in _open_db) before SQLite's busy handler gives
# up and this loop's own backoff even starts -- measured live at 5.38s with
# retries=1 alone, still well past prompt_recall's 3.0s client timeout (i.e.
# still silently dropping the recall context, just slightly less often). The
# write connection on this path MUST also use RECALL_PATH_BUSY_TIMEOUT_MS
# (below), not just a smaller retries=.
RECALL_PATH_BEGIN_RETRIES = 1

# See the note above: busy_timeout, not retry count, is the dominant term.
# 500ms x RECALL_PATH_BEGIN_RETRIES(=1) attempt = ~0.5s worst case for the
# whole write, comfortably inside prompt_recall's 3.0s budget with ~2.5s of
# margin for everything else on that path (the embed_query call, hybrid
# search, formatting). Bulk/ingest writes are unaffected -- they keep
# DEFAULT_BUSY_TIMEOUT_MS via the normal _connect()/_open_db() default.
RECALL_PATH_BUSY_TIMEOUT_MS = 500


def _begin_immediate(db, *, retries: int = _BEGIN_RETRIES) -> None:
    """Start a write transaction, retrying with jittered backoff on lock contention.

    BEGIN IMMEDIATE acquires the write lock up front, so a later read-then-write
    never has to upgrade — the upgrade is what SQLite refuses instantly, ignoring
    busy_timeout. busy_timeout still covers most contention; this retry loop is
    the backstop for the window where it does not.
    """
    import random
    import time as _time
    for attempt in range(retries):
        try:
            db.execute("BEGIN IMMEDIATE")
            return
        except sqlite3.OperationalError as exc:
            if "locked" not in str(exc) and "busy" not in str(exc):
                raise
            if attempt == retries - 1:
                raise
            _time.sleep(_BEGIN_BASE_SLEEP_S * (2 ** attempt) * (0.5 + random.random()))


# Set (non-empty) when apply_reflow's orphan guard fires; every reflow path
# DEFERs while it is set. Cleared only by an attended `bin/reflow.py resume`.
REFLOW_HALT_CURSOR = "reflow:halted"


class ReflowOrphanError(RuntimeError):
    """apply_reflow found a reference to one of the owner's doc_ids with no
    chunk row; the transaction was rolled back (extraction-fidelity §3)."""


# Every (table, column) holding a chunk doc_id that a reflow must remap.
# apply_reflow's final guard: clear a self-referencing dup_of on the given
# new ids. A module constant so a test can EXPLAIN the exact statement.
_SELF_DUP_GUARD_SQL = (
    "UPDATE chunks SET dup_of=NULL, enrich_state=CASE WHEN "
    "enrich_state='duplicate' THEN '' ELSE enrich_state END "
    "WHERE doc_id IN ({qs}) AND dup_of IS NOT NULL AND dup_of=doc_id")

_REFLOW_REF_COLUMNS = (
    ("entity_relations", "source_doc_id"),
    ("entity_observations", "source"),
    ("actions", "source_doc_id"),
    ("actions", "waiting_on_cleared_by_doc_id"),
    ("graph_actions_legacy", "source_doc_id"),
    ("graph_decisions_legacy", "source_doc_id"),
    ("recall_feedback", "doc_id"),
)

# The positional suffix a chunk id carries after its owner prefix, per source
# (gdrive-<fid>-<i>, gmail-<mid>-body-<i> / -att-<n>-<i>, anarlog-<sid>-<kind>-<i>,
# cal-<eid> / cal-<eid>-<i>). owner_chunks requires it so a prefix can never
# take in a different owner whose id merely starts with the same characters.
_OWNER_SUFFIX = {
    "gdrive-": re.compile(r"\d+"),
    # also accepts a narrower caller prefix: "gmail-<mid>-att-" + "2-0"
    "gmail-": re.compile(r"(?:[a-z_]+-)?\d+(?:-\d+)?"),
    "anarlog-": re.compile(r"(?:[a-z_]+-)?\d+"),
    "cal-": re.compile(r"(?:-\d+)?"),
}


def _owner_suffix_ok(prefix: str, rest: str) -> bool:
    for tag, rx in _OWNER_SUFFIX.items():
        if not prefix.startswith(tag):
            continue
        if tag == "cal-":
            # cal-<eid> is itself a chunk id; cal-<eid>- takes only the split pieces
            if prefix.endswith("-"):
                return re.fullmatch(r"\d+", rest) is not None
            return rx.fullmatch(rest) is not None
        if not prefix.endswith("-"):
            # "gdrive-<fid>" / "gmail-<mid>-att-2" given without its dash: the
            # next character must BE the dash, or "att-2" would take "att-20".
            if not rest.startswith("-"):
                return False
            rest = rest[1:]
        return rx.fullmatch(rest) is not None
    return True


_IN_BATCH = 500   # bound-variable slice for IN lists (SQLite caps variables)


class StoreRestoringError(TimeoutError):
    """The store is being swapped for a restored snapshot: every connection is
    refused for that (brief) window. A TimeoutError so callers that classify
    failures treat it as transient."""


class Store:
    # Phase C: bump when the FTS contextual-text format changes so
    # reindex_fts_batch() knows which embedded chunks are stale.
    FTS_CONTEXT_VERSION = 1

    @staticmethod
    def stored_dim(path) -> int | None:
        """The embedding dimension this store was initialised with (the
        `meta` row init() writes), read-only; None when the file or the row is
        absent. Lets an attended CLI open an existing store without loading
        the embedding model just to learn its dimension."""
        p = Path(path)
        if not p.exists():
            return None
        try:
            with closing(_open_db(p, read_only=True)) as db:
                row = db.execute("SELECT v FROM meta WHERE k='dim'").fetchone()
            return int(row[0]) if row else None
        except (sqlite3.Error, TypeError, ValueError):
            return None

    def __init__(self, path: Path, dim: int, read_only: bool = False):
        self.path = Path(path)
        self.dim = dim
        self.read_only = read_only  # the daemon is the sole writer, full stop.
        # Restore gate (restoring_gate): while set, _connect refuses; the gate
        # waits for in-flight connections to close before the swap.
        self._gate_cv = threading.Condition()
        self._gate_closed = False
        self._gate_active = 0
        # The MCP server still CONSTRUCTS a writable handle, but as of Phase 4
        # (tool_exec_in_daemon, default ON) nothing calls it: draft_save /
        # meeting_pack_upsert / finding_resolve route to the daemon, and
        # draft_context was rewired onto the read-only handle. That handle is
        # reached only on the local kill-switch path (flag off), so in the shipped
        # configuration no second writable connection exists to serialise against.

    def _gate(self) -> threading.Condition:
        cv = getattr(self, "_gate_cv", None)
        if cv is None:      # an instance that bypassed __init__
            cv = self._gate_cv = threading.Condition()
            self._gate_closed, self._gate_active = False, 0
        return cv

    @contextmanager
    def restoring_gate(self, timeout_s: float = 30.0):
        """Refuse new connections and wait (up to timeout_s) for in-flight
        ones in THIS process to close, for the duration of a restored-snapshot
        swap. Raises StoreRestoringError (and reopens) if they do not drain.
        Other processes are covered by the caller's checkpoint busy check."""
        import time as _time
        cv = self._gate()
        with cv:
            self._gate_closed = True
            deadline = _time.monotonic() + timeout_s
            while self._gate_active:
                left = deadline - _time.monotonic()
                if left <= 0:
                    self._gate_closed = False
                    cv.notify_all()
                    raise StoreRestoringError(
                        f"{self._gate_active} store connection(s) still open")
                cv.wait(left)
        try:
            yield
        finally:
            with cv:
                self._gate_closed = False
                cv.notify_all()

    @contextmanager
    def _connect(self, *, write: bool = False, retries: int = _BEGIN_RETRIES,
                busy_timeout_ms: int = DEFAULT_BUSY_TIMEOUT_MS,
                bulk: bool = False):
        """_connect_unguarded behind the restore gate: refused (with
        StoreRestoringError) while a restored snapshot is being swapped in,
        and counted so the gate can wait for in-flight connections."""
        cv = self._gate()
        with cv:
            if self._gate_closed:
                raise StoreRestoringError("store is being restored")
            self._gate_active += 1
        try:
            with self._connect_unguarded(write=write, retries=retries,
                                         busy_timeout_ms=busy_timeout_ms,
                                         bulk=bulk) as db:
                yield db
        finally:
            with cv:
                self._gate_active -= 1
                cv.notify_all()

    @contextmanager
    def _connect_unguarded(self, *, write: bool = False, retries: int = _BEGIN_RETRIES,
                           busy_timeout_ms: int = DEFAULT_BUSY_TIMEOUT_MS,
                           bulk: bool = False):
        """Open a connection, commit-or-rollback on exit, and ALWAYS close it.

        sqlite3.Connection is its own context manager but only commits/rollbacks
        — it does NOT close the file handle. Callers that did `with store._connect()
        as db:` leaked one OS fd per call. The control API polls /api/status every
        few seconds, so a long-running daemon exhausted its fd budget and started
        failing with `sqlite3.OperationalError: unable to open database file`.
        This wrapper keeps the existing commit/rollback semantics (via the inner
        `with db:`) and adds an unconditional close in the finally block.

        write=True takes an IMMEDIATE write lock up front instead of Python's
        sqlite3 default DEFERRED transaction. A DEFERRED transaction that reads
        then writes must upgrade its lock, and SQLite refuses that upgrade
        instantly (ignoring busy_timeout) when another writer already holds the
        lock — BEGIN IMMEDIATE avoids the upgrade entirely so busy_timeout (and
        the bounded retry below) actually cover contention between writers.

        retries: passed straight through to _begin_immediate. Callers on a
        latency-sensitive path (e.g. recall) can pass a smaller budget than the
        default so contention fails fast instead of piling up wait time; see
        RECALL_PATH_BEGIN_RETRIES.

        busy_timeout_ms: passed straight through to _open_db. This is the term
        that actually dominates worst-case wait — even a single BEGIN IMMEDIATE
        attempt can block for the full busy_timeout, so a caller that needs a
        hard latency bound (recall) must lower THIS, not just retries; see
        RECALL_PATH_BUSY_TIMEOUT_MS.

        bulk: passed straight through to _open_db (PR #25 finding 5) --
        opts THIS connection into the larger cache_size/mmap_size for a
        genuinely long-lived, throughput-sensitive call (e.g.
        reindex_fts_batch). Leave False for the common per-call case, or
        many concurrent connections can add up to real RSS growth.
        """
        db = _open_db(self.path, self.read_only, busy_timeout_ms=busy_timeout_ms,
                      bulk=bulk)
        try:
            if write and not self.read_only:
                # Manual transaction control: take the write lock up front.
                db.isolation_level = None
                _begin_immediate(db, retries=retries)
                try:
                    yield db
                except BaseException:
                    # SQLite may have already auto-rolled-back the transaction
                    # itself before this exception surfaced (e.g. SQLITE_FULL,
                    # SQLITE_IOERR) — in that case "ROLLBACK" fails with
                    # OperationalError: cannot rollback - no transaction is
                    # active, which used to propagate INSTEAD of the original
                    # error, masking a disk-full as a confusing "no transaction"
                    # message. The unconditional `raise` below always re-raises
                    # the ORIGINAL exception regardless of what happens in this
                    # except block, so there is no signal lost by catching
                    # broadly here — `except Exception` (rather than the
                    # narrower sqlite3.OperationalError) also covers any other
                    # failure this cleanup-only ROLLBACK could hit.
                    try:
                        db.execute("ROLLBACK")
                    except Exception:  # noqa: BLE001 — see comment above; the original error always wins
                        pass
                    raise
                else:
                    db.execute("COMMIT")
            else:
                with db:
                    yield db
        finally:
            # PRAGMA optimize is the documented way to keep planner statistics
            # current; analysis_limit (set in _open_db) bounds its cost so it
            # cannot stall a close. It WRITES, so never on a read-only handle
            # -- AND never on a write=False connection either, even on a
            # writable Store: it would acquire the write lock after the
            # caller's read-only transaction is already done, contending
            # with a drain's writes at exactly the recall path's latency
            # budget (RECALL_PATH_BUSY_TIMEOUT_MS/RECALL_PATH_BEGIN_RETRIES
            # exist to bound that contention, and graph_write.upsert_relation
            # opens one connection per relation, so a drain would pay this
            # tens of thousands of times per cycle) -- reintroducing the
            # 0.7.105 recall-starvation class this pragma was added to help
            # fix in the first place. Only an actual write transaction
            # should pay for a stats refresh.
            if write and not self.read_only:
                try:
                    db.execute("PRAGMA optimize")
                except sqlite3.Error:
                    # Best-effort: a stats refresh must never fail a caller's
                    # otherwise-successful transaction.
                    pass
            db.close()

    def init(self) -> None:
        # journal_mode=WAL must run OUTSIDE any explicit transaction (SQLite
        # refuses to change journal mode from within one), so it gets its own
        # plain (non-write) connect before the write=True block below opens its
        # BEGIN IMMEDIATE. WAL is a file-level setting set once here; every
        # later connection (including this one, moments later) inherits it.
        with self._connect() as db:
            db.execute("PRAGMA journal_mode=WAL")  # concurrent reader (MCP) + one writer (daemon)
        with self._connect(write=True) as db:
            # STRICT (SQLite >= 3.37) makes every declared type below a real
            # constraint instead of an affinity hint. It is a TABLE-CREATION
            # option: an existing store's tables are untouched by
            # CREATE TABLE IF NOT EXISTS and stay loose until the one
            # out-of-place rebuild (bin/optimise_store.py) recreates them
            # through this same init(). Resolved once per init() so no table
            # can drift out of the set.
            _S = _strict_suffix()
            db.execute(f"""CREATE TABLE IF NOT EXISTS chunks(
                rowid INTEGER PRIMARY KEY,
                doc_id TEXT UNIQUE, text TEXT, content_hash TEXT,
                metadata TEXT, embedded INTEGER DEFAULT 0,
                enriched INTEGER DEFAULT 0){_S}""")
            # Expression indexes on the metadata JSON paths that doc_ids_for_messages
            # (called once per extraction by drain) filters on. Without them each
            # call is a full `SCAN chunks` — ~1.4s on the ~108k-chunk live store, so
            # a backlogged drain cycle spends ~24 min scanning and starves the
            # control-API recall threads (GIL + DB), timing out brain_search/actions.
            # The expressions must match doc_ids_for_messages' _meta_extract()
            # paths byte-for-byte or the planner won't use the index — both the
            # index DDL and every query read site build their SQL through the
            # single _meta_extract() source of truth, so they cannot drift apart.
            #
            # `IF NOT EXISTS` KEYS ON THE INDEX NAME, NOT THE EXPRESSION. So this
            # loop does NOT rebuild an index that already exists with a DIFFERENT
            # expression — on every already-installed store it is a silent no-op.
            # If one of these expressions ever has to change, the index must be
            # RENAMED (or explicitly DROPped first), never edited in place:
            # otherwise the persisted index keeps the old expression, the queries
            # move to the new one, they stop matching, and every one of these
            # lookups degrades to the full `SCAN chunks` described above with no
            # error and correct results. See _meta_extract's docstring.
            for _idx_name, _idx_path in (
                ("idx_chunks_msgid", "$.message_id"),
                ("idx_chunks_fileid", "$.file_id"),
                # I6: thread_enrich._chunk_key groups a split calendar event's
                # chunks by event_id, so doc_ids_for_messages resolves that id
                # too — same arm shape as file_id, so it needs the same
                # expression index.
                ("idx_chunks_eventid", "$.event_id"),
                # thread_chunks (recall small-to-big expansion via
                # retrieval_expand, plus the stale-action / stale-reextract
                # passes) filters chunks by metadata.thread_id — a full SCAN
                # (~4.3s on the live store) without this index; a
                # single-equality predicate, so the index alone fixes it.
                ("idx_chunks_threadid", "$.thread_id"),
                # anarlog meeting sessions: doc_ids_for_messages resolves an
                # `anarlog-<session_id>` key to every chunk of that meeting
                # (summary, note, transcript), so the arm needs the same
                # expression index as file_id/event_id.
                ("idx_chunks_sessionid", "$.session_id"),
            ):
                db.execute(f"CREATE INDEX IF NOT EXISTS {_idx_name} "
                           f"ON chunks({_meta_extract(_idx_path)})")
            # inbound_chunks_since (the waiting-on sweep, every cycle) range-filters
            # on COALESCE(date,date_iso); index the SAME expression so the range
            # plans as a SEARCH (~2.9s SCAN -> ~tens of ms). Expression must match
            # inbound_chunks_since's date_expr byte-for-byte.
            db.execute(
                "CREATE INDEX IF NOT EXISTS idx_chunks_inbound_date ON chunks("
                f"COALESCE({_meta_extract('$.date')},"
                f"{_meta_extract('$.date_iso')}))")
            db.execute(f"""CREATE VIRTUAL TABLE IF NOT EXISTS vec_chunks
                USING vec0(embedding float[{self.dim}])""")
            if fts5_supports_contentless():
                # content='' drops FTS5's own duplicate copy of the indexed
                # text -- 0.78 GB of the 2.62 GB live store. External content
                # (content='chunks') is NOT usable: _fts_text indexes the
                # contextual prefix + body while chunks.text stays raw, so the
                # content table could not reproduce the indexed string.
                db.execute("CREATE VIRTUAL TABLE IF NOT EXISTS fts_chunks "
                           "USING fts5(text, content='', contentless_delete=1)")
            else:
                db.execute("CREATE VIRTUAL TABLE IF NOT EXISTS fts_chunks "
                           "USING fts5(text)")
            db.execute(f"""CREATE TABLE IF NOT EXISTS meta(
                k TEXT PRIMARY KEY, v TEXT){_S}""")
            db.execute("INSERT OR REPLACE INTO meta(k,v) VALUES('dim',?)", (str(self.dim),))
            db.execute(f"""CREATE TABLE IF NOT EXISTS sync_cursors(
                source TEXT PRIMARY KEY, cursor TEXT, updated_at TEXT){_S}""")

            # --- sync work queue -------------------------------------------
            # The durable seam between discovery (page the provider delta) and
            # work (fetch/extract/upsert). Presence IS pending; success deletes
            # the row, so `SELECT count(*)` is the backlog as a FACT, not an
            # estimate -- the thing whose absence hid a five-week Drive outage.
            # PRIMARY KEY (source, ref_id) gives per-item event collapse for
            # free: re-discovering a file supersedes its earlier event.
            # modified_at is NOT NULL so the newest-first ORDER BY can use a
            # PLAIN index; discovery falls back to the discovery timestamp for
            # sources (Gmail history) that expose no per-item mtime. An
            # expression index here would reintroduce the 0.7.105 drift class.
            db.execute(f"""CREATE TABLE IF NOT EXISTS sync_queue(
                source          TEXT NOT NULL,
                ref_id          TEXT NOT NULL,
                version         TEXT NOT NULL DEFAULT '',
                event           TEXT NOT NULL,
                modified_at     TEXT NOT NULL,
                discovered_at   TEXT NOT NULL,
                attempts        INTEGER NOT NULL DEFAULT 0,
                next_attempt_at TEXT,
                last_error      TEXT NOT NULL DEFAULT '',
                PRIMARY KEY (source, ref_id)){_S}""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_sync_queue_due "
                       "ON sync_queue(next_attempt_at, modified_at DESC)")
            # Durable bound on a run of consecutive TRANSIENT outcomes (rate
            # limit / gateway / network -- see reflow_handler._is_transient).
            # Those defer without spending an `attempts` give-up slot, which
            # is correct for a real outage but has no terminal bound on its
            # own: a permanently-failing item that happens to classify
            # transient would otherwise retry forever and the backlog never
            # reaches zero. `fail_sync_item` resets this to 0 on any outcome
            # it records (a real failure, or the escalation past the bound),
            # so it only ever counts an unbroken run.
            sq_cols = {r["name"] for r in db.execute("PRAGMA table_info(sync_queue)")}
            if "transient_defers" not in sq_cols:
                db.execute("ALTER TABLE sync_queue ADD COLUMN transient_defers "
                           "INTEGER NOT NULL DEFAULT 0")

            # --- content-preserving reflow (extraction-fidelity §3) -------------
            # reflow_map is an APPEND-ONLY log, not a lookup keyed on old id:
            # doc_ids are positional and reused, so one id is both an old and a
            # new chunk. The latest row for an id (idx_reflow_map_old) is what a
            # stale reference falls back to once that id no longer has a chunk.
            db.execute(f"""CREATE TABLE IF NOT EXISTS reflow_map(
                id          INTEGER PRIMARY KEY,
                owner       TEXT NOT NULL,
                old_doc_id  TEXT NOT NULL,
                new_doc_id  TEXT NOT NULL,
                reason      TEXT NOT NULL,
                at          TEXT NOT NULL){_S}""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_reflow_map_old "
                       "ON reflow_map(old_doc_id, id)")
            db.execute(f"""CREATE TABLE IF NOT EXISTS reflow_owners(
                owner       TEXT PRIMARY KEY,
                source      TEXT NOT NULL,
                at          TEXT NOT NULL,
                chunks_new  INTEGER NOT NULL,
                carried     INTEGER NOT NULL,
                reenrich    INTEGER NOT NULL,
                outcome     TEXT NOT NULL DEFAULT 'carried',
                uncovered   INTEGER NOT NULL DEFAULT 0,
                inherited_unenriched INTEGER NOT NULL DEFAULT 0,
                unequal_lineages INTEGER NOT NULL DEFAULT 0){_S}""")
            # One row per owner the reflow is DONE with, whatever the outcome:
            # carried (apply_reflow) | ordinary (source changed -> normal path)
            # | gave_up | source_gone | unsupported. Pre-outcome stores hold
            # apply_reflow rows only, hence the default.
            ro_cols = {r["name"] for r in db.execute("PRAGMA table_info(reflow_owners)")}
            if "outcome" not in ro_cols:
                db.execute("ALTER TABLE reflow_owners ADD COLUMN outcome TEXT "
                           "NOT NULL DEFAULT 'carried'")
            # Dry run #2 D4: `reenrich` (every new row left enriched=0) overstated
            # the extraction cost. `uncovered` = new text no old chunk held (the
            # genuine new work); `inherited_unenriched` = covered text whose old
            # chunks were never enriched either (cold by design, or pending).
            # `reenrich` is still written (their sum) for older readers. Rows
            # written before these columns read 0 for both.
            # `unequal_lineages`: lineages whose stitched old and new text
            # differed (plan.unequal) on a carried owner -- e.g. text our own
            # normaliser now drops inside a surviving chunk, which maps
            # "nearest" and is otherwise invisible once apply_reflow returns.
            for col in ("uncovered", "inherited_unenriched", "unequal_lineages"):
                if col not in ro_cols:
                    db.execute(f"ALTER TABLE reflow_owners ADD COLUMN {col} INTEGER "
                               "NOT NULL DEFAULT 0")

            # Durable seam for the shared-drive cache-miss -> embed -> publish
            # pipeline. A row means "this file's chunks are extracted and
            # written locally, but not yet shared to the fleet cache" -- it
            # survives across cycles, unlike today's in-memory miss list,
            # because publishing needs the chunk EMBEDDED first (a separate,
            # later step in the same cycle or a subsequent one) and a crash
            # or budget cut between extraction and publish must not lose the
            # obligation to publish once the embedding exists.
            db.execute(f"""CREATE TABLE IF NOT EXISTS shared_drive_pending_publish(
                drive_id      TEXT NOT NULL,
                file_id       TEXT NOT NULL,
                content_hash  TEXT NOT NULL,
                discovered_at TEXT NOT NULL,
                PRIMARY KEY (drive_id, file_id)){_S}""")

            # --- enrichment graph tables (Task 4.2) -----------------------
            db.execute(f"""CREATE TABLE IF NOT EXISTS entities(
                id          TEXT PRIMARY KEY,
                name        TEXT NOT NULL,
                type        TEXT NOT NULL,
                org         TEXT DEFAULT '',
                first_seen  TEXT DEFAULT '',
                last_seen   TEXT DEFAULT '',
                mentions    INTEGER DEFAULT 0,
                email_count INTEGER DEFAULT 0,
                degree      INTEGER DEFAULT 0,
                aliases     TEXT DEFAULT '',
                email_addr  TEXT DEFAULT '',
                notes       TEXT DEFAULT ''){_S}""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_ent_type ON entities(type)")
            # Migrate base columns on very old stores (pre-v0.7). Check columns
            # before creating idx_ent_org, which references the org column.
            ent_cols = {row["name"] for row in db.execute("PRAGMA table_info(entities)").fetchall()}
            for _base_col, _base_def in (
                ("org", "TEXT DEFAULT ''"),
                ("first_seen", "TEXT DEFAULT ''"),
                ("last_seen", "TEXT DEFAULT ''"),
                ("mentions", "INTEGER DEFAULT 0"),
            ):
                if _base_col not in ent_cols:
                    db.execute(f"ALTER TABLE entities ADD COLUMN {_base_col} {_base_def}")
                    ent_cols.add(_base_col)
            db.execute("CREATE INDEX IF NOT EXISTS idx_ent_org  ON entities(org)")
            # Back-fill email_count/degree on pre-existing stores (mirrors the
            # chunks.enriched pattern below). Phase 1 does NOT port Nexus's
            # degree triggers (memory_db.py:486-515): graph_write.upsert_relation
            # (Task 2) increments degree explicitly instead.
            if "email_count" not in ent_cols:
                db.execute("ALTER TABLE entities ADD COLUMN email_count INTEGER DEFAULT 0")
            if "degree" not in ent_cols:
                db.execute("ALTER TABLE entities ADD COLUMN degree INTEGER DEFAULT 0")
            db.execute("CREATE INDEX IF NOT EXISTS idx_ent_degree ON entities(degree)")
            # Dedup-support columns for the graph_write upsert path (Task 2.2):
            # email_addr (email->entity dedup), aliases (alias-merge dedup),
            # notes (accumulated free-text). Back-filled on pre-existing stores.
            if "aliases" not in ent_cols:
                db.execute("ALTER TABLE entities ADD COLUMN aliases TEXT DEFAULT ''")
            if "email_addr" not in ent_cols:
                db.execute("ALTER TABLE entities ADD COLUMN email_addr TEXT DEFAULT ''")
            if "notes" not in ent_cols:
                db.execute("ALTER TABLE entities ADD COLUMN notes TEXT DEFAULT ''")
            if "profile" not in ent_cols:
                db.execute("ALTER TABLE entities ADD COLUMN profile TEXT DEFAULT ''")
            if "profile_updated_at" not in ent_cols:
                db.execute("ALTER TABLE entities ADD COLUMN profile_updated_at TEXT DEFAULT ''")
            if "org_valid_from" not in ent_cols:
                # Date (email valid_from) the current org was asserted, so a
                # newer-dated observation can overwrite a stale org under backfill.
                db.execute("ALTER TABLE entities ADD COLUMN org_valid_from TEXT DEFAULT ''")
            if "profile_audited_at" not in ent_cols:
                # When profile_audit last reviewed this profile, so audit re-runs
                # only after a change (and rotates) rather than re-doing the same
                # most-active profiles every cycle.
                db.execute("ALTER TABLE entities ADD COLUMN profile_audited_at TEXT DEFAULT ''")

            # entity_a/entity_b now REFERENCE entities(id) for real (see the
            # foreign_keys=ON pragma in _open_db). ON DELETE CASCADE, not the
            # default RESTRICT: merge_entities and org_import._remove_org_entity
            # both delete an entity row, and a relation that references a
            # deleted node is meaningless — cascading keeps those paths working
            # AND removes the orphan instead of leaving it (80,577 relation rows
            # on the live store, 8 of them already orphaned).
            db.execute(f"""CREATE TABLE IF NOT EXISTS entity_relations(
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_a      TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
                relation      TEXT NOT NULL,
                entity_b      TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
                source_doc_id TEXT DEFAULT '',
                UNIQUE(entity_a, relation, entity_b)){_S}""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_er_a ON entity_relations(entity_a)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_er_b ON entity_relations(entity_b)")
            # --- entity_relations bitemporal columns (Phase 1, Task 1.6) --
            # Keep the existing UNIQUE(entity_a,relation,entity_b) + source_doc_id
            # (add_relation/merge_entities rely on them). ALTER the bitemporal
            # columns on (Spec 7 shape, memory_db.py:455-471). SQLite ALTER ADD
            # COLUMN cannot use non-constant defaults, so each column is nullable
            # or carries a constant default. Idempotent via PRAGMA check.
            er_cols = {row["name"] for row in db.execute("PRAGMA table_info(entity_relations)").fetchall()}
            for col_name, col_def in (
                ("valid_from", "TEXT"),
                ("valid_to", "TEXT"),
                ("invalidated_at", "TEXT"),
                # SET NULL, not the default NO ACTION or a CASCADE, matching
                # the entity_observations sibling: deleting the relation that
                # superseded another must not delete the superseded row (and
                # must not abort the delete either) -- it just clears the
                # dangling pointer. ALTER TABLE ADD COLUMN can carry a
                # REFERENCES clause as long as the default is NULL, so this
                # takes effect on any store where the column doesn't exist
                # yet (new installs, rebuilt stores) -- existing stores
                # already have this column from before foreign_keys=ON
                # existed, and ALTER cannot retrofit a constraint onto an
                # existing column, so those only pick this up via a rebuild.
                ("invalidated_by_relation_id",
                 "INTEGER REFERENCES entity_relations(id) ON DELETE SET NULL"),
                ("superseded_reason", "TEXT"),
                ("confidence", "REAL DEFAULT 1.0"),
                ("evidence", "TEXT"),
                ("strength", "INTEGER DEFAULT 1"),
                ("last_seen", "TEXT"),
                ("user_verdict", "TEXT"),
            ):
                if col_name not in er_cols:
                    db.execute(f"ALTER TABLE entity_relations ADD COLUMN {col_name} {col_def}")
            # 5 temporal indexes ported from memory_db.py:473-478.
            db.execute("CREATE INDEX IF NOT EXISTS idx_er_valid_now ON entity_relations(entity_a, entity_b, relation) "
                       "WHERE invalidated_at IS NULL AND valid_to IS NULL")
            db.execute("CREATE INDEX IF NOT EXISTS idx_er_a_rel       ON entity_relations(entity_a, relation)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_er_b_rel       ON entity_relations(entity_b, relation)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_er_invalidated ON entity_relations(invalidated_at)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_er_valid_range ON entity_relations(valid_from, valid_to)")

            # -- Org-baseline layer tag (Phase 0, Task 1) ----------------------
            # 'local' (default) or 'org'. Populated stores migrate in place via the
            # PRAGMA-check ALTER idiom (const default only).
            ent_cols = {row["name"] for row in
                        db.execute("PRAGMA table_info(entities)").fetchall()}
            if "origin" not in ent_cols:
                db.execute("ALTER TABLE entities ADD COLUMN origin TEXT DEFAULT 'local'")
            er_origin_cols = {row["name"] for row in
                              db.execute("PRAGMA table_info(entity_relations)").fetchall()}
            if "origin" not in er_origin_cols:
                db.execute("ALTER TABLE entity_relations ADD COLUMN origin TEXT DEFAULT 'local'")
            # The source_doc_id a relation had BEFORE its first reflow remap
            # (NULL = never remapped). org_contrib derives source_ref from it:
            # a remapped id would otherwise read as a second independent
            # source to the curator and corroborate a single-source claim.
            if "contrib_doc_id" not in er_origin_cols:
                db.execute("ALTER TABLE entity_relations ADD COLUMN contrib_doc_id TEXT")
            db.execute("CREATE INDEX IF NOT EXISTS idx_ent_origin ON entities(origin)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_er_origin ON entity_relations(origin)")

            # graph_actions/graph_decisions are only created PRE-migration. Once
            # the Task 1.7 migration has renamed them to *_legacy (meta flag set),
            # CREATE TABLE IF NOT EXISTS would otherwise resurrect empty orphan
            # tables on every re-init, so guard on the flag.
            # Deliberately NOT STRICT: these two are the pre-migration legacy
            # shape, created here only to be drained into `actions` and renamed
            # to *_legacy a few statements below. Tightening a table on its way
            # out would only risk failing the migration copy.
            already_migrated = db.execute(
                "SELECT 1 FROM meta WHERE k='actions_migrated'").fetchone() is not None
            if not already_migrated:
                db.execute("""CREATE TABLE IF NOT EXISTS graph_actions(
                    id            INTEGER PRIMARY KEY AUTOINCREMENT,
                    text          TEXT NOT NULL,
                    owner         TEXT DEFAULT '',
                    deadline      TEXT DEFAULT '',
                    status        TEXT DEFAULT 'open',
                    source_doc_id TEXT DEFAULT '',
                    thread_id     TEXT DEFAULT '',
                    created_at    TEXT DEFAULT CURRENT_TIMESTAMP)""")
                db.execute("""CREATE TABLE IF NOT EXISTS graph_decisions(
                    id            INTEGER PRIMARY KEY AUTOINCREMENT,
                    text          TEXT NOT NULL,
                    decided_on    TEXT DEFAULT '',
                    source_doc_id TEXT DEFAULT '',
                    created_at    TEXT DEFAULT CURRENT_TIMESTAMP)""")

            # --- unified actions table (Phase 1, Task 1.7) ----------------
            # Single forward surface for actions + recorded decisions. The
            # legacy graph_actions/graph_decisions tables are migrated in once
            # (below) and renamed to *_legacy; all new code uses this table.
            db.execute(f"""CREATE TABLE IF NOT EXISTS actions(
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                text             TEXT NOT NULL,
                owner            TEXT DEFAULT '',
                owner_entity_id  TEXT DEFAULT '',
                status           TEXT DEFAULT 'open',
                deadline         TEXT DEFAULT '',
                org              TEXT DEFAULT '',
                project_id       TEXT DEFAULT '',
                area_id          TEXT DEFAULT '',
                confidence       REAL DEFAULT 1.0,
                source           TEXT DEFAULT 'email',
                context_tag      TEXT DEFAULT '',
                cluster_id       TEXT DEFAULT '',
                source_doc_id    TEXT DEFAULT '',
                thread_id        TEXT DEFAULT '',
                resolved_by      TEXT DEFAULT '',
                resolved_at      TEXT DEFAULT '',
                text_fingerprint TEXT DEFAULT '',
                snoozed_until    TEXT DEFAULT '',
                created_at       TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at       TEXT DEFAULT CURRENT_TIMESTAMP){_S}""")
            # Back-fill Phase 1 columns on pre-existing actions tables that were
            # created before the full column set was defined. Must run before the
            # index CREATE statements below, because idx_actions_status references
            # deadline and idx_actions_thread references thread_id.
            _act_p1_cols = {row["name"] for row in db.execute("PRAGMA table_info(actions)").fetchall()}
            for _col, _def in (
                ("owner_entity_id",  "TEXT DEFAULT ''"),
                ("deadline",         "TEXT DEFAULT ''"),
                ("org",              "TEXT DEFAULT ''"),
                ("project_id",       "TEXT DEFAULT ''"),
                ("area_id",          "TEXT DEFAULT ''"),
                ("confidence",       "REAL DEFAULT 1.0"),
                ("source",           "TEXT DEFAULT 'email'"),
                ("context_tag",      "TEXT DEFAULT ''"),
                ("cluster_id",       "TEXT DEFAULT ''"),
                ("source_doc_id",    "TEXT DEFAULT ''"),
                ("thread_id",        "TEXT DEFAULT ''"),
                ("resolved_by",      "TEXT DEFAULT ''"),
                ("resolved_at",      "TEXT DEFAULT ''"),
                ("text_fingerprint", "TEXT DEFAULT ''"),
                ("snoozed_until",    "TEXT DEFAULT ''"),
                ("updated_at",       "TEXT DEFAULT CURRENT_TIMESTAMP"),
            ):
                if _col not in _act_p1_cols:
                    db.execute(f"ALTER TABLE actions ADD COLUMN {_col} {_def}")
            db.execute("CREATE INDEX IF NOT EXISTS idx_actions_owner  ON actions(owner)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_actions_status ON actions(status, deadline)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_actions_thread ON actions(thread_id)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_actions_source_doc ON actions(source_doc_id)")

            # One-time migration: copy graph_actions/graph_decisions into actions,
            # then rename the originals to *_legacy. Guarded by a meta flag so
            # re-running init() is a no-op (no duplicate rows, no re-rename).
            migrated = db.execute(
                "SELECT v FROM meta WHERE k='actions_migrated'").fetchone()
            if migrated is None:
                ga_exists = db.execute(
                    "SELECT 1 FROM sqlite_master WHERE type='table' AND name='graph_actions'"
                ).fetchone() is not None
                gd_exists = db.execute(
                    "SELECT 1 FROM sqlite_master WHERE type='table' AND name='graph_decisions'"
                ).fetchone() is not None
                if ga_exists:
                    db.execute(
                        "INSERT INTO actions(text, owner, deadline, status, "
                        "source_doc_id, thread_id, created_at, source) "
                        "SELECT text, owner, deadline, status, source_doc_id, "
                        "thread_id, created_at, 'email' FROM graph_actions")
                    db.execute("ALTER TABLE graph_actions RENAME TO graph_actions_legacy")
                if gd_exists:
                    # decided_on is deliberately NOT mapped to deadline: a
                    # recorded decision is a past event, and putting its date in
                    # deadline would make it surface as a stalled action (the
                    # Nexus decided_at/deadline split, migrations.py:967-972).
                    db.execute(
                        "INSERT INTO actions(text, source_doc_id, created_at, "
                        "source, status, owner) "
                        "SELECT text, source_doc_id, created_at, "
                        "'decision', 'recorded', '' FROM graph_decisions")
                    db.execute("ALTER TABLE graph_decisions RENAME TO graph_decisions_legacy")
                db.execute("INSERT OR REPLACE INTO meta(k,v) VALUES('actions_migrated','1')")

            # --- email_context + doc_context (Phase 1, Task 1.2) ----------
            # email_context ports doc_db.py:124-143 and folds the two triage
            # signals (reply_needed, reply_reason) on, since mcpbrain has no
            # separate triage surface. doc_context mirrors the same context
            # columns for Drive chunks, keyed by doc_id.
            db.execute(f"""CREATE TABLE IF NOT EXISTS email_context(
                message_id   TEXT PRIMARY KEY,
                subject      TEXT DEFAULT '',
                sender       TEXT DEFAULT '',
                sender_email TEXT DEFAULT '',
                sender_id    TEXT DEFAULT '',
                date_str     TEXT DEFAULT '',
                date_iso     TEXT DEFAULT '',
                thread_id    TEXT DEFAULT '',
                org          TEXT DEFAULT '',
                content_type TEXT DEFAULT '',
                summary      TEXT DEFAULT '',
                topics       TEXT DEFAULT '',
                enriched_at  TEXT DEFAULT '',
                labels       TEXT DEFAULT '',
                contextual_summary TEXT,
                reply_needed INTEGER DEFAULT 0,
                reply_reason TEXT DEFAULT ''){_S}""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_ec_org    ON email_context(org)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_ec_date   ON email_context(date_iso)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_ec_thread ON email_context(thread_id)")

            # email->entity link table (Phase 1, Task 2.5). Ported from
            # doc_db.py:146-153. Keyed (message_id, entity_id); role records how
            # the entity appears (sender / mentioned / about). graph_write.apply
            # writes these via link_email_entity.
            # entity_id CASCADEs: nothing repoints email links away from an
            # entity that org_import._remove_org_entity deletes, so without the
            # cascade that delete would now fail (or, pre-FK, leave a dangling
            # row — 146 of them on the live store).
            db.execute(f"""CREATE TABLE IF NOT EXISTS email_entities(
                message_id TEXT NOT NULL,
                entity_id  TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
                role       TEXT DEFAULT '',
                PRIMARY KEY (message_id, entity_id)){_S}""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_ee_entity  ON email_entities(entity_id)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_ee_message ON email_entities(message_id)")

            # --- entity_observations (Phase 1, Task 1.3) ------------------
            # Bi-temporal role-provenance table ported verbatim from
            # memory_db.py:430-451 (Spec 7 shape: valid_to + REAL confidence +
            # confidence_source + invalidation chain).
            # entity_id already DECLARED its REFERENCES; foreign_keys was OFF so
            # it enforced nothing. ON DELETE CASCADE added for the same reason as
            # the other four child columns — and because plain RESTRICT would
            # newly BREAK merge_entities/org_import if any observation were left
            # behind (96 already orphaned on the live store).
            # created_at was DATETIME: SQLite accepts that on a loose table (it
            # has NUMERIC affinity) and rejects it outright on a STRICT one.
            # CURRENT_TIMESTAMP yields 'YYYY-MM-DD HH:MM:SS', a string, and every
            # live value reads back typeof()='text', so TEXT is what the column
            # has always actually held.
            db.execute(f"""CREATE TABLE IF NOT EXISTS entity_observations(
                id                            INTEGER PRIMARY KEY,
                entity_id                     TEXT NOT NULL
                                              REFERENCES entities(id) ON DELETE CASCADE,
                attribute                     TEXT NOT NULL,
                value                         TEXT,
                source                        TEXT,
                valid_from                    TEXT,
                valid_to                      TEXT,
                confidence                    REAL DEFAULT 1.0,
                confidence_source             TEXT DEFAULT 'pipeline_snapshot',
                invalidated_at                TEXT,
                -- SET NULL, not the default NO ACTION: an entity's cascade
                -- deletes its observations one row at a time, so a pointer
                -- from one of them to another would abort the delete. Nothing
                -- writes this column today; this keeps it safe if anything does.
                invalidated_by_observation_id INTEGER
                                              REFERENCES entity_observations(id)
                                              ON DELETE SET NULL,
                created_at                    TEXT DEFAULT CURRENT_TIMESTAMP){_S}""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_eo_entity   ON entity_observations(entity_id)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_eo_valid_to ON entity_observations(valid_to)")
            # Non-unique partial index: multiple sources can share the same
            # (entity_id, attribute) at once; rank is resolved at read time.
            db.execute("CREATE INDEX IF NOT EXISTS idx_eo_entity_attr "
                       "ON entity_observations(entity_id, attribute) WHERE valid_to IS NULL")
            # Write-time consolidation columns: identical re-observations of the
            # same (entity, attribute, value) across sources collapse onto one
            # active row that counts confirmations (observed_count) and tracks the
            # most recent sighting (last_seen), instead of a row per source.
            # ALTER idiom (const defaults only) so populated stores migrate in place.
            eo_cols = {row["name"] for row in db.execute("PRAGMA table_info(entity_observations)").fetchall()}
            if "observed_count" not in eo_cols:
                db.execute("ALTER TABLE entity_observations ADD COLUMN observed_count INTEGER DEFAULT 1")
            if "last_seen" not in eo_cols:
                db.execute("ALTER TABLE entity_observations ADD COLUMN last_seen TEXT")

            # --- entity merge audit (R4) ----------------------------------
            # IF NOT EXISTS so init() also back-fills the table on existing stores.
            db.execute(f"""CREATE TABLE IF NOT EXISTS entity_merge_log(
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                winner_id   TEXT NOT NULL,
                loser_id    TEXT NOT NULL,
                loser_name  TEXT DEFAULT '',
                method      TEXT NOT NULL,
                at          TEXT DEFAULT CURRENT_TIMESTAMP){_S}""")

            # -- Org-baseline (Phase 0) Task 2 -----------------------------------
            # Edge outbox: allowlisted, redacted ContributionRecords queued locally
            # per drain; a daily cadence uploads pending rows (uploaded_at == '').
            db.execute(f"""CREATE TABLE IF NOT EXISTS org_contrib_outbox(
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                record      TEXT NOT NULL,
                created_at  TEXT DEFAULT CURRENT_TIMESTAMP,
                uploaded_at TEXT DEFAULT ''){_S}""")
            # Curator staging: contributions ingested from the fleet folder awaiting
            # deterministic merge + adjudication. UNIQUE makes re-ingest idempotent.
            db.execute(f"""CREATE TABLE IF NOT EXISTS org_contrib_staging(
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                contributor_email TEXT NOT NULL,
                source_ref        TEXT NOT NULL,
                claim             TEXT NOT NULL,
                confidence        REAL DEFAULT 1.0,
                valid_from        TEXT DEFAULT '',
                valid_to          TEXT DEFAULT '',
                source_kind       TEXT DEFAULT '',
                batch_file        TEXT DEFAULT '',
                ingested_at       TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(contributor_email, source_ref, claim)){_S}""")
            # Consumer re-point log: local entities merged into an org node at import,
            # so a later curator split can restore local flesh (spec B4a rule 4).
            db.execute(f"""CREATE TABLE IF NOT EXISTS org_repoint_log(
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                from_entity_id   TEXT NOT NULL,
                to_entity_id     TEXT NOT NULL,
                snapshot_version INTEGER DEFAULT 0,
                reason           TEXT DEFAULT '',
                at               TEXT DEFAULT CURRENT_TIMESTAMP){_S}""")

            # --- migration: add chunks.enriched to pre-existing stores --------
            # The real ~/.mcpbrain store predates the enriched column. Idempotent:
            # CREATE TABLE IF NOT EXISTS above won't alter an existing table, so
            # check PRAGMA table_info and ALTER if the column is missing.
            cols = {row["name"] for row in db.execute("PRAGMA table_info(chunks)").fetchall()}
            if "enriched" not in cols:
                db.execute("ALTER TABLE chunks ADD COLUMN enriched INTEGER DEFAULT 0")
            if "enriched_version" not in cols:
                # The enrichment-logic version a chunk was last enriched under.
                # Chunks below ENRICH_LOGIC_VERSION are re-flowed for re-extraction
                # under current rules/guards. Pre-existing chunks default to 0.
                db.execute("ALTER TABLE chunks ADD COLUMN enriched_version INTEGER DEFAULT 0")

            # --- Phase 3, Task 0.1: entity_communities + community_summaries --
            # Community membership table: one row per (entity, level). PK is
            # (entity_id, level) so an entity can appear in different communities
            # at different hierarchy levels. idx_ec_community supports fast
            # lookup of all members in a community.
            # CASCADE matters most here: merge_entities repoints relations,
            # observations and email links onto the winner before deleting the
            # loser, but NOTHING repoints community membership. Without the
            # cascade that delete would newly fail; with it, the stale
            # membership row goes and the next community pass recomputes it.
            db.execute(f"""CREATE TABLE IF NOT EXISTS entity_communities (
                entity_id    TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
                community_id INTEGER NOT NULL,
                level        INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (entity_id, level)
            ){_S}""")
            db.execute(
                "CREATE INDEX IF NOT EXISTS idx_ec_community "
                "ON entity_communities(community_id, level)"
            )
            # Community summary table: one row per (community_id, level) with
            # aggregated metadata written by the community-detection pipeline.
            db.execute(f"""CREATE TABLE IF NOT EXISTS community_summaries (
                community_id INTEGER NOT NULL,
                level        INTEGER NOT NULL DEFAULT 0,
                title        TEXT DEFAULT '',
                summary      TEXT DEFAULT '',
                member_count INTEGER DEFAULT 0,
                key_entities TEXT DEFAULT '',
                updated      TEXT DEFAULT '',
                PRIMARY KEY (community_id, level)
            ){_S}""")

            # --- Phase 3, Task 0.2: thread_context ----------------------------
            # Per-thread context row written by the thread-summariser pipeline.
            # thread_id mirrors Gmail's thread identifier so joins to email_context
            # work without an intermediate key.
            db.execute(f"""CREATE TABLE IF NOT EXISTS thread_context (
                thread_id           TEXT PRIMARY KEY,
                subject             TEXT DEFAULT '',
                org                 TEXT DEFAULT '',
                email_count         INTEGER DEFAULT 0,
                participant_ids     TEXT DEFAULT '',
                summary             TEXT DEFAULT '',
                last_updated        TEXT DEFAULT '',
                contextual_summary  TEXT DEFAULT '',
                contextual_summary_at TEXT DEFAULT ''
            ){_S}""")
            # Existing DBs: add contextual_summary_at (stamp of when the
            # contextual_summary was written) so a thread re-summarises when it
            # gains messages after being summarised, not just when it has none.
            _tc_cols = {row["name"] for row in
                        db.execute("PRAGMA table_info(thread_context)").fetchall()}
            if "contextual_summary_at" not in _tc_cols:
                db.execute("ALTER TABLE thread_context ADD COLUMN contextual_summary_at TEXT DEFAULT ''")

            # --- Phase 3, Task 0.3: proactive_findings ------------------------
            # Surface for pipeline-generated signals (overdue actions, missing
            # replies, stalled threads, etc.). UNIQUE(finding_type, ref_id) so
            # re-detecting the same signal upserts in place rather than
            # accumulating duplicates.
            db.execute(f"""CREATE TABLE IF NOT EXISTS proactive_findings (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                finding_type TEXT NOT NULL,
                ref_id       TEXT NOT NULL DEFAULT '',
                org          TEXT DEFAULT '',
                summary      TEXT DEFAULT '',
                detail       TEXT DEFAULT '',
                severity     TEXT DEFAULT 'info',
                detected_at  TEXT DEFAULT '',
                resolved_at  TEXT,
                UNIQUE(finding_type, ref_id)
            ){_S}""")
            _pf_cols = {row["name"] for row in
                        db.execute("PRAGMA table_info(proactive_findings)").fetchall()}
            if "verdict" not in _pf_cols:
                db.execute("ALTER TABLE proactive_findings ADD COLUMN verdict TEXT")
            db.execute(
                "CREATE INDEX IF NOT EXISTS idx_pf_type "
                "ON proactive_findings(finding_type)"
            )
            # Partial index: only open (unresolved) findings. Used by the MCP
            # tool to scan live signals efficiently.
            db.execute(
                "CREATE INDEX IF NOT EXISTS idx_pf_open "
                "ON proactive_findings(finding_type) WHERE resolved_at IS NULL"
            )

            # --- Session-4, Task 2.1: reversible entity suppression ------------
            # Presence of a row here is the entire suppression mechanism: the
            # entities row itself is never mutated or deleted, so suppression is
            # trivially reversible via unsuppress_entity (just delete this row).
            db.execute(f"""CREATE TABLE IF NOT EXISTS entity_suppressions (
                entity_id     TEXT PRIMARY KEY,
                reason        TEXT DEFAULT '',
                suppressed_at TEXT DEFAULT ''
            ){_S}""")

            # --- Graph corrections (2026-09-24 spec) ---------------------------
            # The ledger for brain_graph_correct: every correction the model makes
            # (applied, pending approval, declined, failed, reverted), with the
            # snapshot undo needs. Pending rows are the approval queue for
            # inferred corrections on clients without elicitation.
            db.execute(f"""CREATE TABLE IF NOT EXISTS graph_corrections(
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                op            TEXT NOT NULL,
                basis         TEXT NOT NULL,
                status        TEXT NOT NULL,
                payload       TEXT NOT NULL DEFAULT '{{}}',
                snapshot      TEXT NOT NULL DEFAULT '{{}}',
                reason        TEXT DEFAULT '',
                confirmed_via TEXT DEFAULT '',
                dedup_key     TEXT DEFAULT '',
                error         TEXT DEFAULT '',
                created_at    TEXT DEFAULT CURRENT_TIMESTAMP,
                applied_at    TEXT DEFAULT '',
                reverted_at   TEXT DEFAULT '',
                change_log_id INTEGER,
                applied_order INTEGER){_S}""")
            # When a row BECAME 'applied' (submit or approve), not when it was
            # created: a pending inferred correction gets a lower id but can be
            # approved after a later user_stated one already applied, and the
            # undo-conflict guard must call the approved-later one "later" too.
            # applied_at (1s resolution) can tie exactly on this case, so the
            # guard orders on this monotonically-assigned integer instead.
            gc_cols = {row["name"] for row in db.execute(
                "PRAGMA table_info(graph_corrections)").fetchall()}
            if "applied_order" not in gc_cols:
                db.execute("ALTER TABLE graph_corrections ADD COLUMN applied_order INTEGER")
            db.execute("CREATE INDEX IF NOT EXISTS idx_gc_status ON graph_corrections(status)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_gc_dedup ON graph_corrections(dedup_key)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_gc_applied_order "
                       "ON graph_corrections(applied_order)")
            # Automatic changes held for the owner's review ("ask me first").
            # payload is what auto_changes.APPLY[kind] needs to make the change
            # later; change_log_id is the undoable change approval recorded.
            # status: pending | deciding (claimed by one decide; decided_at is
            # the claim time) | applied | declined | interrupted (APPLY stopped
            # part way: Check it or Clear, never Apply again) | cleared.
            db.execute(f"""CREATE TABLE IF NOT EXISTS pending_changes(
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                kind          TEXT NOT NULL,
                target        TEXT NOT NULL DEFAULT '',
                summary       TEXT DEFAULT '',
                payload       TEXT NOT NULL DEFAULT '{{}}',
                status        TEXT NOT NULL DEFAULT 'pending',
                created_at    TEXT DEFAULT CURRENT_TIMESTAMP,
                decided_at    TEXT DEFAULT '',
                change_log_id INTEGER,
                error         TEXT DEFAULT ''){_S}""")
            # error: why the last approval didn't go through (the row stays
            # pending). Added after the table first shipped on this branch.
            if "error" not in {r["name"] for r in db.execute(
                    "PRAGMA table_info(pending_changes)").fetchall()}:
                db.execute("ALTER TABLE pending_changes ADD COLUMN error TEXT DEFAULT ''")
            db.execute("CREATE INDEX IF NOT EXISTS idx_pc_status ON pending_changes(status)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_pc_kind_target "
                       "ON pending_changes(kind, target)")
            # "These two are different entities": consulted by every merge path.
            # a < b always (the writer sorts), so one row per unordered pair.
            db.execute(f"""CREATE TABLE IF NOT EXISTS entity_distinct_pairs(
                a TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
                b TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
                PRIMARY KEY(a, b)){_S}""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_edp_b ON entity_distinct_pairs(b)")
            # A field the user corrected: automated writers must not overwrite it.
            db.execute(f"""CREATE TABLE IF NOT EXISTS entity_field_locks(
                entity_id TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
                field     TEXT NOT NULL,
                PRIMARY KEY(entity_id, field)){_S}""")
            # Bulk writers exclude locked rows with
            # `id NOT IN (SELECT entity_id FROM entity_field_locks WHERE field=?)`;
            # the PK leads on entity_id, so that subquery needs field first.
            db.execute("CREATE INDEX IF NOT EXISTS idx_efl_field "
                       "ON entity_field_locks(field, entity_id)")

            # --- Session-4, Task 3.2: org-suggestion inbox ----------------------
            # Purely additive/inspectable: an org string the extractor keeps
            # seeing that isn't in the configured taxonomy. Never auto-applied
            # to config.json — a human (or a future dashboard/CLI) reviews these.
            db.execute(f"""CREATE TABLE IF NOT EXISTS org_suggestions (
                raw_org       TEXT PRIMARY KEY,
                reason        TEXT DEFAULT '',
                suggested_at  TEXT DEFAULT ''
            ){_S}""")

            # --- Phase 1 capture: change_log -----------------------------------
            db.execute(f"""CREATE TABLE IF NOT EXISTS change_log (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                change_type TEXT NOT NULL,
                source      TEXT DEFAULT '',
                ref_id      TEXT DEFAULT '',
                summary     TEXT DEFAULT '',
                detail      TEXT DEFAULT '',
                revert_ref  TEXT DEFAULT '',
                created_at  TEXT DEFAULT CURRENT_TIMESTAMP){_S}""")
            # ORDER BY id DESC uses the PK — no secondary index needed.
            cl_cols = {row["name"] for row in db.execute(
                "PRAGMA table_info(change_log)").fetchall()}
            if "source" not in cl_cols:
                db.execute("ALTER TABLE change_log ADD COLUMN source TEXT DEFAULT ''")

            # --- Phase 3, Task 0.4: actions.waiting_on* columns ---------------
            # Back-fill waiting-on tracking onto the unified actions table.
            # Mirrors Nexus waiting_on columns (knowledge_db waiting_on_cleared_by_message_id)
            # with one rename: mcpbrain uses waiting_on_cleared_by_doc_id because
            # the reconcile trigger here is an arriving chunk (doc_id), not a
            # Gmail message row.
            act_cols = {row["name"] for row in db.execute("PRAGMA table_info(actions)").fetchall()}
            for col_name, col_def in (
                ("waiting_on",                    "TEXT"),
                ("waiting_on_entity_id",          "TEXT"),
                ("waiting_on_set_at",             "TEXT"),
                ("waiting_on_cleared_at",         "TEXT"),
                ("waiting_on_cleared_by_doc_id",  "TEXT"),
                ("reply_received",                "INTEGER DEFAULT 0"),
                # ClickUp two-way sync (2026-06-08): link anchor + priority.
                ("clickup_task_id",               "TEXT DEFAULT ''"),
                ("priority",                      "TEXT DEFAULT ''"),
                # Last-synced ClickUp closed-state for reopen detection
                # (2026-06-09). Nullable: NULL = never observed.
                ("clickup_closed",                "INTEGER"),
            ):
                if col_name not in act_cols:
                    db.execute(f"ALTER TABLE actions ADD COLUMN {col_name} {col_def}")
            # Partial index: open actions actively waiting on someone.
            db.execute(
                "CREATE INDEX IF NOT EXISTS idx_actions_waiting "
                "ON actions(status, waiting_on_set_at) "
                "WHERE status='open' AND waiting_on IS NOT NULL"
            )

            # --- meeting_packs (Mac capability uplift) -----------------------
            db.execute(f"""CREATE TABLE IF NOT EXISTS meeting_packs(
                event_id       TEXT PRIMARY KEY,
                event_title    TEXT DEFAULT '',
                event_date     TEXT DEFAULT '',
                pack_text      TEXT DEFAULT '',
                attendees      TEXT DEFAULT '[]',
                built_at       TEXT DEFAULT '',
                cowork_session TEXT DEFAULT '',
                context_hash   TEXT DEFAULT ''){_S}""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_mp_date ON meeting_packs(event_date)")
            # context_hash (2026-06-16): a fingerprint of the inputs a pack was
            # built from, so the hourly meeting-packs task rebuilds a pack only
            # when its context actually changed. Back-filled on pre-existing stores.
            mp_cols = {row["name"] for row in db.execute("PRAGMA table_info(meeting_packs)").fetchall()}
            if "context_hash" not in mp_cols:
                db.execute("ALTER TABLE meeting_packs ADD COLUMN context_hash TEXT DEFAULT ''")

            # --- stale_reextract (Gap A re-extraction trigger, 2026-06-09) ----
            # Records that a thread was reset to enriched=0 for a fresh LLM
            # at-bat, keyed by a content signature so the same unchanged thread
            # is never re-triggered (would re-pay the re-extraction token cost).
            db.execute(f"""CREATE TABLE IF NOT EXISTS stale_reextract(
                thread_id    TEXT PRIMARY KEY,
                signature    TEXT NOT NULL,
                triggered_at TEXT NOT NULL
            ){_S}""")
            # superseded_at: UNUSED. Added for a supersede-on-re-extraction
            # rule that was withdrawn; kept because schema changes are additive.
            sr_cols = {row["name"] for row in db.execute(
                "PRAGMA table_info(stale_reextract)").fetchall()}
            if "superseded_at" not in sr_cols:
                db.execute("ALTER TABLE stale_reextract "
                           "ADD COLUMN superseded_at TEXT NOT NULL DEFAULT ''")

            # --- draft_records (Mac capability uplift) ------------------------
            db.execute(f"""CREATE TABLE IF NOT EXISTS draft_records(
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                email_id        TEXT DEFAULT '',
                thread_id       TEXT DEFAULT '',
                intent          TEXT DEFAULT '',
                audience_tier   TEXT DEFAULT '',
                draft_text      TEXT DEFAULT '',
                critique        TEXT DEFAULT '',
                voice_issues    TEXT DEFAULT '[]',
                samples_used    INTEGER DEFAULT 0,
                model           TEXT DEFAULT '',
                parent_draft_id INTEGER,
                refinement      TEXT DEFAULT '',
                created_at      TEXT DEFAULT CURRENT_TIMESTAMP){_S}""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_dr_email  ON draft_records(email_id)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_dr_thread ON draft_records(thread_id)")

            # --- S2 recall-acceptance feedback (Phase 0, 2026-06-22) ----------
            # recall_feedback: raw event log (one row per recall event).
            # chunk_quality:   per-chunk quality float updated by nightly aggregate.
            db.execute(f"""CREATE TABLE IF NOT EXISTS recall_feedback(
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                doc_id     TEXT NOT NULL,
                session_id TEXT DEFAULT '',
                event_type TEXT NOT NULL,
                ts         TEXT DEFAULT ''){_S}""")
            db.execute(
                "CREATE INDEX IF NOT EXISTS idx_rf_doc_id "
                "ON recall_feedback(doc_id)")
            db.execute(
                "CREATE INDEX IF NOT EXISTS idx_rf_ts "
                "ON recall_feedback(ts)")

            # exposures/uses are REAL, not INTEGER. They were declared INTEGER,
            # but feedback.aggregate_feedback has always written TIME-DECAYED
            # counts -- round(s["exposures"], 2) -- so the live store holds
            # values like 3.77 exposures / 0.62 uses (9 rows, found by auditing
            # typeof() against the declared type before turning STRICT on).
            # Under STRICT that write would raise, and rounding it in the writer
            # would throw away the decay resolution the algorithm exists for:
            # a decayed 0.62 uses is not 1 use. The declaration was the thing
            # that was wrong.
            db.execute(f"""CREATE TABLE IF NOT EXISTS chunk_quality(
                doc_id     TEXT PRIMARY KEY,
                quality    REAL DEFAULT 1.0,
                exposures  REAL DEFAULT 0,
                uses       REAL DEFAULT 0,
                updated_at TEXT DEFAULT ''){_S}""")

            # --- Q1 salience gate: enrich_state on chunks (Phase 0, 2026-06-22)
            # 'cold' = embedded/searchable but skip graph-extraction.
            # unenriched_chunks() excludes cold chunks so they don't re-queue.
            ch_cols = {row["name"] for row in
                       db.execute("PRAGMA table_info(chunks)").fetchall()}
            if "enrich_state" not in ch_cols:
                db.execute("ALTER TABLE chunks ADD COLUMN enrich_state TEXT DEFAULT ''")
            # --- Q8: per-chunk extraction attempt counter (2026-06-23) ---------
            # Bumped each time an extraction covering this chunk yields nothing.
            # After a cap the chunk is consumed (mark_enriched) so a genuinely
            # content-empty doc stops re-queuing+re-extracting forever.
            if "enrich_attempts" not in ch_cols:
                db.execute("ALTER TABLE chunks ADD COLUMN enrich_attempts INTEGER DEFAULT 0")
            # --- B3 salience (Phase 2, 2026-06-23) ----------------------------
            if "salience" not in ch_cols:
                db.execute("ALTER TABLE chunks ADD COLUMN salience REAL DEFAULT 0.0")
            # --- B2 memory tier + type (Phase 2, 2026-06-23) ------------------
            # tier: core/hot/warm/cold/''.  type: episodic/semantic/procedural
            if "memory_tier" not in ch_cols:
                db.execute("ALTER TABLE chunks ADD COLUMN memory_tier TEXT DEFAULT ''")
            if "memory_type" not in ch_cols:
                db.execute("ALTER TABLE chunks ADD COLUMN memory_type TEXT DEFAULT 'episodic'")
            # --- Phase C: FTS contextual-reindex marker (bounded backfill) -----
            if "fts_context_version" not in ch_cols:
                db.execute("ALTER TABLE chunks ADD COLUMN fts_context_version INTEGER DEFAULT 0")
            # --- console source controls (2026-11-09): enrichment priority ----
            # The owner can move waiting chunks to the front of the enrichment
            # queue ("See what's waiting" -> Prioritise). unenriched_chunks
            # orders priority DESC, rowid DESC.
            if "priority" not in ch_cols:
                db.execute("ALTER TABLE chunks ADD COLUMN priority INTEGER DEFAULT 0")

            # --- partial indexes for the two work-queue filters ----------------
            # Both backlog scans were a full `SCAN chunks` (confirmed by EXPLAIN
            # QUERY PLAN -- count_unembedded's "`embedded` is indexed" docstring
            # was never true; there was no index on either column). A partial
            # index holds ONLY the rows matching its WHERE, so on a corpus that
            # is ~fully embedded and enriched these stay tiny and nearly free to
            # maintain -- the same trade the existing partial indexes make
            # (idx_actions_waiting, idx_pf_open, idx_eo_entity_attr,
            # idx_er_valid_now): index what the query reads, put the selective
            # constant in the WHERE.
            #
            # Placed HERE, after the ALTERs above, because enrich_state and
            # fts_context_version do not exist in the CREATE TABLE -- an index
            # created earlier would fail on a fresh store.
            db.execute("CREATE INDEX IF NOT EXISTS idx_chunks_unembedded "
                       "ON chunks(rowid) WHERE embedded=0")
            # unenriched_chunks(): the key is rowid ALONE, deliberately. That
            # removes the full scan on `enriched=0`, and because rowid is the
            # only key column a reverse walk also satisfies the query's
            # ORDER BY rowid DESC — measured plan: 'SCAN chunks USING INDEX
            # idx_chunks_unenriched', no temp b-tree.
            #
            # A (enrich_state, rowid) key was measured strictly WORSE: the
            # leading column destroys that ordering (the plan gains USE TEMP
            # B-TREE FOR ORDER BY) and buys nothing on the predicate side,
            # because the query filters COALESCE(enrich_state,'') != 'cold',
            # not the bare column — an expression no plain-column index can
            # seek. That and the doc_id NOT LIKE are filtered per row either
            # way.
            #
            # 2026-11-09: the queue now orders `priority DESC, rowid DESC`, so
            # the key is (priority, rowid) -- a reverse walk of it is that
            # order, again with no temp b-tree. The rowid-only index it
            # replaces is dropped (same predicate, so nothing else loses it).
            db.execute("DROP INDEX IF EXISTS idx_chunks_unenriched")
            db.execute("CREATE INDEX IF NOT EXISTS idx_chunks_unenriched_prio "
                       "ON chunks(priority, rowid) WHERE enriched=0")
            # reindex_fts_batch's `embedded=1 AND fts_context_version < N`.
            #
            # That query MUST filter the bare column, not COALESCE(...,0): a
            # plain-column index cannot serve a COALESCE-wrapped predicate, so
            # the COALESCE form plans as SCAN chunks and this index would be
            # pure write-time cost on one of the hottest tables in the store.
            # Same index/query-drift class as the 0.7.105 json_extract bug that
            # _meta_extract() exists to prevent. The COALESCE was removed as
            # dead defensive code: the column is INTEGER DEFAULT 0, SQLite
            # returns that default for rows predating the ALTER, all three
            # writers stamp an int, and the live store reads 170,695/170,695
            # rows as typeof()='integer' with zero NULLs. If a NULL ever
            # becomes reachable, make this an expression index on
            # COALESCE(fts_context_version,0) and put the COALESCE back — index
            # and query must move together.
            db.execute("CREATE INDEX IF NOT EXISTS idx_chunks_fts_stale "
                       "ON chunks(fts_context_version) WHERE embedded=1")

            # --- B5 decay: strength + last_accessed on chunk_quality (Phase 2) -
            cq_cols = {row["name"] for row in
                       db.execute("PRAGMA table_info(chunk_quality)").fetchall()}
            if "memory_strength" not in cq_cols:
                db.execute("ALTER TABLE chunk_quality ADD COLUMN memory_strength REAL DEFAULT 5.0")
            if "last_accessed" not in cq_cols:
                db.execute("ALTER TABLE chunk_quality ADD COLUMN last_accessed TEXT DEFAULT ''")

            # --- B6 voice suggestions table (Phase 2, 2026-06-23) -------------
            db.execute(f"""CREATE TABLE IF NOT EXISTS voice_suggestions(
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                kind         TEXT NOT NULL,
                rule         TEXT NOT NULL,
                confidence   REAL DEFAULT 0.0,
                explanation  TEXT DEFAULT '',
                evidence_ids TEXT DEFAULT '[]',
                status       TEXT DEFAULT 'pending',
                created_at   TEXT DEFAULT CURRENT_TIMESTAMP,
                applied_at   TEXT DEFAULT ''){_S}""")
            db.execute(
                "CREATE INDEX IF NOT EXISTS idx_vs_status ON voice_suggestions(status)")

            # --- B6 voice state table (Phase 2, 2026-06-23) ------------------
            db.execute(f"""CREATE TABLE IF NOT EXISTS voice_analyser_state(
                key        TEXT PRIMARY KEY,
                value      TEXT DEFAULT '',
                updated_at TEXT DEFAULT ''){_S}""")

            # --- A4, Task 1: enrich_payloads (cache enrichment payloads) ----
            # Carries the extraction so importers skip re-enrich on shared-drive
            # artifacts. Keyed on the Drive FILE, one row per file: drain used
            # to write the whole-unit payload once per chunk doc_id while
            # ingest_cache.publish_file reads exactly one per file, which on the
            # live store was 50,099 rows for 8,183 files -- 13.5GB of a 15.65GB
            # store, and the reason the plaintext backup copy stopped fitting on
            # disk.
            db.execute(f"""CREATE TABLE IF NOT EXISTS enrich_payloads(
                file_id       TEXT PRIMARY KEY,
                payload       TEXT NOT NULL,
                logic_version INTEGER DEFAULT 0,
                at            TEXT DEFAULT CURRENT_TIMESTAMP,
                covers        TEXT){_S}""")
            # A store written before the re-key is keyed per chunk doc_id. Move
            # it aside -- metadata-only, so init() stays instant -- and let the
            # enrich_payload_migration cadence drain it in the background.
            # Collapsing here would free 41,916 rows' overflow pages on the
            # startup path, minutes of I/O.
            #
            # Driven from init() on whatever store it finds, NOT a one-shot
            # behind a version marker: a backup artifact captured before this
            # change carries the old schema, and restoring it into a post-fix
            # build has to migrate it too.
            _ep_cols = {row["name"] for row in
                        db.execute("PRAGMA table_info(enrich_payloads)").fetchall()}
            if "doc_id" in _ep_cols:
                db.execute("ALTER TABLE enrich_payloads RENAME TO enrich_payloads_legacy")
                # Same shape (STRICT included) as the CREATE above -- this branch
                # recreates the very table that one skipped because the legacy
                # doc_id-keyed version was still standing.
                db.execute(f"""CREATE TABLE enrich_payloads(
                    file_id       TEXT PRIMARY KEY,
                    payload       TEXT NOT NULL,
                    logic_version INTEGER DEFAULT 0,
                    at            TEXT DEFAULT CURRENT_TIMESTAMP,
                    covers        TEXT){_S}""")
            # `covers`: the JSON list of chunk doc_ids the payload's extraction
            # was actually made from. NULL = a payload written before this
            # column existed, trusted as whole-file (the pre-reflow behaviour);
            # apply_reflow replaces it with an explicit list. publish_file
            # attaches a payload only when it covers every non-cold chunk.
            if "covers" not in {row["name"] for row in
                                db.execute("PRAGMA table_info(enrich_payloads)")}:
                db.execute("ALTER TABLE enrich_payloads ADD COLUMN covers TEXT")

            # One-time baseline stats. _connect's write-close PRAGMA optimize
            # (below) is opportunistic and NOT guaranteed to create sqlite_stat1
            # even on a pristine schema -- confirmed empirically: SQLite 3.45.1
            # (Ubuntu's linked libsqlite3, vs 3.50+ elsewhere) declines to do so
            # even after a real write plus a second, standalone PRAGMA optimize
            # call. Run ANALYZE once here, unconditionally, so sqlite_stat1
            # exists from the very first init() regardless of the linked
            # SQLite version's heuristics -- a one-time cost against an empty
            # store, not a per-write one, so it does not reintroduce the
            # write-path latency PRAGMA optimize's write-only gating exists to
            # avoid. It writes no per-index rows yet (nothing to sample on an
            # empty table), but the table's existence is what every later
            # ANALYZE / PRAGMA optimize call updates in place.
            db.execute("ANALYZE")

            # One-shot: drop per-round state the queue replaces, for the
            # sources that got migrated (drive/gmail/calendar's bare
            # discover_*/handle_*_item split, and -- now that
            # `sync_shared_drive` is deleted -- every pinned Shared Drive's
            # per-drive equivalent too). resume_ids tracked which files a
            # ROUND had written; rounds no longer exist for these sources.
            # page_token (0.7.123) existed because the cursor could not
            # advance per page; it now does. The real cursors are untouched.
            #
            # The bare two-segment keys (drive/gmail/calendar) are an exact-
            # match list since there is exactly one of each. Shared-drive
            # keys are per-drive (`drive:<driveId>:resume_ids` etc.), so they
            # can't be enumerated by exact match -- a suffix LIKE scoped to
            # the `drive:` prefix is now safe to use for them specifically,
            # because no live function writes `drive:<id>:resume_ids`-shaped
            # state any more (sync_shared_drive, the only writer, is gone).
            # Do NOT widen this to a bare `source LIKE '%:resume_ids'` etc.:
            # that would also match any unrelated future source that happens
            # to end in one of these suffixes, not just the drive:-prefixed
            # state this task actually retires.
            db.execute(
                "DELETE FROM sync_cursors WHERE source IN "
                "('drive:resume_ids', 'drive:resume_removed_ids', "
                "'drive:page_token', 'gmail:resume_ids', 'calendar:resume_ids') "
                "OR (source LIKE 'drive:%:resume_ids' "
                "    OR source LIKE 'drive:%:resume_removed_ids' "
                "    OR source LIKE 'drive:%:page_token')")

            # --- ingestion integrity: source classes, per-source support,
            # reversible clean-up (spec 2026-10-22). Additive only.
            for _tbl, _cols in (
                ("chunks", (("dup_of", "TEXT DEFAULT NULL"),)),
                ("email_entities", (("derived", "INTEGER NOT NULL DEFAULT 0"),
                                    ("derived_reason", "TEXT DEFAULT NULL"))),
                ("entity_relations", (
                    ("derived", "INTEGER NOT NULL DEFAULT 0"),
                    ("legacy_strength", "INTEGER DEFAULT NULL"))),
                ("entity_observations", (
                    ("derived", "INTEGER NOT NULL DEFAULT 0"),)),
                ("actions", (
                    ("prior_thread_id", "TEXT DEFAULT NULL"),
                    ("prior_owner", "TEXT DEFAULT NULL"),
                    # The owner repair's prior owner id (ruling I19) -- set
                    # only by action_owner.repair_owner_actions, cleared by
                    # its undo.
                    ("prior_owner_entity_id", "TEXT DEFAULT NULL"))),
            ):
                _have = {r["name"] for r in
                         db.execute(f"PRAGMA table_info({_tbl})")}
                for _c, _decl in _cols:
                    if _c not in _have:
                        db.execute(f"ALTER TABLE {_tbl} ADD COLUMN {_c} {_decl}")
            # Content-duplicate carry (spec §4): upsert_chunk looks a new
            # chunk's content_hash up among existing rows, and every write
            # that changes or removes a canonical looks up its dups -- both
            # would be full scans of chunks without these.
            db.execute("CREATE INDEX IF NOT EXISTS idx_chunks_content_hash "
                       "ON chunks(content_hash)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_chunks_dup_of "
                       "ON chunks(dup_of) WHERE dup_of IS NOT NULL")
            # note_id lookups (consolidated-note provenance); same pattern as
            # idx_chunks_threadid -- expression comes from _meta_extract.
            db.execute("CREATE INDEX IF NOT EXISTS idx_chunks_noteid "
                       f"ON chunks({_meta_extract('$.note_id')})")
            db.execute(f"""CREATE TABLE IF NOT EXISTS relation_sources(
                relation_id  INTEGER NOT NULL
                             REFERENCES entity_relations(id) ON DELETE CASCADE,
                source_key   TEXT NOT NULL,
                source_class TEXT NOT NULL,
                first_seen   TEXT NOT NULL,
                PRIMARY KEY (relation_id, source_key)){_S}""")
            # Removal looks support rows up by source (M3): without this the
            # primary key (relation_id first) cannot serve it.
            db.execute("CREATE INDEX IF NOT EXISTS idx_relation_sources_key "
                       "ON relation_sources(source_key)")
            db.execute(f"""CREATE TABLE IF NOT EXISTS observation_sources(
                observation_id INTEGER NOT NULL
                               REFERENCES entity_observations(id) ON DELETE CASCADE,
                source_key     TEXT NOT NULL,
                source_class   TEXT NOT NULL,
                first_seen     TEXT NOT NULL,
                PRIMARY KEY (observation_id, source_key)){_S}""")
            db.execute(f"""CREATE TABLE IF NOT EXISTS cleanup_log(
                id          INTEGER PRIMARY KEY,
                step        TEXT,
                table_name  TEXT,
                row_key     TEXT,
                column_name TEXT,
                old_value   TEXT,
                at          TEXT,
                new_value   TEXT){_S}""")
            # new_value: the value the clean-up wrote, so --undo restores only
            # rows nobody has changed since (additive; NULL on older rows).
            if "new_value" not in {r["name"] for r in
                                   db.execute("PRAGMA table_info(cleanup_log)")}:
                db.execute("ALTER TABLE cleanup_log ADD COLUMN new_value TEXT")

    # --- S2 recall-acceptance feedback methods --------------------------------

    def record_recall_feedback(self, doc_id: str, session_id: str,
                               event_type: str, ts: str) -> None:
        """Append one recall feedback event row."""
        with self._connect(write=True) as db:
            db.execute(
                "INSERT INTO recall_feedback(doc_id,session_id,event_type,ts) VALUES(?,?,?,?)",
                (doc_id, session_id, event_type, ts))

    def record_recall_feedback_batch(self, rows: list[tuple]) -> None:
        """Append many recall feedback events in one transaction.

        rows: list of (doc_id, session_id, event_type, ts). One executemany so the
        recall hot path pays a single write, not one connection per chunk.
        """
        if not rows:
            return
        with self._connect(write=True) as db:
            db.executemany(
                "INSERT INTO recall_feedback(doc_id,session_id,event_type,ts) VALUES(?,?,?,?)",
                rows)

    def all_feedback_rows(self) -> list[dict]:
        """Return every recall_feedback row as {doc_id, event_type, ts}."""
        with self._connect() as db:
            rows = db.execute(
                "SELECT doc_id,event_type,ts FROM recall_feedback ORDER BY id").fetchall()
            return [dict(r) for r in rows]

    def get_chunk_quality(self, doc_id: str) -> float:
        """Return the chunk's quality score (1.0 = neutral if not yet computed)."""
        with self._connect() as db:
            row = db.execute(
                "SELECT quality FROM chunk_quality WHERE doc_id=?", (doc_id,)).fetchone()
            return float(row["quality"]) if row else 1.0

    def update_chunk_quality(self, doc_id: str, quality: float,
                             exposures: float, uses: float) -> None:
        """Upsert the quality row for one chunk.

        exposures/uses are FLOATS: feedback.aggregate_feedback passes
        time-decayed counts (round(x, 2)), never whole events. The columns were
        declared INTEGER, which STRICT would have rejected — see the
        chunk_quality DDL in init()."""
        from datetime import datetime, timezone
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        with self._connect(write=True) as db:
            db.execute(
                """INSERT INTO chunk_quality(doc_id,quality,exposures,uses,updated_at)
                   VALUES(?,?,?,?,?)
                   ON CONFLICT(doc_id) DO UPDATE SET
                       quality=excluded.quality,
                       exposures=excluded.exposures,
                       uses=excluded.uses,
                       updated_at=excluded.updated_at""",
                (doc_id, quality, exposures, uses, ts))

    # --- Q1 salience gate methods ----------------------------------------------

    def set_enrich_state(self, doc_ids: list[str], state: str) -> None:
        """Set enrich_state on the given chunks.

        state='cold'  → chunk stays embedded/searchable but skips graph-extraction.
        state=''      → reset to normal; chunk re-enters the extraction backlog.
        """
        if not doc_ids:
            return
        with self._connect(write=True) as db:
            db.executemany(
                "UPDATE chunks SET enrich_state=? WHERE doc_id=?",
                [(state, d) for d in doc_ids])

    def drop_cold(self, doc_ids: list[str]) -> list[str]:
        """Filter cold chunks out of doc_ids, preserving input order.

        A Drive file-wide resolve (doc_ids_for_messages's file_id branch)
        returns EVERY chunk of a document, including any the salience gate has
        since marked enrich_state='cold' -- that match is enrich_state-blind by
        design. But a Drive extraction's batch text only ever covers the hot
        (non-cold) chunks should_enrich() queued, so drain calls this right
        before apply/mark_enriched to consume exactly the chunks it actually
        extracted. Cold chunks stay enriched=0 (embedded/searchable, gated from
        graph-extraction) so cold-reversibility holds. Email doc_ids are never
        cold-gated the same way, so this is a no-op for them.
        """
        ids = [d for d in (doc_ids or []) if d]
        if not ids:
            return []
        ph = ",".join("?" * len(ids))
        with self._connect() as db:
            rows = db.execute(
                f"SELECT doc_id FROM chunks WHERE doc_id IN ({ph}) "
                f"AND COALESCE(enrich_state,'') != 'cold'",
                ids,
            ).fetchall()
        hot = {r["doc_id"] for r in rows}
        return [d for d in ids if d in hot]

    def cold_chunk_count(self) -> int:
        """Number of chunks currently in the cold (gated) state."""
        with self._connect() as db:
            return db.execute(
                "SELECT COUNT(*) FROM chunks WHERE enrich_state='cold'").fetchone()[0]

    def bump_enrich_attempts(self, doc_ids: list[str]) -> int:
        """Increment the extraction-attempt counter for the given chunks (Q8).

        Returns the MAX attempt count across them after the bump, so the caller
        can decide whether the cap is reached. No-op (returns 0) for an empty list.
        """
        if not doc_ids:
            return 0
        with self._connect(write=True) as db:
            qmarks = ",".join("?" for _ in doc_ids)
            db.execute(
                f"UPDATE chunks SET enrich_attempts = COALESCE(enrich_attempts,0) + 1 "
                f"WHERE doc_id IN ({qmarks})", list(doc_ids))
            row = db.execute(
                f"SELECT MAX(COALESCE(enrich_attempts,0)) FROM chunks "
                f"WHERE doc_id IN ({qmarks})", list(doc_ids)).fetchone()
            return int(row[0] or 0)

    def email_mentions(self, *needles: str) -> bool:
        """True if any email chunk's text references one of the given strings.

        Used by the salience gate's optional Drive mention-check (a Drive doc is
        "worth enriching" when its file_id or file_name appears in an email). Scans
        gmail-source chunks with a LIKE for each non-empty needle; cheap at our
        email volume. Returns False on any error (fail-open is the caller's choice).
        """
        terms = [n.strip() for n in needles if n and n.strip() and len(n.strip()) >= 4]
        if not terms:
            return False
        clause = " OR ".join("text LIKE ?" for _ in terms)
        params = [f"%{t}%" for t in terms]
        sql = ("SELECT 1 FROM chunks "
               f"WHERE {_meta_extract('$.source_type')}='gmail' "
               f"AND ({clause}) LIMIT 1")
        try:
            with self._connect() as db:
                return db.execute(sql, params).fetchone() is not None
        except Exception:  # noqa: BLE001
            return False

    # --- Q4 org-backfill helper -----------------------------------------------

    def entities_without_org(self, limit: int | None = None) -> list[dict]:
        """Entities where org is empty (candidates for org_from_email backfill).

        Returns {id, name, type, email_addr} dicts, ordered by id.
        Only returns entities with a non-empty email_addr (needed for domain lookup).
        limit caps how many rows are returned; None = all.
        """
        sql = ("SELECT id,name,type,email_addr FROM entities "
               "WHERE (org='' OR org IS NULL) AND email_addr!='' "
               "ORDER BY id")
        if limit is not None:
            sql += f" LIMIT {int(limit)}"
        with self._connect() as db:
            rows = db.execute(sql).fetchall()
            return [dict(r) for r in rows]

    def update_entity_org(self, entity_id: str, org: str, org_valid_from: str = "",
                          *, user: bool = False, change: dict | None = None) -> bool:
        """Set the org (and optionally org_valid_from) on one entity. Returns True if a
        row was actually updated. A user-locked org is left alone unless user=True:
        that single check covers org_backfill and both review appliers.

        change: when given ({change_type, summary, source}), the prior org is read
        on this connection and an undoable change_log row is written in the same
        transaction."""
        with self._connect(write=True) as db:
            if not user and _field_is_locked(db, entity_id, "org"):
                return False
            prior = db.execute("SELECT org, org_valid_from FROM entities WHERE id=?",
                               (entity_id,)).fetchone() if change is not None else None
            cur = db.execute(
                "UPDATE entities SET org=?, org_valid_from=? WHERE id=?",  # lock-exempt: guarded by _field_is_locked above
                (org, org_valid_from, entity_id))
            if cur.rowcount > 0 and prior is not None:
                _log_recorded_change(
                    db, change, entity_id,
                    {"org": prior["org"] or "", "org_valid_from": prior["org_valid_from"] or ""},
                    {"org": org, "org_valid_from": org_valid_from})
            return cur.rowcount > 0

    def rename_entity(self, entity_id: str, new_name: str, *, user: bool = False) -> bool:
        """Rename an entity, preserving the old name as an alias.

        aliases is a '|'-separated, de-duplicated list. The old name is appended
        (case-preserving) unless it already equals the new name or is already
        present. Returns True iff the entity exists and was updated. A
        user-locked name is left alone unless user=True.
        """
        new_name = (new_name or "").strip()
        if not new_name:
            return False
        with self._connect(write=True) as db:
            if not user and _field_is_locked(db, entity_id, "name"):
                return False
            row = db.execute("SELECT name, COALESCE(aliases,'') AS aliases "
                             "FROM entities WHERE id=?", (entity_id,)).fetchone()
            if row is None:
                return False
            old = (row["name"] or "").strip()
            parts = split_aliases(row["aliases"])
            if old and old != new_name and old not in parts:
                parts.append(old)
            db.execute("UPDATE entities SET name=?, aliases=? WHERE id=?",  # lock-exempt: guarded by _field_is_locked above
                       (new_name, "|".join(parts), entity_id))
            return True

    def set_entity_email(self, entity_id: str, email_addr: str, *, user: bool = False) -> bool:
        """Set an entity's email_addr. Returns True iff a row was updated. A
        user-locked email is left alone unless user=True."""
        with self._connect(write=True) as db:
            if not user and _field_is_locked(db, entity_id, "email"):
                return False
            cur = db.execute("UPDATE entities SET email_addr=? WHERE id=?",  # lock-exempt: guarded by _field_is_locked above
                             (email_addr or "", entity_id))
            return cur.rowcount > 0

    def set_entity_notes(self, entity_id: str, notes: str) -> bool:
        """Set an entity's notes. Returns True iff a row was updated."""
        with self._connect(write=True) as db:
            cur = db.execute("UPDATE entities SET notes=? WHERE id=?",
                             (notes or "", entity_id))
            return cur.rowcount > 0

    def rewrite_org_field(self, variant_org: str, canonical_org: str, *,
                          change: dict | None = None) -> int:
        """Bulk-correct the org field: relabel every entity currently tagged
        with variant_org to canonical_org. Returns the number of rows updated
        (0 means no entity currently carries variant_org — a stale finding).
        Entities with a user-locked org field are excluded.

        change: when given, the relabelled entity ids are read on this
        connection and an undoable change_log row is written with the write."""
        unlocked = ("org=? AND id NOT IN "
                    "(SELECT entity_id FROM entity_field_locks WHERE field='org')")
        with self._connect(write=True) as db:
            ids = [r[0] for r in db.execute(
                f"SELECT id FROM entities WHERE {unlocked}", (variant_org,))
            ] if change is not None else []
            cur = db.execute(f"UPDATE entities SET org=? WHERE {unlocked}",  # lock-exempt: {unlocked} excludes entity_field_locks
                             (canonical_org, variant_org))
            if cur.rowcount > 0 and change is not None:
                _log_recorded_change(db, change, variant_org,
                                     {"org": variant_org, "entity_ids": ids},
                                     {"org": canonical_org})
            return cur.rowcount

    def update_entity_org_if_empty(self, entity_id: str, org: str) -> bool:
        """Set org on an entity only if it currently has none. Returns True if set.

        Used by write-time dedup: when a new mention with a real org redirects to
        an existing entity that lacks one, fill it without clobbering a known org.
        A user-locked org (e.g. deliberately cleared) is left alone.
        """
        if not org:
            return False
        with self._connect(write=True) as db:
            if _field_is_locked(db, entity_id, "org"):
                return False
            cur = db.execute(
                "UPDATE entities SET org=? WHERE id=? AND (org='' OR org IS NULL)",  # lock-exempt: guarded by _field_is_locked above
                (org, entity_id))
            return cur.rowcount > 0

    def update_entity_email_if_empty(self, entity_id: str, email_addr: str) -> bool:
        """Set email_addr on an entity only if it currently has none. Returns True if set.

        Used by write-time dedup: when a new mention carries a header-sourced
        email and redirects to an existing entity that lacks one, fill it
        without clobbering a better-sourced address.
        """
        if not email_addr:
            return False
        with self._connect(write=True) as db:
            cur = db.execute(
                "UPDATE entities SET email_addr=? WHERE id=? AND (email_addr='' OR email_addr IS NULL) "
                "AND id NOT IN (SELECT entity_id FROM entity_field_locks WHERE field='email')",
                (email_addr, entity_id))
            return cur.rowcount > 0

    def upsert_meeting_pack(self, event_id: str, event_title: str,
                            event_date: str, pack_text: str,
                            attendees: list | None = None,
                            cowork_session: str = "",
                            context_hash: str = "") -> None:
        now = datetime.now(timezone.utc).isoformat()
        with self._connect(write=True) as db:
            db.execute(
                """INSERT INTO meeting_packs(event_id, event_title, event_date, pack_text,
                       attendees, built_at, cowork_session, context_hash)
                   VALUES(?,?,?,?,?,?,?,?)
                   ON CONFLICT(event_id) DO UPDATE SET
                       event_title=excluded.event_title,
                       event_date=excluded.event_date,
                       pack_text=excluded.pack_text,
                       attendees=excluded.attendees,
                       built_at=excluded.built_at,
                       cowork_session=excluded.cowork_session,
                       context_hash=excluded.context_hash""",
                (event_id, event_title, event_date, pack_text,
                 json.dumps(attendees or []), now, cowork_session, context_hash))

    def get_meeting_pack(self, event_id: str) -> dict | None:
        with self._connect() as db:
            row = db.execute(
                "SELECT * FROM meeting_packs WHERE event_id=?", (event_id,)).fetchone()
            return dict(row) if row else None

    def pack_event_ids_for_date(self, date_iso: str) -> set:
        with self._connect() as db:
            rows = db.execute(
                "SELECT event_id FROM meeting_packs WHERE event_date=?",
                (date_iso,)).fetchall()
            return {r["event_id"] for r in rows}

    def save_draft(self, email_id: str, thread_id: str, intent: str,
                   audience_tier: str, draft_text: str, critique: str,
                   voice_issues: list, samples_used: int, model: str,
                   parent_draft_id: int | None = None,
                   refinement: str = "") -> int:
        with self._connect(write=True) as db:
            cur = db.execute(
                """INSERT INTO draft_records(email_id, thread_id, intent, audience_tier,
                       draft_text, critique, voice_issues, samples_used, model,
                       parent_draft_id, refinement)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (email_id, thread_id, intent, audience_tier, draft_text, critique,
                 json.dumps(voice_issues), samples_used, model,
                 parent_draft_id, refinement))
            return cur.lastrowid

    def get_draft(self, draft_id: int) -> dict | None:
        with self._connect() as db:
            row = db.execute(
                "SELECT * FROM draft_records WHERE id=?", (draft_id,)).fetchone()
            return dict(row) if row else None

    def upsert_chunk(self, doc_id, text, content_hash, metadata) -> bool:
        """Insert or update a chunk. Returns True when a row was inserted or its
        content changed, False when the call was a no-op (same content_hash).

        Callers use the return value as a single signal for "did this write
        anything", which closes the crash-retry gap where a read-then-write pair
        could double-count or silently drop a re-processed envelope.
        """
        with self._connect(write=True) as db:
            cur = db.execute(
                f"SELECT rowid, content_hash, {_meta_extract('$.force_enrich')} AS fe "
                "FROM chunks WHERE doc_id=?", (doc_id,))
            row = cur.fetchone()
            if row and row["content_hash"] == content_hash:
                return False  # idempotent: unchanged
            self._uncover_changed_chunk(db, doc_id)
            if row:
                metadata = self._keep_force_enrich(metadata, row["fe"])
                db.execute(
                    "UPDATE chunks SET text=?,content_hash=?,metadata=?,embedded=0,"
                    "enriched=0,dup_of=NULL,"
                    "enrich_state=CASE WHEN enrich_state='duplicate' THEN '' "
                    "ELSE enrich_state END WHERE doc_id=?",
                    (text, content_hash, json.dumps(metadata), doc_id),
                )
                # Its text moved: chunks carried as duplicates of the old text
                # must be extracted on their own now.
                self._release_stale_dups(db, [doc_id])
            else:
                db.execute(
                    "INSERT INTO chunks(doc_id,text,content_hash,metadata) VALUES(?,?,?,?)",
                    (doc_id, text, content_hash, json.dumps(metadata)),
                )
            self._carry_duplicate(db, doc_id, text, content_hash, metadata)
            return True

    @staticmethod
    def _keep_force_enrich(metadata, old_flag):
        """The owner's re-include (reinclude_chunks) is a standing choice about
        this chunk, not about one version of its text: a rewrite with fresh
        metadata from the source keeps `force_enrich`. `old_flag` is the
        stored row's json_extract of it (1 for true)."""
        if old_flag in (1, True) and not (metadata or {}).get("force_enrich"):
            return {**(metadata or {}), "force_enrich": True}
        return metadata

    # A chunk shorter than this is never carried as a duplicate: short lines
    # (sign-offs, boilerplate, "Thanks!") repeat across unrelated sources.
    DUP_MIN_CHARS = 200

    @classmethod
    def _carry_duplicate(cls, db, doc_id, text, content_hash, metadata) -> bool:
        """Spec §4: if `doc_id`'s text equals an already-ENRICHED EVIDENCE
        chunk's, mark it a duplicate of that chunk (dup_of, enriched=1,
        enrich_state='duplicate') instead of letting it queue for extraction;
        its evidence is the canonical's (graph_write.extraction_sources), so it
        adds no support. The canonical is the oldest qualifying chunk (lowest
        rowid). Never carried: short text, a derived new chunk (a draft copy
        keeps its own class), or a canonical that is cold, derived, itself a
        duplicate or unenriched. Returns True when carried."""
        from mcpbrain import source_class as sc
        if not content_hash or len(text or "") < cls.DUP_MIN_CHARS:
            return False
        if not cls._carry_eligible(doc_id, metadata or {}):
            return False
        label_ids = cls._generated_label_ids(db)
        rules = sc.Rules(generated_label_ids=label_ids)
        if not sc.is_evidence(sc.classify(doc_id, metadata or {}, rules)):
            return False
        for r in db.execute(
                "SELECT doc_id, text, metadata, enriched_version FROM chunks "
                "WHERE content_hash=? AND doc_id != ? AND enriched=1 "
                "AND dup_of IS NULL "
                "AND COALESCE(enrich_state,'') NOT IN ('cold','duplicate') "
                "ORDER BY rowid LIMIT 20", (content_hash, doc_id)):
            if r["text"] != text:
                continue  # a hash that is not sha256(text) must not collide
            try:
                cmeta = json.loads(r["metadata"] or "{}") or {}
            except (ValueError, TypeError):
                cmeta = {}
            if not sc.is_evidence(sc.classify(r["doc_id"], cmeta, rules)):
                continue
            db.execute(
                "UPDATE chunks SET dup_of=?, enriched=1, enriched_version=?, "
                "enrich_state='duplicate' WHERE doc_id=?",
                (r["doc_id"], r["enriched_version"] or 0, doc_id))
            return True
        return False

    @staticmethod
    def _carry_eligible(doc_id: str, meta: dict) -> bool:
        """Only My Drive files and notes may be carried as duplicates.

        Gmail (bodies AND attachments) never: a fully-carried message never
        enters a unit, so its sender/recipient links and thread actions would
        be lost -- and signature blocks / Fwd: bodies duplicate constantly.
        Shared-drive chunks (any drive_id) never: the file's enrich payload
        publishes only when it covers every non-cold chunk
        (enrich_payload_covers_file), and a carried chunk is in no unit, so
        it would withhold the payload forever."""
        from mcpbrain.org_contracts import DRIVE_ID_META_KEY
        st = meta.get("source_type")
        if st == "gdrive":
            return not meta.get(DRIVE_ID_META_KEY)
        if st:
            return False
        return meta.get("source") == "note" or (doc_id or "").startswith("note-")

    @staticmethod
    def _generated_label_ids(db) -> frozenset:
        """source_class.cached_generated_label_ids, on an open connection."""
        from mcpbrain import source_class as sc
        try:
            row = db.execute("SELECT v FROM meta WHERE k=?",
                             (sc.GENERATED_LABEL_META_KEY,)).fetchone()
            ids = (json.loads(row[0]).get("ids") or []) if row and row[0] else []
            return frozenset(str(i) for i in ids if str(i).strip())
        except Exception:  # noqa: BLE001 — a cache miss never blocks a write
            return frozenset()

    @staticmethod
    def _release_stale_dups(db, canon_ids) -> int:
        """Chunks carried as duplicates of `canon_ids` whose canonical no longer
        exists or no longer holds the same text go back to extraction on their
        own (dup_of cleared, enriched=0, enrich_state ''). Returns the count."""
        ids = [d for d in dict.fromkeys(canon_ids or []) if d]
        released = 0
        for i in range(0, len(ids), 500):
            batch = ids[i:i + 500]
            qs = ",".join("?" * len(batch))
            released += db.execute(
                "UPDATE chunks SET dup_of=NULL, enriched=0, enriched_version=0, "
                "enrich_state=CASE WHEN enrich_state='duplicate' THEN '' "
                "ELSE enrich_state END "
                f"WHERE dup_of IN ({qs}) AND NOT EXISTS (SELECT 1 FROM chunks c "
                "WHERE c.doc_id = chunks.dup_of "
                "AND c.content_hash = chunks.content_hash)", batch).rowcount
        return released

    def canonical_for(self, doc_id: str) -> str:
        """The chunk whose extraction `doc_id` carries: its dup_of (followed
        once -- a canonical is never itself a duplicate), else `doc_id`."""
        with self._connect() as db:
            r = db.execute("SELECT dup_of FROM chunks WHERE doc_id=?",
                           (doc_id,)).fetchone()
        return (r["dup_of"] if r and r["dup_of"] else doc_id)

    @staticmethod
    def _uncover_changed_chunk(db, doc_id: str) -> None:
        """A Drive chunk's text is about to change (or a new chunk appear):
        take it out of its file's enrich payload `covers`, in the caller's
        transaction. The payload was not made from the new text, and a later
        mark_enriched that bypasses drain (drain._give_up_or_bump, the prepare
        noise filter, the trivial short-circuit) would otherwise make a stale
        payload look whole-file to enrich_payload_covers_file. A NULL (legacy
        whole-file) covers is materialised as the file's other non-cold
        chunks. One primary-key lookup; nothing for a non-Drive doc_id.

        Never raises: it runs inside upsert_chunk's transaction on the hottest
        write path, so a raise would roll back every content change to the
        file on every sync. A malformed covers (unparseable, or not a list)
        is rewritten as [] -- fail closed: the payload is withheld until
        drain re-covers the file."""
        import logging
        try:
            fid = _file_key_from_doc_id(doc_id)
            if fid is None:
                return
            prow = db.execute("SELECT covers FROM enrich_payloads WHERE file_id=?",
                              (fid,)).fetchone()
            if prow is None:
                return
            if prow[0] is None:
                covers = {x[0] for x in db.execute(
                    f"SELECT doc_id FROM chunks WHERE {_meta_extract('$.file_id')}=? "
                    "AND COALESCE(enrich_state,'')!='cold'", (fid,))}
            else:
                try:
                    parsed = json.loads(prow[0])
                except (TypeError, ValueError):
                    parsed = None
                if not isinstance(parsed, list) or not all(isinstance(x, str) for x in parsed):
                    logging.getLogger(__name__).debug(
                        "enrich payload %s: malformed covers %r reset to []", fid, prow[0])
                    db.execute("UPDATE enrich_payloads SET covers='[]' WHERE file_id=?", (fid,))
                    return
                covers = set(parsed)
                if doc_id not in covers:
                    return
            covers.discard(doc_id)
            db.execute("UPDATE enrich_payloads SET covers=? WHERE file_id=?",
                       (json.dumps(sorted(covers)), fid))
        except Exception as exc:  # noqa: BLE001 — payload bookkeeping must never fail the write
            logging.getLogger(__name__).debug(
                "enrich payload covers update skipped for %s: %s", doc_id, exc)

    def mark_all_unembedded(self) -> None:
        with self._connect(write=True) as db:
            db.execute("UPDATE chunks SET embedded=0")

    def delete_calendar_chunks_after(self, iso_cutoff: str) -> int:
        """Delete calendar chunks whose start time is after iso_cutoff.

        Called when the calendar sync's forward horizon shrinks: events that
        were previously synced past the new horizon stay in the store unless
        we evict them, and they'd keep occupying embedding/enrichment slots.

        ISO-8601 dates sort lexicographically, so a string comparison on the
        stored metadata.start field is correct. Removes the row from chunks
        plus its mirrors in vec_chunks and fts_chunks (keyed on rowid). Graph
        rows that reference entities/actions from those chunks are NOT
        touched — the graph is canonical knowledge, the chunk is just one of
        the evidence sources. Returns the number of chunk rows deleted.
        """
        with self._connect(write=True) as db:
            cur = db.execute(
                "SELECT rowid FROM chunks "
                f"WHERE {_meta_extract('$.source_type')}='calendar' "
                f"  AND {_meta_extract('$.start')} > ?",
                (iso_cutoff,),
            )
            rowids = [r["rowid"] for r in cur.fetchall()]
            if not rowids:
                return 0
            placeholders = ",".join("?" * len(rowids))
            db.execute(f"DELETE FROM vec_chunks WHERE rowid IN ({placeholders})", rowids)
            db.execute(f"DELETE FROM fts_chunks WHERE rowid IN ({placeholders})", rowids)
            db.execute(f"DELETE FROM chunks WHERE rowid IN ({placeholders})", rowids)
            Store._release_stale_dups(db, [r["dup_of"] for r in db.execute(
                "SELECT DISTINCT dup_of FROM chunks WHERE dup_of IS NOT NULL "
                "AND NOT EXISTS (SELECT 1 FROM chunks c WHERE c.doc_id=chunks.dup_of)")])
            return len(rowids)

    def doc_ids_for_drive(self, drive_id: str) -> list[str]:
        """Chunk doc_ids whose metadata drive_id matches (see DRIVE_ID_META_KEY)."""
        with self._connect() as db:
            return [r["doc_id"] for r in db.execute(
                f"SELECT doc_id FROM chunks WHERE {_meta_extract('$.drive_id')}=?",
                (drive_id,)).fetchall()]

    def drive_chunk_metadata(self, drive_id: str) -> list[tuple[str, dict]]:
        """(doc_id, metadata dict) for every chunk whose metadata drive_id
        matches. Unindexed scan: for rare maintenance only."""
        with self._connect() as db:
            rows = db.execute(
                f"SELECT doc_id, metadata FROM chunks WHERE {_meta_extract('$.drive_id')}=?",
                (drive_id,)).fetchall()
        out = []
        for r in rows:
            try:
                meta = json.loads(r["metadata"] or "{}")
            except (TypeError, ValueError):
                meta = {}
            out.append((r["doc_id"], meta if isinstance(meta, dict) else {}))
        return out

    def meta_with_prefix(self, prefix: str) -> dict[str, str]:
        """Every meta row whose key starts with `prefix` (exact, case-sensitive)."""
        with self._connect() as db:
            rows = db.execute("SELECT k, v FROM meta WHERE substr(k, 1, ?) = ?",
                              (len(prefix), prefix)).fetchall()
        return {r["k"]: r["v"] for r in rows}

    def doc_ids_for_file(self, file_id: str) -> list[str]:
        """Chunk doc_ids for one Drive file. Filters on metadata.file_id
        (index-backed by idx_chunks_fileid; see _chunks_for_file_query), NOT a
        doc_id LIKE/range match on `gdrive-<file_id>-*`: Drive file ids use the
        base64url alphabet (embed '-' and '_'), so one file's id can be a
        '-'-delimited prefix of another's (file_id 'abc' vs 'abc-1' — the
        second's doc_ids, gdrive-abc-1-0 etc., would fall inside any prefix or
        range bound built from the first's id) and LIKE's '_' wildcard can
        over-match a sibling file outright (file_id 'F_1' vs 'FA1'). An exact
        equality match on the metadata field has neither failure mode.
        """
        with self._connect() as db:
            return [r["doc_id"] for r in db.execute(
                f"SELECT doc_id FROM chunks WHERE {_meta_extract('$.file_id')}=?",
                (file_id,)).fetchall()]

    def doc_root_content_hashes(self, roots: list[str]) -> dict[str, frozenset[str]]:
        """Batched: for each of `roots` (a doc_id with its trailing '-<n>' chunk
        index already stripped, e.g. gdrive-<fid>-3 -> gdrive-<fid>), the set
        of DISTINCT content_hash values across every chunk under that root —
        i.e. the document's whole known content fingerprint, not just one
        chunk's hash or a flat chunk count.

        Used by hybrid_search's content-hash dedup to tell apart two crowding
        shapes that both surface as a shared content_hash on ONE chunk: a
        genuinely duplicate FILE (another document's WHOLE chunk-hash-set
        matches this one — safe to collapse to the best-ranked copy, however
        many chunks each copy has) versus two DIFFERENT documents that merely
        share one boilerplate/template chunk (e.g. a shared board-charter
        letterhead) while the rest of each document's own chunks diverge —
        collapsing THAT case on the one shared chunk drops a genuinely
        different document from the result set. A per-chunk sibling COUNT
        alone can't tell these apart (a genuine multi-chunk duplicate file has
        count > 1 on every one of its own chunks too); comparing the full hash
        SET can.

        ONE query per namespace for the whole batch (two total when both are
        present) — hybrid_search calls this once per search against its small
        candidate pool (the interactive recall hot path), not once per
        candidate. `_doc_root` runs over every doc_id namespace this codebase
        produces, not just Drive's, so roots are split in two:

        - `gdrive-<file_id>` roots resolve via an exact
          `json_extract(metadata,'$.file_id')=?` match (index-backed by
          idx_chunks_fileid — see doc_ids_for_file), not a doc_id prefix/range
          test. Drive file ids use the base64url alphabet (embed '-' and '_'),
          so one file's id can be a '-'-delimited prefix of another's — a range
          bound built from a root string can't tell "gdrive-abc"'s own chunks
          from "gdrive-abc-1"'s. An exact metadata match has no such ambiguity
          regardless of what characters a file id contains.
        - every other namespace (cal-, note-, gmail-, enriched-, ...) keeps the
          indexed doc_id RANGE condition (`doc_id >= root+'-' AND doc_id <
          root+'.'`, exploiting '.' sorting immediately after '-' in ASCII to
          bound a "starts with root-" prefix match) rather than `doc_id LIKE
          ... ESCAPE`: this codebase has a documented incident (0.7.105,
          chunks_for_file) where ESCAPE disables SQLite's LIKE-to-index
          optimisation and silently turns a doc_id prefix match into a full
          `SCAN chunks`; verified via EXPLAIN QUERY PLAN that the range form
          here plans as `SEARCH ... USING INDEX` instead, both standalone and
          inside this batched CTE-join. These namespaces' own ids (Calendar
          event ids, content hashes, Gmail message ids) don't contain '-', so
          the prefix-collision risk that forces Drive onto the metadata match
          doesn't apply to them.
        """
        roots = list(dict.fromkeys(roots))  # de-dup, order doesn't matter
        if not roots:
            return {}
        result: dict[str, set[str]] = {r: set() for r in roots}
        gdrive_roots = [r for r in roots if r.startswith("gdrive-")]
        other_roots = [r for r in roots if not r.startswith("gdrive-")]
        with self._connect() as db:
            if gdrive_roots:
                file_ids = [r[len("gdrive-"):] for r in gdrive_roots]
                qs = ",".join("?" * len(file_ids))
                rows = db.execute(
                    f"SELECT {_meta_extract('$.file_id')} AS fid, "
                    f"content_hash AS h FROM chunks "
                    f"WHERE {_meta_extract('$.file_id')} IN ({qs})",
                    file_ids).fetchall()
                for row in rows:
                    result[f"gdrive-{row['fid']}"].add(row["h"])
            if other_roots:
                values = ",".join("(?,?,?)" for _ in other_roots)
                params: list[str] = []
                for r in other_roots:
                    params.extend([r, f"{r}-", f"{r}."])
                rows = db.execute(
                    f"WITH roots(root, lo, hi) AS (VALUES {values}) "
                    "SELECT roots.root AS root, chunks.content_hash AS h FROM chunks "
                    "JOIN roots ON chunks.doc_id >= roots.lo AND chunks.doc_id < roots.hi",
                    params).fetchall()
                for row in rows:
                    result[row["root"]].add(row["h"])
        return {r: frozenset(s) for r, s in result.items()}

    def delete_chunks(self, doc_ids) -> int:
        """Delete the given chunk rows and their vec_chunks/fts_chunks mirrors
        (keyed on rowid, mirroring delete_calendar_chunks_after). Graph rows are
        NOT touched here — invalidation is a separate, bitemporal step. Returns
        the number of chunk rows deleted."""
        doc_ids = list(doc_ids)
        if not doc_ids:
            return 0
        with self._connect(write=True) as db:
            return self._delete_chunk_rows(db, doc_ids)

    def replace_note_pieces(self, base_id: str, pieces, *,
                            enrich_state: str = "cold") -> bool:
        """Make `pieces` the whole of note `base_id`, in ONE transaction.

        `pieces` is [(doc_id, text, metadata), ...]; each piece's content_hash
        is the hash of ITS OWN text, so a re-capture that only appends leaves
        the unchanged leading pieces byte-identical -- no rewrite, no
        re-embed. An unchanged piece whose metadata moved (chunk_total grows
        as the note does) gets its metadata updated in place, embedded state
        kept (fts_context_version reset only when the contextual prefix
        changed, as patch_chunk_metadata does). Every piece is set to
        `enrich_state`, and every other row of the note -- carrying
        metadata.note_id == base_id, or the bare base_id itself -- is
        deleted through the delete_chunks path. Atomic, so a failure cannot
        leave a piece hot or a surplus piece orphaned.

        Returns True when any row was inserted, rewritten or deleted.
        """
        from mcpbrain.chunking import content_hash
        from mcpbrain.embed import contextual_prefix
        pieces = list(pieces)
        keep = {d for d, _, _ in pieces}
        changed = False
        with self._connect(write=True) as db:
            for doc_id, text, meta in pieces:
                h = content_hash(text)
                row = db.execute(
                    "SELECT content_hash, metadata FROM chunks WHERE doc_id=?",
                    (doc_id,)).fetchone()
                if row is None:
                    db.execute(
                        "INSERT INTO chunks(doc_id,text,content_hash,metadata) "
                        "VALUES(?,?,?,?)", (doc_id, text, h, json.dumps(meta)))
                    changed = True
                elif row["content_hash"] != h:
                    db.execute(
                        "UPDATE chunks SET text=?,content_hash=?,metadata=?,"
                        "embedded=0,enriched=0,dup_of=NULL WHERE doc_id=?",
                        (text, h, json.dumps(meta), doc_id))
                    self._release_stale_dups(db, [doc_id])
                    changed = True
                else:
                    try:
                        old = json.loads(row["metadata"] or "{}")
                    except ValueError:
                        old = {}
                    if old != meta:
                        reset = contextual_prefix(old) != contextual_prefix(meta)
                        db.execute(
                            "UPDATE chunks SET metadata=?"
                            + (", fts_context_version=0" if reset else "")
                            + " WHERE doc_id=?", (json.dumps(meta), doc_id))
                db.execute("UPDATE chunks SET enrich_state=? WHERE doc_id=?",
                           (enrich_state, doc_id))
            prior = [r["doc_id"] for r in db.execute(
                # UNION, not OR: an OR across the note_id expression index
                # and the primary key plans as a full SCAN chunks.
                "SELECT doc_id FROM chunks WHERE "
                + _meta_extract("$.note_id") + " = ? "
                "UNION SELECT doc_id FROM chunks WHERE doc_id = ?",
                (base_id, base_id)).fetchall()]
            surplus = [d for d in prior if d not in keep]
            if surplus and self._delete_chunk_rows(db, surplus):
                changed = True
        return changed

    @staticmethod
    def _delete_chunk_rows(db, doc_ids: list[str]) -> int:
        """delete_chunks' body, on an open write connection (so a caller can
        make the delete part of a larger transaction). Every IN list is sliced
        at _IN_BATCH: a revoked shared drive can hold more chunks than SQLite
        allows bound variables in one statement."""
        doc_ids = list(dict.fromkeys(doc_ids))
        rowids: list = []
        for i in range(0, len(doc_ids), _IN_BATCH):
            part = doc_ids[i:i + _IN_BATCH]
            qs = ",".join("?" * len(part))
            rowids += [r["rowid"] for r in db.execute(
                f"SELECT rowid FROM chunks WHERE doc_id IN ({qs})", part).fetchall()]
        # Which Drive files these doc_ids belong to, resolved BEFORE the
        # delete so the payload cleanup below can ask whether anything is
        # left. Derived from the doc_id rather than metadata so an orphaned
        # payload (no chunk row at all) is still cleaned up.
        file_ids = {k for k in (_file_key_from_doc_id(d) for d in doc_ids) if k}
        for i in range(0, len(rowids), _IN_BATCH):
            part = rowids[i:i + _IN_BATCH]
            ph = ",".join("?" * len(part))
            db.execute(f"DELETE FROM vec_chunks WHERE rowid IN ({ph})", part)
            db.execute(f"DELETE FROM fts_chunks WHERE rowid IN ({ph})", part)
            db.execute(f"DELETE FROM chunks WHERE rowid IN ({ph})", part)
        if rowids:
            Store._release_stale_dups(db, doc_ids)
        # A file's cached payload dies only with its LAST chunk. Before the
        # re-key each chunk had its own row and the file's others survived a
        # partial delete, so dropping it on any delete would be a behaviour
        # change — and ingest_cache's shrink path deletes stale chunks of a
        # file that is still very much present.
        for fid in file_ids:
            remaining = db.execute(
                f"SELECT 1 FROM chunks WHERE {_meta_extract('$.file_id')}=? "
                "LIMIT 1", (fid,)).fetchone()
            if remaining is None:
                db.execute("DELETE FROM enrich_payloads WHERE file_id=?", (fid,))
        return len(rowids)

    def sweep_changed_chunks(self, owner: str, remap: dict[str, str], *,
                             invalidate_reason: str = "reflow_source_changed",
                             map_reason: str = "source_changed") -> dict:
        """Remove chunks a CHANGED source no longer yields (the reflow's
        ordinary-path stale-tail sweep, dry run #2 D3), in ONE transaction:

          * origin='local' relations sourced from them are invalidated (as the
            ordinary change path does -- the old text no longer evidences
            them), and keep their source_doc_id: invalidated rows are history;
          * live relations of any OTHER origin (e.g. 'org' on the curator's
            own store) are remapped instead, contrib_doc_id keeping the
            pre-remap id (first remap wins) -- exactly as apply_reflow;
          * every OTHER reference (_REFLOW_REF_COLUMNS minus entity_relations)
            is repointed to remap[old] by simultaneous substitution through a
            temp table, and chunk_quality is merged -- exactly as apply_reflow
            does -- so no observation / action / feedback row is left naming
            a deleted id;
          * the chunk rows (+ vec/fts mirrors) are deleted;
          * the mapping is appended to reflow_map with reason `map_reason`.

        `remap` maps each swept id to a chunk that exists (the lineage's first
        new chunk); a target with no chunk row raises ValueError and nothing
        is written. Returns {deleted, invalidated, remapped}."""
        remap = {o: n for o, n in (remap or {}).items() if o != n}
        if not remap:
            return {"deleted": 0, "invalidated": 0, "remapped": 0}
        olds = list(remap)
        now = datetime.now(timezone.utc).isoformat()
        with self._connect(write=True) as db:
            targets = sorted(set(remap.values()))
            tp = ",".join("?" * len(targets))
            present = {r[0] for r in db.execute(
                f"SELECT doc_id FROM chunks WHERE doc_id IN ({tp})", targets)}
            if set(targets) - present:
                raise ValueError(f"sweep_changed_chunks {owner}: remap target(s) with no "
                                 f"chunk {sorted(set(targets) - present)[:5]}")
            tables = {r[0] for r in db.execute(
                "SELECT name FROM sqlite_master WHERE type='table'")}
            op = ",".join("?" * len(olds))
            invalidated = db.execute(
                f"UPDATE entity_relations SET invalidated_at=?, superseded_reason=? "
                f"WHERE source_doc_id IN ({op}) AND invalidated_at IS NULL "
                f"AND COALESCE(origin,'local')='local'",
                (now, invalidate_reason, *olds)).rowcount
            db.execute("CREATE TEMP TABLE IF NOT EXISTS reflow_tmp("
                       "old TEXT PRIMARY KEY, new TEXT NOT NULL)")
            db.execute("DELETE FROM reflow_tmp")
            db.executemany("INSERT INTO reflow_tmp(old, new) VALUES(?,?)", list(remap.items()))
            remapped = 0
            if "entity_relations" in tables:
                # Non-local relations (origin='org' on a curator's own store,
                # which keeps the local source_doc_id) are not the ordinary
                # path's to invalidate: remap them, exactly as apply_reflow
                # does, keeping the pre-remap id for org contribution (first
                # remap wins). Local rows were invalidated above and keep
                # their source_doc_id as history.
                live_nonlocal = ("WHERE source_doc_id IN (SELECT old FROM reflow_tmp) "
                                 "AND invalidated_at IS NULL "
                                 "AND COALESCE(origin,'local')!='local'")
                db.execute("UPDATE entity_relations SET contrib_doc_id=source_doc_id "
                           f"{live_nonlocal} AND contrib_doc_id IS NULL")
                remapped += db.execute(
                    "UPDATE entity_relations SET source_doc_id=(SELECT new FROM reflow_tmp "
                    f"WHERE old=entity_relations.source_doc_id) {live_nonlocal}").rowcount
            for table, col in _REFLOW_REF_COLUMNS:
                if table == "entity_relations" or table not in tables:
                    continue
                remapped += db.execute(
                    f"UPDATE {table} SET {col}=(SELECT new FROM reflow_tmp "
                    f"WHERE old={table}.{col}) WHERE {col} IN (SELECT old FROM reflow_tmp)"
                ).rowcount
            if "chunk_quality" in tables:
                # Merge the targets' own rows in as well: a target is a live
                # chunk whose quality must be summed with, never replaced by,
                # the swept id's.
                self._merge_chunk_quality(db, {**{t: t for t in targets}, **remap})
            deleted = self._delete_chunk_rows(db, olds)
            db.executemany(
                "INSERT INTO reflow_map(owner, old_doc_id, new_doc_id, reason, at) "
                "VALUES(?,?,?,?,?)", [(owner, o, n, map_reason, now) for o, n in remap.items()])
            db.execute("DROP TABLE reflow_tmp")
        return {"deleted": deleted, "invalidated": invalidated, "remapped": remapped}

    def invalidate_local_relations_for_docs(self, doc_ids, *,
                                            reason: str = "drive_revoked",
                                            at: str | None = None) -> int:
        """A source is gone: take its support away from origin='local'
        relations, and invalidate (bitemporally: invalidated_at +
        superseded_reason) only those left with no evidence. origin='org' rows
        are never touched -- layer 1 is curator-owned (spec A3). Returns the
        number of relations invalidated.

        Call BEFORE the chunk rows are deleted: each doc's logical source key
        (Gmail thread, Drive file, note, event, anarlog session) is read from
        its chunk, and counts as gone only when no chunk OUTSIDE `doc_ids`
        still carries it (a Gmail message deleted from a live thread leaves
        the thread's support in place). Then, in one transaction:

          * relation_sources rows of the gone keys are deleted;
          * every live local relation those rows supported, or whose
            source_doc_id is one of `doc_ids`, has its strength recounted
            (graph_write.relation_strength); one with evidence left stays
            live at the new count, one without is invalidated. A legacy row
            (no source rows at all) has no evidence left and is invalidated,
            as before source counting existed.

        IN lists are sliced at _IN_BATCH; the source_key lookup is served by
        idx_relation_sources_key, each per-key liveness probe by the matching
        chunk-metadata expression index."""
        from mcpbrain.graph_write import relation_strength
        doc_ids = list(dict.fromkeys(d for d in (doc_ids or ()) if d))
        if not doc_ids:
            return 0
        at = at or datetime.now(timezone.utc).isoformat()
        n = 0
        with self._connect(write=True) as db:
            gone = self._gone_source_keys(db, doc_ids)
            cand: set = set()
            for i in range(0, len(doc_ids), _IN_BATCH):
                part = doc_ids[i:i + _IN_BATCH]
                qs = ",".join("?" * len(part))
                cand |= {r[0] for r in db.execute(
                    f"SELECT id FROM entity_relations WHERE source_doc_id IN ({qs}) "
                    "AND invalidated_at IS NULL AND COALESCE(origin,'local')='local'",
                    part)}
            gone = sorted(gone)
            for i in range(0, len(gone), _IN_BATCH):
                part = gone[i:i + _IN_BATCH]
                qs = ",".join("?" * len(part))
                hit = [r[0] for r in db.execute(
                    "SELECT rs.relation_id FROM relation_sources rs "
                    "JOIN entity_relations er ON er.id = rs.relation_id "
                    f"WHERE rs.source_key IN ({qs}) "
                    "AND COALESCE(er.origin,'local')='local'", part)]
                if not hit:
                    continue
                db.execute(  # admin-delete-ok: a removed source's support row
                    f"DELETE FROM relation_sources WHERE source_key IN ({qs}) "
                    "AND relation_id IN (SELECT id FROM entity_relations "
                    "WHERE COALESCE(origin,'local')='local')", part)
                cand |= set(hit)
            dead: list = []
            for rid in sorted(cand):
                row = db.execute("SELECT strength, invalidated_at FROM entity_relations "
                                 "WHERE id=?", (rid,)).fetchone()
                if row is None or row["invalidated_at"] is not None:
                    continue
                left = relation_strength(db, rid)
                if left > 0:
                    if row["strength"] != left:
                        db.execute("UPDATE entity_relations SET strength=? WHERE id=?",
                                   (left, rid))
                else:
                    dead.append(rid)
            for i in range(0, len(dead), _IN_BATCH):
                part = dead[i:i + _IN_BATCH]
                qs = ",".join("?" * len(part))
                n += db.execute(
                    f"UPDATE entity_relations SET invalidated_at=?, superseded_reason=? "
                    f"WHERE id IN ({qs}) AND invalidated_at IS NULL",
                    (at, reason, *part)).rowcount
        return n

    # The metadata field that names a chunk's logical source (source_class.
    # source_key's namespaces), with the key built from its value.
    _SOURCE_KEY_FIELDS = (
        ("file_id", "$.file_id", lambda v: v),
        ("session_id", "$.session_id", lambda v: f"anarlog-{v}"),
        ("event_id", "$.event_id", lambda v: f"cal-{v}"),
        ("note_id", "$.note_id", lambda v: v),
    )

    @classmethod
    def _gone_source_keys(cls, db, doc_ids) -> set:
        """Logical source keys of `doc_ids` that no chunk outside `doc_ids`
        still carries. A content duplicate is skipped (its key is its
        canonical's, which is not being removed by removing the duplicate);
        a doc with no chunk row left names itself."""
        removed = set(doc_ids)
        probes: dict = {}                     # key -> (expression, value)
        seen: set = set()
        for i in range(0, len(doc_ids), _IN_BATCH):
            part = doc_ids[i:i + _IN_BATCH]
            qs = ",".join("?" * len(part))
            for r in db.execute(f"SELECT doc_id, metadata, dup_of FROM chunks "
                                f"WHERE doc_id IN ({qs})", part):
                seen.add(r["doc_id"])
                if r["dup_of"]:
                    continue
                try:
                    meta = json.loads(r["metadata"] or "{}") or {}
                except (TypeError, ValueError):
                    meta = {}
                if meta.get("source_type") == "gmail":
                    field = "thread_id" if meta.get("thread_id") else "message_id"
                    if meta.get(field):
                        probes[str(meta[field])] = (f"$.{field}", str(meta[field]))
                        continue
                for fld, expr, mk in cls._SOURCE_KEY_FIELDS:
                    if meta.get(fld):
                        probes[mk(str(meta[fld]))] = (expr, str(meta[fld]))
                        break
                else:
                    if meta.get("thread_id"):
                        probes[str(meta["thread_id"])] = ("$.thread_id",
                                                          str(meta["thread_id"]))
                    else:
                        probes[r["doc_id"]] = None
        gone = {d for d in doc_ids if d not in seen}
        for key, probe in probes.items():
            if probe is None:
                gone.add(key)
                continue
            expr, val = probe
            live = any(r[0] not in removed for r in db.execute(
                f"SELECT doc_id FROM chunks WHERE {_meta_extract(expr)} = ?", (val,)))
            if not live:
                gone.add(key)
        return gone

    def invalidate_sources_for_docs(self, doc_ids, *, source_ids=(),
                                    file_ids=(),
                                    reason: str = "source_gone",
                                    match_thread: bool = True) -> dict:
        """A source (Drive file / Gmail message) is gone: take its derived
        state with it. Reversible: nothing is deleted.

        * local relations sourced from `doc_ids` are invalidated;
        * OPEN actions with source='email' whose source_doc_id (or, with
          match_thread, thread_id) is one of the source ids become
          status='auto_archived', resolved_by=<reason>, resolved_at set --
          user/manual/clickup actions are never touched;
        * email_entities rows for the source ids are marked derived=1
          (derived_reason=<reason>, so a re-link can revive them) and the
          entity's email_count is decremented once per link that was counting
          (floored at 0). A second call finds nothing counting: idempotent.

        `file_ids` additionally match STALE chunk ids `gdrive-<fid>-<digits>`
        that reflow replaced but never remapped in email_entities/actions;
        candidates are found with one prefix scan and confirmed by an exact
        owner parse, since base64url ids contain '-' and a bare prefix
        over-matches.
        All IN lists are sliced. TWO transactions, in order: the relation step
        (invalidate_local_relations_for_docs) commits first, then the
        action/link step runs in its own. A failure in the second leaves the
        relations already handled -- harmless, as both steps are idempotent
        and the caller retries the whole removal.
        """
        doc_ids = list(doc_ids or ())
        source_ids = [x for x in dict.fromkeys(source_ids or ()) if x]
        fid_set = {f for f in (file_ids or ()) if f}
        out = {"relations": 0, "actions": 0, "links": 0}
        out["relations"] = self.invalidate_local_relations_for_docs(
            doc_ids, reason=reason)
        if not source_ids and not fid_set:
            return out
        at = datetime.now(timezone.utc).isoformat()
        with self._connect(write=True) as db:
            ids = set(source_ids)
            if fid_set:
                ids |= self._stale_drive_ids(db, fid_set)
            got = self._invalidate_sources_in(db, list(ids), reason=reason, at=at,
                                              match_thread=match_thread)
        out["actions"], out["links"] = got["actions"], got["links"]
        return out

    @staticmethod
    def _invalidate_sources_in(db, ids, *, reason: str, at: str,
                               match_thread: bool = True, actions: bool = True,
                               links: bool = True) -> dict:
        """invalidate_sources_for_docs' action/link step on an OPEN write
        connection, so a caller (the ingestion clean-up) can run it inside its
        own transaction and log the old values there. `ids` are the exact
        source ids; IN lists are sliced. actions=False / links=False skip that
        half."""
        out = {"actions": 0, "links": 0}
        ids = [x for x in dict.fromkeys(ids or ()) if x]
        for i in range(0, len(ids), _IN_BATCH):
            part = ids[i:i + _IN_BATCH]
            qs = ",".join("?" * len(part))
            if actions:
                cond = f"source_doc_id IN ({qs})"
                params: list = list(part)
                if match_thread:
                    cond = f"({cond} OR thread_id IN ({qs}))"
                    params += part
                out["actions"] += db.execute(
                    "UPDATE actions SET status='auto_archived', resolved_by=?, "
                    "resolved_at=? WHERE status='open' "
                    f"AND COALESCE(source,'email')='email' AND {cond}",
                    (reason, at, *params)).rowcount
            if links:
                live = db.execute(
                    f"SELECT message_id, entity_id FROM email_entities "
                    f"WHERE message_id IN ({qs}) AND COALESCE(derived,0)=0",
                    part).fetchall()
                for r in live:
                    # Every new primary link counted a mention with its
                    # email_count (graph_write.apply); take both back, or each
                    # remove/revive cycle inflates mentions (M7).
                    db.execute(
                        "UPDATE entities SET email_count = "
                        "MAX(0, COALESCE(email_count,0) - 1), "
                        "mentions = MAX(0, COALESCE(mentions,0) - 1) "
                        "WHERE id=?",
                        (r["entity_id"],))
                db.execute(
                    f"UPDATE email_entities SET derived=1, derived_reason=? "
                    f"WHERE message_id IN ({qs}) AND COALESCE(derived,0)=0",
                    (reason, *part))
                out["links"] += len(live)
        return out

    # One range probe per (table, column): prefix 'gdrive-<fid>-' up to the same
    # prefix with its last char bumped ('-' -> '.'), served by an index.
    _STALE_PROBES = (
        "SELECT message_id FROM email_entities WHERE message_id >= ? AND message_id < ?",
        "SELECT thread_id FROM actions WHERE thread_id >= ? AND thread_id < ?",
        "SELECT source_doc_id FROM actions WHERE source_doc_id >= ? AND source_doc_id < ?",
    )

    @staticmethod
    def _stale_drive_ids(db, file_ids) -> set:
        """Ids `gdrive-<fid>-<digits>` held by email_entities / actions whose
        <fid> is in file_ids (chunk ids that no longer exist). Per file, an
        index range scan on the exact prefix, then a strict owner parse
        (base64url ids contain '-', so a bare prefix over-matches)."""
        found: set = set()
        for fid in file_ids:
            lo = f"gdrive-{fid}-"
            hi = lo[:-1] + "."
            pat = re.compile(r"^gdrive-" + re.escape(fid) + r"-\d+$")
            for q in Store._STALE_PROBES:
                for r in db.execute(q, (lo, hi)):
                    if pat.match(r[0] or ""):
                        found.add(r[0])
        return found

    def chunk_count(self) -> int:
        """Total number of rows in the chunks table."""
        with self._connect() as db:
            return db.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]

    def enriched_count(self) -> int:
        """Number of chunks that have been enriched into the graph."""
        with self._connect() as db:
            return db.execute("SELECT COUNT(*) FROM chunks WHERE enriched=1").fetchone()[0]

    def digest_chunks(self, *, limit: int | None = None) -> list[dict]:
        """Every enriched-digest chunk as {doc_id, text, metadata}.

        The `enriched-<thread_id>` synthesised docs build_semantic_doc writes.
        Selected on the doc_id prefix rather than on metadata.source_type,
        because correcting that very field is one of the things the caller does
        (C4) — filtering on it would skip the mislabelled rows.
        """
        sql = ("SELECT doc_id, text, metadata FROM chunks "
               "WHERE doc_id LIKE 'enriched-%' ORDER BY rowid")
        params: tuple = ()
        if limit is not None:
            sql += " LIMIT ?"
            params = (int(limit),)
        with self._connect() as db:
            return [{"doc_id": r["doc_id"], "text": r["text"],
                     "metadata": json.loads(r["metadata"])}
                    for r in db.execute(sql, params)]

    def count_pending_embeddings(self) -> int:
        """Chunks written but not yet embedded — i.e. not yet searchable by
        meaning. Served by the partial index idx_chunks_unembedded, which holds
        only the embedded=0 rows (this docstring used to claim `embedded` was
        indexed; until that index existed, it was a full SCAN)."""
        with self._connect() as db:
            return db.execute(
                "SELECT COUNT(*) FROM chunks WHERE embedded=0").fetchone()[0]

    def count_chunks_longer_than(self, n: int) -> int:
        """Chunks whose stored text exceeds n characters — i.e. whose tail the
        512-token embedder silently discards (B3). 15,576 in the live store."""
        with self._connect() as db:
            return db.execute("SELECT COUNT(*) FROM chunks WHERE length(text) > ?",
                              (int(n),)).fetchone()[0]

    # --- one-shot oversize heal (2026-10-26) ------------------------------------

    # Gmail bodies rendered before strip_html dropped <style> content carry CSS
    # rules as text. A brace plus one CSS-only token: a brace alone (a template,
    # code) or a font name alone (prose about fonts) is not enough.
    _CSS_TEXT_SQL = ("text LIKE '%{%' AND (text LIKE '%font-family%' OR "
                     "text LIKE '%@media%' OR text LIKE '%mso-%' OR "
                     "text LIKE '%-webkit-%')")

    def oversize_heal_targets(self, *, window: int = 2000) -> dict[str, list[str]]:
        """Owners whose reflow now re-renders differently because of the
        oversize/CSS fixes: Gmail messages (message_id) with a CSS-polluted
        chunk, and Drive files (file_id) with a table chunk longer than
        `window`. Prose over the window is not a target -- its re-render is
        the same text; the windowed re-embed alone fixes it.

        Excludes owners already queued for any reflow source and owners with
        any chunk stamped `reflow_skipped` (whatever the reason): those were
        already given up on, and re-queueing them would only repeat that.
        One full scan per call -- the daemon calls it once per install."""
        st, sub = _meta_extract("$.source_type"), _meta_extract("$.content_subtype")
        skipped = _meta_extract("$.reflow_skipped")
        rules = (("reflow:gmail", "gmail", "$.message_id", self._CSS_TEXT_SQL, ()),
                 ("reflow:drive", "gdrive", "$.file_id",
                  f"COALESCE({sub},'')='table' AND length(text) > ?", (int(window),)))
        out: dict[str, list[str]] = {}
        with self._connect() as db:
            for src, stype, fld, where, args in rules:
                owner = _meta_extract(fld)
                out[src] = [str(r["o"]) for r in db.execute(
                    f"SELECT DISTINCT {owner} AS o FROM chunks "
                    f"WHERE {st}=? AND {where} "
                    f"AND {owner} IS NOT NULL AND {owner} != '' "
                    f"AND {owner} NOT IN (SELECT ref_id FROM sync_queue "
                    f"WHERE source LIKE 'reflow:%') "
                    f"AND {owner} NOT IN (SELECT {owner} FROM chunks WHERE {st}=? "
                    f"AND {skipped} IS NOT NULL AND {owner} IS NOT NULL) "
                    f"ORDER BY o",
                    (stype, *args, stype))]
        return out

    def _over_window_rows(self, db, window: int, *, use_prefix: bool, where: str = "1"):
        """Yield (rowid, embedded) for every chunk (matching `where`) whose
        embed passage is longer than `window`, by embed.passage_over_window --
        the embedder's own measure. `length(text) + length(metadata) + 64`
        bounds the prefixed passage from above (the prefix is built from
        metadata values plus under 64 chars of fixed labels), so it serves as
        the SQL prefilter; the exact check runs in Python. A row whose metadata
        is not valid JSON is skipped (it cannot be embedded with a prefix)."""
        from mcpbrain.embed import passage_over_window
        bound = "length(text) + length(metadata) + 64" if use_prefix else "length(text)"
        for r in db.execute(
                f"SELECT rowid, embedded, text, metadata FROM chunks "
                f"WHERE ({where}) AND {bound} > ?", (int(window),)):
            md: dict = {}
            if use_prefix:
                try:
                    md = json.loads(r["metadata"] or "{}")
                except ValueError:
                    continue
            if passage_over_window(r["text"] or "", md, use_prefix=use_prefix,
                                   window=window):
                yield r["rowid"], r["embedded"]

    def count_passages_over_window(self, window: int, *, use_prefix: bool = True
                                   ) -> tuple[int, int]:
        """(total, unembedded): chunks whose embed passage is over `window`,
        and how many of those still wait for their (windowed) embedding.
        Read-only, one prefiltered scan; the measure doctor reports so it
        matches what the heal and the embedder act on."""
        total = pending = 0
        with self._connect() as db:
            for _rowid, embedded in self._over_window_rows(db, window,
                                                           use_prefix=use_prefix):
                total += 1
                pending += 0 if embedded else 1
        return total, pending

    def reset_embedding_for_oversize(self, window: int, *, use_prefix: bool = True,
                                     bulk_section=None, batch: int = 2000) -> int:
        """Set embedded=0 on every embedded chunk whose embed passage is longer
        than `window`, so index_pending re-embeds it across windows instead of
        keeping the vector of its truncated head. Returns the number reset.

        The passage is `contextual_prefix(metadata) + text` when use_prefix
        (what index_pending embeds), else the raw text -- measured by
        embed.passage_over_window via _over_window_rows.

        Writes in transactions of at most `batch` rows, each inside
        `bulk_section()` when given (the daemon's chunk-mutating section)."""
        with self._connect() as db:
            hits = [(rowid,) for rowid, _ in self._over_window_rows(
                db, window, use_prefix=use_prefix, where="embedded=1")]
        section = bulk_section or nullcontext
        for i in range(0, len(hits), max(1, int(batch))):
            with section():
                with self._connect(write=True) as db:
                    db.executemany("UPDATE chunks SET embedded=0 WHERE rowid=?",
                                   hits[i:i + batch])
        return len(hits)

    def unembedded_chunks(self, limit: int | None = None) -> list[dict]:
        """Chunks awaiting embedding. `limit` bounds one cycle's slice of work.

        Unbounded by default for callers that genuinely want the whole set
        (tests, one-shot CLI). The daemon always passes a limit: embedding the
        entire backlog in one call is what used to hold the cycle for hours.
        """
        sql = "SELECT rowid,doc_id,text,metadata FROM chunks WHERE embedded=0"
        params: tuple = ()
        if limit is not None:
            sql += " LIMIT ?"
            params = (int(limit),)
        with self._connect() as db:
            cur = db.execute(sql, params)
            return [
                {
                    "rowid": r["rowid"],
                    "doc_id": r["doc_id"],
                    "text": r["text"],
                    "metadata": json.loads(r["metadata"]),
                }
                for r in cur.fetchall()
            ]

    def unenriched_chunks(self, limit: int | None = None) -> list[dict]:
        """Chunks not yet enriched into the graph (enriched=0).

        Independent of embedding: gated on enriched=0 only, not embedded.
        Shape mirrors unembedded_chunks(): {rowid, doc_id, text, metadata}.

        limit caps how many rows are returned (LIMIT in SQL, so the backlog is
        not fully loaded then sliced). limit=None returns every unenriched
        chunk — the no-arg behaviour existing callers/tests rely on.
        """
        # Exclude 'cold' chunks: they are deliberately gated by the salience gate
        # and must not re-queue for extraction while in cold state.
        #
        # Exclude 'enriched-%' doc_ids: these are the synthesised semantic
        # digest chunks (build_semantic_doc's enriched-<thread_id> docs) —
        # enrichment OUTPUT, never input. A digest can end up at enriched=0
        # (graph_write.apply stamps it via mark_enriched at whatever
        # ENRICH_LOGIC_VERSION was current, so a version bump's reflow resets it
        # exactly like any other chunk) with no real content to extract FROM.
        # Without this guard, group_unenriched_threads groups the digest into
        # the SAME batch as its own thread's real messages (both carry
        # thread_id via _group_key), and reassemble_thread's own enriched-
        # special-case then splits it back out as a fake extra "message" —
        # subject and date intact, body = the thread's own prior synthesized
        # summary — handed to the model alongside the genuine messages. That
        # risks re-deriving near-duplicate entities that the anti-
        # hallucination grounding check cannot catch, because the digest text
        # trivially contains the exact names being "grounded" against itself.
        # Found and fixed 2026-08-03, before it had fired in production.
        #
        # Prioritised chunks (prioritise_chunks) come first, then newest-first.
        sql = ("SELECT rowid,doc_id,text,metadata FROM chunks "
               "WHERE enriched=0 AND COALESCE(enrich_state,'') != 'cold' "
               "AND doc_id NOT LIKE 'enriched-%' "
               "ORDER BY priority DESC, rowid DESC")
        params: tuple = ()
        if limit is not None:
            sql += " LIMIT ?"
            params = (limit,)
        with self._connect() as db:
            cur = db.execute(sql, params)
            return [
                {
                    "rowid": r["rowid"],
                    "doc_id": r["doc_id"],
                    "text": r["text"],
                    "metadata": json.loads(r["metadata"]),
                }
                for r in cur.fetchall()
            ]

    def iter_hot_chunks(self) -> Iterator[dict]:
        """Yield every non-cold chunk as {doc_id, text, metadata}, streaming.

        Feeds bin/resalience.py, which re-applies prepare.should_enrich to the
        existing corpus after a gate change. Streams rather than materialising:
        the live store is ~109k non-cold rows and this is an attended,
        daemon-stopped sweep, not a cycle pass.
        """
        with self._connect() as db:
            for r in db.execute(
                "SELECT doc_id, text, metadata FROM chunks "
                "WHERE COALESCE(enrich_state,'') != 'cold' ORDER BY rowid"
            ):
                try:
                    meta = json.loads(r["metadata"])
                except (TypeError, ValueError):
                    meta = {}
                yield {"doc_id": r["doc_id"], "text": r["text"], "metadata": meta}

    def mark_enriched(self, doc_ids: list[str], version: int = ENRICH_LOGIC_VERSION) -> None:
        """Set enriched=1 and stamp the enrichment-logic version for the given
        doc_ids, so reflow_outdated_chunks can later re-extract anything enriched
        under older logic."""
        if not doc_ids:
            return
        with self._connect(write=True) as db:
            db.executemany(
                "UPDATE chunks SET enriched=1, enriched_version=? WHERE doc_id=?",
                [(version, d) for d in doc_ids],
            )

    def reflow_outdated_chunks(self, version: int, cap: int) -> int:
        """Reset enriched=0 on up to `cap` enriched chunks whose enriched_version
        is below `version` (oldest first), so they re-flow through enrichment under
        current logic. The embedding is kept (only enriched is cleared). Returns the
        number reset. This is the change-driven re-extraction lever: bump
        ENRICH_LOGIC_VERSION when enrichment improves and the corpus re-extracts
        itself gradually as the daemon calls this each cycle.

        Never resets a digest chunk (doc_id 'enriched-<thread_id>'): it is
        enrichment OUTPUT, not input, and there is nothing to re-flow FOR it —
        graph_write.apply regenerates and re-stamps this exact chunk the moment
        its thread is genuinely re-extracted. Reset one anyway (a 2026-08-03
        version bump did, since this exclusion did not exist yet) and it
        manufactures pure backlog noise; worse, unenriched_chunks' own doc_id
        guard is the only thing standing between that and the digest's prior
        summary being handed back to the model as a fake extra thread message.
        This is the write-side half of that fix.
        """
        with self._connect(write=True) as db:
            rows = db.execute(
                "SELECT doc_id FROM chunks "
                "WHERE enriched=1 AND COALESCE(enriched_version,0) < ? "
                "AND doc_id NOT LIKE 'enriched-%' AND dup_of IS NULL "
                "ORDER BY rowid LIMIT ?",
                (version, cap),
            ).fetchall()
            ids = [r["doc_id"] for r in rows]
            if ids:
                qs = ",".join("?" for _ in ids)
                db.execute(f"UPDATE chunks SET enriched=0 WHERE doc_id IN ({qs})", ids)
        return len(ids)

    # Maps each source_type to the metadata field that identifies its owning
    # file/thread/event -- kept as one named, documented constant (rather
    # than an inline literal) so the mapping's correctness is visible in one
    # place. It relies on these writers stamping exactly these field names:
    # sync/drive.py's base_meta (file_id), sync/gmail.py's normalise_gmail /
    # attachments.normalise_attachment (thread_id), and
    # sync/calendar.py's normalise_calendar (event_id). A future rename in
    # any of those three writers must be mirrored here, or that source type's
    # stale chunks silently stop being selected (a false-green "0 stale"
    # result, not an error) -- there's no automated guard against that drift.
    _STALE_ID_FIELDS = (
        ("gdrive", "file_id"), ("gmail", "thread_id"), ("calendar", "event_id"),
    )

    def reflow_owns(self, source_type: str, owner_id: str) -> bool:
        """True when the reflow selector covers this repair owner
        (_STALE_ID_FIELDS: a Drive file, a Gmail THREAD, a calendar event):
        any lineage of its chunks is a reflow.needs_reflow candidate.
        bin/repair.py reingest-stale skips these -- its plain re-ingest would
        reset their enrichment and strand their provenance."""
        from mcpbrain import reflow
        field = dict(self._STALE_ID_FIELDS).get(source_type)
        if not field:
            return False
        with self._connect() as db:
            rows = [dict(r) for r in db.execute(
                "SELECT doc_id, metadata FROM chunks WHERE "
                f"{_meta_extract('$.source_type')}=? AND {_meta_extract('$.' + field)}=?",
                (source_type, owner_id))]
        for r in rows:
            r["metadata"] = json.loads(r["metadata"] or "{}")
        return bool(rows) and reflow.needs_reflow(rows)

    def stale_chunker_ids(self, *, table_version: int, other_version: int,
                          limit: int | None) -> list[dict]:
        """File/thread/event ids with at least one chunk written by an older
        chunker, across every source type.

        The level-triggered selector for bin/repair.py's re-ingest phase: no
        queue, no cursor, no new state. Re-running walks forward because a
        repaired item stops matching, and an interrupted run simply resumes.

        Distinct ids (not doc_ids) because re-ingest operates per FILE/
        THREAD/EVENT: one fetch replaces all of that owner's chunks at once.

        Originally Drive-only, on the theory that "Gmail chunks pick up the
        new version as they naturally re-sync." That assumption doesn't
        hold: a Gmail message is immutable once received, and ordinary sync
        only ever touches NEW/changed messages via the history API -- an
        already-ingested message's chunker_version never gets revisited by
        anything else, so it stays stale forever without this. Generalized
        to cover gmail/calendar too.

        TWO version floors, not one, because chunker_version is a single
        monotonic number shared by every content type, but a version bump
        can affect only ONE of them (CHUNKER_VERSION 2->3 changed table
        rendering only -- chunk_text, which renders every non-table chunk,
        is untouched). A single `< CHUNKER_VERSION` floor would mark every
        historical chunk of every type stale, including prose already at
        version 2 that would just re-chunk byte-identically -- a full-mailbox
        re-fetch for zero benefit. `table_version` (pass chunking.CHUNKER_VERSION)
        applies only to content_subtype=='table' chunks; `other_version`
        (pass chunking.PRIOR_CHUNKER_VERSION) applies to everything else, so
        only content that ACTUALLY needs re-chunking under the current
        release is swept.

        Ordered by MIN(rowid) within each source type, Drive rows first then
        Gmail then Calendar (not interleaved) -- see bin/repair.py's
        phase_reingest_stale for why sequential-by-source is enough.
        """
        out: list[dict] = []
        with self._connect() as db:
            for source_type, id_field in self._STALE_ID_FIELDS:
                # Routed through _meta_extract (sqlite-optimisation's single
                # source of truth for chunks.metadata reads) rather than the
                # hand-written json_extract this generalization originally
                # landed with -- id_field is always file_id/thread_id/
                # event_id, each of which already has an expression index
                # keyed on _meta_extract's exact fragment.
                id_expr = _meta_extract(f"$.{id_field}")
                # Alias is owner_id, NOT `oid`: SQLite treats `oid` as a
                # built-in alias for the table's rowid, so `GROUP BY oid`
                # resolved to rowid and grouped NOTHING — every chunk became its
                # own entry. bin/repair.py fetches one item per entry, so a
                # 16-chunk spreadsheet was re-fetched 16 times (49,526 entries
                # for 3,019 real Drive files on the live store), and doctor's
                # "Items awaiting re-chunk" was inflated by the same factor.
                rows = db.execute(
                    f"SELECT {id_expr} AS owner_id, "
                    f"MIN(rowid) AS r FROM chunks "
                    f"WHERE {_meta_extract('$.source_type')}=? "
                    f"  AND {id_expr} IS NOT NULL "
                    f"  AND ("
                    f"    (COALESCE({_meta_extract('$.content_subtype')},'')='table' "
                    f"     AND COALESCE({_meta_extract('$.chunker_version')},0) < ?)"
                    f"    OR "
                    f"    (COALESCE({_meta_extract('$.content_subtype')},'')<>'table' "
                    f"     AND COALESCE({_meta_extract('$.chunker_version')},0) < ?)"
                    f"  ) "
                    f"GROUP BY owner_id ORDER BY r LIMIT ?",
                    # limit=None means unbounded (bin/repair.py's `--limit 0`).
                    # SQLite reads a negative LIMIT as "no limit", which keeps
                    # one code path instead of branching the SQL.
                    (source_type, table_version, other_version,
                     -1 if limit is None else limit - len(out)),
                ).fetchall()
                out.extend({"source_type": source_type, "id": r["owner_id"]}
                           for r in rows)
                if limit is not None and len(out) >= limit:
                    break
        return out

    @staticmethod
    def _content_free(text: str | None) -> bool:
        """True if `text` carries no alphanumeric character at all.

        68,193 of 196,396 live chunks (34.7%) match: ~2,000-char strings of
        '| | | | |' from empty spreadsheet cells, all embedded, none matchable.

        Registered as a per-row SQLite scalar function rather than expressed as
        a GLOB expression: SQLite's GLOB character classes ([A-Za-z0-9]) are
        ASCII-only, so `text NOT GLOB '*[A-Za-z0-9]*'` would wrongly flag a
        genuine non-ASCII chunk (e.g. Chinese-language board minutes) as
        content-free. Python's str.isalnum() is Unicode-aware, so real
        non-ASCII content is correctly spared while pipe/dash separator rows
        are still caught. Full scan by necessity — this runs from an attended
        CLI, not the recall path.
        """
        return not any(c.isalnum() for c in (text or ""))

    def count_content_free(self) -> int:
        """How many chunks carry no alphanumeric character."""
        with self._connect() as db:
            db.create_function("is_content_free", 1, self._content_free)
            return db.execute(
                "SELECT COUNT(*) FROM chunks WHERE is_content_free(text)"
            ).fetchone()[0]

    def content_free_doc_ids(self, limit: int) -> list[str]:
        """Up to `limit` content-free chunk doc_ids, oldest first."""
        with self._connect() as db:
            db.create_function("is_content_free", 1, self._content_free)
            return [r["doc_id"] for r in db.execute(
                "SELECT doc_id FROM chunks WHERE is_content_free(text) "
                "ORDER BY rowid LIMIT ?", (int(limit),))]

    def cited_doc_ids(self, doc_ids) -> list[str]:
        """Which of `doc_ids` the graph cites as provenance.

        `delete_chunks` deliberately does not touch graph rows — invalidation is
        a separate, bitemporal step — so deleting a cited chunk leaves dangling
        provenance that nothing cleans up. This is the check that makes a purge
        safe rather than merely measured-safe.
        """
        doc_ids = list(doc_ids)
        if not doc_ids:
            return []
        marks = ",".join("?" * len(doc_ids))
        with self._connect() as db:
            rows = db.execute(
                f"SELECT source_doc_id AS d FROM entity_relations "
                f"WHERE source_doc_id IN ({marks}) "
                f"UNION SELECT message_id AS d FROM email_entities "
                f"WHERE message_id IN ({marks})",
                (*doc_ids, *doc_ids)).fetchall()
        return [r["d"] for r in rows]

    def purge_doc_ids(self, doc_ids) -> int:
        """Delete these chunks and their vec/FTS mirrors. Returns rows deleted.

        Raises ValueError, deleting NOTHING, if the graph cites any of them —
        all-or-nothing so the caller can always say what happened. Delegates the
        actual delete to `delete_chunks`, which already clears both mirrors.
        """
        doc_ids = list(doc_ids)
        if not doc_ids:
            return 0
        cited = self.cited_doc_ids(doc_ids)
        if cited:
            raise ValueError(
                f"refusing to purge {len(cited)} doc_id(s) cited as graph "
                f"provenance (e.g. {cited[:3]}); graph invalidation is a "
                "separate bitemporal step and this would orphan those rows")
        return self.delete_chunks(doc_ids)

    def embed_doc(self, doc_id: str, embedder, *, home=None) -> bool:
        """Embed a single chunk by doc_id, in place.

        Fetches the chunk's rowid + text, runs embedder.embed_passages on the
        contextual-prefixed passage (matching the index_pending batch path) —
        gated on contextual_retrieval_enabled(home), same as index_pending, so
        this path never contextualises a passage the batch path wouldn't have —
        and writes the vector via write_embedding (which also flips embedded=1
        and refreshes the FTS row). Returns True on success, False if no such
        chunk.

        Used by graph_write.apply when an embedder is injected so the enriched
        semantic doc is searchable immediately; when no embedder is passed the
        chunk is left at embedded=0 for the daemon's index_pending pass.
        """
        from mcpbrain import config
        from mcpbrain.embed import embed_chunk_passages
        _home = str(home) if home is not None else str(config.app_dir())
        with self._connect() as db:
            r = db.execute(
                "SELECT rowid, text, metadata FROM chunks WHERE doc_id=?",
                (doc_id,)).fetchone()
        if not r:
            return False
        metadata = json.loads(r["metadata"])
        use_prefix = config.contextual_retrieval_enabled(_home)
        vector = embed_chunk_passages(
            embedder, [(r["text"], metadata)], use_prefix=use_prefix)[0]
        self.write_embedding(r["rowid"], vector, home=_home)
        return True

    @staticmethod
    def _fts_text(text: str, metadata: dict, *, home=None) -> tuple[str, bool]:
        """FTS-indexed text: contextual prefix + body when contextual_retrieval is
        on (mirrors the embed side), else raw body. Keeps the chunks.text column
        and all returned text RAW — only the FTS mirror is contextualised.

        Returns (fts_text, applied) — `applied` is True only when the contextual
        prefix was actually prepended, so callers can stamp fts_context_version
        accordingly (a raw write under an OFF flag must stay at version 0, not
        the current version, so it gets picked back up by reindex_fts_batch if
        the flag later flips ON). `home` is read explicitly (default app_dir())
        so this reads the same config as the embed side.
        """
        from mcpbrain import config
        from mcpbrain.embed import contextual_prefix
        _home = str(home) if home is not None else str(config.app_dir())
        if config.contextual_retrieval_enabled(_home):
            return contextual_prefix(metadata) + text, True
        return text, False

    def reindex_fts_batch(self, cap: int = 5000) -> int:
        """Rebuild the FTS row (contextual text) for up to `cap` embedded chunks
        whose fts_context_version is behind. Resumable; no re-embed. Returns count.

        Selection is unchanged (fts_context_version < FTS_CONTEXT_VERSION); since
        writers now stamp the version at write time based on whether the prefix
        was actually applied (see _fts_text), this only ever migrates genuinely
        stale rows — either legacy pre-Phase-C rows, or rows written while the
        contextual_retrieval flag was OFF that need to catch up once it flips ON.

        The predicate reads the BARE column, not COALESCE(fts_context_version,0):
        SQLite cannot serve a COALESCE-wrapped predicate from the plain-column
        partial index idx_chunks_fts_stale, so the COALESCE form scanned the
        whole chunks table while paying that index's write cost anyway. The
        COALESCE was dead defensively: the column is INTEGER DEFAULT 0 (SQLite
        returns that default for rows predating the ALTER), all three writers
        stamp an int, and the live store has zero NULLs in 170,695 rows.
        """
        # bulk=True: up to `cap` (default 5000) rows re-derived through one
        # connection -- exactly the throughput-sensitive case the larger
        # cache_size/mmap_size are for (PR #25 finding 5).
        with self._connect(write=True, bulk=True) as db:
            rows = db.execute(
                "SELECT rowid, text, metadata FROM chunks "
                "WHERE embedded=1 AND fts_context_version < ? LIMIT ?",
                (self.FTS_CONTEXT_VERSION, cap)).fetchall()
            n = 0
            for r in rows:
                fts_text, applied = self._fts_text(r["text"], json.loads(r["metadata"]))
                db.execute("DELETE FROM fts_chunks WHERE rowid=?", (r["rowid"],))
                db.execute("INSERT INTO fts_chunks(rowid, text) VALUES(?,?)",
                           (r["rowid"], fts_text))
                db.execute("UPDATE chunks SET fts_context_version=? WHERE rowid=?",
                           (self.FTS_CONTEXT_VERSION if applied else 0, r["rowid"]))
                n += 1
            return n

    def write_embedding(self, rowid: int, vector: list[float] | None, *, home=None) -> None:
        """Write a chunk's embedding and FTS row, stamping embedded=1.

        vector=None means "skip the dense vector, still write FTS and stamp
        embedded=1". Every RETRIEVAL path that gates on
        embedded=1 handles that state correctly on its own: a join against
        vec_chunks simply returns nothing for that rowid, which is exactly
        the desired "never surfaces via dense search" behavior, while
        unembedded_chunks() correctly stops re-fetching it.

        The one place it is NOT self-evidently safe is a consistency CHECK
        rather than a query: `backup._verify_artifact` samples the
        lowest-rowid embedded=1 chunks and RAISES if one does not resolve to
        a vector. It therefore excludes content_subtype='table' from its
        sample -- keep that exclusion in step with this method (and with
        bin/cleanup_tabular_vectors.py, which produces the same state on
        already-embedded rows), or a periodic backup and bin/repair.py's
        pre-apply safety snapshot both start failing on a deliberately
        vector-less chunk.
        """
        with self._connect(write=True) as db:
            db.execute("DELETE FROM vec_chunks WHERE rowid=?", (rowid,))
            if vector is not None:
                db.execute("INSERT INTO vec_chunks(rowid, embedding) VALUES(?,?)",
                           (rowid, sqlite_vec.serialize_float32(vector)))
            row = db.execute("SELECT text, metadata FROM chunks WHERE rowid=?",
                             (rowid,)).fetchone()
            fts_text, applied = self._fts_text(row["text"], json.loads(row["metadata"]),
                                                home=home)
            db.execute("DELETE FROM fts_chunks WHERE rowid=?", (rowid,))
            db.execute("INSERT INTO fts_chunks(rowid, text) VALUES(?,?)", (rowid, fts_text))
            db.execute(
                "UPDATE chunks SET embedded=1, fts_context_version=? WHERE rowid=?",
                (self.FTS_CONTEXT_VERSION if applied else 0, rowid))

    @staticmethod
    def _write_cached_chunk_row(db, doc_id, text, content_hash, metadata, vector,
                                *, enriched=False, enriched_version=0, home=None,
                                uncover=False) -> None:
        """Write one cached chunk row + its vec_chunks/fts_chunks mirrors against
        an already-open connection `db`. Shared by import_cached_chunk (one row,
        one transaction) and import_cached_chunks (many rows, one transaction).

        `uncover=True` (the cache-import paths) applies upsert_chunk's H4 rule:
        a new row, or one whose content_hash changes, leaves its file's enrich
        payload `covers`. apply_reflow passes False because it rewrites covers
        itself from the plan in the same transaction.

        `vector=None` writes the row embedded=0 with no vec_chunks row, so
        index_pending embeds it locally (a cache import whose passage is over
        the window: the peer's vector may be of its truncated head)."""
        embedded = 0 if vector is None else 1
        row = db.execute(
            f"SELECT rowid, content_hash, {_meta_extract('$.force_enrich')} AS fe "
            "FROM chunks WHERE doc_id=?", (doc_id,)).fetchone()
        if uncover and (row is None or row["content_hash"] != content_hash):
            Store._uncover_changed_chunk(db, doc_id)
        if row and uncover:
            # Same identity (a cache import of this chunk): keep a re-include.
            # apply_reflow (uncover=False) reuses positional ids for DIFFERENT
            # text, so it carries the flag along its remap itself.
            metadata = Store._keep_force_enrich(metadata, row["fe"])
        if row:
            rowid = row["rowid"]
            db.execute(
                "UPDATE chunks SET text=?,content_hash=?,metadata=?,embedded=?,"
                "enriched=?,enriched_version=? WHERE rowid=?",
                (text, content_hash, json.dumps(metadata), embedded,
                 1 if enriched else 0, enriched_version, rowid))
            if row["content_hash"] != content_hash:
                # New text at this id: it is no longer a copy of anything, and
                # copies of its old text must extract on their own.
                db.execute("UPDATE chunks SET dup_of=NULL WHERE rowid=?", (rowid,))
                Store._release_stale_dups(db, [doc_id])
        else:
            cur = db.execute(
                "INSERT INTO chunks(doc_id,text,content_hash,metadata,embedded,"
                "enriched,enriched_version) VALUES(?,?,?,?,?,?,?)",
                (doc_id, text, content_hash, json.dumps(metadata), embedded,
                 1 if enriched else 0, enriched_version))
            rowid = cur.lastrowid
        db.execute("DELETE FROM vec_chunks WHERE rowid=?", (rowid,))
        if vector is not None:
            db.execute("INSERT INTO vec_chunks(rowid, embedding) VALUES(?,?)",
                       (rowid, sqlite_vec.serialize_float32(list(vector))))
        db.execute("DELETE FROM fts_chunks WHERE rowid=?", (rowid,))
        fts_text, applied = Store._fts_text(text, metadata, home=home)
        db.execute("INSERT INTO fts_chunks(rowid, text) VALUES(?,?)", (rowid, fts_text))
        db.execute(
            "UPDATE chunks SET fts_context_version=? WHERE rowid=?",
            (Store.FTS_CONTEXT_VERSION if applied else 0, rowid))

    def import_cached_chunk(self, doc_id, text, content_hash, metadata, vector,
                            *, enriched=False, enriched_version=0, home=None) -> bool:
        """Insert (or replace) a chunk plus its vector + FTS mirror from a cache
        artifact, in one transaction. Sets embedded=1 (the vector is supplied, so
        the chunk must NOT re-queue for embedding) and marks enriched when the
        artifact's enrich block cleared the version gates (see ingest_cache).

        The vector is the publisher's already-contextual-prefixed passage vector;
        it is stored verbatim so a cache hit is bit-identical to local embedding.
        fts_chunks mirrors write_embedding: contextual-prefixed when
        contextual_retrieval is enabled, else raw text. Returns True.
        """
        with self._connect(write=True) as db:
            self._write_cached_chunk_row(db, doc_id, text, content_hash, metadata, vector,
                                         enriched=enriched, enriched_version=enriched_version,
                                         home=home, uncover=True)
            return True

    def import_cached_chunks(self, rows: list[dict], *, home=None) -> bool:
        """Atomically import many cached chunks in ONE transaction.

        Each row is {doc_id, text, content_hash, metadata, vector, enriched,
        enriched_version}. All rows are written under a single `_connect()`
        (commit-or-rollback as one unit) so a whole artifact either lands
        completely or not at all — unlike calling import_cached_chunk per row,
        where each call is its own transaction and a failure partway through
        an artifact would leave a partial, silently-truncated import committed.
        Returns True (raises if the connection/write itself fails; callers that
        need fail-safe behaviour catch around this call — see ingest_cache).
        """
        with self._connect(write=True) as db:
            for row in rows:
                self._write_cached_chunk_row(
                    db, row["doc_id"], row["text"], row["content_hash"],
                    row["metadata"], row["vector"],
                    enriched=row.get("enriched", False),
                    enriched_version=row.get("enriched_version", 0),
                    home=home, uncover=True)
        return True

    def embedding_for_doc(self, doc_id: str) -> list[float] | None:
        """Return the stored embedding for doc_id as a list[float], or None.

        sqlite-vec vec0 stores the raw little-endian float32 payload; selecting
        the column returns those bytes, which we unpack. Used by the ingest cache
        to serialise a locally-embedded chunk into a shareable artifact.
        """
        import struct
        with self._connect() as db:
            r = db.execute("SELECT rowid FROM chunks WHERE doc_id=?", (doc_id,)).fetchone()
            if not r:
                return None
            v = db.execute("SELECT embedding FROM vec_chunks WHERE rowid=?",
                           (r["rowid"],)).fetchone()
            if not v or v["embedding"] is None:
                return None
            raw = v["embedding"]
            if isinstance(raw, str):        # some builds surface JSON text
                return [float(x) for x in json.loads(raw)]
            n = len(raw) // 4
            return list(struct.unpack(f"<{n}f", raw))

    @staticmethod
    def _chunks_for_file_query() -> str:
        """SQL for chunks_for_file. Filters on metadata.file_id (index-backed by
        idx_chunks_fileid), NOT `doc_id LIKE 'gdrive-<id>-%' ESCAPE` — specifying
        ESCAPE disables SQLite's LIKE-to-index optimisation, forcing a full
        `SCAN chunks` (~432ms on the live store). A Drive chunk's doc_id is
        gdrive-<file_id>-<i> AND it carries metadata.file_id=<file_id> (the same
        identity doc_ids_for_messages resolves on), so the two are equivalent
        (verified 0 mismatches over 200 live file_ids, incl. base64url ids with
        LIKE metacharacters)."""
        return ("SELECT doc_id,text,content_hash,metadata FROM chunks "
                f"WHERE {_meta_extract('$.file_id')}=?")

    def chunks_for_file(self, file_id: str) -> list[dict]:
        """All gdrive-<file_id>-<i> chunks as {doc_id,text,content_hash,metadata,idx},
        ordered by chunk index. Used to build a cache artifact from local state.

        Ordering authority is the Python `.sort(key=idx)` below (chunk_index is
        the logical order; rowid is mere insertion order, which can diverge on
        re-import) — so the SQL query intentionally does not ORDER BY anything."""
        out = []
        with self._connect() as db:
            for r in db.execute(self._chunks_for_file_query(), (file_id,)):
                meta = json.loads(r["metadata"])
                out.append({"doc_id": r["doc_id"], "text": r["text"],
                            "content_hash": r["content_hash"], "metadata": meta,
                            "idx": int(meta.get("chunk_index", 0))})
        out.sort(key=lambda c: c["idx"])
        return out

    def file_fully_enriched(self, file_id: str) -> bool:
        """True when the file has chunks and every one that is not cold
        (salience-gated, never extracted by design) is enriched=1. The gate on
        attaching a file's enrich payload to its cache artifact: after a reflow
        (or any re-chunk) the file-keyed payload describes the OLD text, and an
        importer marks every row enriched from it."""
        with self._connect() as db:
            r = db.execute(
                "SELECT count(*) n, COALESCE(sum(CASE WHEN enriched=1 "
                "OR COALESCE(enrich_state,'')='cold' THEN 0 ELSE 1 END),0) u "
                f"FROM chunks WHERE {_meta_extract('$.file_id')}=?", (file_id,)).fetchone()
        return bool(r["n"]) and not r["u"]

    def vec_knn(self, query_vec: list[float], k: int) -> list[tuple[str, float]]:
        with self._connect() as db:
            cur = db.execute(
                "SELECT c.doc_id, v.distance FROM vec_chunks v "
                "JOIN chunks c ON c.rowid=v.rowid "
                "WHERE v.embedding MATCH ? AND k=? ORDER BY v.distance",
                (sqlite_vec.serialize_float32(query_vec), k))
            return [(r["doc_id"], r["distance"]) for r in cur.fetchall()]

    def fts_search(self, query: str, k: int) -> list[tuple[str, float]]:
        match = _fts_match_query(query)
        if not match:
            return []
        sql = ("SELECT c.doc_id, bm25(fts_chunks) AS rank FROM fts_chunks "
               "JOIN chunks c ON c.rowid=fts_chunks.rowid "
               "WHERE fts_chunks MATCH ? ORDER BY rank LIMIT ?")
        with self._connect() as db:
            rows = db.execute(sql, (match, k)).fetchall()
            if not rows:
                # A real natural-language query rarely contains every one of its
                # own words verbatim in the matching document (paraphrase,
                # different word forms, form-field text) — strict AND then finds
                # nothing for most realistic queries (14/20 on the live gold
                # set) even though a real match exists. Falling back to OR
                # (any token) recovers those, but ONLY when AND found zero rows
                # — a query AND already satisfies is never displaced by looser
                # OR-only noise. Verified on the gold set: AND-first/OR-fallback
                # recall@10 0.700->0.850, MRR 0.506->0.592, with zero cases
                # worse than plain AND (plain OR-always regressed 2 cases from
                # RR 1.0 to ~0.1-0.3 — generic terms like "financial statement"
                # flooded in unrelated documents that outscored the true match).
                or_match = _fts_match_query(query, require_all=False)
                if or_match and or_match != match:
                    rows = db.execute(sql, (or_match, k)).fetchall()
            return [(r["doc_id"], r["rank"]) for r in rows]

    def get_chunk(self, doc_id: str) -> dict | None:
        with self._connect() as db:
            try:
                r = db.execute(
                    "SELECT doc_id,text,metadata,memory_tier,content_hash "
                    "FROM chunks WHERE doc_id=?",
                    (doc_id,)).fetchone()
                tier = (r["memory_tier"] or "") if r else ""
            except sqlite3.OperationalError:
                # Pre-Phase-2 schema (memory_tier not yet ALTERed in): a read-only
                # handle can hit this in the window between a wheel upgrade and the
                # daemon's init() migration. Degrade gracefully — recall must not crash.
                r = db.execute(
                    "SELECT doc_id,text,metadata,content_hash FROM chunks WHERE doc_id=?",
                    (doc_id,)).fetchone()
                tier = ""
            if not r:
                return None
            return {
                "doc_id": r["doc_id"],
                "text": r["text"],
                "metadata": json.loads(r["metadata"]),
                "memory_tier": tier,
                "content_hash": r["content_hash"],
            }

    def get_chunks(self, doc_ids: list[str], *,
                   with_salience: bool = False) -> dict[str, dict]:
        """Batched get_chunk (+ optional get_chunk_salience): one connection,
        not one per id.

        hybrid_search's candidate pool (FUSION_DEPTH per ranker, up to ~200
        ids; it was limit*6 under collapse_documents when this was written)
        used to call get_chunk/get_chunk_salience once
        PER CANDIDATE -- each a separate SQLite connection open. Measured:
        6.6k -> 18.2k connection opens over 50 queries, pushing p95 latency
        1.5-1.65x over the collapse-off figure (gate <= 1.25x). This fetches
        the whole pool in one connection, batched at 500 ids per IN (...) to
        stay well under SQLite's host-parameter ceiling (999 on older builds).

        Each returned dict is EXACTLY what get_chunk(doc_id) returns for that
        id today -- same keys, same metadata decoding, same memory_tier
        fallback -- plus "salience" (get_chunk_salience's value, 0.0 when
        NULL/unscored) when with_salience is True. A doc_id with no row is
        simply absent from the result, matching get_chunk's None contract.

        Replicates both single-id methods' sqlite3.OperationalError fallback
        for a pre-Phase-2 schema (memory_tier / salience columns not yet
        ALTERed in) -- a read-only handle can see that schema in the window
        between a wheel upgrade and the daemon's init() migration, and recall
        must not crash: missing memory_tier reads as '', missing salience
        reads as 0.0, for every id in that batch.
        """
        ids = list(dict.fromkeys(doc_ids))  # de-dup, preserve caller order
        if not ids:
            return {}
        out: dict[str, dict] = {}
        with self._connect() as db:
            for batch in _chunked(ids, 500):
                qs = ",".join("?" * len(batch))
                try:
                    rows = db.execute(
                        "SELECT doc_id,text,metadata,memory_tier,content_hash "
                        f"FROM chunks WHERE doc_id IN ({qs})",
                        batch).fetchall()
                    has_tier = True
                except sqlite3.OperationalError:
                    # Pre-Phase-2 schema: no memory_tier column yet.
                    rows = db.execute(
                        "SELECT doc_id,text,metadata,content_hash "
                        f"FROM chunks WHERE doc_id IN ({qs})",
                        batch).fetchall()
                    has_tier = False
                for r in rows:
                    out[r["doc_id"]] = {
                        "doc_id": r["doc_id"],
                        "text": r["text"],
                        "metadata": json.loads(r["metadata"]),
                        "memory_tier": (r["memory_tier"] or "") if has_tier else "",
                        "content_hash": r["content_hash"],
                    }
            if with_salience:
                for batch in _chunked(ids, 500):
                    qs = ",".join("?" * len(batch))
                    try:
                        srows = db.execute(
                            "SELECT doc_id, salience FROM chunks "
                            f"WHERE doc_id IN ({qs})", batch).fetchall()
                    except sqlite3.OperationalError:
                        # Pre-Phase-2 schema: no salience column yet.
                        continue
                    for r in srows:
                        if r["doc_id"] in out:
                            out[r["doc_id"]]["salience"] = float(r["salience"] or 0.0)
                for c in out.values():
                    c.setdefault("salience", 0.0)
        return out

    # Bi-temporal back-pointers: which row superseded this one. Both columns
    # declare REFERENCES ... ON DELETE SET NULL, so the FK keeps them honest
    # going forward -- but that only reaches an EXISTING store through a
    # rebuild, and only bites while foreign_keys=ON is set on the connection.
    # Stores that predate either can still carry residue, and foreign_key_check
    # only sees the columns that actually declare a REFERENCES clause.
    _INVALIDATOR_COLUMNS = (
        ("entity_relations", "invalidated_by_relation_id", "entity_relations", "id"),
        ("entity_observations", "invalidated_by_observation_id",
         "entity_observations", "id"),
    )

    def _dangling_invalidator_counts(self, db) -> dict[str, int]:
        """Per-column count of back-pointers whose target row is gone."""
        out: dict[str, int] = {}
        for child, col, parent, pcol in self._INVALIDATOR_COLUMNS:
            try:
                n = db.execute(
                    f'SELECT count(*) FROM "{child}" c WHERE c."{col}" IS NOT NULL '
                    f'AND NOT EXISTS (SELECT 1 FROM "{parent}" p '
                    f'WHERE p."{pcol}" = c."{col}")'
                ).fetchone()[0]
            except sqlite3.OperationalError:
                continue  # column or table absent on an older schema
            if n:
                out[f"{child}.{col}"] = n
        return out

    def count_dangling_invalidators(self) -> int:
        """Total dangling bi-temporal back-pointers across both columns."""
        with self._connect() as db:
            return sum(self._dangling_invalidator_counts(db).values())

    def nullify_dangling_invalidators(self) -> dict[str, int]:
        """Null every back-pointer whose target is gone. Returns counts by column.

        NULL is already the normal value for the overwhelming majority of these
        rows -- a pointer to a row that no longer exists carries no provenance,
        it just fails foreign_key_check. Idempotent: a second run returns {}.

        Uses NOT EXISTS rather than `NOT IN (SELECT id ...)`, which returns NULL
        (never true) for every row if the subquery yields a single NULL.
        """
        done: dict[str, int] = {}
        with self._connect(write=True) as db:
            for child, col, parent, pcol in self._INVALIDATOR_COLUMNS:
                try:
                    db.execute(
                        f'UPDATE "{child}" SET "{col}"=NULL WHERE "{col}" IS NOT NULL '
                        f'AND NOT EXISTS (SELECT 1 FROM "{parent}" p '
                        f'WHERE p."{pcol}" = "{child}"."{col}")')
                except sqlite3.OperationalError:
                    continue
                n = db.execute("SELECT changes()").fetchone()[0]
                if n:
                    done[f"{child}.{col}"] = n
        return done

    def patch_chunk_metadata(self, doc_id: str, **patch) -> bool:
        """Merge kwargs into a chunk's metadata JSON without touching content_hash or embedded.

        Returns True if the chunk exists and was updated, False if not found.
        Leaves content_hash and embedded untouched so an expiry flag (or any other
        metadata patch) does not re-queue embedding.

        If the patch changes what embed.contextual_prefix() would render for this
        chunk (e.g. Drive stamping folder_path onto a content-unchanged file),
        fts_context_version is reset to 0 so reindex_fts_batch's `< FTS_CONTEXT_VERSION`
        selector picks the row back up -- otherwise an already-migrated row's FTS
        mirror silently drifts from its own metadata forever, since nothing else
        ever re-derives it. Patches that don't touch a prefix-relevant field (e.g.
        bin/repair.py's chunker_version/reextract_*) leave the version untouched,
        so they don't needlessly re-queue every repaired chunk for re-indexing.
        """
        from mcpbrain.embed import contextual_prefix
        with self._connect(write=True) as db:
            row = db.execute(
                "SELECT metadata FROM chunks WHERE doc_id=?", (doc_id,)).fetchone()
            if row is None:
                return False
            meta = json.loads(row["metadata"])
            prefix_before = contextual_prefix(meta)
            meta.update(patch)
            prefix_after = contextual_prefix(meta)
            if prefix_after != prefix_before:
                db.execute(
                    "UPDATE chunks SET metadata=?, fts_context_version=0 WHERE doc_id=?",
                    (json.dumps(meta), doc_id))
            else:
                db.execute(
                    "UPDATE chunks SET metadata=? WHERE doc_id=?",
                    (json.dumps(meta), doc_id))
            return True

    def patch_note_metadata(self, note_id: str, **patch) -> bool:
        """Merge kwargs into EVERY chunk of a note. Returns True if any updated.

        A chunked note has no row at its bare `note-<hash>` id — only
        `note-<hash>-<i>` siblings — so memory_distil's patch_chunk_metadata call
        would silently no-op and the note would be re-offered for distillation
        forever. Falls back to the bare doc_id for legacy single-chunk notes.

        These fields (expired / distilled_at / distilled_verdict) are not read by
        _fts_text or contextual_prefix, so this does not add to the known
        patch_chunk_metadata FTS-mirror drift.
        """
        ids = self._note_sibling_ids(note_id)
        if not ids:
            ids = [note_id]          # legacy single-chunk note
        # A LIST, then any() — never `any(generator)`, which short-circuits on
        # the first True and leaves siblings 1..N unpatched. That silently made
        # this "patch every sibling" function patch exactly one row: an expired
        # note's remaining chunks still grouped into a live note_chunks() row, so
        # the note stayed live and was re-offered for distillation anyway.
        patched = [self.patch_chunk_metadata(d, **patch) for d in ids]
        return any(patched)

    def _note_sibling_ids(self, note_id: str) -> list[str]:
        """doc_ids of every chunk carrying metadata.note_id == note_id, ordered.

        Empty for a legacy single-chunk note (no note_id stamped) and for an id
        that matches nothing at all — the callers distinguish the two.
        """
        if not note_id:
            return []
        with self._connect() as db:
            return [r["doc_id"] for r in db.execute(
                "SELECT doc_id FROM chunks WHERE "
                + _meta_extract("$.note_id") + " = ? ORDER BY doc_id",
                (note_id,)).fetchall()]

    def get_note_metadata(self, note_id: str) -> dict | None:
        """The metadata dict of a note's FIRST chunk, or None if it has no rows.

        Same sibling lookup as patch_note_metadata, with the same fallback to the
        bare doc_id for a legacy single-chunk note. A chunked note has no row at
        its bare `note-<hash>` id, so `get_chunk(note_id)` returns None for it and
        any caller that gates on that silently skips the whole note (memory_distil
        did, on both the expire and promote branches). Always a dict when a row
        exists — the JSON is parsed here, so callers need no defensive re-parse.
        """
        ids = self._note_sibling_ids(note_id) or ([note_id] if note_id else [])
        for doc_id in ids:
            row = self.get_chunk(doc_id)
            if row is None:
                continue
            meta = row.get("metadata") or {}
            if isinstance(meta, str):
                try:
                    meta = json.loads(meta)
                except Exception:  # noqa: BLE001 — malformed metadata is not fatal
                    meta = {}
            return meta if isinstance(meta, dict) else {}
        return None

    def read_doc(self, doc_id: str) -> dict | None:
        """get_chunk(doc_id), transparently reassembling a chunked note.

        get_chunk covers every ordinary case -- email/drive/calendar chunks,
        and a legacy or single-piece note. A multi-chunk note (drain.py's
        ingest branch, Task 7) has no row at its own bare `note-<hash>` id --
        only `note-<hash>-<i>` siblings -- so a plain get_chunk(doc_id) call
        silently returned None for every long captured note once chunking
        landed. note_chunks() (and memory_index, which renders exactly this
        base id under "read it with brain_read") still hand out that base id
        as the note's identity, so both brain_read dispatch sites
        (mcp_server.py, daemon.py) call this instead of get_chunk directly --
        one place, so the two can't drift.
        """
        row = self.get_chunk(doc_id)
        if row is not None:
            return row
        # An id a reflow deleted (the document now has fewer chunks) resolves to
        # the chunk that holds its text now, rather than silently missing.
        target = self.resolve_reflowed_ids([doc_id])
        if target:
            row = self.get_chunk(target[0])
            if row is not None:
                return row
        if not doc_id.startswith("note-"):
            return None
        rows = [r for r in (self.get_chunk(d) for d in self._note_sibling_ids(doc_id))
                if r is not None]
        if not rows:
            return None
        rows.sort(key=lambda r: (r.get("metadata") or {}).get("chunk_index", 0))
        first = rows[0]
        return {"doc_id": doc_id, "text": "\n\n".join(r["text"] for r in rows),
                "metadata": first["metadata"], "memory_tier": first["memory_tier"],
                "content_hash": first["content_hash"]}

    def note_chunks(self, *, observation_type: str | None = None,
                    include_expired: bool = False, exclude_distilled: bool = False,
                    keep_review_days: int = 30, limit: int = 500) -> list[dict]:
        """Return capture-note chunks (doc_id starting with 'note-'), with parsed metadata.

        Excludes expired chunks (meta["expired"] is truthy) unless include_expired=True.
        Excludes chunks memory_distil has already classified (meta["distilled_at"] is
        truthy) when exclude_distilled=True — pass this only from memory_distil's own
        selection query; callers like memory_index.py that render the live memory set
        must NOT set it, since a distilled note still belongs in the index.

        A "keep" verdict is a deferral, not a decision, so it is time-boxed: a
        distilled_verdict="keep" chunk is RE-INCLUDED once distilled_at is more than
        keep_review_days old, so memory_distil reconsiders it. "expire"/"promote" (or a
        distilled_at with no distilled_verdict at all) stay excluded permanently — those
        are genuine terminal decisions. A malformed distilled_at on a "keep" row fails
        safe (stays excluded); a keep-verdicted row with no distilled_at key at all is
        included (not excluded) by the outer truthy check, but this never occurs in
        practice since drain_distil always stamps distilled_at and distilled_verdict together.

        Filters by observation_type if provided. Returns the newest `limit` live results
        (ORDER BY rowid DESC). The limit is applied AFTER the Python-side expired/
        distilled/observation_type filter, so a store full of expired or already-distilled
        notes never truncates live/fresh ones — we iterate the cursor and stop once
        `limit` live (complete) notes are collected rather than pre-truncating in SQL.

        A note that needed more than one `chunk_text` piece (see drain.py's
        `drain_captures`, `kind == "ingest"`) is stored as several rows sharing one
        `metadata["note_id"]` (the base `note-<hash>` id) and distinguished by
        `chunk_index`/`chunk_total`. Those rows are reassembled here into a single
        logical note — doc_id = note_id, text = pieces joined in chunk_index order
        with the same "\n\n" separator `chunk_text` split on — so callers (memory_index,
        memory_distil) keep seeing one row per captured note, same as before chunking
        existed. A row with no `note_id` (every note captured before this, plus any
        single-piece note, which keeps the bare id) is its own one-row group, unchanged.
        """
        sql = ("SELECT doc_id, text, metadata FROM chunks "
               "WHERE doc_id LIKE 'note-%' ORDER BY rowid DESC")
        groups: dict[str, list[dict]] = {}
        order: list[str] = []
        completed = 0
        with self._connect() as db:
            for r in db.execute(sql):
                try:
                    meta = json.loads(r["metadata"])
                except Exception:
                    continue
                if not include_expired and meta.get("expired"):
                    continue
                if exclude_distilled and meta.get("distilled_at"):
                    stale = False
                    if meta.get("distilled_verdict") == "keep":
                        try:
                            stamped = datetime.fromisoformat(
                                meta["distilled_at"].replace("Z", "+00:00"))
                            stale = (datetime.now(timezone.utc) - stamped
                                     > timedelta(days=keep_review_days))
                        except (ValueError, TypeError, AttributeError):
                            stale = False  # malformed timestamp: fail safe, stay excluded
                    if not stale:
                        continue
                if observation_type is not None and meta.get("observation_type") != observation_type:
                    continue
                key = meta.get("note_id") or r["doc_id"]
                if key not in groups:
                    groups[key] = []
                    order.append(key)
                groups[key].append({"doc_id": r["doc_id"], "text": r["text"], "metadata": meta})
                # Pieces of one note are written consecutively (ascending chunk_index
                # -> ascending rowid), so under this DESC scan they arrive contiguously
                # counting down from chunk_total-1 to 0: once a group holds
                # chunk_total rows it cannot grow further, so it's safe to count
                # toward `limit` now instead of scanning the whole table.
                total = meta.get("chunk_total") or 1
                if len(groups[key]) >= total:
                    completed += 1
                    if completed >= limit:
                        break

        results = []
        for key in order:
            pieces = groups[key]
            if len(pieces) == 1:
                results.append(pieces[0])
            else:
                pieces.sort(key=lambda p: p["metadata"].get("chunk_index", 0))
                # Pieces produced by chunking.split_lossless carry their own
                # trailing separators, so they rejoin with "" and reproduce the
                # note byte-for-byte. Joining those with "\n\n" would inject a
                # blank line that was never in the note. Pieces written by the
                # older chunk_text path carry no marker and keep the "\n\n"
                # convention they were written under.
                sep = "" if pieces[0]["metadata"].get("split") == "lossless" else "\n\n"
                text = sep.join(p["text"] for p in pieces)
                meta = dict(pieces[0]["metadata"])
                results.append({"doc_id": key, "text": text, "metadata": meta})
            if len(results) == limit:
                break
        return results

    def get_cursor(self, source: str) -> str | None:
        with self._connect() as db:
            r = db.execute("SELECT cursor FROM sync_cursors WHERE source=?", (source,)).fetchone()
            return r["cursor"] if r else None

    def set_cursor(self, source: str, cursor: str) -> None:
        with self._connect(write=True) as db:
            db.execute(
                "INSERT INTO sync_cursors(source, cursor, updated_at) VALUES(?,?,datetime('now')) "
                "ON CONFLICT(source) DO UPDATE SET cursor=excluded.cursor, updated_at=datetime('now')",
                (source, cursor))

    def purge_drive_sync_state(self, drive_id: str) -> dict:
        """Clear a Shared Drive's queue/cursor/pending-publish state on revocation.

        `ingest_cache.purge_drive` (unchanged by the sync-queue migration --
        it predates it and stays scoped to chunks/relations) has no idea
        `sync_queue`, `sync_cursors`, or `shared_drive_pending_publish` rows
        exist for a drive. Without this, a revoked/unpinned drive's queued
        items KeyError forever (fixed separately in the work-loop handler)
        and its cursor/pending-publish rows sit orphaned, never cleaned up.
        Called from run_sync_cycle for each id `note_drive_presence` purges.

        Exact-match on `drive:<id>` and its two backfill-floor cursor keys --
        never a substring/prefix match, which could otherwise collide with
        `drive` (My Drive) or another source. Returns counts for logging.
        """
        source = f"drive:{drive_id}"
        with self._connect(write=True) as db:
            queue_rows = db.execute(
                "DELETE FROM sync_queue WHERE source=?", (source,)).rowcount
            cursors = db.execute(
                "DELETE FROM sync_cursors WHERE source IN (?,?,?)",
                (source, f"{source}_backfill_until", f"{source}_backfill_empty"),
            ).rowcount
            pending_publishes = db.execute(
                "DELETE FROM shared_drive_pending_publish WHERE drive_id=?",
                (drive_id,)).rowcount
        return {"queue_rows": queue_rows, "cursors": cursors,
                "pending_publishes": pending_publishes}

    # --- reflow (extraction-fidelity, 2026-09-24) ------------------------------

    def enqueue_items(self, items, *, source: str) -> int:
        """enqueue_and_advance without a cursor: for producers (the reflow
        seed) that have no feed position to persist. ON CONFLICT(source,
        ref_id) DO NOTHING -- an item already queued keeps its attempts and
        backoff. Returns the number of rows actually inserted."""
        now = datetime.now(timezone.utc).isoformat()
        n = 0
        with self._connect(write=True) as db:
            for it in items:
                n += db.execute(
                    "INSERT INTO sync_queue(source, ref_id, version, event, modified_at,"
                    " discovered_at) VALUES(?,?,?,?,?,?) "
                    "ON CONFLICT(source, ref_id) DO NOTHING",
                    (source, it["ref_id"], it.get("version", ""), it["event"],
                     it["modified_at"], now)).rowcount
        return n

    def owner_chunks(self, doc_id_prefixes: list[str]) -> list[dict]:
        """Rows (doc_id, text, metadata dict, enriched, enriched_version,
        enrich_state, salience, memory_tier, memory_type) for every chunk whose
        doc_id starts with any prefix, in rowid order.

        Case-SENSITIVE and positional-suffix checked. SQLite's LIKE folds ASCII
        case, so `gdrive-abc-%` would also return `gdrive-ABC-0` -- another
        file's chunks, which a reflow would then remap and DELETE. The match is
        an index-backed half-open range on the UNIQUE doc_id instead, and the
        remainder after the prefix must be the owner's own positional suffix
        (`_OWNER_SUFFIX`): a bare `cal-<eid>` prefix must not take in a
        recurring instance `cal-<eid>_20260901T...` or a longer id that happens
        to start with the same characters."""
        out: list[dict] = []
        seen: set[str] = set()
        with self._connect() as db:
            for pfx in doc_id_prefixes:
                if not pfx:
                    continue
                hi = pfx[:-1] + chr(ord(pfx[-1]) + 1)
                for r in db.execute(
                        "SELECT doc_id, text, metadata, enriched, enriched_version, "
                        "enrich_state, salience, memory_tier, memory_type FROM chunks "
                        "WHERE doc_id >= ? AND doc_id < ? ORDER BY rowid", (pfx, hi)):
                    d = dict(r)
                    did = d["doc_id"]
                    if (did in seen or not did.startswith(pfx)
                            or not _owner_suffix_ok(pfx, did[len(pfx):])):
                        continue
                    seen.add(did)
                    d["metadata"] = json.loads(d["metadata"] or "{}")
                    out.append(d)
        return out

    def apply_reflow(self, owner: str, source: str, plan, vectors, *, home=None) -> dict:
        """Apply a reflow.ReflowPlan in ONE transaction (spec §3); returns
        {written, carried, uncovered, inherited_unenriched, deleted, remapped}
        (carried = covered AND enriched; uncovered = covered False, the
        genuinely new extraction work; inherited_unenriched = covered but the
        old text was unenriched too).

        Order inside the single BEGIN IMMEDIATE: write every new chunk over its
        positional id with its vector + FTS row -> carry enrichment state ->
        remap every doc_id reference SIMULTANEOUSLY (one UPDATE per target
        table through a temp mapping table, so i->j and j->i can never chain)
        -> merge chunk_quality -> delete the old ids beyond the new chunk set
        -> append reflow_map -> orphan guard. The guard raises
        ReflowOrphanError INSIDE the transaction, so `_connect` rolls the whole
        thing back to the untouched old chunks: a wrong remap must stop, not
        propagate."""
        rows = list(plan.rows)
        gone = sorted(o for o, why in plan.reasons.items() if why == "lineage_gone")
        if gone:
            # A reflow never deletes a whole lineage. An old lineage with no new
            # counterpart (e.g. an attachment whose re-extraction silently came
            # back empty) is a failed extraction, not a proof of absence -- the
            # handler must take the ordinary change path, not apply this plan.
            raise ValueError(f"apply_reflow {owner}: plan would delete whole "
                             f"lineage(s) {sorted(plan.unequal)}: {gone[:5]}")
        if len(vectors) != len(rows):
            raise ValueError("apply_reflow: one vector per new chunk")
        if not rows:
            raise ValueError("apply_reflow: no new chunks -- never apply a deletion")
        new_ids = [r.chunk.doc_id for r in rows]
        if len(set(new_ids)) != len(new_ids):
            raise ValueError("apply_reflow: duplicate new doc_id")
        old_ids = list(plan.remap)
        stray = set(plan.deletes) - set(old_ids)
        if stray or set(plan.deletes) & set(new_ids):
            raise ValueError("apply_reflow: deletes must be old ids with no new chunk")
        now = datetime.now(timezone.utc).isoformat()
        # carried = text whose enrichment survived. What is left at enriched=0
        # splits into uncovered (new text: the real extraction cost) and
        # inherited_unenriched (its old text was never enriched either).
        counts = {"carried": sum(1 for r in rows if r.covered and r.enriched),
                  "uncovered": sum(1 for r in rows if not r.covered),
                  "inherited_unenriched": sum(1 for r in rows
                                              if r.covered and not r.enriched),
                  "unequal_lineages": len(set(plan.unequal))}
        try:
            return self._apply_reflow_txn(owner, source, plan, vectors, rows, new_ids,
                                          old_ids, now, counts, home)
        except ReflowOrphanError as exc:
            # A wrong remap on ANY carry-over path (the reflow queue handler or
            # the ingest-cache import) halts the reflow cadence: the
            # transaction has already rolled back, and this separate small
            # write is what doctor and `bin/reflow.py resume` act on.
            try:
                self.set_cursor(REFLOW_HALT_CURSOR, str(exc)[:500])
            except Exception as cur_exc:  # noqa: BLE001 — never mask the orphan error
                import logging
                # Raising the cursor error instead would hide the orphan from
                # the handler (it catches ReflowOrphanError) and leave the
                # cadence un-halted; the transaction is rolled back either way.
                logging.getLogger(__name__).error(
                    "reflow %s: could not record the halt cursor: %s", owner, cur_exc)
            raise exc

    def _apply_reflow_txn(self, owner, source, plan, vectors, rows, new_ids, old_ids,
                          now, counts, home) -> dict:
        with self._connect(write=True) as db:
            # The plan was built from rows read BEFORE this transaction; under
            # BEGIN IMMEDIATE, re-check that every old id still exists so a plan
            # made on rows another writer has since removed is never applied.
            present = 0
            for i in range(0, len(old_ids), 500):
                batch = old_ids[i:i + 500]
                present += db.execute(
                    f"SELECT count(*) FROM chunks WHERE doc_id IN ({','.join('?' * len(batch))})",
                    batch).fetchone()[0]
            if present != len(old_ids):
                raise ValueError(f"apply_reflow {owner}: stale plan -- "
                                 f"{len(old_ids) - present} old chunk(s) no longer exist")
            tables = {r[0] for r in db.execute(
                "SELECT name FROM sqlite_master WHERE type='table'")}
            payload_covers = self._reflowed_payload_covers(db, tables, rows, old_ids)
            # A content duplicate keeps dup_of across the remap only when its
            # text is unchanged: content_hash -> canonical, read from
            # the old rows before they are overwritten. Keyed on the hash
            # alone (within this owner): a re-chunk may move the identical
            # text to a different positional id.
            old_dups: dict[str, str] = {}
            for i in range(0, len(old_ids), 500):
                batch = old_ids[i:i + 500]
                for r in db.execute(
                        "SELECT doc_id, content_hash, dup_of FROM chunks "
                        f"WHERE doc_id IN ({','.join('?' * len(batch))}) "
                        "AND dup_of IS NOT NULL", batch):
                    old_dups.setdefault(r["content_hash"], r["dup_of"])
            # The owner's re-include follows the text: a new chunk the plan
            # remaps an old re-included chunk onto keeps force_enrich.
            forced_new: set = set()
            for i in range(0, len(old_ids), 500):
                batch = old_ids[i:i + 500]
                for r in db.execute(
                        "SELECT doc_id FROM chunks "
                        f"WHERE doc_id IN ({','.join('?' * len(batch))}) "
                        f"AND {_meta_extract('$.force_enrich')} = 1", batch):
                    if r["doc_id"] in plan.remap:
                        forced_new.add(plan.remap[r["doc_id"]])
            for row, vec in zip(rows, vectors):
                c = row.chunk
                meta = (self._keep_force_enrich(c.metadata, 1)
                        if c.doc_id in forced_new else c.metadata)
                self._write_cached_chunk_row(
                    db, c.doc_id, c.text, c.content_hash, meta, vec,
                    enriched=bool(row.enriched), enriched_version=row.enriched_version,
                    home=home)
                # Covered rows carry the majority state of the old text they
                # hold; everything else gets the column defaults. Never
                # COALESCE with the row already at this positional id: that is
                # an old chunk of DIFFERENT text (ids are reused), so its
                # salience/tier/type say nothing about this text.
                db.execute("UPDATE chunks SET enrich_state=?, salience=?, memory_tier=?,"
                           " memory_type=?, enrich_attempts=0 WHERE doc_id=?",
                           (row.enrich_state,
                            row.salience if row.covered and row.salience is not None else 0.0,
                            row.memory_tier if row.covered and row.memory_tier is not None
                            else "",
                            row.memory_type if row.covered and row.memory_type is not None
                            else "episodic",
                            c.doc_id))
                dup = old_dups.get(c.content_hash)
                # Store the OLD canonical id (the dup_of remap below translates
                # it exactly once) but judge self-reference on where it lands:
                # a canonical in this same owner may move onto this very id.
                if dup and plan.remap.get(dup, dup) != c.doc_id:
                    db.execute("UPDATE chunks SET dup_of=? WHERE doc_id=?",
                               (dup, c.doc_id))
                else:
                    db.execute(
                        "UPDATE chunks SET dup_of=NULL, enrich_state=CASE WHEN "
                        "enrich_state='duplicate' THEN '' ELSE enrich_state END "
                        "WHERE doc_id=?", (c.doc_id,))
            db.execute("CREATE TEMP TABLE IF NOT EXISTS reflow_tmp("
                       "old TEXT PRIMARY KEY, new TEXT NOT NULL)")
            db.execute("DELETE FROM reflow_tmp")
            db.executemany("INSERT INTO reflow_tmp(old, new) VALUES(?,?)",
                           list(plan.remap.items()))
            if "entity_relations" in tables:
                # Keep the pre-remap id for org contribution (first remap wins).
                db.execute(
                    "UPDATE entity_relations SET contrib_doc_id=source_doc_id "
                    "WHERE contrib_doc_id IS NULL "
                    "AND source_doc_id IN (SELECT old FROM reflow_tmp) "
                    "AND source_doc_id != (SELECT new FROM reflow_tmp "
                    "WHERE old=entity_relations.source_doc_id)")
            remapped = 0
            for table, col in _REFLOW_REF_COLUMNS:
                if table not in tables:
                    continue
                remapped += db.execute(
                    f"UPDATE {table} SET {col}=(SELECT new FROM reflow_tmp "
                    f"WHERE old={table}.{col}) "
                    f"WHERE {col} IN (SELECT old FROM reflow_tmp) "
                    f"AND {col} != (SELECT new FROM reflow_tmp WHERE old={table}.{col})"
                ).rowcount
            # Content duplicates follow their canonical to its new id; any
            # whose canonical's text did not survive there are released
            # (after the deletes below) to extract on their own.
            db.execute(
                "UPDATE chunks SET dup_of=(SELECT new FROM reflow_tmp "
                "WHERE old=chunks.dup_of) "
                "WHERE dup_of IN (SELECT old FROM reflow_tmp)")
            if "chunk_quality" in tables and old_ids:
                self._merge_chunk_quality(db, plan.remap)
            if plan.deletes:
                ph = ",".join("?" * len(plan.deletes))
                rowids = [r[0] for r in db.execute(
                    f"SELECT rowid FROM chunks WHERE doc_id IN ({ph})", plan.deletes)]
                if rowids:
                    rp = ",".join("?" * len(rowids))
                    db.execute(f"DELETE FROM vec_chunks WHERE rowid IN ({rp})", rowids)
                    db.execute(f"DELETE FROM fts_chunks WHERE rowid IN ({rp})", rowids)
                    db.execute(f"DELETE FROM chunks WHERE rowid IN ({rp})", rowids)
            self._release_stale_dups(
                db, list(dict.fromkeys(list(plan.remap.values()) + new_ids
                                       + list(plan.deletes))))
            # Final guard: a chunk is never its own duplicate. Only a new id
            # can be (dup_of is assigned or remapped onto new ids alone), so
            # it is scoped to them -- a PK lookup, never a scan of chunks.
            for i in range(0, len(new_ids), 500):
                batch = new_ids[i:i + 500]
                db.execute(_SELF_DUP_GUARD_SQL.format(qs=",".join("?" * len(batch))),
                           batch)
            db.executemany(
                "INSERT INTO reflow_map(owner, old_doc_id, new_doc_id, reason, at) "
                "VALUES(?,?,?,?,?)",
                [(owner, o, n, plan.reasons.get(o, "exact"), now)
                 for o, n in plan.remap.items()])
            # Orphan guard. (1) Every remap target must be a chunk that now
            # exists -- otherwise reflow_map would log, and read_doc would
            # resolve to, an id with no row. (2) Nothing may reference one of
            # this owner's ids that no longer has a chunk row.
            ids = sorted(set(old_ids) | set(new_ids))
            ph = ",".join("?" * len(ids))
            present = {r[0] for r in db.execute(
                f"SELECT doc_id FROM chunks WHERE doc_id IN ({ph})", ids)}
            missing_targets = sorted(set(plan.remap.values()) - present)
            dangling = 0
            for table, col in _REFLOW_REF_COLUMNS:
                if table not in tables:
                    continue
                # NOT EXISTS, never `NOT IN (SELECT doc_id FROM chunks)`:
                # chunks.doc_id is nullable, and one NULL makes NOT IN
                # unknown for every row -- the guard would count 0.
                dangling += db.execute(
                    f"SELECT count(*) FROM {table} t WHERE t.{col} IN ({ph}) "
                    f"AND NOT EXISTS (SELECT 1 FROM chunks c WHERE c.doc_id = t.{col})",
                    ids).fetchone()[0]
            if missing_targets or dangling:
                raise ReflowOrphanError(
                    f"reflow {owner}: {dangling} dangling reference(s), "
                    f"{len(missing_targets)} remap target(s) with no chunk "
                    f"{missing_targets[:5]}")
            for fid, covers in payload_covers.items():
                db.execute("UPDATE enrich_payloads SET covers=? WHERE file_id=?",
                           (json.dumps(covers), fid))
            db.execute("INSERT OR REPLACE INTO reflow_owners(owner, source, at, chunks_new,"
                       " carried, reenrich, outcome, uncovered, inherited_unenriched,"
                       " unequal_lineages) VALUES(?,?,?,?,?,?,'carried',?,?,?)",
                       (owner, source, now, len(rows), counts["carried"],
                        counts["uncovered"] + counts["inherited_unenriched"],
                        counts["uncovered"], counts["inherited_unenriched"],
                        counts["unequal_lineages"]))
            db.execute("DROP TABLE reflow_tmp")
        return {"written": len(rows), **counts,
                "deleted": len(plan.deletes), "remapped": remapped}

    @staticmethod
    def _reflowed_payload_covers(db, tables, rows, old_ids) -> dict[str, list[str]]:
        """The `covers` each of this owner's Drive enrich payloads has after
        the reflow, computed BEFORE the new rows overwrite the old ones.

        A payload survives a re-chunk only for text it was made from: a
        whole-file payload (NULL covers, or covers holding every non-cold old
        chunk) now covers exactly the CARRIED rows -- covered text whose
        enrichment survived. A payload that already covered only part of the
        file covers nothing. Uncovered (re-enrich) rows are never in covers,
        so publish_file withholds the payload until one extraction covers the
        whole file again."""
        if "enrich_payloads" not in tables:
            return {}
        by_file: dict[str, list] = {}
        for r in rows:
            fid = _file_key_from_doc_id(r.chunk.doc_id)
            if fid:
                by_file.setdefault(fid, []).append(r)
        out: dict[str, list[str]] = {}
        for fid, frows in by_file.items():
            prow = db.execute("SELECT covers FROM enrich_payloads WHERE file_id=?",
                              (fid,)).fetchone()
            if prow is None:
                continue
            olds = [o for o in old_ids if _file_key_from_doc_id(o) == fid]
            if olds:
                ph = ",".join("?" * len(olds))
                hot_old = {x[0] for x in db.execute(
                    f"SELECT doc_id FROM chunks WHERE doc_id IN ({ph}) "
                    "AND COALESCE(enrich_state,'')!='cold'", olds)}
            else:
                hot_old = set()
            whole = prow[0] is None or hot_old <= set(json.loads(prow[0]))
            out[fid] = sorted(r.chunk.doc_id for r in frows
                              if whole and r.covered and r.enriched)
        return out

    @staticmethod
    def _merge_chunk_quality(db, remap: dict[str, str]) -> None:
        """Fold the old ids' chunk_quality rows into their remap targets:
        exposures and uses summed; quality, memory_strength, last_accessed and
        updated_at the max. Every old id is removed first, then one merged row
        per target is written -- so a target that is also an old id (positional
        reuse) is replaced by the merge, never double-counted."""
        old_ids = list(remap)
        ph = ",".join("?" * len(old_ids))
        qrows = [dict(q) for q in db.execute(
            f"SELECT * FROM chunk_quality WHERE doc_id IN ({ph})", old_ids)]
        if not qrows:
            return
        merged: dict[str, dict] = {}
        for q in qrows:
            tgt = remap[q["doc_id"]]
            m = merged.get(tgt)
            if m is None:
                merged[tgt] = {**q, "doc_id": tgt}
                continue
            for k in ("exposures", "uses"):
                if k in q:
                    m[k] = (m.get(k) or 0) + (q[k] or 0)
            for k in ("quality", "memory_strength", "last_accessed", "updated_at"):
                if k in q and q[k] is not None and (m.get(k) is None or q[k] > m[k]):
                    m[k] = q[k]
        db.execute(f"DELETE FROM chunk_quality WHERE doc_id IN ({ph})", old_ids)
        for m in merged.values():
            cols = list(m)
            db.execute(f"INSERT OR REPLACE INTO chunk_quality({','.join(cols)}) "
                       f"VALUES({','.join('?' * len(cols))})", [m[k] for k in cols])

    def latest_reflow_target(self, doc_id: str) -> str | None:
        """The new_doc_id of the most recent reflow_map row for `doc_id`, or
        None. One hop; resolve_reflowed_ids follows the chain."""
        with self._connect() as db:
            try:
                r = db.execute("SELECT new_doc_id FROM reflow_map WHERE old_doc_id=? "
                               "ORDER BY id DESC LIMIT 1", (doc_id,)).fetchone()
            except sqlite3.OperationalError as exc:
                if "no such table" in str(exc):     # a store not yet init()'d
                    return None
                raise
        return r["new_doc_id"] if r else None

    def reflow_map_rows(self, after_id: int = 0) -> list[dict]:
        """reflow_map rows with id > after_id, ascending: {id, owner,
        old_doc_id, new_doc_id, reason, at}. Read-only; the input to
        bin/tenant.py remap-gold. [] on a store without the table."""
        with self._connect() as db:
            try:
                return [dict(r) for r in db.execute(
                    "SELECT id, owner, old_doc_id, new_doc_id, reason, at FROM reflow_map "
                    "WHERE id > ? ORDER BY id", (int(after_id),))]
            except sqlite3.OperationalError as exc:
                if "no such table" in str(exc):
                    return []
                raise

    def resolve_reflowed_ids(self, doc_ids: list[str], *, max_hops: int = 8) -> list[str]:
        """Map doc_ids onto chunks that exist, preserving order, de-duplicated.

        An id with a chunk row is kept as-is. An id without one is followed
        through reflow_map (latest row per hop -- a second reflow of the same
        owner can have deleted the first one's target) until it reaches an id
        that exists; if it never does, it is dropped. The fallback spec §3
        gives read_doc, drain's doc_id resolution and org provenance."""
        ids = [d for d in (doc_ids or []) if d]
        if not ids:
            return []
        ph = ",".join("?" * len(ids))
        with self._connect() as db:
            present = {r[0] for r in db.execute(
                f"SELECT doc_id FROM chunks WHERE doc_id IN ({ph})", ids)}
        out: list[str] = []
        for d in ids:
            cur, seen = d, {d}
            while cur not in present:
                nxt = self.latest_reflow_target(cur)
                if not nxt or nxt in seen or len(seen) > max_hops:
                    cur = None
                    break
                seen.add(nxt)
                if self.get_chunk(nxt) is not None:
                    present.add(nxt)
                cur = nxt
            if cur is not None and cur not in out:
                out.append(cur)
        return out

    REFLOW_OUTCOMES = ("carried", "ordinary", "gave_up", "source_gone", "unsupported")

    def record_reflow_outcome(self, owner: str, source: str, outcome: str) -> None:
        """Record a terminal reflow outcome that did not go through
        apply_reflow (which records 'carried' itself, in its transaction)."""
        if outcome not in self.REFLOW_OUTCOMES:
            raise ValueError(f"unknown reflow outcome {outcome!r}")
        now = datetime.now(timezone.utc).isoformat()
        with self._connect(write=True) as db:
            db.execute("INSERT OR REPLACE INTO reflow_owners(owner, source, at, chunks_new,"
                       " carried, reenrich, outcome) VALUES(?,?,?,0,0,0,?)",
                       (owner, source, now, outcome))

    def reset_reflow_transient_attempts(self, is_transient_message, *, sources=None,
                                        apply: bool = True) -> int:
        """Queued reflow rows whose stored last_error `is_transient_message`
        recognises as a network failure: attempts, transient_defers and the
        backoff are cleared (attempts=0, transient_defers=0,
        next_attempt_at=NULL, last_error=''). Repairs rows that spent give-up
        attempts on an outage before _is_transient knew network errors.
        Returns the count (what it would change when not `apply`). Attended
        only (bin/reflow_drain.py --reset-transient-attempts)."""
        srcs = list(sources) if sources else None
        where = "source LIKE 'reflow:%' AND last_error != ''"
        args: list = []
        if srcs:
            where += f" AND source IN ({','.join('?' * len(srcs))})"
            args = srcs
        with self._connect(write=apply) as db:
            keys = [(r["source"], r["ref_id"]) for r in db.execute(
                f"SELECT source, ref_id, last_error FROM sync_queue WHERE {where}", args)
                if is_transient_message(r["last_error"])]
            if apply and keys:
                db.executemany(
                    "UPDATE sync_queue SET attempts=0, transient_defers=0, "
                    "next_attempt_at=NULL, last_error='' WHERE source=? AND ref_id=?", keys)
        return len(keys)

    # Owner id field per source_type, for counting the owners a retry touches.
    _REFLOW_OWNER_FIELD = {"gdrive": ("file_id", "drive"), "gmail": ("message_id", "gmail"),
                           "anarlog": ("session_id", "anarlog"),
                           "calendar": ("event_id", "calendar")}
    _REFLOW_SOURCE_TYPE = {"reflow:drive": "gdrive", "reflow:gmail": "gmail",
                           "reflow:anarlog": "anarlog", "reflow:calendar": "calendar"}

    def retry_reflow_gave_up(self, *, sources=None, apply: bool = True,
                             doc_ids=None) -> dict:
        """Undo the `reflow_skipped="gave_up"` stamp: remove reflow_skipped,
        split_version and extraction_version from every such chunk (so the
        level-triggered selector matches its owner again) and drop the owners'
        'gave_up' reflow_owners outcome, in ONE transaction. Other stamps
        (source_gone / unsupported / source_disabled) are never touched. A
        genuinely broken owner simply gives up again after five real attempts.
        Returns {"owners", "chunks"} (what it would change when not `apply`).
        Attended (bin/reflow_drain.py --retry-gave-up), or scoped by `doc_ids`
        from the console's gave-up list: only the owners those chunks belong to
        are retried (every gave-up chunk of each such owner, so the owner is
        whole again for the selector)."""
        from mcpbrain.embed import contextual_prefix
        types = ({self._REFLOW_SOURCE_TYPE[s] for s in sources if s in self._REFLOW_SOURCE_TYPE}
                 if sources else None)
        skipped = _meta_extract("$.reflow_skipped")
        owners: set[tuple[str, str]] = set()
        updates: list[tuple] = []

        def _owner_of(doc_id, meta):
            field, kind = self._REFLOW_OWNER_FIELD.get(meta.get("source_type"),
                                                       (None, meta.get("source_type")))
            owner = meta.get(field) if field else None
            return kind, owner or doc_id

        with self._connect(write=apply) as db:
            wanted = None
            if doc_ids is not None:
                ids = [d for d in dict.fromkeys(doc_ids) if d]
                wanted = set()
                for i in range(0, len(ids), 500):
                    part = ids[i:i + 500]
                    for r in db.execute(
                            f"SELECT doc_id, metadata FROM chunks WHERE {skipped}='gave_up' "
                            f"AND doc_id IN ({','.join('?' * len(part))})", part):
                        wanted.add(_owner_of(r["doc_id"], json.loads(r["metadata"])))
                if not wanted:
                    return {"owners": 0, "chunks": 0}
            for r in db.execute(f"SELECT doc_id, metadata FROM chunks WHERE {skipped}='gave_up'"):
                meta = json.loads(r["metadata"])
                stype = meta.get("source_type")
                if types is not None and stype not in types:
                    continue
                key = _owner_of(r["doc_id"], meta)
                if wanted is not None and key not in wanted:
                    continue
                owners.add(key)
                before = contextual_prefix(meta)
                for k in ("reflow_skipped", "split_version", "extraction_version"):
                    meta.pop(k, None)
                updates.append((json.dumps(meta), contextual_prefix(meta) != before,
                                r["doc_id"]))
            if apply and updates:
                db.executemany("UPDATE chunks SET metadata=? WHERE doc_id=?",
                               [(m, d) for m, _, d in updates])
                db.executemany("UPDATE chunks SET fts_context_version=0 WHERE doc_id=?",
                               [(d,) for _, changed, d in updates if changed])
                db.executemany("DELETE FROM reflow_owners WHERE owner=? AND source=? "
                               "AND outcome='gave_up'", [(o, k) for k, o in owners])
        return {"owners": len(owners), "chunks": len(updates)}

    def reflow_stats(self, *, live_remaining: bool = False,
                     remaining_cap: int = 5000, sources=None) -> dict:
        """{owners_done, by_outcome, chunks_carried, chunks_uncovered,
        chunks_inherited_unenriched, owners_text_differed (carried owners with
        at least one lineage whose old and new text differed), queued, remaining, held, total, last_seed}.

        owners_done counts every owner with a terminal outcome (by_outcome
        splits it). chunks_carried = new chunks covered AND enriched;
        chunks_uncovered = new chunks no old text covered (the genuine new
        extraction work); chunks_inherited_unenriched = covered chunks whose
        old text was unenriched too (cold by design, or never reached) --
        not a cost the reflow adds. remaining = owners the
        selector still matches and that are not queued: computed live (a
        bounded reflow_candidates call, capped at remaining_cap -- several
        chunk-table scans, so for attended callers: doctor, bin/reflow.py) when
        live_remaining, else the figure the last seed recorded (None before the
        first seed). total = owners_done + queued + remaining (None when
        remaining is unknown). last_seed = the seed's last recorded status
        dict ({status, at, enqueued?, remaining?, sources?}) or None.

        `held` = how many of `remaining` the selector's 24 h loop guard keeps
        out of the seed (a recent 'ordinary' outcome that did not converge).
        remaining INCLUDES them, so every consumer of remaining (doctor's
        pending, the daemon's backlog-empty check, total) still sees held
        owners as work; held is the subset to warn about. Live like
        remaining when live_remaining, else the last seed's figure (None
        before a seed recorded one).

        A live `remaining` counts only `sources` -- by default the workable
        set the seed last recorded (reflow.workable_reflow_sources), so an
        owner of a source this install can never work (scope not granted,
        anarlog disabled) never holds doctor off ✅. Before the first seed
        records one, every source counts."""
        with self._connect() as db:
            by = {r["outcome"]: r["n"] for r in db.execute(
                "SELECT outcome, count(*) n FROM reflow_owners GROUP BY outcome")}
            o = db.execute("SELECT count(*) n, COALESCE(sum(carried),0) c, "
                           "COALESCE(sum(uncovered),0) u, "
                           "COALESCE(sum(inherited_unenriched),0) i, "
                           "COALESCE(sum(unequal_lineages > 0),0) d "
                           "FROM reflow_owners").fetchone()
            q = db.execute("SELECT count(*) FROM sync_queue WHERE source LIKE 'reflow:%'"
                           ).fetchone()[0]
        last_seed = None
        raw = self.get_cursor("reflow:last_seed")
        if raw:
            try:
                last_seed = json.loads(raw)
            except ValueError:
                last_seed = {"status": str(raw)}
        if live_remaining:
            if sources is None and (last_seed or {}).get("sources") is not None:
                sources = set(last_seed["sources"])
            remaining, held = self.reflow_live_counts(remaining_cap, sources=sources)
        else:
            remaining = (last_seed or {}).get("remaining")
            held = (last_seed or {}).get("held")
        total = (o["n"] + q + remaining) if remaining is not None else None
        return {"owners_done": o["n"], "by_outcome": by, "chunks_carried": o["c"],
                "chunks_uncovered": o["u"], "chunks_inherited_unenriched": o["i"],
                "owners_text_differed": o["d"], "queued": q, "remaining": remaining,
                "held": held, "total": total, "last_seed": last_seed}

    def reflow_due_count(self, now: str | None = None) -> int:
        """Queued reflow rows that are DUE (next_attempt_at unset or <= now),
        the same filter due_sync_items applies. The seed sizes REFLOW_WINDOW
        on this, not on every queued row: a row a handler deferred with a
        delay (a long transient outage) is not work this cycle can do, and
        counting it let deferred rows hold the window full and stall every
        other source's reflow. `now` defaults to naive-UTC isoformat, the
        format sync.queue writes."""
        if now is None:
            now = datetime.now(timezone.utc).replace(tzinfo=None).isoformat()
        with self._connect() as db:
            return db.execute(
                "SELECT count(*) FROM sync_queue WHERE source LIKE 'reflow:%' "
                "AND (next_attempt_at IS NULL OR next_attempt_at <= ?)", (now,)
            ).fetchone()[0]

    def reflow_status(self, *, live_remaining: bool = False, sources=None) -> dict:
        """reflow_stats plus `halted` (the halt reason, or None) and
        `integrity` (the backlog-end integrity_check result, or None): the one
        assembly /api/status, doctor and bin/reflow.py status all show."""
        st = self.reflow_stats(live_remaining=live_remaining, sources=sources)
        return {**st, "halted": self.get_cursor(REFLOW_HALT_CURSOR) or None,
                "integrity": self.get_cursor("reflow:integrity_checked") or None}

    def drop_queued_reflow_rows(self, sources) -> int:
        """Delete queued reflow rows for `sources` (e.g. {"reflow:calendar"}).
        For a source that cannot be worked on this install (scope not
        granted, source not configured), so its rows stop holding the seed
        window. Loses nothing: the selector is level-triggered and re-seeds
        them once the source is available."""
        srcs = sorted(sources or ())
        if not srcs:
            return 0
        with self._connect(write=True) as db:
            return db.execute(f"DELETE FROM sync_queue WHERE source IN "
                              f"({','.join('?' * len(srcs))})", srcs).rowcount

    @staticmethod
    def _reflow_hold_cutoff() -> str:
        """The reflow_candidates loop guard's window start: an 'ordinary'
        outcome recorded after this is held (24 h)."""
        return (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()

    def reflow_live_counts(self, cap: int, *, sources=None) -> tuple[int, int]:
        """(remaining, held), counted now. remaining = unqueued owners the
        selector matches WITHOUT the loop guard, capped at `cap` -- so it
        INCLUDES held owners; held = how many of those the guard keeps out
        of the seed (a recent 'ordinary' outcome that did not converge).
        Every counting caller goes through this, never through the guarded
        reflow_candidates: a held owner is still work, and a backlog that
        hides it reads empty while it is stuck."""
        found = self.reflow_candidates(cap, sources=sources, hold_recent_ordinary=False)
        if not found:
            return 0, 0
        with self._connect() as db:
            recent = {(f"reflow:{r['source']}", str(r["owner"])) for r in db.execute(
                "SELECT owner, source FROM reflow_owners WHERE outcome='ordinary' "
                "AND at > ?", (self._reflow_hold_cutoff(),))}
        return len(found), sum(1 for k in found if k in recent)

    def reflow_candidates(self, limit: int, *, sources=None,
                          hold_recent_ordinary: bool = True) -> list[tuple[str, str]]:
        """Level-triggered reflow selector (spec §4): (source, owner) pairs,
        source in reflow:drive|gmail|anarlog|calendar, excluding owners already
        queued. An owner stops matching once its chunks carry the current
        split/extraction versions, so the seed converges and goes idle.

        Rules, one query each:
          1. Drive files in a block-extracted MIME below that MIME's
             EXTRACTION_VERSIONS entry (owner file_id);
          2. Gmail attachments likewise, on attachment_mime (owner message_id);
          3. any multi-chunk, non-table owner below SPLIT_VERSION -- gdrive
             (file_id), gmail (message_id), anarlog (session_id), calendar
             (event_id); a legacy chunk with no chunk_total counts as
             multi-chunk when its owner has more than one such chunk.
        The already-queued exclusion is IN the query, before LIMIT: filtered
        afterwards, a window of stuck (backing-off) items would fill every
        rule's LIMIT with owners that are then discarded, and the seed would
        stall with real candidates left.

        `sources`, when given, restricts the rules to those reflow sources --
        again in the query, so an unavailable source's owners cannot fill the
        LIMIT.

        hold_recent_ordinary (default True, what the SEED wants): an owner
        whose reflow_owners outcome is 'ordinary' and less than 24 h old is
        also excluded in the query (loop guard: it gets one retry a day, not
        one per cycle). Counting callers must pass False -- or use
        reflow_live_counts -- because a held owner is NOT done: the ordinary
        path failed to converge it, and hiding it would let the backlog read
        empty (and the end-of-backlog integrity check fire) while it is
        stuck."""
        from mcpbrain.chunking import SPLIT_VERSION
        from mcpbrain.sync.blocks import EXTRACTION_VERSIONS
        if limit <= 0:
            return []
        mimes = list(EXTRACTION_VERSIONS)
        mph = ",".join("?" * len(mimes))
        case_args = [x for m in mimes for x in (m, EXTRACTION_VERSIONS[m])]

        def case(expr: str) -> str:
            return f"CASE {expr} " + " ".join("WHEN ? THEN ?" for _ in mimes) + " ELSE 0 END"

        st, xv, sv = (_meta_extract("$.source_type"), _meta_extract("$.extraction_version"),
                      _meta_extract("$.split_version"))
        total, sub = _meta_extract("$.chunk_total"), _meta_extract("$.content_subtype")
        mime, amime = _meta_extract("$.mime_type"), _meta_extract("$.attachment_mime")
        rules = [
            ("reflow:drive", "$.file_id",
             f"{st}='gdrive' AND {mime} IN ({mph}) AND COALESCE({xv},0) < {case(mime)}",
             mimes + case_args),
            ("reflow:gmail", "$.message_id",
             f"{st}='gmail' AND {amime} IN ({mph}) AND COALESCE({xv},0) < {case(amime)}",
             mimes + case_args),
        ]
        for src, stype, fld in (("reflow:drive", "gdrive", "$.file_id"),
                                ("reflow:gmail", "gmail", "$.message_id"),
                                ("reflow:anarlog", "anarlog", "$.session_id"),
                                ("reflow:calendar", "calendar", "$.event_id")):
            rules.append((src, fld,
                          f"{st}=? AND COALESCE({sv},0) < ? AND {total} > 1 "
                          f"AND COALESCE({sub},'') != 'table'",
                          [stype, SPLIT_VERSION]))
            # Legacy chunks carry no chunk_total at all: count the owner's
            # chunks instead (an owner with one such chunk was never split).
            rules.append((src, fld,
                          f"{st}=? AND COALESCE({sv},0) < ? AND {total} IS NULL "
                          f"AND COALESCE({sub},'') != 'table'",
                          [stype, SPLIT_VERSION], "HAVING count(*) > 1"))
        out: list[tuple[str, str]] = []
        seen: set[tuple[str, str]] = set()
        if sources is not None:
            rules = [r for r in rules if r[0] in sources]
        # Loop guard: an owner the reflow routed to the ORDINARY path within
        # the last 24 h is not re-seeded yet. The ordinary path is supposed to
        # write current-version chunks; when it cannot (a stale peer artifact,
        # an extractor that still yields old shape) re-seeding every cycle is a
        # tight re-fetch loop that also keeps the backlog from ever reaching
        # zero. One retry a day, not one a cycle.
        cutoff = self._reflow_hold_cutoff()
        with self._connect() as db:
            for src, fld, where, args, *having in rules:
                owner = _meta_extract(fld)
                tail = f"GROUP BY {owner} {having[0]} " if having else ""
                pick = f"{owner} AS o" if having else f"DISTINCT {owner} AS o"
                hold, hold_args = "", []
                if hold_recent_ordinary:
                    hold = (f"AND {owner} NOT IN (SELECT owner FROM reflow_owners "
                            f"WHERE outcome='ordinary' AND source=? AND at > ?) ")
                    hold_args = [src.split(":", 1)[1], cutoff]
                for r in db.execute(
                        f"SELECT {pick} FROM chunks WHERE {where} "
                        f"AND {owner} IS NOT NULL AND {owner} != '' "
                        f"AND {owner} NOT IN (SELECT ref_id FROM sync_queue "
                        f"WHERE source LIKE 'reflow:%') "
                        f"{hold}{tail}LIMIT ?",
                        [*args, *hold_args, limit]):
                    key = (src, str(r["o"]))
                    if key in seen:
                        continue
                    seen.add(key)
                    out.append(key)
                    if len(out) >= limit:
                        return out
        return out

    def enqueue_and_advance(self, items, *, source: str, cursor: str) -> int:
        """UPSERT queue rows and advance this source's cursor in ONE transaction.

        THE invariant of the sync redesign: the cursor can never be ahead of
        what is recorded. Discovery advances per PAGE rather than per completed
        round, which is what makes a budget cutoff free -- the next cycle
        resumes at the last committed page and re-does nothing.

        A differing `version` on an existing row resets attempts/backoff: a
        genuinely new edit is new work, not a continuation of a failing one.
        """
        now = datetime.now(timezone.utc).isoformat()
        with self._connect(write=True) as db:
            for it in items:
                db.execute(
                    "INSERT INTO sync_queue(source, ref_id, version, event, "
                    "  modified_at, discovered_at) VALUES(?,?,?,?,?,?) "
                    "ON CONFLICT(source, ref_id) DO UPDATE SET "
                    "  event=excluded.event, modified_at=excluded.modified_at, "
                    "  attempts=CASE WHEN sync_queue.version=excluded.version "
                    "                THEN sync_queue.attempts ELSE 0 END, "
                    "  next_attempt_at=CASE WHEN sync_queue.version=excluded.version "
                    "                       THEN sync_queue.next_attempt_at ELSE NULL END, "
                    "  last_error=CASE WHEN sync_queue.version=excluded.version "
                    "                  THEN sync_queue.last_error ELSE '' END, "
                    "  version=excluded.version",
                    (source, it["ref_id"], it.get("version", ""), it["event"],
                     it["modified_at"], now))
            db.execute(
                "INSERT INTO sync_cursors(source, cursor, updated_at) VALUES(?,?,?) "
                "ON CONFLICT(source) DO UPDATE SET cursor=excluded.cursor, "
                "updated_at=excluded.updated_at",
                (source, str(cursor), now))
        return len(items)

    def record_pending_publish(self, drive_id: str, file_id: str,
                               content_hash: str) -> None:
        """A file was extracted locally and needs sharing to the fleet cache
        once its chunks are embedded. UPSERT: a later call for the same file
        replaces the hash -- only the latest version should ever publish."""
        with self._connect(write=True) as db:
            db.execute(
                "INSERT INTO shared_drive_pending_publish"
                "(drive_id, file_id, content_hash, discovered_at) VALUES(?,?,?,?) "
                "ON CONFLICT(drive_id, file_id) DO UPDATE SET "
                "  content_hash=excluded.content_hash, "
                "  discovered_at=excluded.discovered_at",
                (drive_id, file_id, content_hash, datetime.now(timezone.utc).isoformat()))

    def pending_publishes(self, drive_id: str) -> list[tuple[str, str]]:
        """(file_id, content_hash) pairs awaiting publish for one drive --
        the exact shape _publish_drive_misses's `misses` parameter expects."""
        with self._connect() as db:
            return [(r["file_id"], r["content_hash"]) for r in db.execute(
                "SELECT file_id, content_hash FROM shared_drive_pending_publish "
                "WHERE drive_id=?", (drive_id,)).fetchall()]

    def clear_pending_publish(self, drive_id: str, file_id: str) -> None:
        with self._connect(write=True) as db:
            db.execute("DELETE FROM shared_drive_pending_publish "
                       "WHERE drive_id=? AND file_id=?", (drive_id, file_id))

    def sync_queue_pending(self, source: str | None = None) -> int:
        """Rows still to be worked. Presence is pending, so this is a count."""
        with self._connect() as db:
            if source is None:
                return db.execute("SELECT count(*) FROM sync_queue").fetchone()[0]
            return db.execute("SELECT count(*) FROM sync_queue WHERE source=?",
                              (source,)).fetchone()[0]

    def due_sync_items(self, *, limit: int, now: str, sources=None,
                       exclude=None) -> list[dict]:
        """Queue rows ready to work, newest-first. A PURE READ -- no lease.

        The daemon is the only worker and holds the single-writer lock, and a
        crash mid-item leaves the row present (deletion happens only on
        success), so a claim/lease would be machinery with no failure to catch.

        Filtering on next_attempt_at is what makes "retry forever" safe: a
        backed-off item is simply not selected, so it can never sit at the head
        of the queue and stall everything behind it.

        `sources` (prefixes, e.g. ("drive",)) narrows the selection to those
        sources and their `<prefix>:<id>` sub-sources -- a per-source sync.
        `exclude` (prefixes, same matching) leaves those rows out entirely --
        a switched-off source, whose rows must neither be worked nor take a
        slot of `limit` from the sources still on.
        """
        where = "(next_attempt_at IS NULL OR next_attempt_at <= ?)"
        args: list = [now]

        def _match(prefs):
            nonlocal args
            for p in prefs:
                args += [p, len(p) + 1, p + ":"]
            return " OR ".join("source = ? OR substr(source, 1, ?) = ?" for _ in prefs)
        if sources:
            where += " AND (" + _match([str(p) for p in sources]) + ")"
        if exclude:
            where += " AND NOT (" + _match([str(p) for p in exclude]) + ")"
        with self._connect() as db:
            return [dict(r) for r in db.execute(
                "SELECT source, ref_id, version, event, modified_at, discovered_at, "
                "       attempts, next_attempt_at, last_error, transient_defers "
                f"FROM sync_queue WHERE {where} "
                "ORDER BY modified_at DESC LIMIT ?", (*args, limit)).fetchall()]

    def complete_sync_item(self, source: str, ref_id: str) -> None:
        """Delete the queue row, marking the item done.

        Delivery is AT-LEAST-ONCE, not exactly-once: a crash between the
        handler's chunk write and this call leaves the row queued, so the item
        is re-worked next cycle. That is safe because the handlers are
        idempotent -- upsert_file_chunks keys on positional gdrive-<fid>-<i>
        doc_ids and reconciles orphans, so re-working converges on the same
        state. The crash window resume_ids papered over still exists; it is now
        harmless rather than lossy.
        """
        with self._connect(write=True) as db:
            db.execute("DELETE FROM sync_queue WHERE source=? AND ref_id=?",
                       (source, ref_id))

    def fail_sync_item(self, source: str, ref_id: str, error: str, *,
                       now: str) -> int:
        """Record a failed attempt and schedule the next one. Returns attempts.

        The row is never deleted: retry-forever with a capped backoff. Safe only
        because due_sync_items filters on next_attempt_at, so this row cannot
        block the queue behind it.

        Resets `transient_defers` to 0: this call IS a recorded failure (a
        genuinely non-transient error, or a transient run that just escalated
        past reflow_handler's bound), so the next transient run -- if any --
        starts counting fresh rather than inheriting this one's tally.
        """
        with self._connect(write=True) as db:
            row = db.execute("SELECT attempts FROM sync_queue "
                             "WHERE source=? AND ref_id=?",
                             (source, ref_id)).fetchone()
            if row is None:
                return 0
            attempts = int(row["attempts"]) + 1
            delay = _SYNC_BACKOFF_S[min(attempts, len(_SYNC_BACKOFF_S)) - 1]
            nxt = (datetime.fromisoformat(now) + timedelta(seconds=delay)).isoformat()
            db.execute("UPDATE sync_queue SET attempts=?, next_attempt_at=?, "
                       "last_error=?, transient_defers=0 WHERE source=? AND ref_id=?",
                       (attempts, nxt, str(error)[:200], source, ref_id))
        return attempts

    def defer_sync_item(self, source: str, ref_id: str, until: str) -> bool:
        """Push a queue row's next_attempt_at to `until` WITHOUT counting a
        failed attempt (attempts and last_error untouched). For a handler that
        cannot work an item yet for a reason that is not the item's fault (an
        in-flight enrichment unit names it, its service is unavailable, the
        reflow cadence is halted): without a delay such rows are re-selected
        every cycle and, sharing one modified_at, hold the head of the queue.
        Returns False if the row does not exist."""
        with self._connect(write=True) as db:
            return db.execute("UPDATE sync_queue SET next_attempt_at=? "
                              "WHERE source=? AND ref_id=?",
                              (until, source, ref_id)).rowcount > 0

    def defer_sync_item_transient(self, source: str, ref_id: str, until: str) -> int:
        """Like `defer_sync_item`, but also counts this defer toward a durable
        run of consecutive TRANSIENT outcomes for the row (rate limit / gateway
        / network -- reflow_handler is the only caller today). Returns the
        row's `transient_defers` count AFTER this call (0 if the row does not
        exist), so the caller can compare it against its own give-up bound and
        escalate to `fail_sync_item` once crossed. `fail_sync_item` is what
        resets the count back to 0."""
        with self._connect(write=True) as db:
            cur = db.execute(
                "UPDATE sync_queue SET next_attempt_at=?, "
                "transient_defers=transient_defers+1 WHERE source=? AND ref_id=?",
                (until, source, ref_id))
            if cur.rowcount == 0:
                return 0
            row = db.execute("SELECT transient_defers FROM sync_queue "
                             "WHERE source=? AND ref_id=?",
                             (source, ref_id)).fetchone()
            return int(row["transient_defers"])

    def sync_queue_stats(self) -> dict:
        """Backlog as a fact, for doctor. `failing` is advisory, not terminal --
        those rows are still retrying."""
        with self._connect() as db:
            pending = db.execute("SELECT count(*) FROM sync_queue").fetchone()[0]
            oldest = db.execute(
                "SELECT min(discovered_at) FROM sync_queue").fetchone()[0]
            failing = [dict(r) for r in db.execute(
                "SELECT source, ref_id, attempts, last_error FROM sync_queue "
                "WHERE attempts >= ? ORDER BY attempts DESC LIMIT 5",
                (_SYNC_FAILING_ATTEMPTS,)).fetchall()]
        return {"pending": pending, "oldest_discovered_at": oldest,
                "failing": failing}

    # --- generic meta accessors -------------------------------------------

    def set_meta(self, k: str, v: str) -> None:
        """Insert or replace a key/value pair in the meta table."""
        with self._connect(write=True) as db:
            db.execute("INSERT OR REPLACE INTO meta(k, v) VALUES(?, ?)", (k, v))

    def get_meta(self, k: str) -> str | None:
        """Return the value for key k, or None if absent."""
        with self._connect() as db:
            r = db.execute("SELECT v FROM meta WHERE k=?", (k,)).fetchone()
            return r["v"] if r else None

    def delete_meta(self, k: str) -> None:
        """Delete the row for key k. No-op (does not raise) if absent."""
        with self._connect(write=True) as db:
            db.execute("DELETE FROM meta WHERE k=?", (k,))

    # --- enrichment graph writers (Task 4.2) ------------------------------

    def upsert_entity(self, ent_id, name, entity_type, org="", seen="", *,
                      bump_mentions: bool = True) -> bool:
        """Insert or merge an entity. Returns True if a NEW row was created,
        False if an existing entity was merged into.

        bump_mentions=False (graph_write.apply): mentions is NOT counted per
        call — apply bumps it only when a new primary-source link is written,
        so a re-extracted thread or a derived note adds nothing (spec
        2026-10-22 §3). A new row then starts at 0."""
        # Single-writer invariant: this SELECT + upsert is race-free only because
        # the daemon is the sole writer. Do not call concurrently.
        start, step = (1, 1) if bump_mentions else (0, 0)
        with self._connect(write=True) as db:
            existed = db.execute(
                "SELECT 1 FROM entities WHERE id=?", (ent_id,)).fetchone() is not None
            db.execute(
                f"""INSERT INTO entities(id, name, type, org, first_seen, last_seen, mentions)
                   VALUES(?,?,?,?,?,?,{start})
                   ON CONFLICT(id) DO UPDATE SET
                       first_seen = CASE WHEN entities.first_seen = '' THEN excluded.first_seen ELSE entities.first_seen END,
                       last_seen  = MAX(last_seen, excluded.last_seen),
                       mentions   = mentions + {step},
                       name       = CASE WHEN name = '' AND NOT EXISTS (SELECT 1 FROM entity_field_locks
                                        WHERE entity_id = entities.id AND field = 'name')
                                    THEN excluded.name ELSE name END,
                       org        = CASE WHEN org  = '' AND NOT EXISTS (SELECT 1 FROM entity_field_locks
                                        WHERE entity_id = entities.id AND field = 'org')
                                    THEN excluded.org  ELSE org  END,
                       type       = CASE WHEN type = 'unknown' THEN excluded.type ELSE type END""",
                (ent_id, name, entity_type, org, seen, seen))
            return not existed

    def upsert_topic_entity(self, tag: str) -> str | None:
        """Insert or bump a topic entity (id 'topic-<slug>', type 'topic').

        Ported from memory_db.py:1720-1745. Tags under 2 chars (after collapse)
        return None and write nothing. A new topic starts at email_count=0;
        a call on an existing one refreshes last_seen only. email_count is
        driven by the caller's NEW primary-source link rows (graph_write.apply
        bumps it when link_email_entity inserts), so it counts distinct
        messages — it used to be bumped on every call while the link insert
        was ignored, so a re-applied thread counted again (spec 2026-10-22
        §3). Returns the entity id both times.
        """
        tag = re.sub(r"\s+", " ", (tag or "").strip().lower())
        if len(tag) < 2:
            return None
        eid = slugify(f"topic-{tag}")
        if not eid:
            return None
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        with self._connect(write=True) as db:
            existing = db.execute("SELECT 1 FROM entities WHERE id=?", (eid,)).fetchone()
            if existing:
                db.execute("UPDATE entities SET last_seen = ? WHERE id = ?", (today, eid))
            else:
                db.execute(
                    "INSERT INTO entities(id, name, type, org, first_seen, last_seen, email_count) "
                    "VALUES(?,?,'topic','',?,?,0)",
                    (eid, tag, today, today))
        return eid

    def append_occurrence(self, entity_id, valid_from, value, source) -> bool:
        """Append one occurrence row to entity_observations, idempotently.

        Occurrences are ACCUMULATING facts (a recurring meeting's instances), not a
        superseding attribute, so this deliberately does NOT go through
        graph_write.write_observation (which retires prior same-source rows). Keyed
        for idempotency on (entity_id, 'occurrence', valid_from, source): re-applying
        a thread must not duplicate the row. Single-writer daemon, so SELECT-then-
        INSERT is race-free. Returns True on insert, False when the row already
        exists.
        """
        with self._connect(write=True) as db:
            exists = db.execute(
                "SELECT 1 FROM entity_observations "
                "WHERE entity_id=? AND attribute='occurrence' AND valid_from=? AND source=?",
                (entity_id, valid_from, source)).fetchone()
            if exists:
                return False
            db.execute(
                "INSERT INTO entity_observations "
                "(entity_id, attribute, value, source, valid_from, confidence_source) "
                "VALUES (?, 'occurrence', ?, ?, ?, 'llm_extraction')",
                (entity_id, value, source, valid_from))
        return True

    def add_relation(self, entity_a, relation, entity_b, source_doc_id="") -> bool:
        """Insert a relation triple. Returns True if a new row was inserted,
        False if the (entity_a, relation, entity_b) triple already existed."""
        with self._connect(write=True) as db:
            cursor = db.execute(
                "INSERT OR IGNORE INTO entity_relations(entity_a, relation, entity_b, source_doc_id) "
                "VALUES(?,?,?,?)",
                (entity_a, relation, entity_b, source_doc_id))
            return cursor.rowcount == 1

    def upsert_email_context(self, message_id, *, subject="", sender="",
                             sender_email="", sender_id="", date_str="",
                             date_iso="", thread_id="", org="", content_type="",
                             summary="", topics="", enriched_at="", labels="",
                             contextual_summary="", reply_needed=0,
                             reply_reason="") -> None:
        """Insert or update the email_context row for a message.

        Ported from doc_db.upsert_email_context (doc_db.py:406-444), with the two
        triage signals (reply_needed, reply_reason) folded on per the mcpbrain
        schema. The org is written as-passed: callers canonicalise via
        graph_write.canonical_org before calling (store stays decoupled from the
        org map). On conflict, the situational fields refresh; identity columns
        (sender, date) are left as first written.
        """
        with self._connect(write=True) as db:
            db.execute(
                """INSERT INTO email_context
                   (message_id, subject, sender, sender_email, sender_id, date_str,
                    date_iso, thread_id, org, content_type, summary, topics,
                    enriched_at, labels, contextual_summary, reply_needed, reply_reason)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(message_id) DO UPDATE SET
                     org                = excluded.org,
                     content_type       = excluded.content_type,
                     summary            = excluded.summary,
                     topics             = excluded.topics,
                     enriched_at        = excluded.enriched_at,
                     labels             = excluded.labels,
                     contextual_summary = excluded.contextual_summary,
                     reply_needed       = excluded.reply_needed,
                     reply_reason       = excluded.reply_reason""",
                (message_id, subject, sender, sender_email, sender_id, date_str,
                 date_iso, thread_id, org, content_type, summary, topics,
                 enriched_at or datetime.now(timezone.utc).strftime("%Y-%m-%d"),
                 labels, contextual_summary, 1 if reply_needed else 0, reply_reason))

    def link_email_entity(self, message_id, entity_id, role="", *,
                          derived: bool = False) -> bool:
        """Link an entity to a message. Ported from doc_db.py:447-453.

        Keyed (message_id, entity_id); INSERT OR IGNORE so re-linking the same
        pair is a no-op (role is set on first link only). Returns True when a new
        link row was created, False when the pair already existed — callers use
        this to drive email_count, so the link table is the single source of
        truth for how many distinct messages an entity appears in.

        derived=True: the message is a non-evidence source (mcpbrain's own
        note, a brief, a draft); the row is written derived=1 and callers do
        NOT count it toward email_count/mentions.
        """
        with self._connect(write=True) as db:
            cur = db.execute(
                "INSERT OR IGNORE INTO email_entities (message_id, entity_id, role, derived) "
                "VALUES (?, ?, ?, ?)",
                (message_id, entity_id, role, 1 if derived else 0))
            if cur.rowcount > 0:
                return True
            if derived:
                return False
            # The source came back: a link a removal marked derived is
            # evidence again (only removal reasons revive; Task 7's
            # derived-class links keep derived_reason NULL).
            rev = db.execute(
                "UPDATE email_entities SET derived=0, derived_reason=NULL "
                "WHERE message_id=? AND entity_id=? AND derived=1 "
                "AND derived_reason IN ('source_gone','drive_revoked','infra_purged')",
                (message_id, entity_id))
            return rev.rowcount > 0

    def merge_entities(self, loser_id, winner_id, *, canonical_name=None,
                       method="deterministic", change: dict | None = None) -> dict | None:
        """Fold loser into winner, keeping the winner's id stable.

        The winner id is never re-slugged: relations reference ids, so changing
        it would orphan them. Relations are repointed onto the winner with
        UPDATE OR IGNORE (the UNIQUE(entity_a,relation,entity_b) constraint drops
        rows that would duplicate an existing winner triple); leftover loser rows
        and any self-loops the repoint created are then deleted. Scalars take the
        winner's value unless it's a stub (org "" / "unknown", type "unknown"),
        in which case the loser's value wins; mentions are summed. One
        transaction. Loser==winner or a missing id is a no-op.

        Returns the undo snapshot from _merge_entities_tx (None for a no-op);
        existing callers ignore it. The body lives in _merge_entities_tx so a
        caller holding its own write transaction (the corrections applier) can
        merge and record the snapshot atomically.
        """
        if loser_id == winner_id:
            return None  # no-op without taking the write lock, as before
        with self._connect(write=True) as db:
            snap = _merge_entities_tx(db, loser_id, winner_id,
                                      canonical_name=canonical_name, method=method)
            if snap is not None and change is not None:
                # The snapshot is what _unmerge_tx reverses; its merge_log_id
                # tells undo whether the merge still stands.
                _log_recorded_change(
                    db, change, winner_id, {"snapshot": snap},
                    {"winner_id": winner_id, "loser_id": loser_id,
                     "merge_log_id": snap["merge_log_id"]})
            return snap

    # --- unified actions table (Task 1.7) ---------------------------------

    def add_unified_action(self, *, text, owner="", owner_entity_id="",
                           status="open", deadline="", org="", project_id="",
                           area_id="", confidence=1.0, source="email",
                           context_tag="", cluster_id="", source_doc_id="",
                           thread_id="", text_fingerprint="", waiting_on="",
                           waiting_on_entity_id="", waiting_on_set_at="",
                           created_at="", clickup_task_id="",
                           priority="") -> int:
        """Insert a row into the unified actions table. Returns the new id.

        waiting_on* mark an action as awaiting a reply from a person (cleared by
        the waiting-on reconciler when that person's chunk arrives). created_at,
        when given, overrides the CURRENT_TIMESTAMP default so a caller with an
        injected clock (apply's `now`) keeps the near-duplicate window aligned
        with the clock the gates use. clickup_task_id and priority, when given,
        are set atomically on insert so callers like import_baseline avoid a
        separate update_action_fields call.
        """
        cols = ["text", "owner", "owner_entity_id", "status", "deadline", "org",
                "project_id", "area_id", "confidence", "source", "context_tag",
                "cluster_id", "source_doc_id", "thread_id", "text_fingerprint",
                "waiting_on", "waiting_on_entity_id", "waiting_on_set_at"]
        vals = [text, owner, owner_entity_id, status, deadline, org, project_id,
                area_id, confidence, source, context_tag, cluster_id,
                source_doc_id, thread_id, text_fingerprint,
                waiting_on or None, waiting_on_entity_id or None,
                waiting_on_set_at or None]
        if created_at:
            cols.append("created_at")
            vals.append(created_at)
        if clickup_task_id:
            cols.append("clickup_task_id")
            vals.append(clickup_task_id)
        if priority:
            cols.append("priority")
            vals.append(priority)
        placeholders = ",".join("?" * len(cols))
        with self._connect(write=True) as db:
            cur = db.execute(
                f"INSERT INTO actions({','.join(cols)}) VALUES({placeholders})",
                vals)
            return cur.lastrowid

    def set_action_status(self, action_id: int, status: str,
                          resolved_by: str = "", *, thread_id: str | None = None,
                          only_if_open: bool = False, change: dict | None = None) -> int:
        """Close or reopen a unified action. Returns the number of rows changed.

        Ported from knowledge_db/memory_db.update_action_status (memory_db.py:1346-1375),
        stripped of the ClickUp sync path (out of scope for Phase 1). Sets
        resolved_at when closing, clears it when reopening, and refreshes
        updated_at.

        thread_id / only_if_open scope the update: an LLM-supplied
        resolved_action_id should only close an OPEN action belonging to the
        thread that raised it, never an arbitrary or already-closed row. The
        rowcount lets the caller log a miss instead of silently re-stamping.

        change: when given, the prior status is read on this connection and an
        undoable change_log row is written with the write (only on a hit).
        """
        resolved_at = "" if status == "open" else datetime.now(timezone.utc).strftime(
            "%Y-%m-%dT%H:%M:%SZ")
        where = ["id = ?"]
        params: list = [status, resolved_by, resolved_at,
                        datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                        action_id]
        if only_if_open:
            where.append("status = 'open'")
        if thread_id is not None:
            where.append("thread_id = ?")
            params.append(thread_id)
        with self._connect(write=True) as db:
            prior = db.execute(
                "SELECT status, resolved_by, resolved_at FROM actions WHERE id = ?",
                (action_id,)).fetchone() if change is not None else None
            cur = db.execute(
                f"UPDATE actions SET status = ?, resolved_by = ?, resolved_at = ?, "
                f"updated_at = ? WHERE {' AND '.join(where)}", params)
            if cur.rowcount > 0 and prior is not None:
                _log_recorded_change(
                    db, change, action_id,
                    {"status": prior["status"] or "", "resolved_by": prior["resolved_by"] or "",
                     "resolved_at": prior["resolved_at"] or ""},
                    {"status": status, "resolved_by": resolved_by,
                     "resolved_at": resolved_at})
            return cur.rowcount

    def archive_stale_actions(self, *, cutoff_days: int = 120,
                              overdue_cutoff_days: int = 730,
                              as_of: str | None = None,
                              dry_run: bool = False) -> dict:
        """Archive (never delete) stale open actions, on two independent rules.

        Reversible: an eligible action's status flips to 'auto_archived' —
        reopen it any time via set_action_status. Never touches a row that is
        already closed, and never a row snoozed to a future date (a deferred
        task resurfaces on its snooze date and must not be archived out from
        under that). Idempotent. `as_of` (ISO) is for tests.

        Rule 1 — UNDATED by age (resolved_by='ttl'), cutoff_days:
          no deadline at all, and of KNOWN age captured before the cutoff
          (empty/NULL created_at means unknown age and is left alone).

        Rule 2 — DATED but long dead (resolved_by='ttl_overdue'),
        overdue_cutoff_days: a deadline this far in the past is not a follow-up,
        it is debris — the live store carried open actions dated 2018-2023.
        A merely-recent slip is still spared, deliberately: an overdue task is
        normally high-signal, so this cutoff is far more generous than Rule 1's
        (default 2 years vs 120 days). Future deadlines are never eligible.

        Returns {'archived': n} (or {'candidates': n, 'ids': [...]} for dry_run),
        combining both rules.
        """
        now = (datetime.now(timezone.utc) if as_of is None
               else datetime.fromisoformat(as_of.replace("Z", "+00:00")))
        cutoff = (now - timedelta(days=int(cutoff_days))).strftime("%Y-%m-%d")
        dead_by = (now - timedelta(days=int(overdue_cutoff_days))).strftime("%Y-%m-%d")
        today = now.strftime("%Y-%m-%d")
        stamp = now.strftime("%Y-%m-%dT%H:%M:%SZ")   # match set_action_status's ISO format
        _live = ("status = 'open' AND (COALESCE(snoozed_until, '') = '' "
                 "OR substr(snoozed_until, 1, 10) < :today)")
        undated = (f"{_live} "
                   "AND COALESCE(created_at, '') != '' "
                   "AND substr(created_at, 1, 10) < :cutoff "
                   "AND COALESCE(deadline, '') = ''")
        long_dead = (f"{_live} "
                     "AND COALESCE(deadline, '') != '' "
                     "AND substr(deadline, 1, 10) < :dead_by")
        params = {"cutoff": cutoff, "dead_by": dead_by, "today": today}

        def _ids(db, where):
            return [r["id"] for r in db.execute(
                f"SELECT id FROM actions WHERE {where}", params).fetchall()]

        if dry_run:
            # Read-only: no mutation happens on this path, so don't take the
            # write lock (BEGIN IMMEDIATE) just to answer "what would this do".
            with self._connect() as db:
                todo = [("ttl", undated, _ids(db, undated)),
                        ("ttl_overdue", long_dead, _ids(db, long_dead))]
            total = sum(len(ids) for _, _, ids in todo)
            merged = [i for _, _, ids in todo for i in ids]
            return {"candidates": total, "ids": merged[:20]}

        with self._connect(write=True) as db:
            todo = [("ttl", undated, _ids(db, undated)),
                    ("ttl_overdue", long_dead, _ids(db, long_dead))]
            total = sum(len(ids) for _, _, ids in todo)
            for marker, where, ids in todo:
                if not ids:
                    continue
                db.execute(
                    f"UPDATE actions SET status = 'auto_archived', resolved_by = '{marker}', "
                    f"resolved_at = :stamp, updated_at = :stamp WHERE {where}",
                    {**params, "stamp": stamp})
            return {"archived": total}

    def archive_duplicate_actions(self, *, as_of: str | None = None,
                                  dry_run: bool = False) -> dict:
        """Collapse exact-duplicate OPEN actions, keeping the earliest row.

        Write-time dedup (find_open_action_by_fingerprint) is supposed to prevent
        these, but the live store still accumulated 424 redundant open rows across
        390 fingerprint groups — the same commitment re-extracted from a second
        email, each copy burning a slot in every actions surface. This is the
        sweep-up for what already got through.

        Groups on text_fingerprint and keeps MIN(id) — the original — archiving
        the rest as 'auto_archived' with resolved_by='dedup' (reversible).
        Rows with a BLANK fingerprint are never grouped: many unrelated actions
        share an empty string, so treating that as a group would archive most of
        the table. Only 'open' rows are considered, so an already-closed twin is
        not competition for a live one.

        Returns {'archived': n} (or {'candidates': n, 'ids': [...]} for dry_run).
        """
        now = (datetime.now(timezone.utc) if as_of is None
               else datetime.fromisoformat(as_of.replace("Z", "+00:00")))
        stamp = now.strftime("%Y-%m-%dT%H:%M:%SZ")
        # Every open, fingerprinted row that is NOT the earliest of its group.
        _fp_open = "status = 'open' AND COALESCE(text_fingerprint, '') != ''"
        where = (f"{_fp_open} AND id NOT IN "
                 f"(SELECT MIN(id) FROM actions WHERE {_fp_open} GROUP BY text_fingerprint)")
        if dry_run:
            # Read-only: no mutation happens on this path, so don't take the
            # write lock (BEGIN IMMEDIATE) just to answer "what would this do".
            with self._connect() as db:
                ids = [r["id"] for r in db.execute(
                    f"SELECT id FROM actions WHERE {where}").fetchall()]
            return {"candidates": len(ids), "ids": ids[:20]}

        with self._connect(write=True) as db:
            ids = [r["id"] for r in db.execute(
                f"SELECT id FROM actions WHERE {where}").fetchall()]
            if not ids:
                return {"archived": 0}
            db.execute(
                f"UPDATE actions SET status = 'auto_archived', resolved_by = 'dedup', "
                f"resolved_at = :stamp, updated_at = :stamp WHERE {where}",
                {"stamp": stamp})
            return {"archived": len(ids)}

    def assign_action_owner(self, action_id: int, owner: str, owner_entity_id: str = "",
                            *, change: dict | None = None) -> bool:
        """Set owner/owner_entity_id on one action. Returns True if a row was actually updated.

        Used by the ownerless-action review applier (Session-4, Task 3.1): a
        rowcount check so a stale/nonexistent action_id (e.g. resolved or
        deleted between detection and verdict) is reported as a no-op miss
        rather than a phantom success.

        change: when given, the prior owner is read on this connection and an
        undoable change_log row is written with the write.
        """
        with self._connect(write=True) as db:
            prior = db.execute("SELECT owner, owner_entity_id FROM actions WHERE id=?",
                               (action_id,)).fetchone() if change is not None else None
            cur = db.execute(
                "UPDATE actions SET owner=?, owner_entity_id=? WHERE id=?",
                (owner, owner_entity_id, action_id))
            if cur.rowcount > 0 and prior is not None:
                _log_recorded_change(
                    db, change, action_id,
                    {"owner": prior["owner"] or "",
                     "owner_entity_id": prior["owner_entity_id"] or ""},
                    {"owner": owner, "owner_entity_id": owner_entity_id})
            return cur.rowcount > 0

    def snooze_action(self, action_id: int, until_iso: str) -> bool:
        """Snooze an OPEN action until until_iso (a YYYY-MM-DD date).

        The dashboard listing hides a snoozed action until today reaches
        until_iso, then it reappears automatically. Only open actions can be
        snoozed: a missing or closed row is a no-op.

        until_iso must parse as an ISO date — date.fromisoformat raises
        ValueError on garbage, which the control API maps to a 400 (distinct
        from the 404 a missing/closed row returns False for). Returns True only
        when a row was updated, and records the prior snoozed_until in the
        change_log revert_ref so the snooze can be undone.
        """
        date.fromisoformat(until_iso)  # raises ValueError on a non-date string
        # The UPDATE's status='open' predicate, not a prior SELECT, decides
        # whether the row is snoozable — so a concurrent close on another
        # ThreadingHTTPServer thread can't be clobbered and a closed/missing
        # row never gains a snooze or a change_log entry. The prior-value read
        # for revert_ref shares the same connection (single SQLite write-lock
        # window), and record_change runs only when rowcount confirms a hit.
        with self._connect(write=True) as db:
            row = db.execute(
                "SELECT snoozed_until FROM actions WHERE id = ?",
                (action_id,)).fetchone()
            prev = (row["snoozed_until"] if row else "") or ""
            cur = db.execute(
                "UPDATE actions SET snoozed_until = ?, updated_at = ? "
                "WHERE id = ? AND status = 'open'",
                (until_iso,
                 datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                 action_id))
            if cur.rowcount == 0:
                return False
        self.record_change(
            "action_snoozed", ref_id=str(action_id),
            summary=f"Snoozed action {action_id} until {until_iso}",
            revert_ref=f"snoozed_until:{prev}", source="dashboard")
        return True

    def set_action_text(self, action_id: int, new_text: str, *,
                        thread_id: str | None = None,
                        only_if_open: bool = False) -> int:
        """Rewrite a unified action's text. Returns the number of rows changed.

        Ported from update_action_text (memory_db.py:1411-1421). Also refreshes
        the text_fingerprint so later near-duplicate checks see the new text, and
        bumps updated_at. thread_id / only_if_open scope the update the same way
        set_action_status does, for the same reason.
        """
        where = ["id = ?"]
        params: list = [new_text, _action_fingerprint(new_text),
                        datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                        action_id]
        if only_if_open:
            where.append("status = 'open'")
        if thread_id is not None:
            where.append("thread_id = ?")
            params.append(thread_id)
        with self._connect(write=True) as db:
            cur = db.execute(
                f"UPDATE actions SET text = ?, text_fingerprint = ?, updated_at = ? "
                f"WHERE {' AND '.join(where)}", params)
            return cur.rowcount

    # --- ClickUp sync (2026-06-08) ----------------------------------------

    def set_action_clickup_id(self, action_id: int, clickup_task_id: str) -> int:
        """Cache the linked ClickUp task id on an action. Returns rows changed."""
        with self._connect(write=True) as db:
            cur = db.execute(
                "UPDATE actions SET clickup_task_id = ?, updated_at = ? WHERE id = ?",
                (clickup_task_id,
                 datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                 action_id))
            return cur.rowcount

    def set_action_clickup_closed(self, action_id: int, closed: bool) -> int:
        """Record the last-observed ClickUp closed-state (bookkeeping for reopen
        detection). Stores 1/0; does not touch updated_at."""
        with self._connect(write=True) as db:
            cur = db.execute(
                "UPDATE actions SET clickup_closed=? WHERE id=?",
                (1 if closed else 0, action_id))
            return cur.rowcount

    def update_action_fields(self, action_id: int, **fields) -> int:
        """Update a whitelisted set of action columns in one statement.

        Used by the ClickUp inbound pass to mirror ClickUp edits (org, deadline,
        priority). Status/text have dedicated methods (they touch resolved_at /
        fingerprint); this handles the plain columns. Unknown keys are ignored.
        Always bumps updated_at. Returns rows changed.
        """
        allowed = {"org", "deadline", "priority", "clickup_task_id",
                   "owner", "owner_entity_id"}
        sets, params = [], []
        for k, v in fields.items():
            if k in allowed:
                sets.append(f"{k} = ?")
                params.append(v)
        if not sets:
            return 0
        sets.append("updated_at = ?")
        params.append(datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"))
        params.append(action_id)
        with self._connect(write=True) as db:
            cur = db.execute(
                f"UPDATE actions SET {', '.join(sets)} WHERE id = ?", params)
            return cur.rowcount

    def action_by_clickup_id(self, clickup_task_id: str) -> dict | None:
        with self._connect() as db:
            r = db.execute("SELECT * FROM actions WHERE clickup_task_id = ?",
                           (clickup_task_id,)).fetchone()
            return dict(r) if r else None

    def get_stale_reextract(self, thread_id: str) -> dict | None:
        """Return the stale-reextract marker row for a thread, or None."""
        with self._connect() as db:
            r = db.execute(
                "SELECT thread_id, signature, triggered_at, superseded_at "
                "FROM stale_reextract WHERE thread_id=?",
                (thread_id,)).fetchone()
            return dict(r) if r else None

    def set_stale_reextract(self, thread_id: str, signature: str,
                            triggered_at: str) -> None:
        """Upsert the marker recording that `thread_id` was re-triggered at the
        given content `signature` and time."""
        with self._connect(write=True) as db:
            db.execute(
                "INSERT OR REPLACE INTO stale_reextract"
                "(thread_id, signature, triggered_at) VALUES(?,?,?)",
                (thread_id, signature, triggered_at))

    def set_enrich_payload(self, file_id: str, payload: str, logic_version: int,
                           covers: list[str] | None = None) -> None:
        """Persist the validated extraction (JSON string) a Drive FILE produced,
        so its shared-drive cache artifact can carry it and importers skip
        re-enrich. One row per file, and publish_file reads exactly one.

        `covers` is the chunk doc_ids the extraction was made from. drain
        always passes it: after a reflow (or across seam-split units) one
        unit's extraction describes only part of the file, and a payload is
        attached to a cache artifact only when it covers every non-cold chunk
        (`enrich_payload_covers_file`). None means "whole file" and exists for
        rows written before the column (and callers that write a whole-file
        payload directly)."""
        with self._connect(write=True) as db:
            db.execute("INSERT OR REPLACE INTO enrich_payloads"
                       "(file_id, payload, logic_version, covers) VALUES(?,?,?,?)",
                       (file_id, payload, int(logic_version),
                        None if covers is None else json.dumps(sorted(set(covers)))))

    def enrich_payload_covers_file(self, file_id: str) -> bool:
        """True when the file's payload was made from every chunk of the file
        that is not cold (a NULL `covers` is a whole-file payload). False when
        there is no payload, and False -- never a raise -- when `covers` is
        malformed (unparseable, not a list, or holding non-strings): fail
        closed, the payload is withheld and the file publishes without it."""
        import logging
        with self._connect() as db:
            r = db.execute("SELECT covers FROM enrich_payloads WHERE file_id=?",
                           (file_id,)).fetchone()
            if r is None:
                return False
            if r["covers"] is None:
                return True
            try:
                covers = json.loads(r["covers"])
            except (TypeError, ValueError):
                covers = None
            if not isinstance(covers, list) or not all(isinstance(x, str) for x in covers):
                logging.getLogger(__name__).debug(
                    "enrich payload %s: malformed covers %r -- withheld", file_id, r["covers"])
                return False
            need = {x[0] for x in db.execute(
                f"SELECT doc_id FROM chunks WHERE {_meta_extract('$.file_id')}=? "
                "AND COALESCE(enrich_state,'')!='cold'", (file_id,))}
        return need <= set(covers)

    def get_enrich_payload(self, file_id: str) -> dict | None:
        with self._connect() as db:
            r = db.execute("SELECT payload, logic_version FROM enrich_payloads "
                           "WHERE file_id=?", (file_id,)).fetchone()
        return {"payload": r["payload"], "logic_version": r["logic_version"]} if r else None

    def migrate_enrich_payloads_batch(self, limit: int = 200) -> dict:
        """Move up to `limit` Drive files' cached payloads out of the legacy
        doc_id-keyed table, deleting the legacy rows as it goes. Drops the
        legacy table once empty. Returns {"migrated", "deleted", "done"}.

        Incremental because the work is genuinely large: on the live store the
        legacy table is 13.5GB, and deleting a row means freeing its overflow
        chain. Runs on the daemon's maintenance cadence, never on init() and
        never inside the backup path.

        THE KEEPER IS THE HIGHEST CHUNK INDEX PER FILE, NOT THE HIGHEST
        logic_version, and that is deliberate. Reading logic_version means
        reading past the `payload` column and traversing the very overflow
        pages this exists to reclaim, whereas ordering on doc_id alone is
        served by the primary-key index. Every row for a file is written in one
        loop and shares a logic_version in the normal case; where they differ
        (the file grew between enrichments) the highest chunk index is the
        newer. Worst case is one cache miss and one re-enrichment -- the table
        is a regenerable cache, not user data.

        The chunk index is compared as a PARSED INT
        (`_chunk_index_from_doc_id`), never as the raw doc_id string: indices
        are unpadded, so string order disagrees with numeric order past 9
        chunks (e.g. "gdrive-F-9" > "gdrive-F-89" lexicographically, even
        though 9 < 89) -- a real case on this codebase's own 2,303-chunk PDF.
        Parsing the trailing digits costs nothing beyond string manipulation;
        it still never touches the `payload` column.
        """
        with self._connect(write=True) as db:
            if db.execute("SELECT count(*) FROM sqlite_schema WHERE type='table' "
                          "AND name='enrich_payloads_legacy'").fetchone()[0] == 0:
                return {"migrated": 0, "deleted": 0, "done": True}

            # doc_id only: covered by the primary-key index, so this does not
            # touch the payload overflow pages.
            doc_ids = [r["doc_id"] for r in db.execute(
                "SELECT doc_id FROM enrich_payloads_legacy ORDER BY doc_id").fetchall()]
            if not doc_ids:
                db.execute("DROP TABLE enrich_payloads_legacy")
                return {"migrated": 0, "deleted": 0, "done": True}

            keeper: dict[str, str] = {}
            keeper_idx: dict[str, int] = {}
            legacy_ids: dict[str, set[str]] = {}
            unkeyed: list[str] = []
            for d in doc_ids:
                fid = _file_key_from_doc_id(d)
                if fid is None:
                    unkeyed.append(d)
                    continue
                legacy_ids.setdefault(fid, set()).add(d)
                idx = _chunk_index_from_doc_id(d)
                if fid not in keeper or idx > keeper_idx[fid]:
                    keeper[fid] = d
                    keeper_idx[fid] = idx

            batch = sorted(keeper.items())[:limit]
            migrated = 0
            for fid, doc_id in batch:
                row = db.execute("SELECT payload, logic_version FROM "
                                 "enrich_payloads_legacy WHERE doc_id=?",
                                 (doc_id,)).fetchone()
                if row is None:
                    continue
                # INSERT OR IGNORE, not REPLACE: a row written since the rename
                # is current and a legacy row for the same file is stale.
                # covers is explicit, never NULL: a legacy payload is trusted
                # as whole-file only when it provably is (below), else it
                # covers nothing and is withheld until drain re-covers it.
                db.execute("INSERT OR IGNORE INTO enrich_payloads"
                           "(file_id, payload, logic_version, covers) VALUES(?,?,?,?)",
                           (fid, row["payload"], row["logic_version"],
                            json.dumps(self._legacy_payload_covers(db, fid, legacy_ids[fid]))))
                migrated += 1

            done_keys = {fid for fid, _ in batch}
            drop = [d for d in doc_ids
                    if (_file_key_from_doc_id(d) in done_keys) or d in unkeyed]
            db.executemany("DELETE FROM enrich_payloads_legacy WHERE doc_id=?",
                           [(d,) for d in drop])

            remaining = db.execute(
                "SELECT count(*) FROM enrich_payloads_legacy").fetchone()[0]
            if remaining == 0:
                db.execute("DROP TABLE enrich_payloads_legacy")
            return {"migrated": migrated, "deleted": len(drop),
                    "done": remaining == 0}

    @staticmethod
    def _legacy_payload_covers(db, fid: str, legacy: set[str]) -> list[str]:
        """The `covers` a migrated legacy payload gets. The legacy table wrote
        one row per chunk the extraction came from, so it is PROVABLY whole-file
        only when every current non-cold chunk of the file has a legacy row and
        is still enriched (an unenriched chunk changed since, or was never
        extracted). Then covers is that explicit list; otherwise []."""
        need = [(x[0], x[1]) for x in db.execute(
            f"SELECT doc_id, enriched FROM chunks WHERE {_meta_extract('$.file_id')}=? "
            "AND COALESCE(enrich_state,'')!='cold'", (fid,))]
        if need and all(d in legacy and e for d, e in need):
            return sorted(d for d, _e in need)
        return []

    def get_unified_action(self, action_id: int) -> dict | None:
        with self._connect() as db:
            r = db.execute("SELECT * FROM actions WHERE id = ?",
                           (action_id,)).fetchone()
            return dict(r) if r else None

    def list_unified_actions(self) -> list[dict]:
        with self._connect() as db:
            return [dict(r) for r in db.execute("SELECT * FROM actions ORDER BY id").fetchall()]

    def actions_for_owner_unified(self, owner: str) -> list[dict]:
        """Unified-table actions owned by `owner` (case-insensitive)."""
        with self._connect() as db:
            return [dict(r) for r in db.execute(
                "SELECT * FROM actions WHERE lower(owner)=lower(?) ORDER BY id",
                (owner,)).fetchall()]

    # --- enrichment graph readers -----------------------------------------

    def get_entity(self, ent_id) -> dict | None:
        with self._connect() as db:
            r = db.execute("SELECT * FROM entities WHERE id=?", (ent_id,)).fetchone()
            return dict(r) if r else None

    def get_entities(self, ent_ids) -> dict[str, dict]:
        """id -> entity dict, for the ids that exist. One query, not N.

        brain_graph's traversal used to call get_entity() once per visited node
        (18,397 queries on a live hub walk). Missing ids are simply absent from
        the result, so callers keep the get_entity contract of "no row, no key"
        without needing a second existence check.
        """
        ids = list(dict.fromkeys(ent_ids))  # de-dup, preserve caller order
        if not ids:
            return {}
        out: dict[str, dict] = {}
        with self._connect() as db:
            for batch in _chunked(ids, _SQL_VAR_BATCH):
                q = ",".join("?" * len(batch))
                for r in db.execute(
                        f"SELECT * FROM entities WHERE id IN ({q})", batch).fetchall():
                    out[r["id"]] = dict(r)
        return out

    def entity_degrees(self, ent_ids) -> dict[str, int]:
        """id -> number of non-invalidated relations touching it (0 if none).

        Derived rows (no primary source) are not counted. Legacy rows (strength
        predating source counting) still are: degree counts edges, not their
        support, so a legacy edge is still an edge until Task 10's clean-up
        decides otherwise.

        Every requested id gets a key, so a caller can compare against a
        threshold without a `.get(id, 0)` at each site. Counts BOTH directions,
        matching what relations_for(id) would return, because that is the cost
        the traversal is deciding whether to pay.
        """
        ids = list(dict.fromkeys(ent_ids))
        if not ids:
            return {}
        deg = dict.fromkeys(ids, 0)
        with self._connect() as db:
            for batch in _chunked(ids, _SQL_VAR_BATCH):
                q = ",".join("?" * len(batch))
                for col in ("entity_a", "entity_b"):
                    rows = db.execute(
                        f"SELECT {col} AS eid, COUNT(*) AS n FROM entity_relations "
                        f"WHERE {col} IN ({q}) AND invalidated_at IS NULL "
                        f"AND COALESCE(derived, 0) = 0 "
                        f"GROUP BY {col}", batch).fetchall()
                    for r in rows:
                        deg[r["eid"]] += r["n"]
        return deg

    def find_entity(self, query: str) -> dict | None:
        """Resolve an entity by id, then by slug of a display name, then by name.

        Tries the literal query as an id first, then slugify(query) as an id
        (handles "Dana Okafor" -> "dana-okafor"), then a case-insensitive
        name match. Returns the entity dict or None.
        """
        hit = self.get_entity(query)
        if hit:
            return hit
        slug = slugify(query)
        if slug and slug != query:
            hit = self.get_entity(slug)
            if hit:
                return hit
        with self._connect() as db:
            r = db.execute(
                "SELECT * FROM entities WHERE lower(name)=lower(?) LIMIT 1", (query,)
            ).fetchone()
            return dict(r) if r else None

    def relations_for(self, ent_id: str, *, at_time: str | None = None,
                      include_invalidated: bool = False) -> list[dict]:
        """All relations touching ent_id (as entity_a or entity_b).

        DEFAULT excludes invalidated rows (invalidated_at IS NOT NULL) and
        derived rows (derived=1: written from mcpbrain's own notes/briefs/drafts,
        no primary source — spec 2026-10-22 §3). Relations written by
        add_relation leave invalidated_at NULL, so they still surface.
        include_invalidated=True returns every row regardless.

        at_time (ISO date string) returns the graph as it stood at that point:
        valid_from <= at_time AND (valid_to IS NULL OR valid_to > at_time). Rows
        with a NULL valid_from are treated as always-valid (they pre-date the
        bitemporal columns), so the at_time gate only narrows rows that carry a
        valid_from. Returned dict keeps the backward-compatible shape
        (entity_a, relation, entity_b, source_doc_id) plus valid_from/valid_to.
        """
        sql = ("SELECT entity_a, relation, entity_b, source_doc_id, "
               "valid_from, valid_to FROM entity_relations "
               "WHERE (entity_a=:eid OR entity_b=:eid)")
        params: dict = {"eid": ent_id}
        if not include_invalidated:
            sql += " AND invalidated_at IS NULL AND COALESCE(derived, 0) = 0"
        if at_time is not None:
            sql += (" AND (valid_from IS NULL OR valid_from <= :at) "
                    "AND (valid_to IS NULL OR valid_to > :at)")
            params["at"] = at_time
        sql += " ORDER BY id"
        with self._connect() as db:
            return [dict(r) for r in db.execute(sql, params).fetchall()]

    def unified_actions(self, owner: str | None = None, status: str | None = None,
                        thread_id: str | None = None) -> list[dict]:
        """Rows from the unified actions table, filtered by any combination of
        owner (case-insensitive), status, and thread_id. A None argument applies
        no filter on that column. ORDER BY id for stable output."""
        clauses, params = [], []
        if owner is not None:
            clauses.append("lower(owner)=lower(?)")
            params.append(owner)
        if status is not None:
            clauses.append("status=?")
            params.append(status)
        if thread_id is not None:
            clauses.append("thread_id=?")
            params.append(thread_id)
        sql = "SELECT * FROM actions"
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY id"
        with self._connect() as db:
            return [dict(r) for r in db.execute(sql, params).fetchall()]

    def list_entities(self) -> list[dict]:
        with self._connect() as db:
            return [dict(r) for r in db.execute("SELECT * FROM entities ORDER BY id").fetchall()]

    def list_relations(self) -> list[dict]:
        with self._connect() as db:
            return [dict(r) for r in db.execute("SELECT * FROM entity_relations ORDER BY id").fetchall()]

    def entities_for_resolution(self) -> list[dict]:
        """All entities as {id,name,type,org,mentions} dicts — input for the resolver."""
        with self._connect() as db:
            return [dict(r) for r in db.execute(
                "SELECT id,name,type,org,mentions FROM entities ORDER BY id").fetchall()]

    def list_entity_merges(self) -> list[dict]:
        """Merge audit rows in insertion order."""
        with self._connect() as db:
            return [dict(r) for r in db.execute(
                "SELECT winner_id,loser_id,loser_name,method,at FROM entity_merge_log "
                "ORDER BY id").fetchall()]

    def supersede_older_drafts(self, thread_id: str) -> list[str]:
        """Keep only the newest DRAFT version of a Gmail thread live in recall.

        Every save of a Gmail draft is a NEW message id, so one reply drafted in
        five sittings lands as five overlapping versions (spec: 451 versions,
        298 superseded). Among this thread's DRAFT-labelled chunks, the newest
        message — by parsed `date`, then by latest rowid — is left alone; every
        chunk of every other draft message is set `enrich_state='cold'` and
        stamped `metadata.superseded = true`. Idempotent (rows already in that
        state are not rewritten). Returns the doc_ids changed by this call.

        Nothing is deleted. Non-draft messages of the thread (including the
        SENT version of the same reply) are never touched. The newest draft is
        not marked superseded; it is cold anyway as a derived class (prepare's
        derived gate), and cold chunks stay in recall.
        """
        if not thread_id:
            return []
        with self._connect(write=True) as db:
            return self._supersede_older_drafts_in(db, thread_id)

    @staticmethod
    def _supersede_older_drafts_in(db, thread_id: str, *, write: bool = True) -> list[str]:
        """supersede_older_drafts on an open connection. write=False returns
        the doc_ids it WOULD change without writing (dry runs); the attended
        clean-up calls it inside its own transaction to log old values."""
        if not thread_id:
            return []
        from email.utils import parsedate_to_datetime

        def _ts(raw) -> float:
            try:
                dt = parsedate_to_datetime(str(raw or ""))
                return dt.timestamp() if dt is not None else 0.0
            except (TypeError, ValueError, IndexError, OverflowError):
                pass
            try:
                return datetime.fromisoformat(str(raw)).timestamp()
            except (TypeError, ValueError, OverflowError):
                return 0.0

        rows = db.execute(
            "SELECT rowid, doc_id, metadata, enrich_state FROM chunks "
            f"WHERE {_meta_extract('$.thread_id')} = ?", (thread_id,)).fetchall()
        drafts: dict[str, dict] = {}
        for r in rows:
            meta = json.loads(r["metadata"] or "{}")
            if meta.get("source_type") != "gmail":
                continue
            raw = meta.get("labels") or ""
            labels = ({str(x).strip() for x in raw} if isinstance(raw, (list, tuple))
                      else {x.strip() for x in str(raw).split(",")})
            if "DRAFT" not in labels:
                continue
            mid = meta.get("message_id") or r["doc_id"]
            d = drafts.setdefault(mid, {"ts": 0.0, "rowid": 0, "rows": []})
            d["ts"] = max(d["ts"], _ts(meta.get("date")))
            d["rowid"] = max(d["rowid"], r["rowid"])
            d["rows"].append((r["doc_id"], meta, r["enrich_state"]))
        if len(drafts) < 2:
            return []
        newest = max(drafts, key=lambda m: (drafts[m]["ts"], drafts[m]["rowid"]))
        changed = []
        for mid, d in drafts.items():
            if mid == newest:
                continue
            for doc_id, meta, state in d["rows"]:
                if meta.get("superseded") is True and state == "cold":
                    continue
                meta["superseded"] = True
                if write:
                    db.execute(
                        "UPDATE chunks SET metadata=?, enrich_state='cold' WHERE doc_id=?",
                        (json.dumps(meta), doc_id))
                changed.append(doc_id)
        return changed

    def thread_chunks(self, thread_id: str) -> list[dict]:
        """Return all chunks whose metadata.thread_id matches thread_id.

        Each result is {doc_id, text, metadata} with metadata parsed from JSON.

        Row order is arbitrary (no ORDER BY). Callers MUST sort by
        (date, message_id, chunk_index) — see retrieval_expand._by_date. Sorting
        by date alone is NOT an ordering within a message, because every chunk
        of one message shares its date; that was B4.
        """
        with self._connect() as db:
            # Index-backed by idx_chunks_threadid (see init()).
            cur = db.execute(
                "SELECT doc_id, text, metadata FROM chunks "
                f"WHERE {_meta_extract('$.thread_id')} = ?",
                (thread_id,),
            )
            return [
                {
                    "doc_id": r["doc_id"],
                    "text": r["text"],
                    "metadata": json.loads(r["metadata"]),
                }
                for r in cur.fetchall()
            ]

    def thread_has_unenriched(self, thread_id: str) -> bool:
        """True if any chunk in the thread is enriched=0 (so the normal
        enrichment path already owns it; the stale sweep must not double-trigger)."""
        with self._connect() as db:
            r = db.execute(
                "SELECT 1 FROM chunks "
                f"WHERE {_meta_extract('$.thread_id')}=? AND enriched=0 "
                "LIMIT 1",
                (thread_id,)).fetchone()
            return r is not None

    def mark_thread_unenriched(self, thread_id: str) -> int:
        """Set enriched=0 on every enriched chunk in the thread so the next
        enrichment cycle re-extracts it. Returns the number of rows flipped.
        Touches only this thread; leaves embedded untouched.

        Deliberately `$.thread_id` only: matching note_id/file_id too would
        re-extract whole Drive files whose thread_signature never changes."""
        with self._connect(write=True) as db:
            cur = db.execute(
                "UPDATE chunks SET enriched=0 "
                f"WHERE {_meta_extract('$.thread_id')}=? AND enriched=1",
                (thread_id,))
            return cur.rowcount

    def thread_signature(self, thread_id: str) -> str:
        """sha256 over the thread's (doc_id, content_hash) pairs in doc_id order.
        Stable across enriched-flag changes; changes iff thread content changes.
        Empty thread -> a fixed empty-set digest."""
        with self._connect() as db:
            rows = db.execute(
                "SELECT doc_id, content_hash FROM chunks "
                f"WHERE {_meta_extract('$.thread_id')}=? ORDER BY doc_id",
                (thread_id,)).fetchall()
        h = hashlib.sha256()
        for r in rows:
            h.update(r["doc_id"].encode())
            h.update(b"\x1f")
            h.update((r["content_hash"] or "").encode())
            h.update(b"\x1e")
        return h.hexdigest()

    def doc_ids_for_messages(self, message_ids) -> list[str]:
        """doc_ids of the chunks whose messages these are.

        A chunk's "message id" is its metadata.message_id, or its doc_id when the
        chunk carries no message_id (mirroring thread_enrich.reassemble_thread,
        which keys each message on `message_id or doc_id`). drain recovers the
        chunks an extraction covers this way, so it marks exactly the messages
        that were extracted — a late-arriving or dropped message is not in the
        extraction, so its chunk stays enriched=0 and re-queues next cycle.

        Drive docs are the third case: reassemble_thread keys them on file_id, so
        the extraction's message_id is a file_id. Drive chunks carry no
        message_id and their doc_id is gdrive-<file_id>-<idx> (never the bare
        file_id), so an id matching a chunk's metadata.file_id resolves to every
        chunk of that document. file_ids (~33-char base64) don't collide with
        email message/thread ids, so this branch only fires for real Drive ids.

        Calendar events are the fourth: reassemble_thread keys them on
        `cal-<event_id>` (the namespace their chunks' doc_ids already use), and a
        split event's chunk doc_ids are cal-<event_id>-<i> — never the bare
        `cal-<event_id>`. So the event arm is bound with the `cal-` prefix
        STRIPPED, matching the raw `event_id` metadata field the chunks actually
        carry (sync/calendar.py stamps the bare id there). A single-chunk event is
        additionally resolvable through the doc_id fallback arm, since for it the
        key and the doc_id coincide.

        anarlog meetings are the fifth: a meeting's chunks are
        anarlog-<session_id>-<kind>-<i> across three subtypes (summary, note,
        transcript) and never the bare `anarlog-<session_id>`, so the arm is
        bound with _ANARLOG_PREFIX STRIPPED and matches the raw session_id the
        chunks carry. One key therefore resolves the whole meeting, which is
        what deletion needs.

        Returns doc_ids ordered by the chunk rowid for stable output.
        """
        ids = [m for m in (message_ids or []) if m]
        if not ids:
            return []
        # Same length as `ids` so the arm's placeholder count is unchanged. A
        # non-calendar id binds as NULL rather than passing through: the calendar
        # identity is ALWAYS prefixed, so an unprefixed id has no business
        # matching an event_id, and `x IN (NULL)` never does.
        event_ids = [m[len(_CAL_PREFIX):] if m.startswith(_CAL_PREFIX) else None
                     for m in ids]
        # Same rule as event_ids: the anarlog identity is always prefixed, so an
        # unprefixed id binds as NULL and cannot match a session_id.
        session_ids = [m[len(_ANARLOG_PREFIX):] if m.startswith(_ANARLOG_PREFIX)
                       else None for m in ids]
        with self._connect() as db:
            rows = db.execute(self._doc_ids_query(len(ids)),
                              ids + ids + event_ids + session_ids + ids + ids).fetchall()
        return [r["doc_id"] for r in rows]

    @staticmethod
    def _doc_ids_query(n: int) -> str:
        """SQL for doc_ids_for_messages resolving ``n`` ids per path.

        A UNION of five single-path SELECTs, NOT one SELECT with an OR: SQLite
        will not union expression-indexes (idx_chunks_msgid/idx_chunks_fileid/
        idx_chunks_eventid/idx_chunks_sessionid) across an OR, so the OR form
        plans as a full `SCAN chunks` — ~1.4s per call on the ~108k-chunk live
        store. Each UNION arm filters on a single indexed path so it plans as an
        index SEARCH. Params bind per arm (message_id, file_id, event_id,
        session_id, then the doc_id fallback) — the event_id and session_id arms
        get their prefix-stripped ids, see the caller. Ordered by rowid for the
        stable output drain relies on; UNION also dedups a chunk that matches
        two arms.

        The event_id arm exists for the same reason as the file_id one (I6):
        thread_enrich._chunk_key groups a split calendar event's chunks under
        `cal-<event_id>`, so that is the `message_id` the extraction carries, and
        for a SPLIT event it is never any chunk's doc_id (those are
        cal-<event_id>-<idx>). Calendar event ids don't collide with Gmail
        message/thread ids.

        The session_id arm is the anarlog analogue: a meeting's chunks are
        anarlog-<session_id>-<kind>-<i>, never the bare `anarlog-<session_id>`,
        so this arm is what makes one key resolve every chunk of the meeting.
        The note_id arm (one captured note = one thread) follows it, also index-backed
        (idx_chunks_noteid). It must stay AFTER the event_id arm and BEFORE the doc_id fallback arm,
        since the caller's bind list is positional per arm."""
        ph = ",".join("?" * n)
        return (
            f"SELECT doc_id, rowid FROM chunks "
            f"WHERE {_meta_extract('$.message_id')} IN ({ph}) "
            f"UNION "
            f"SELECT doc_id, rowid FROM chunks "
            f"WHERE {_meta_extract('$.file_id')} IN ({ph}) "
            f"UNION "
            f"SELECT doc_id, rowid FROM chunks "
            f"WHERE {_meta_extract('$.event_id')} IN ({ph}) "
            f"UNION "
            f"SELECT doc_id, rowid FROM chunks "
            f"WHERE {_meta_extract('$.session_id')} IN ({ph}) "
            f"UNION "
            f"SELECT doc_id, rowid FROM chunks "
            f"WHERE {_meta_extract('$.note_id')} IN ({ph}) "
            f"UNION "
            f"SELECT doc_id, rowid FROM chunks "
            f"WHERE {_meta_extract('$.message_id')} IS NULL "
            f"  AND doc_id IN ({ph}) "
            f"ORDER BY rowid")

    def meeting_source_doc_ids(self) -> list[str]:
        """Doc_ids of chunks that produced any type='meeting' entity.

        Three provenance paths, unioned: email_entities links (message -> chunk
        via doc_ids_for_messages), entity_relations.source_doc_id, and — for
        calendar-sourced meetings whose attended/instance_of/involved_in
        relations were written without a stamped source_doc_id (a real gap:
        the calendar-chunk enrichment path never threads doc_ids through) —
        entity_relations.evidence, which holds the bare Calendar event id,
        matched against that event's own chunk doc_id convention
        ('cal-<event_id>', or 'cal-<event_id>_<instant>' for a recurring
        instance). Used by the scoped meeting migration to reset exactly those
        chunks for re-extraction."""
        with self._connect() as db:
            msg_ids = [r["message_id"] for r in db.execute(
                "SELECT DISTINCT ee.message_id FROM email_entities ee "
                "JOIN entities e ON e.id = ee.entity_id WHERE e.type='meeting'").fetchall()]
            rel_docs = [r["source_doc_id"] for r in db.execute(
                "SELECT DISTINCT er.source_doc_id FROM entity_relations er "
                "JOIN entities e ON (e.id=er.entity_a OR e.id=er.entity_b) "
                "WHERE e.type='meeting' AND COALESCE(er.source_doc_id,'')!=''").fetchall()]
            cal_evidence = [r["evidence"] for r in db.execute(
                "SELECT DISTINCT er.evidence FROM entity_relations er "
                "JOIN entities e ON (e.id=er.entity_a OR e.id=er.entity_b) "
                "WHERE e.type='meeting' AND COALESCE(er.source_doc_id,'')='' "
                "AND COALESCE(er.evidence,'')!=''").fetchall()]
            cal_docs: set[str] = set()
            for ev in cal_evidence:
                for r in db.execute(
                        "SELECT doc_id FROM chunks WHERE doc_id LIKE ?",
                        (f"cal-{ev}%",)).fetchall():
                    cal_docs.add(r["doc_id"])
        docs = set(self.doc_ids_for_messages(msg_ids)) | set(rel_docs) | cal_docs
        return sorted(docs)

    def reinclude_chunks(self, doc_ids, *, rules=None) -> dict:
        """Put skipped chunks back into the enrichment queue, for good.

        The owner's "Include in the graph" from the console's cold list.
        A chunk made from other items (source_class.is_derived: consolidated
        note, summary or brief including the owner's own automated mail,
        session note, draft, superseded draft) is refused and counted as
        skipped: a derived chunk is never evidence (prepare.derived_cold).
        `rules` (source_class.Rules) carries the owner's brief rules.

        Otherwise enrich_state is cleared and `metadata.force_enrich = true`
        is stamped so prepare's salience gate does not cold-mark the chunk
        again. A chunk not yet enriched also gets enriched/enriched_version/
        enrich_attempts reset to 0 so it joins the queue; an already-enriched
        chunk keeps them (it is in the graph already, so re-including it must
        not spend enrichment again). The flag is kept when the chunk is
        rewritten later -- a source refetch through upsert_chunk, a cache
        import, or a reflow re-chunk (carried along the plan's remap) -- so
        the re-include sticks.

        Records one undoable `chunks_reincluded` change_log row (the prior
        columns and flag of every changed chunk) in the same transaction.
        Returns {"changed", "skipped"}; unknown ids are ignored."""
        from mcpbrain import source_class as _sc
        ids = [d for d in dict.fromkeys(doc_ids or []) if d]
        out = {"changed": 0, "skipped": 0}
        if not ids:
            return out
        before: dict = {}
        after: dict = {}
        with self._connect(write=True) as db:
            for i in range(0, len(ids), 500):
                part = ids[i:i + 500]
                ph = ",".join("?" * len(part))
                rows = db.execute(
                    f"SELECT doc_id, metadata, enrich_state, enriched, enriched_version, "
                    f"enrich_attempts FROM chunks WHERE doc_id IN ({ph})", part).fetchall()
                for r in rows:
                    try:
                        meta = json.loads(r["metadata"] or "{}")
                    except (TypeError, ValueError):
                        meta = {}
                    if not isinstance(meta, dict):
                        meta = {}
                    if _sc.is_derived(r["doc_id"], meta, rules):
                        out["skipped"] += 1
                        continue
                    prior = _chunk_enrich_snapshot(r, meta)
                    meta["force_enrich"] = True
                    if int(r["enriched"] or 0):
                        db.execute("UPDATE chunks SET enrich_state='', metadata=? "
                                   "WHERE doc_id=?", (json.dumps(meta), r["doc_id"]))
                        now = {**prior, "enrich_state": "", "force_enrich": True}
                    else:
                        db.execute("UPDATE chunks SET enrich_state='', enriched=0, "
                                   "enriched_version=0, enrich_attempts=0, metadata=? "
                                   "WHERE doc_id=?", (json.dumps(meta), r["doc_id"]))
                        now = {"enrich_state": "", "enriched": 0, "enriched_version": 0,
                               "enrich_attempts": 0, "force_enrich": True}
                    before[r["doc_id"]] = prior
                    after[r["doc_id"]] = now
                    out["changed"] += 1
            if out["changed"]:
                from mcpbrain.change_undo import revert_json
                n = out["changed"]
                self.record_change_tx(
                    db, "chunks_reincluded",
                    ref_id=next(iter(before)) if n == 1 else "",
                    summary=f"Included {n} item{'' if n == 1 else 's'} in the graph",
                    revert_ref=revert_json({"chunks": before}, {"chunks": after}),
                    source="dashboard")
        return out

    def prioritise_chunks(self, doc_ids) -> int:
        """Move waiting chunks to the front of the enrichment queue
        (priority=1; unenriched_chunks orders priority DESC). Only chunks still
        waiting (enriched=0) are touched, so the count is what actually moved:
        an already-enriched chunk is not re-queued by this (a reflow that gave
        up is retried with retry_reflow_gave_up instead). Records a
        `chunks_prioritised` change_log row when anything moved; it carries no
        revert_ref, so it is not undoable (the summary says so)."""
        ids = [d for d in dict.fromkeys(doc_ids or []) if d]
        if not ids:
            return 0
        changed = 0
        with self._connect(write=True) as db:
            for i in range(0, len(ids), 500):
                part = ids[i:i + 500]
                ph = ",".join("?" * len(part))
                changed += db.execute(f"UPDATE chunks SET priority=1 WHERE enriched=0 "
                                      f"AND doc_id IN ({ph})", part).rowcount
            if changed:
                self.record_change_tx(
                    db, "chunks_prioritised",
                    summary=(f"Moved {changed} item{'' if changed == 1 else 's'} to the "
                             "front of the enrichment queue (can't be undone)"),
                    source="dashboard")
        return changed

    # The console's chunk lists (source_controls): which chunks each names.
    _CHUNK_LISTS = {
        "cold": ("COALESCE(enrich_state,'')='cold'", "rowid DESC"),
        "waiting": ("enriched=0 AND COALESCE(enrich_state,'') != 'cold' "
                    "AND doc_id NOT LIKE 'enriched-%'", "priority DESC, rowid DESC"),
        "reflow_gave_up": (f"{_meta_extract('$.reflow_skipped')}='gave_up'", "rowid DESC"),
    }

    def chunk_list_page(self, kind: str, *, offset: int, limit: int) -> tuple[list[dict], int]:
        """One page of the named chunk list, and the list's total.
        Rows: {doc_id, metadata (dict), enrich_state, priority, enriched}."""
        where, order = self._CHUNK_LISTS[kind]
        with self._connect() as db:
            total = db.execute(f"SELECT COUNT(*) FROM chunks WHERE {where}").fetchone()[0]
            rows = db.execute(
                f"SELECT doc_id, metadata, enrich_state, priority, enriched FROM chunks "
                f"WHERE {where} ORDER BY {order} LIMIT ? OFFSET ?",
                (int(limit), int(offset))).fetchall()
        out = []
        for r in rows:
            try:
                meta = json.loads(r["metadata"] or "{}")
            except (TypeError, ValueError):
                meta = {}
            out.append({"doc_id": r["doc_id"], "metadata": meta if isinstance(meta, dict) else {},
                        "enrich_state": r["enrich_state"] or "",
                        "priority": int(r["priority"] or 0),
                        "enriched": bool(r["enriched"])})
        return out, int(total)

    # Metadata keys with an expression index (init()); item_trace looks an
    # item up by these, never by an unindexed key.
    TRACE_KEYS = ("file_id", "thread_id", "message_id", "event_id", "session_id",
                  "note_id")

    def chunks_by_meta_key(self, key: str, value: str, *, limit: int = 2000) -> list[dict]:
        """Chunks whose metadata.<key> equals `value`, in rowid order. Rows:
        {doc_id, metadata (dict), enrich_state, enriched, priority}. `key` must
        be one of TRACE_KEYS so the lookup is index-backed."""
        if key not in self.TRACE_KEYS:
            raise ValueError(f"not an indexed metadata key: {key!r}")
        with self._connect() as db:
            rows = db.execute(
                "SELECT doc_id, metadata, enrich_state, enriched, priority FROM chunks "
                f"WHERE {_meta_extract('$.' + key)} = ? ORDER BY rowid LIMIT ?",
                (value, int(limit))).fetchall()
        return self._state_rows(rows)

    def chunk_rows(self, doc_ids) -> list[dict]:
        """Rows shaped like chunks_by_meta_key for the given doc_ids."""
        ids = [d for d in (doc_ids or []) if d]
        if not ids:
            return []
        ph = ",".join("?" * len(ids))
        with self._connect() as db:
            rows = db.execute(
                "SELECT doc_id, metadata, enrich_state, enriched, priority FROM chunks "
                f"WHERE doc_id IN ({ph}) ORDER BY rowid", ids).fetchall()
        return self._state_rows(rows)

    @staticmethod
    def _state_rows(rows) -> list[dict]:
        out = []
        for r in rows:
            try:
                meta = json.loads(r["metadata"] or "{}")
            except (TypeError, ValueError):
                meta = {}
            out.append({"doc_id": r["doc_id"],
                        "metadata": meta if isinstance(meta, dict) else {},
                        "enrich_state": r["enrich_state"] or "",
                        "enriched": bool(r["enriched"]),
                        "priority": int(r["priority"] or 0)})
        return out

    def sync_queue_rows(self, *, ref_ids=None, limit: int = 500) -> list[dict]:
        """Sync queue rows, oldest discovery first; only `ref_ids` when given.
        Each row: source, ref_id, event, modified_at, discovered_at, attempts,
        next_attempt_at, last_error."""
        cols = ("source, ref_id, event, modified_at, discovered_at, attempts, "
                "next_attempt_at, last_error")
        with self._connect() as db:
            if ref_ids is not None:
                ids = [r for r in ref_ids if r]
                if not ids:
                    return []
                ph = ",".join("?" * len(ids))
                rows = db.execute(f"SELECT {cols} FROM sync_queue WHERE ref_id IN ({ph}) "
                                  "ORDER BY discovered_at LIMIT ?", (*ids, int(limit)))
            else:
                rows = db.execute(f"SELECT {cols} FROM sync_queue "
                                  "ORDER BY discovered_at LIMIT ?", (int(limit),))
            return [dict(r) for r in rows.fetchall()]

    def reset_enriched(self, doc_ids) -> int:
        """Set enriched=0, enriched_version=0 on the given chunks so the daemon
        re-extracts them. Returns rows affected."""
        ids = [d for d in (doc_ids or []) if d]
        if not ids:
            return 0
        ph = ",".join("?" * len(ids))
        with self._connect(write=True) as db:
            cur = db.execute(
                f"UPDATE chunks SET enriched=0, enriched_version=0 WHERE doc_id IN ({ph})", ids)
            return cur.rowcount

    def meeting_series_for_old(self, old_id) -> str | None:
        """The single 'meeting-*' series entity now linked to the same messages as
        old_id, or None when zero or more than one match (ambiguous -> leave alone,
        per the non-destructive migration policy).

        Only counts candidates that are GENUINE re-extracted series — i.e. carry
        at least one 'occurrence' observation (written by append_occurrence). A
        legacy bare 'meeting-*' slug (e.g. 'meeting-with-bob', pre-dating the
        series scheme) has none, so it is never mistaken for a candidate series
        and never creates false ambiguity for a real old_id resolution.

        Two independent matching paths, unioned (still None on ambiguity across
        their combined candidates): shared email_entities.message_id, and — for
        calendar-sourced legacy meetings, which predate the email_entities
        linkage convention entirely and so never match the first path — a shared
        Calendar event id, comparing old_id's entity_relations.evidence (the bare
        event id; the same gap meeting_source_doc_ids() works around) against a
        candidate series' own calendar-derived email_entities.message_id
        ('cal-<event_id>[_<instant>]'), by base event id so a recurring series'
        per-instance suffix doesn't block the match."""
        with self._connect() as db:
            rows = db.execute(
                "SELECT DISTINCT e2.id FROM email_entities ee1 "
                "JOIN email_entities ee2 ON ee1.message_id = ee2.message_id "
                "JOIN entities e2 ON e2.id = ee2.entity_id "
                "WHERE ee1.entity_id = ? AND e2.type='meeting' "
                "AND e2.id != ? AND e2.id LIKE 'meeting-%' "
                "AND EXISTS (SELECT 1 FROM entity_observations o "
                "            WHERE o.entity_id = e2.id AND o.attribute = 'occurrence')",
                (old_id, old_id)).fetchall()
            series = {r["id"] for r in rows}

            old_events = {_base_cal_event_id(r["evidence"]) for r in db.execute(
                "SELECT DISTINCT evidence FROM entity_relations "
                "WHERE (entity_a=? OR entity_b=?) AND COALESCE(evidence,'')!=''",
                (old_id, old_id)).fetchall()}
            if old_events:
                candidates = db.execute(
                    "SELECT DISTINCT ee.entity_id, ee.message_id FROM email_entities ee "
                    "JOIN entities e ON e.id = ee.entity_id "
                    "WHERE e.type='meeting' AND e.id != ? AND e.id LIKE 'meeting-%' "
                    "AND ee.message_id LIKE 'cal-%' "
                    "AND EXISTS (SELECT 1 FROM entity_observations o "
                    "            WHERE o.entity_id = e.id AND o.attribute = 'occurrence')",
                    (old_id,)).fetchall()
                for r in candidates:
                    if _base_cal_event_id(r["message_id"]) in old_events:
                        series.add(r["entity_id"])
        series = list(series)
        return series[0] if len(series) == 1 else None

    # --- Phase 3, Task 0.5A: community reader/writer methods ----------------

    def replace_communities(self, partition: dict, summaries: dict) -> int:
        """Atomically replace all community membership and summary data.

        Returns the number of partition ids SKIPPED for having no entities row
        (store.py carries no logger; communities._save logs the count).

        partition: {entity_id: community_id} — every entity's community at level 0.
        summaries: {community_id: {"member_count": int, "key_entities": str,
                                   "title": str, "summary": str, "updated": str}}

        Deletes both tables then reinserts in a single transaction so callers
        always see either the full old set or the full new set.
        """
        with self._connect(write=True) as db:
            db.execute("DELETE FROM entity_communities")  # admin-delete-ok
            db.execute("DELETE FROM community_summaries")  # admin-delete-ok
            # Skip ids with no entities row. communities.build_graph reads
            # entity_relations, so a relation still pointing at a merged-away
            # entity puts a dead id in the partition; with the FK enforced (the
            # 2026-08-25 rebuild) that INSERT fails and rolls back the WHOLE
            # transaction. Nothing looks broken -- the rollback leaves the old
            # rows in place -- so the data silently freezes. Live: 714 failures
            # over three days, every one of them caused by a SINGLE dead id
            # (`joshua-kemp`, residue from a merge into `josh-kemp`), while
            # community_summaries sat stale for five days and brain_context
            # (mode="communities") kept serving it.
            #
            # One dangling id must degrade one node, not the cadence. The
            # residue is still worth sweeping -- this makes the pass survive it,
            # it does not make it correct to leave.
            live = {r["id"] for r in db.execute("SELECT id FROM entities")}
            rows = [(eid, cid) for eid, cid in partition.items() if eid in live]
            skipped = len(partition) - len(rows)
            db.executemany(
                "INSERT INTO entity_communities(entity_id, community_id, level) "
                "VALUES(?, ?, 0)",
                rows,
            )
            db.executemany(
                "INSERT INTO community_summaries"
                "(community_id, level, title, summary, member_count, key_entities, updated) "
                "VALUES(?, 0, ?, ?, ?, ?, ?)",
                [
                    (
                        cid,
                        meta.get("title", ""),
                        meta.get("summary", ""),
                        meta.get("member_count", 0),
                        meta.get("key_entities", ""),
                        meta.get("updated", ""),
                    )
                    for cid, meta in summaries.items()
                ],
            )
        return skipped

    def communities_for(self, entity_ids: list) -> list[dict]:
        """Return entity_communities rows for the given entity_ids."""
        if not entity_ids:
            return []
        placeholders = ",".join("?" * len(entity_ids))
        with self._connect() as db:
            return [
                dict(r)
                for r in db.execute(
                    f"SELECT * FROM entity_communities WHERE entity_id IN ({placeholders})",
                    entity_ids,
                ).fetchall()
            ]

    def community_members(self, community_id: int) -> list[dict]:
        """Return entity rows for all members of a community (level=0).

        Joins entity_communities → entities so each result is a full entity dict.
        """
        with self._connect() as db:
            return [
                dict(r)
                for r in db.execute(
                    "SELECT e.* FROM entities e "
                    "JOIN entity_communities ec ON ec.entity_id = e.id "
                    "WHERE ec.community_id = ? AND ec.level = 0 "
                    "ORDER BY e.id",
                    (community_id,),
                ).fetchall()
            ]

    def list_communities(self) -> list[dict]:
        """Return all community_summaries rows at level=0."""
        with self._connect() as db:
            return [
                dict(r)
                for r in db.execute(
                    "SELECT * FROM community_summaries WHERE level = 0 "
                    "ORDER BY community_id"
                ).fetchall()
            ]

    # --- Phase 3, Task 0.5B: thread_context reader/writer methods -----------

    def upsert_thread_context(
        self,
        thread_id: str,
        *,
        subject: str = "",
        org: str = "",
        email_count: int = 0,
        summary: str = "",
        contextual_summary: str = "",
        participant_ids: str = "",
    ) -> None:
        """Insert or update the thread_context row for thread_id.

        On conflict, only non-empty/non-zero values overwrite the existing row.
        This lets callers pass a partial update (e.g. summary= only) without
        clobbering already-populated subject/org/email_count.
        """
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        with self._connect(write=True) as db:
            db.execute(
                "INSERT INTO thread_context"
                "(thread_id, subject, org, email_count, participant_ids, "
                "summary, last_updated, contextual_summary, contextual_summary_at) "
                "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) "
                "ON CONFLICT(thread_id) DO UPDATE SET "
                "    subject            = CASE WHEN excluded.subject != '' THEN excluded.subject ELSE subject END, "
                "    org                = CASE WHEN excluded.org != '' THEN excluded.org ELSE org END, "
                "    email_count        = CASE WHEN excluded.email_count != 0 THEN excluded.email_count ELSE email_count END, "
                "    participant_ids    = CASE WHEN excluded.participant_ids != '' THEN excluded.participant_ids ELSE participant_ids END, "
                "    summary            = CASE WHEN excluded.summary != '' THEN excluded.summary ELSE summary END, "
                "    last_updated       = CASE WHEN excluded.last_updated != '' THEN excluded.last_updated ELSE last_updated END, "
                "    contextual_summary = CASE WHEN excluded.contextual_summary != '' THEN excluded.contextual_summary ELSE contextual_summary END, "
                # Stamp the summary's write-time only when a contextual_summary is
                # actually being written, so threads_needing_summary can tell that a
                # later message (which bumps last_updated) post-dates the summary.
                "    contextual_summary_at = CASE WHEN excluded.contextual_summary != '' THEN excluded.last_updated ELSE contextual_summary_at END",
                (
                    thread_id,
                    subject,
                    org,
                    email_count,
                    participant_ids,
                    summary,
                    now,
                    contextual_summary,
                    now if contextual_summary else "",
                ),
            )

    def threads_needing_summary(self, min_emails: int = 5) -> list[dict]:
        """Threads with email_count >= min_emails that need a contextual_summary —
        either they have none yet, OR they have gained messages SINCE the summary
        was written (last_updated > contextual_summary_at), so a long thread's
        narrative refreshes as it grows instead of freezing at first summary.
        """
        with self._connect() as db:
            return [
                dict(r)
                for r in db.execute(
                    "SELECT * FROM thread_context "
                    "WHERE email_count >= ? "
                    "  AND (contextual_summary IS NULL OR contextual_summary = '' "
                    "       OR (COALESCE(contextual_summary_at,'') != '' "
                    "           AND last_updated > contextual_summary_at)) "
                    "ORDER BY thread_id",
                    (min_emails,),
                ).fetchall()
            ]

    def thread_messages(self, thread_id: str) -> list[dict]:
        """Return email_context rows for a thread, ordered by date ascending.

        Reads email_context WHERE thread_id=? ORDER BY date_iso. Each result is
        a full email_context dict (message_id, subject, sender, date_iso,
        content_type, summary, thread_id, ...).
        """
        with self._connect() as db:
            return [
                dict(r)
                for r in db.execute(
                    "SELECT * FROM email_context WHERE thread_id = ? ORDER BY date_iso",
                    (thread_id,),
                ).fetchall()
            ]

    def thread_summary_digest(self, thread_id: str, max_chars: int | None = 1500) -> str:
        """Join a thread's per-message summaries into one digest, oldest
        message first, dropping the OLDEST lines first if it doesn't fit.

        thread_context.contextual_summary is only ever populated by the
        periodic cross-message synthesis pass (threads with email_count>=5).
        A thread under that threshold gets a genuinely empty
        prior_thread_context otherwise, even though every message's own
        one-line summary is already sitting right here in email_context.
        This is the fallback prepare._thread_block reaches for when
        thread_context is empty -- the most recent messages are the most
        relevant prior context for whatever's about to be enriched next, so
        recency wins when trimming to budget, not chronological completeness.

        max_chars=None means no cap (used by build_synthesis_requests, which
        already caps the THREAD count via min_emails/limit rather than the
        digest's own length).

        Line format matches build_synthesis_requests' prior inline join loop
        exactly (this method is now the shared, canonical source of it):
        "- {date_iso}{ ' [content_type]' if content_type else ''}: {summary}"
        """
        if not thread_id:
            return ""
        with self._connect() as db:
            rows = db.execute(
                "SELECT date_iso, content_type, summary FROM email_context "
                "WHERE thread_id=? AND summary != '' ORDER BY date_iso",
                (thread_id,),
            ).fetchall()
        lines = []
        for r in rows:
            ctype = f" [{r['content_type']}]" if r["content_type"] else ""
            lines.append(f"- {r['date_iso'] or '?'}{ctype}: {r['summary']}")
        if max_chars is None:
            return "\n".join(lines)
        # Drop OLDEST lines first (lines is already oldest-to-newest) until
        # the joined result fits.
        while lines and len("\n".join(lines)) > max_chars:
            lines.pop(0)
        return "\n".join(lines)

    # --- Phase 3, Task 0.5C: proactive_findings reader/writer methods -------

    def record_finding(
        self,
        finding_type: str,
        ref_id: str,
        org: str = "",
        summary: str = "",
        detail: str = "",
        severity: str = "info",
        detected_at: str = "",
    ) -> None:
        """Insert or update a proactive finding.

        Upserts on the UNIQUE(finding_type, ref_id) constraint so re-detecting
        the same signal updates the existing row rather than accumulating
        duplicates. resolved_at is cleared on upsert UNLESS the existing row
        already carries a verdict (set by resolve_finding) — a settled review
        decision must not be thrown away just because the same unchanged
        signal was detected again. record_finding itself never writes the
        verdict column; only resolve_finding does.
        """
        if not detected_at:
            detected_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        with self._connect(write=True) as db:
            db.execute(
                "INSERT INTO proactive_findings"
                "(finding_type, ref_id, org, summary, detail, severity, detected_at, resolved_at) "
                "VALUES(?, ?, ?, ?, ?, ?, ?, NULL) "
                "ON CONFLICT(finding_type, ref_id) DO UPDATE SET "
                "  org         = excluded.org, "
                "  summary     = excluded.summary, "
                "  detail      = excluded.detail, "
                "  severity    = excluded.severity, "
                "  detected_at = excluded.detected_at, "
                "  resolved_at = CASE WHEN verdict IS NOT NULL THEN resolved_at ELSE NULL END",
                (finding_type, ref_id, org, summary, detail, severity, detected_at),
            )

    def open_findings(self, finding_type: str | None = None) -> list[dict]:
        """Return unresolved proactive_findings rows.

        finding_type=None returns all types. Pass a type string to filter.
        """
        sql = "SELECT * FROM proactive_findings WHERE resolved_at IS NULL"
        params: list = []
        if finding_type is not None:
            sql += " AND finding_type = ?"
            params.append(finding_type)
        sql += " ORDER BY id"
        with self._connect() as db:
            return [dict(r) for r in db.execute(sql, params).fetchall()]

    def resolve_findings_not_in(
        self, finding_type: str, live_ref_ids: list, now: str
    ) -> int:
        """Close open findings of finding_type whose ref_id is not in live_ref_ids.

        Used at the end of a pipeline pass to retire findings whose underlying
        condition has cleared. Returns the count of rows resolved.
        """
        with self._connect(write=True) as db:
            if not live_ref_ids:
                # Everything of this type is stale.
                cur = db.execute(
                    "UPDATE proactive_findings SET resolved_at = ? "
                    "WHERE finding_type = ? AND resolved_at IS NULL",
                    (now, finding_type),
                )
            else:
                placeholders = ",".join("?" * len(live_ref_ids))
                cur = db.execute(
                    f"UPDATE proactive_findings SET resolved_at = ? "
                    f"WHERE finding_type = ? AND resolved_at IS NULL "
                    f"AND ref_id NOT IN ({placeholders})",
                    [now, finding_type] + list(live_ref_ids),
                )
            return cur.rowcount

    # --- Phase 1 capture: change_log + finding helpers -----------------------

    def record_change(self, change_type: str, *, ref_id: str = "", summary: str = "",
                      detail: str = "", revert_ref: str = "", source: str = "") -> int:
        """Append one row to the change digest's audit trail."""
        with self._connect(write=True) as db:
            return _log_change_tx(db, change_type, ref_id=ref_id, summary=summary,
                                  detail=detail, revert_ref=revert_ref, source=source)

    def record_change_tx(self, db, change_type: str, *, ref_id: str = "", summary: str = "",
                         detail: str = "", revert_ref: str = "", source: str = "") -> int:
        """record_change on the caller's open write connection, so the change
        row commits (or rolls back) with the write it describes."""
        return _log_change_tx(db, change_type, ref_id=ref_id, summary=summary,
                              detail=detail, revert_ref=revert_ref, source=source)

    def recent_changes(self, limit: int = 20) -> list[dict]:
        with self._connect() as db:
            rows = db.execute(
                "SELECT * FROM change_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
            return [dict(r) for r in rows]

    def prune_change_log(self, keep: int = 500, *, undo_days: int = 30) -> int:
        """Delete old change_log rows, keeping the most recent `keep`. Returns count deleted.

        An undoable row (non-empty revert_ref) and its change_undone marker are
        also kept for `undo_days`, so a burst of plain rows (ingest skips) can't
        push a recent change out of reach of undo."""
        cutoff = (datetime.now(timezone.utc) - timedelta(days=undo_days)
                  ).strftime("%Y-%m-%d %H:%M:%S")
        with self._connect(write=True) as db:
            row = db.execute(
                "SELECT id FROM change_log ORDER BY id DESC LIMIT 1 OFFSET ?",
                (keep - 1,)).fetchone()
            if row is None:
                return 0
            cur = db.execute(
                "DELETE FROM change_log WHERE id < ? AND NOT ("
                "(revert_ref != '' OR change_type = 'change_undone') AND created_at >= ?)",
                (row["id"], cutoff))
            return cur.rowcount

    def open_findings_count(self, exclude_types: tuple = ()) -> int:
        sql = "SELECT COUNT(*) FROM proactive_findings WHERE resolved_at IS NULL"
        if exclude_types:
            sql += f" AND finding_type NOT IN ({','.join('?' * len(exclude_types))})"
        with self._connect() as db:
            row = db.execute(sql, tuple(exclude_types)).fetchone()
            return row[0] if row else 0

    def pending_changes_count(self) -> int:
        """Automatic changes waiting for the owner: queued for review, or
        stopped part way and waiting to be checked."""
        with self._connect() as db:
            row = db.execute(
                "SELECT COUNT(*) FROM pending_changes "
                "WHERE status IN ('pending', 'interrupted')").fetchone()
            return row[0] if row else 0

    def get_finding(self, finding_id) -> dict | None:
        """Return one finding as {id, finding_type, ref_id, resolved_at, verdict}
        or None.

        The review appliers use this to target the finding's OWN stored ref_id
        and finding_type rather than trusting the adjudicator's verdict payload —
        so a malformed verdict can't redirect an unattended mutation onto an
        arbitrary entity or resolve an unrelated finding (defense-in-depth)."""
        with self._connect() as db:
            r = db.execute(
                "SELECT id, finding_type, ref_id, resolved_at, verdict "
                "FROM proactive_findings WHERE id=?",
                (finding_id,)).fetchone()
        if r is None:
            return None
        return {"id": r["id"], "finding_type": r["finding_type"],
                "ref_id": r["ref_id"], "resolved_at": r["resolved_at"] or "",
                "verdict": r["verdict"] or ""}

    def resolve_finding(self, finding_id: int, verdict: str | None = None) -> bool:
        """Dismiss one finding (sets resolved_at). If `verdict` is given, it is
        stored too, and record_finding's upsert will not reopen this finding on
        a later re-detection of the same (finding_type, ref_id) — a settled
        review decision (keep/skip/dismissed/etc.) should not resurface just
        because the same unchanged signal was detected again. Leave verdict
        None for a resolution that SHOULD still be reopenable (today's only
        path, and resolve_findings_not_in's "the underlying ref genuinely
        disappeared" case, which is a real new occurrence if it reappears).
        True if a row changed."""
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        with self._connect(write=True) as db:
            cur = db.execute(
                "UPDATE proactive_findings SET resolved_at=?, verdict=? "
                "WHERE id=? AND resolved_at IS NULL", (now, verdict, finding_id))
            return cur.rowcount > 0

    # --- Session-4, Task 2.1: reversible entity suppression ------------------

    def suppress_entity(self, entity_id: str, reason: str = "", *,
                        change: dict | None = None) -> bool:
        """Suppress an entity by inserting a row into entity_suppressions.

        Purely additive/reversible: the entities row is validated to exist but
        never touched (no column added, no delete). Returns False (no-op) if
        entity_id isn't a real entity. Reverse with unsuppress_entity.

        change: when given, any prior suppression row is read on this
        connection and an undoable change_log row is written with the write.
        """
        with self._connect(write=True) as db:
            row = db.execute("SELECT id FROM entities WHERE id=?", (entity_id,)).fetchone()
            if not row:
                return False
            prior = db.execute(
                "SELECT reason, suppressed_at FROM entity_suppressions WHERE entity_id=?",
                (entity_id,)).fetchone() if change is not None else None
            now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            db.execute(
                "INSERT OR REPLACE INTO entity_suppressions(entity_id, reason, suppressed_at) "
                "VALUES(?, ?, ?)",
                (entity_id, reason, now),
            )
            if change is not None:
                _log_recorded_change(
                    db, change, entity_id,
                    {"suppressed": dict(prior) if prior else None},
                    {"suppressed": {"reason": reason, "suppressed_at": now}})
            return True

    def unsuppress_entity(self, entity_id: str, *, change: dict | None = None) -> bool:
        """Remove a suppression. True if a row was deleted.

        change: when given and a row was deleted, an undoable change_log row is
        written on the same connection, recording the suppression it removed
        (reason and time) so the undo can hide the entity again exactly.
        """
        with self._connect(write=True) as db:
            prior = db.execute(
                "SELECT reason, suppressed_at FROM entity_suppressions WHERE entity_id=?",
                (entity_id,)).fetchone() if change is not None else None
            cur = db.execute("DELETE FROM entity_suppressions WHERE entity_id=?", (entity_id,))
            if cur.rowcount > 0 and change is not None and prior is not None:
                _log_recorded_change(db, change, entity_id,
                                     {"suppressed": dict(prior)}, {"suppressed": None})
            return cur.rowcount > 0

    def add_manual_observation(self, entity_id: str, attribute: str, value: str, *,
                               change: dict | None = None) -> int | None:
        """Write a fact the owner stated about an entity: a current observation
        with source='manual' and high confidence. Like a role set through
        graph_corrections._apply_set_field, it supersedes: any current manual
        observation of the same attribute is closed (valid_to = today) first.

        Returns the new observation id; None for an unknown entity; raises
        EntityHidden for a suppressed one (a fact there would be invisible).

        change: when given, an undoable change_log row recording the
        observation it wrote and the ones it closed is logged on the same
        connection."""
        today = datetime.now(timezone.utc).date().isoformat()
        with self._connect(write=True) as db:
            if db.execute("SELECT 1 FROM entities WHERE id=?", (entity_id,)).fetchone() is None:
                return None
            if db.execute("SELECT 1 FROM entity_suppressions WHERE entity_id=?",
                          (entity_id,)).fetchone():
                raise EntityHidden(entity_id)
            closed = [r["id"] for r in db.execute(
                "SELECT id FROM entity_observations WHERE entity_id=? AND attribute=? "
                "AND source='manual' AND valid_to IS NULL AND invalidated_at IS NULL",
                (entity_id, attribute))]
            if closed:
                marks = ",".join("?" * len(closed))
                db.execute(f"UPDATE entity_observations SET valid_to=? WHERE id IN ({marks})",
                           (today, *closed))
            oid = db.execute(
                "INSERT INTO entity_observations(entity_id, attribute, value, source, valid_from, "
                "confidence_source, last_seen) VALUES(?, ?, ?, 'manual', ?, 'high', ?)",
                (entity_id, attribute, value, today, today)).lastrowid
            if change is not None:
                _log_recorded_change(db, change, entity_id,
                                     {"fact": None, "closed": closed},
                                     {"fact": {"id": oid, "attribute": attribute,
                                               "value": value},
                                      "closed_on": today})
            return oid

    # --- Graph corrections (read side) ----------------------------------------

    @staticmethod
    def _decode_correction(row) -> dict:
        d = dict(row)
        d["payload"] = json.loads(d.get("payload") or "{}")
        d["snapshot"] = json.loads(d.get("snapshot") or "{}")
        return d

    def get_correction(self, correction_id: int) -> dict | None:
        with self._connect() as db:
            row = db.execute("SELECT * FROM graph_corrections WHERE id=?",
                             (int(correction_id),)).fetchone()
        return self._decode_correction(row) if row else None

    def pending_corrections(self, limit: int = 50) -> list[dict]:
        with self._connect() as db:
            rows = db.execute(
                "SELECT * FROM graph_corrections WHERE status='pending' "
                "ORDER BY id LIMIT ?", (int(limit),)).fetchall()
        return [self._decode_correction(r) for r in rows]

    def distinct_pair_set(self) -> set[tuple[str, str]]:
        with self._connect() as db:
            return {(r["a"], r["b"]) for r in db.execute(
                "SELECT a, b FROM entity_distinct_pairs")}

    def is_distinct_pair(self, a: str, b: str) -> bool:
        lo, hi = sorted((a, b))
        with self._connect() as db:
            return db.execute("SELECT 1 FROM entity_distinct_pairs WHERE a=? AND b=?",
                              (lo, hi)).fetchone() is not None

    def has_user_corrections(self, entity_id: str) -> bool:
        """True when the user corrected this entity in a way a merge would
        silently undo: a field lock (the loser's lock cascades away with its
        row) or a user hide (the loser's suppression row is deleted). Every
        automated merge applier skips a pair where either side has one --
        only the user may merge a corrected entity."""
        with self._connect() as db:
            return db.execute(
                "SELECT 1 FROM entity_field_locks WHERE entity_id=? UNION ALL "
                "SELECT 1 FROM entity_suppressions WHERE entity_id=? AND reason='user' "
                "LIMIT 1", (entity_id, entity_id)).fetchone() is not None

    def locked_fields(self, entity_id: str) -> set[str]:
        with self._connect() as db:
            return {r["field"] for r in db.execute(
                "SELECT field FROM entity_field_locks WHERE entity_id=?", (entity_id,))}

    # --- Session-4, Task 3.2: org-suggestion inbox ---------------------------

    def suggest_org_mapping(self, raw_org: str, reason: str = "") -> bool:
        """Record a suggestion that `raw_org` (an unrecognised org string the
        extractor keeps seeing) be added to the configured taxonomy.

        Purely additive: never writes config.json itself, just an inspectable
        row for a human (or a future dashboard/CLI) to review. INSERT OR
        REPLACE keyed on raw_org, so re-suggesting the same string refreshes
        reason/suggested_at instead of accumulating duplicates. Always
        succeeds — unlike suppress_entity, there's no existence precondition
        to fail (raw_org is a free-text string, not a foreign key).
        """
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        with self._connect(write=True) as db:
            db.execute(
                "INSERT OR REPLACE INTO org_suggestions(raw_org, reason, suggested_at) "
                "VALUES(?, ?, ?)",
                (raw_org, reason, now),
            )
            return True

    def find_open_action_by_fingerprint(self, fp: str) -> int | None:
        if not fp:
            return None
        with self._connect() as db:
            row = db.execute(
                "SELECT id FROM actions WHERE text_fingerprint=? AND status='open' "
                "LIMIT 1", (fp,)).fetchone()
            return row["id"] if row else None

    # --- Phase 3, Task 0.5D: waiting-on reader/writer methods ---------------

    def open_waiting_actions(
        self, window_days: int = 30, now: str | None = None
    ) -> list[dict]:
        """Open actions with a non-null waiting_on set within window_days of now.

        Filters: status='open', waiting_on IS NOT NULL, waiting_on_set_at > cutoff.
        If now is None, uses the current UTC time. Returns dicts ordered by id.
        """
        if now is None:
            now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        # Compute cutoff as an ISO string. SQLite text comparison on ISO-8601
        # strings is lexicographic and correct for this date range.
        cutoff_dt = datetime.fromisoformat(now.replace("Z", "+00:00"))
        cutoff = (cutoff_dt - timedelta(days=window_days)).strftime("%Y-%m-%dT%H:%M:%SZ")
        with self._connect() as db:
            return [
                dict(r)
                for r in db.execute(
                    "SELECT * FROM actions "
                    "WHERE status = 'open' "
                    "  AND waiting_on IS NOT NULL "
                    "  AND waiting_on_set_at > ? "
                    "ORDER BY id",
                    (cutoff,),
                ).fetchall()
            ]

    def clear_waiting(
        self, action_id: int, cleared_by_doc_id: str, now: str
    ) -> None:
        """Clear the waiting_on state for an action when a reply arrives.

        Sets waiting_on=NULL, stamps waiting_on_cleared_at and
        waiting_on_cleared_by_doc_id, sets reply_received=1, refreshes updated_at.
        No-op if the id does not exist.
        """
        with self._connect(write=True) as db:
            db.execute(
                "UPDATE actions SET "
                "  waiting_on = NULL, "
                "  waiting_on_cleared_at = ?, "
                "  waiting_on_cleared_by_doc_id = ?, "
                "  reply_received = 1, "
                "  updated_at = ? "
                "WHERE id = ?",
                (now, cleared_by_doc_id, now, action_id),
            )

    def inbound_chunks_since(self, cursor: str | None) -> list[dict]:
        """Return inbound chunks with metadata date > cursor.

        The date filter is pushed into SQL (json_extract over metadata.date, then
        metadata.date_iso) so a sweep no longer loads and JSON-parses the entire
        chunks table every cycle — only chunks newer than the cursor come back.
        cursor is an ISO date string or None (returns all inbound chunks). Chunks
        with no date are excluded when a cursor is set (NULL > cursor is NULL),
        included when cursor=None.

        SENT chunks are excluded in Python on the reduced set (labels may be a
        JSON array or a comma string, awkward to test in SQL).

        Note: the cursor uses strict `>`. With day-granular dates a same-day
        arrival after the cursor advances would be skipped; clearing is idempotent
        so a future move to `>=` (re-scanning the boundary day) would be safe. At
        larger corpus sizes, add a generated-column index on the extracted date.
        """
        date_expr = f"COALESCE({_meta_extract('$.date')}, {_meta_extract('$.date_iso')})"
        with self._connect() as db:
            if cursor:
                rows = db.execute(
                    f"SELECT rowid, doc_id, text, metadata FROM chunks "
                    f"WHERE metadata IS NOT NULL AND {date_expr} > ?",
                    (cursor,),
                ).fetchall()
            else:
                rows = db.execute(
                    "SELECT rowid, doc_id, text, metadata FROM chunks "
                    "WHERE metadata IS NOT NULL",
                ).fetchall()
        results = []
        for r in rows:
            try:
                meta = json.loads(r["metadata"])
            except Exception:
                continue
            # Skip SENT chunks.
            labels = meta.get("labels", [])
            if isinstance(labels, str):
                labels = json.loads(labels) if labels.startswith("[") else labels.split(",")
            if "SENT" in labels:
                continue
            results.append({
                "rowid": r["rowid"],
                "doc_id": r["doc_id"],
                "text": r["text"],
                "metadata": meta,
            })
        return results

    # --- B3 salience methods (Phase 2, 2026-06-23) ----------------------------

    def chunks_needing_salience(self, limit: int = 500) -> list[dict]:
        """Return chunks whose salience is 0.0 (never scored) and are embedded.

        Only embedded chunks are scored so the embedding exists as context.
        Returns {rowid, doc_id, text, metadata} dicts.
        """
        with self._connect() as db:
            rows = db.execute(
                "SELECT rowid, doc_id, text, metadata FROM chunks "
                "WHERE embedded=1 AND COALESCE(salience, 0.0) = 0.0 "
                "ORDER BY rowid DESC LIMIT ?",
                (limit,),
            ).fetchall()
        result = []
        for r in rows:
            try:
                meta = json.loads(r["metadata"])
            except Exception:
                meta = {}
            result.append({"rowid": r["rowid"], "doc_id": r["doc_id"],
                           "text": r["text"], "metadata": meta})
        return result

    def set_chunk_salience(self, doc_id: str, salience: float) -> None:
        """Write the salience score for one chunk."""
        with self._connect(write=True) as db:
            db.execute(
                "UPDATE chunks SET salience=? WHERE doc_id=?",
                (round(float(salience), 3), doc_id))

    def set_chunk_salience_batch(self, pairs: list[tuple]) -> None:
        """Write salience for many chunks. pairs = [(doc_id, salience), ...]."""
        if not pairs:
            return
        with self._connect(write=True) as db:
            db.executemany(
                "UPDATE chunks SET salience=? WHERE doc_id=?",
                [(round(float(s), 3), d) for d, s in pairs])

    def get_chunk_salience(self, doc_id: str) -> float:
        """Return the stored salience for a chunk (0.0 if unscored).

        Defensive against a pre-Phase-2 schema (no `salience` column) that a
        read-only handle can see in the upgrade→migration window — recall must
        not crash; an unscored chunk is simply 0.0.
        """
        with self._connect() as db:
            try:
                row = db.execute(
                    "SELECT salience FROM chunks WHERE doc_id=?", (doc_id,)).fetchone()
            except sqlite3.OperationalError:
                return 0.0
            return float(row["salience"] or 0.0) if row else 0.0

    # --- B2 memory tier/type methods (Phase 2, 2026-06-23) -------------------

    def set_chunk_tier(self, doc_id: str, tier: str) -> None:
        """Set memory_tier for one chunk. tier: core/hot/warm/cold/''."""
        with self._connect(write=True) as db:
            db.execute(
                "UPDATE chunks SET memory_tier=? WHERE doc_id=?", (tier, doc_id))

    def set_chunk_type(self, doc_id: str, memory_type: str) -> None:
        """Set memory_type for one chunk. type: episodic/semantic/procedural."""
        with self._connect(write=True) as db:
            db.execute(
                "UPDATE chunks SET memory_type=? WHERE doc_id=?", (memory_type, doc_id))

    def core_chunks(self, max_chars: int = 800) -> list[dict]:
        """Return chunks in the 'core' tier, newest first, up to max_chars total.

        The budget is calculated on snippet[:200] (same cap get_core_block uses),
        so a 1200-char consolidated note contributes at most 200 chars to the budget
        rather than exceeding it and being silently dropped.
        """
        _SNIPPET_CAP = 200
        with self._connect() as db:
            rows = db.execute(
                "SELECT doc_id, text, metadata FROM chunks "
                "WHERE memory_tier='core' AND COALESCE(enrich_state,'')!='cold' "
                "ORDER BY COALESCE(salience,0.0) DESC, rowid DESC",
            ).fetchall()
        result = []
        total = 0
        for r in rows:
            try:
                meta = json.loads(r["metadata"])
            except Exception:
                meta = {}
            snippet = (r["text"] or "").strip()
            if not snippet:
                continue
            contribution = min(len(snippet), _SNIPPET_CAP)
            if total + contribution > max_chars:
                break
            result.append({"doc_id": r["doc_id"], "text": snippet, "metadata": meta})
            total += contribution
        return result

    def promote_chunk_tier(self, doc_id: str, from_tier: str, to_tier: str) -> bool:
        """Promote a chunk from from_tier to to_tier. Returns True if updated."""
        with self._connect(write=True) as db:
            cur = db.execute(
                "UPDATE chunks SET memory_tier=? "
                "WHERE doc_id=? AND memory_tier=?",
                (to_tier, doc_id, from_tier))
            return cur.rowcount > 0

    def chunks_by_tier(self, tier: str, limit: int = 200) -> list[dict]:
        """Return {doc_id, text, metadata} for chunks in the given tier."""
        with self._connect() as db:
            rows = db.execute(
                "SELECT doc_id, text, metadata FROM chunks "
                "WHERE memory_tier=? ORDER BY rowid DESC LIMIT ?",
                (tier, limit),
            ).fetchall()
        result = []
        for r in rows:
            try:
                meta = json.loads(r["metadata"])
            except Exception:
                meta = {}
            result.append({"doc_id": r["doc_id"], "text": r["text"], "metadata": meta})
        return result

    # Core-tier durability (spec 2026-10-22 §2, M8): a semantic note earns core
    # only when recall surfaced it (exposure) or it was used in at least this
    # many distinct ISO weeks. Core is never refreshed by the core block itself
    # (/api/core records no exposures), so the signal is not self-feeding.
    CORE_DURABLE_WEEKS = 3

    def top_core_candidates(self, limit: int = 12) -> list[dict]:
        """Durable notes for the 'core' tier (spec 2026-10-22 §2): core
        requires an identity or procedural note, or a durability signal —
        surfaced by recall in >= CORE_DURABLE_WEEKS distinct weeks — never tied
        salience alone. Ranked identity first, then procedural, then durable
        notes by weeks seen, salience, recency. Cold chunks are excluded (a
        consolidated note is cold: derived, never core), except the identity
        seed, which is always core.

        Returns [{doc_id}]. Episodic email is intentionally excluded — core is for
        durable distilled facts, not raw correspondence.
        """
        ot = _meta_extract("$.observation_type")
        with self._connect() as db:
            rows = db.execute(
                f"SELECT doc_id, rank, weeks FROM ("
                f"  SELECT c.doc_id, c.rowid AS rid, COALESCE(c.salience,0.0) AS sal, "
                f"    CASE WHEN {ot} IN ('identity_seed','identity') THEN 0 "
                f"         WHEN c.memory_type = 'procedural' OR {ot} = 'procedural' THEN 1 "
                f"         ELSE 2 END AS rank, "
                f"    (SELECT COUNT(DISTINCT strftime('%Y-%W', rf.ts)) "
                f"       FROM recall_feedback rf WHERE rf.doc_id = c.doc_id "
                f"       AND rf.event_type IN ('exposure','used')) AS weeks, "
                f"    COALESCE(c.enrich_state,'') AS st "
                f"  FROM chunks c WHERE c.memory_type IN ('semantic','procedural')"
                f") WHERE (rank = 0) OR (st != 'cold' AND (rank = 1 OR weeks >= ?)) "
                f"ORDER BY rank, weeks DESC, sal DESC, rid DESC LIMIT ?",
                (self.CORE_DURABLE_WEEKS, limit),
            ).fetchall()
        return [{"doc_id": r["doc_id"]} for r in rows]

    def warm_chunks_above_strength(self, min_strength: float, limit: int = 2000) -> list[dict]:
        """Warm/untiered chunks whose memory_strength (built by recall) is at or
        above min_strength — candidates for promotion to 'hot'. Returns [{doc_id}]."""
        with self._connect() as db:
            rows = db.execute(
                "SELECT c.doc_id FROM chunks c "
                "JOIN chunk_quality cq ON cq.doc_id = c.doc_id "
                "WHERE COALESCE(c.memory_tier,'') IN ('', 'warm') "
                "  AND COALESCE(cq.memory_strength, 5.0) >= ? "
                "ORDER BY cq.memory_strength DESC LIMIT ?",
                (float(min_strength), limit),
            ).fetchall()
        return [{"doc_id": r["doc_id"]} for r in rows]

    # --- B4 thread context reader (Phase 2, 2026-06-23) ----------------------

    def thread_context(self, thread_id: str) -> str:
        """Return the contextual_summary for a thread (empty string if none).

        The summary is written by the thread synthesis cadence and piped into
        extraction context by prepare._thread_block. Returns '' so the caller
        can use `or ''` safely.
        """
        if not thread_id:
            return ""
        with self._connect() as db:
            row = db.execute(
                "SELECT contextual_summary FROM thread_context WHERE thread_id=?",
                (thread_id,),
            ).fetchone()
        if not row:
            return ""
        return (row["contextual_summary"] or "").strip()

    # --- B5 decay / memory strength methods (Phase 2, 2026-06-23) -----------

    def get_memory_strength(self, doc_id: str) -> tuple:
        """Return (strength, last_accessed_iso) for a chunk.

        Strength defaults to 5.0 (mid-range) and last_accessed to '' if the
        chunk_quality row doesn't exist yet.
        """
        with self._connect() as db:
            row = db.execute(
                "SELECT memory_strength, last_accessed FROM chunk_quality WHERE doc_id=?",
                (doc_id,),
            ).fetchone()
        if not row:
            return (5.0, "")
        return (float(row["memory_strength"] or 5.0), row["last_accessed"] or "")

    def update_memory_strength(self, doc_id: str, strength: float, last_accessed: str, *,
                               retries: int = _BEGIN_RETRIES,
                               busy_timeout_ms: int = DEFAULT_BUSY_TIMEOUT_MS) -> None:
        """Upsert memory_strength + last_accessed in chunk_quality."""
        with self._connect(write=True, retries=retries, busy_timeout_ms=busy_timeout_ms) as db:
            db.execute(
                "INSERT INTO chunk_quality(doc_id, quality, memory_strength, last_accessed) "
                "VALUES(?, 1.0, ?, ?) "
                "ON CONFLICT(doc_id) DO UPDATE SET "
                "  memory_strength=excluded.memory_strength, "
                "  last_accessed=excluded.last_accessed",
                (doc_id, round(float(strength), 3), last_accessed),
            )

    def update_memory_strength_batch(self, rows: list[tuple], *,
                                     retries: int = _BEGIN_RETRIES,
                                     busy_timeout_ms: int = DEFAULT_BUSY_TIMEOUT_MS) -> None:
        """Update many rows. rows = [(doc_id, strength, last_accessed), ...].

        retries / busy_timeout_ms: passed to _connect — callers on the recall
        path (see decay.update_on_recall) pass RECALL_PATH_BEGIN_RETRIES and
        RECALL_PATH_BUSY_TIMEOUT_MS so contention fails fast instead of adding
        wait time to a live recall response. retries alone does NOT bound the
        wait (see the comment on RECALL_PATH_BEGIN_RETRIES) -- both must be
        passed together.
        """
        if not rows:
            return
        with self._connect(write=True, retries=retries, busy_timeout_ms=busy_timeout_ms) as db:
            db.executemany(
                "INSERT INTO chunk_quality(doc_id, quality, memory_strength, last_accessed) "
                "VALUES(?, 1.0, ?, ?) "
                "ON CONFLICT(doc_id) DO UPDATE SET "
                "  memory_strength=excluded.memory_strength, "
                "  last_accessed=excluded.last_accessed",
                [(d, round(float(s), 3), la) for d, s, la in rows],
            )

    def chunks_for_decay_pass(self, limit: int = 2000) -> list[dict]:
        """Chunks eligible for decay evaluation: embedded, not core tier.

        Returns {doc_id, salience, memory_tier, memory_strength, last_accessed,
        metadata}. metadata lets decay anchor never-accessed chunks on their
        source date (email/file/event time) instead of exempting them forever.
        Joins chunks → chunk_quality (LEFT JOIN so unscored chunks still appear).
        """
        with self._connect() as db:
            rows = db.execute(
                "SELECT c.doc_id, COALESCE(c.salience,0.0) AS salience, "
                "       COALESCE(c.memory_tier,'') AS memory_tier, "
                "       COALESCE(c.metadata,'') AS metadata, "
                "       COALESCE(cq.memory_strength, 5.0) AS memory_strength, "
                "       COALESCE(cq.last_accessed, '') AS last_accessed "
                "FROM chunks c "
                "LEFT JOIN chunk_quality cq ON cq.doc_id = c.doc_id "
                "WHERE c.embedded=1 AND COALESCE(c.memory_tier,'') != 'core' "
                "ORDER BY c.rowid DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [dict(r) for r in rows]

    def demote_chunks_to_cold(self, doc_ids: list[str]) -> int:
        """Set memory_tier='cold' for the given doc_ids. Returns count changed."""
        if not doc_ids:
            return 0
        with self._connect(write=True) as db:
            qs = ",".join("?" for _ in doc_ids)
            cur = db.execute(
                f"UPDATE chunks SET memory_tier='cold' "
                f"WHERE doc_id IN ({qs}) AND memory_tier != 'core'",
                doc_ids,
            )
            return cur.rowcount

    # --- B6 voice suggestion methods (Phase 2, 2026-06-23) ------------------

    def insert_voice_suggestion(self, kind: str, rule: str, confidence: float,
                                evidence_ids: list, explanation: str) -> int:
        """Insert one voice suggestion. Returns the new row id."""
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        with self._connect(write=True) as db:
            cur = db.execute(
                "INSERT INTO voice_suggestions(kind, rule, confidence, explanation, "
                "evidence_ids, status, created_at) VALUES(?,?,?,?,?,?,?)",
                (kind, rule, round(float(confidence), 3), explanation,
                 json.dumps(evidence_ids), "pending", ts),
            )
            return cur.lastrowid

    def pending_voice_suggestions(self) -> list[dict]:
        """Return all pending voice suggestions."""
        with self._connect() as db:
            rows = db.execute(
                "SELECT * FROM voice_suggestions WHERE status='pending' ORDER BY id"
            ).fetchall()
        return [dict(r) for r in rows]

    def mark_voice_suggestion_applied(self, suggestion_id: int) -> None:
        """Mark one suggestion as applied."""
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        with self._connect(write=True) as db:
            db.execute(
                "UPDATE voice_suggestions SET status='applied', applied_at=? WHERE id=?",
                (ts, suggestion_id),
            )

    def claim_voice_suggestions(self, suggestion_ids: list[int]) -> list[int]:
        """Mark these pending suggestions applied and stamp last_applied_at, in
        one transaction, before voice.md is written: a retry after a later
        failure finds them applied and can't append them again. Returns the
        ids this call moved from pending to applied."""
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        claimed: list[int] = []
        with self._connect(write=True) as db:
            for sid in suggestion_ids:
                if db.execute("UPDATE voice_suggestions SET status='applied', applied_at=? "
                              "WHERE id=? AND status='pending'", (ts, sid)).rowcount:
                    claimed.append(sid)
            if claimed:
                db.execute(
                    "INSERT INTO voice_analyser_state(key, value, updated_at) VALUES(?, ?, ?) "
                    "ON CONFLICT(key) DO UPDATE SET value=excluded.value, "
                    "updated_at=excluded.updated_at", ("last_applied_at", ts, ts))
        return claimed

    def unclaim_voice_suggestions(self, suggestion_ids: list[int],
                                  last_applied_at: str) -> None:
        """Undo claim_voice_suggestions when voice.md could not be written:
        the suggestions go back to pending and last_applied_at to its prior
        value."""
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        with self._connect(write=True) as db:
            for sid in suggestion_ids:
                db.execute("UPDATE voice_suggestions SET status='pending', applied_at='' "
                           "WHERE id=? AND status='applied'", (sid,))
            db.execute("UPDATE voice_analyser_state SET value=?, updated_at=? "
                       "WHERE key='last_applied_at'", (last_applied_at or "", ts))

    def get_voice_analyser_state(self, key: str, default: str = "") -> str:
        """Read a key from voice_analyser_state."""
        with self._connect() as db:
            row = db.execute(
                "SELECT value FROM voice_analyser_state WHERE key=?", (key,)
            ).fetchone()
        return row["value"] if row else default

    def set_voice_analyser_state(self, key: str, value: str) -> None:
        """Upsert a key in voice_analyser_state."""
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        with self._connect(write=True) as db:
            db.execute(
                "INSERT INTO voice_analyser_state(key, value, updated_at) "
                "VALUES(?, ?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
                (key, value, ts),
            )

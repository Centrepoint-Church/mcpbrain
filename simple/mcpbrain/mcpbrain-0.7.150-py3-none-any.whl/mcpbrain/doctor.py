"""mcpbrain doctor — diagnose every health dimension and auto-fix the local,
idempotent failures, pointing at the exact next step for anything only
Claude/Cowork/the user can fix.

Reuses probes.all_connections (so CLI, wizard, monitor and doctor never
disagree) and adds a repair layer. Each probe maps to one of three
dispositions:

  auto    — a local idempotent fix exists: attempt it, re-probe, report fixed/❌
  guided  — only Claude/Cowork/the user can fix it: print the exact remedy
  ok/—    — healthy or deliberately unconfigured: report, do nothing

The repair calls are INJECTED (default dispatch wraps agents.* and the
records bootstrap) so the logic is unit-testable with stubs — no real
launchd/git/agent side effects in tests.

Scheduled-task health is INFERRED from probe_enrichment: the daemon cannot read
the Cowork app DB, so doctor cannot verify the four scheduled tasks directly.
It states this honestly. Recreating tasks is therefore always a guided step
(/mcpbrain:install), never auto.
"""
from __future__ import annotations

import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

from mcpbrain.mcp_server import live_version_records

# Probe key -> disposition. "auto" keys carry the repair-dispatch key to call;
# "guided" keys carry the remedy string to print. Keys absent here are reported
# verbatim with no action.
#
# Note: probe keys are google/claude/backup/records/enrichment. The
# report adds a synthetic "scheduled_tasks" line inferred from enrichment.
_DISPOSITIONS: dict[str, dict] = {
    "claude":     {"kind": "auto", "repair": "daemon",
                   "label": "Daemon",
                   "guided": "Install the mcpbrain plugin and run /reload-plugins"},
    "records":    {"kind": "auto", "repair": "records", "label": "Records"},
    "google":     {"kind": "guided", "label": "Google",
                   "guided": "Run: mcpbrain auth"},
    "enrichment": {"kind": "guided", "label": "Enrichment",
                   "guided": "Open Claude or run /mcpbrain:install in Claude Code"},
    "backup":     {"kind": "guided", "label": "Backup",
                   "guided": "Run: mcpbrain backup"},
}

# States that mean "needs attention". not_started is deliberately healthy for
# the optional connections (backup/enrichment): an unconfigured feature
# is not a fault. claude not_started (plugin never connected) and records
# not_started (repo never created) ARE actionable, so they are handled per-key.
_FAIL_STATES = {"needs_action"}


def _platform() -> str:
    p = sys.platform
    if p.startswith("linux"):
        return "linux"
    if p == "darwin":
        return "darwin"
    if p in ("win32", "cygwin"):
        return "win32"
    return p


def _mcpbrain_bin() -> str:
    return shutil.which("mcpbrain") or sys.argv[0] or "mcpbrain"


def _default_repairs(home: str, platform: str, mcpbrain_bin: str) -> dict:
    """The real repair dispatch: idempotent local fixes only."""
    from mcpbrain import agents, config, records

    def _repair_daemon():
        agents.restart_agent(platform)

    def _repair_agent():
        agents.install_agent(platform, mcpbrain_bin=mcpbrain_bin, home=home)

    def _repair_records():
        # Pass profile so ensure_records_repo renders the CLAUDE.md + context/
        # reference templates, not just the git scaffold anchors.
        records.ensure_records_repo(
            config.records_dir(home),
            git_name=config.owner_full_name(home) or "mcpbrain",
            git_email=config.owner_email(home) or "mcpbrain@localhost",
            profile=config.read_config(home),
        )

    def _repair_embedder():
        # Warming the embedder forces fastembed to (re-)download the weights into
        # the persistent cache dir and verifies onnxruntime can actually load them.
        # Idempotent: a no-op when the weights are already present. Needs network.
        #
        # On Windows-ARM, x64 onnxruntime/sqlite-vec run under emulation and need
        # the x64 VC++ runtime. The primary fix is the clean x64 vc_redist
        # installed by install.ps1; this is the last-resort safety net — copy the
        # required DLLs from an MS-signed x64 copy on the machine into
        # app_dir()/vcruntime (a location that survives package reinstalls), then
        # add that dir to THIS process's DLL search path (daemon.py does the same
        # on its own startup via the shared helper) before retrying the warm-up —
        # otherwise the freshly-copied DLLs aren't visible until the next daemon
        # restart.
        if sys.platform == "win32":
            from mcpbrain import vcruntime
            vcruntime.ensure_vcruntime_dlls(str(home))
            vcruntime.add_search_dir(str(home))
        from mcpbrain.embed import get_embedder
        get_embedder().embed_query("warm")

    def _repair_baseline():
        # Re-run the baseline bootstrap via the running daemon (which owns the
        # store + Google services). Degrades if the daemon is down.
        from mcpbrain.control_client import ControlClient, DaemonUnavailable
        try:
            return ControlClient(home, timeout=600).bootstrap_baseline()
        except DaemonUnavailable:
            return {"status": "skipped", "reason": "daemon not running"}

    def _repair_ocr():
        # Install the tesseract CLI. Scanned, image-only PDFs have no text layer,
        # so OCR is the only way to read them, and extractors.py degrades to an
        # empty text layer without it — silently, which is why this needs to be
        # both reported and repairable rather than left to a log line during
        # ingestion. Best-effort: returns why, never raises.
        from mcpbrain import ocr
        ok, msg = ocr.install_tesseract(platform)
        return {"status": "ok" if ok else "skipped", "reason": msg}

    def _repair_connector():
        # Re-register with every Claude surface present. Idempotent, and the
        # merge writer refuses to touch a config it cannot parse.
        from mcpbrain import connector
        connector.register_connector(mcpbrain_bin=mcpbrain_bin)

    return {"daemon": _repair_daemon, "agent": _repair_agent,
            "records": _repair_records, "embedder": _repair_embedder,
            "baseline": _repair_baseline, "ocr": _repair_ocr,
            "connector": _repair_connector}


def _is_problem(key: str, state: str) -> bool:
    """True when this probe state is an actionable problem for doctor."""
    if key in ("claude", "records"):
        return state in _FAIL_STATES or state == "not_started"
    return state in _FAIL_STATES


def _reprobe(home, key: str, fallback: dict) -> dict:
    """Re-run the live probes and return this key's fresh result."""
    from mcpbrain import probes
    return probes.all_connections(home).get(key, fallback)


def _live_daemon_status(home) -> dict | None:
    """The running daemon's /api/status, or None when it isn't reachable.

    A down daemon is already reported by the "claude" probe, so this degrades
    silently rather than adding a second failure line for the same cause.
    """
    from mcpbrain.control_client import ControlClient
    try:
        return ControlClient(str(home), timeout=5).status()
    except Exception:  # noqa: BLE001 — diagnostics must never fail on a probe
        return None


def _same_install(command: str, mcpbrain_bin: str) -> bool:
    """True when the config's command and the running install are one file.

    uv puts a link on PATH (~/.local/bin/mcpbrain) to the tool venv's real
    script. The connector writes the link; a daemon started by launchd has no
    ~/.local/bin on PATH, so it sees itself as the venv script. Compared as
    text the two never match, which reported a correct connector as stale.
    """
    if command == mcpbrain_bin:
        return True
    try:
        return Path(command).resolve() == Path(mcpbrain_bin).resolve()
    except (OSError, RuntimeError, ValueError):
        return False


def connector_lines(*, mcpbrain_bin: str) -> list[str]:
    """One report line per Claude config file on this machine.

    The failure this exists for is silent: on Windows MSIX installs the app reads
    a virtualised config path, so a write to the documented %APPDATA% location
    succeeds and is then ignored. Nothing surfaced that until a hardware QA gate
    did. A config file that simply is not present is informational (➖), not a
    fault — a machine may legitimately have only one of the two surfaces.
    """
    import json as _json
    from mcpbrain import connector

    lines: list[str] = []
    targets = list(connector.desktop_config_paths()) + [connector.code_config_path()]
    for path in targets:
        label = "Connector"
        if not path.exists():
            lines.append(f"➖ {label:<16} {path.name} not present ({path.parent})")
            continue
        try:
            data = _json.loads(path.read_text())
        except (OSError, ValueError) as exc:
            lines.append(f"⚠️  {label:<16} could not read {path} ({exc})")
            continue
        # data/mcpServers/entry can each independently be the wrong JSON shape
        # (a hand-edited config, or one written by something else entirely) —
        # never let .get()/.get() on a non-dict raise out of this function.
        servers = data.get("mcpServers") if isinstance(data, dict) else None
        entry = servers.get("mcpbrain") if isinstance(servers, dict) else None
        if not entry:
            lines.append(f"⚠️  {label:<16} not registered in {path} — "
                         f"run 'mcpbrain connect'")
            continue
        if not isinstance(entry, dict):
            lines.append(f"⚠️  {label:<16} malformed connector entry in {path} — "
                         f"run 'mcpbrain connect'")
            continue
        command = entry.get("command") or ""
        if not Path(command).exists():
            lines.append(f"⚠️  {label:<16} {path.name} points at {command}, which "
                         f"does not exist — run 'mcpbrain connect'")
            continue
        if not _same_install(command, mcpbrain_bin):
            lines.append(f"⚠️  {label:<16} {path.name} points at {command}, which "
                         f"differs from the current install ({mcpbrain_bin}) — "
                         f"run 'mcpbrain connect'")
            continue
        lines.append(f"✅ {label:<16} registered in {path.name} → {command}")
    return lines


# A sync queue item is normally fetched within minutes of being found. Only a
# backlog whose oldest item has waited this long is worth a person's look;
# anything younger is the queue doing its job.
SYNC_QUEUE_STUCK_S = 3600


def _age_words(seconds: float) -> str:
    m = int(seconds // 60)
    if m < 1:
        return "under a minute"
    if m < 120:
        return f"{m} min"
    h = m // 60
    return f"{h} h" if h < 48 else f"{h // 24} days"


def sync_queue_line(pending: int, oldest_discovered_at, now: datetime | None = None) -> str:
    """One doctor line for the sync queue: ✅ while it is moving, ⚠️ once its
    oldest item has waited SYNC_QUEUE_STUCK_S (the tail-starvation risk
    accepted with newest-first ordering shows as an age that climbs)."""
    if not pending:
        return f"✅ {'Sync queue':<16} 0 pending"
    now = now or datetime.now(timezone.utc)
    age = None
    try:
        found = datetime.fromisoformat(str(oldest_discovered_at))
        if found.tzinfo is None:
            found = found.replace(tzinfo=timezone.utc)
        age = max(0.0, (now - found).total_seconds())
    except (TypeError, ValueError):
        pass
    if age is None:
        return (f"⚠️ {'Sync queue':<16} {pending:,} pending "
                f"(oldest discovered {oldest_discovered_at})")
    if age < SYNC_QUEUE_STUCK_S:
        return f"✅ {'Sync queue':<16} {pending:,} pending, oldest {_age_words(age)} old"
    return (f"⚠️ {'Sync queue':<16} {pending:,} pending, oldest {_age_words(age)} old "
            f"(discovered {oldest_discovered_at})")


def infra_refused_lines(store) -> list[str]:
    """One ⚠️ per drive whose infrastructure purge was refused."""
    import json as _json
    from mcpbrain.ingest_cache import INFRA_REFUSED_META
    out = []
    for key, raw in sorted(store.meta_with_prefix(INFRA_REFUSED_META).items()):
        try:
            n = int(_json.loads(raw).get("count") or 0)
        except (TypeError, ValueError, AttributeError):
            n = 0
        drive = key[len(INFRA_REFUSED_META):]
        out.append(f"⚠️  {'Infra drives':<16} mcpbrain did not remove {n} item(s) "
                   f"from {drive} because they look like real documents → keep "
                   "mcpbrain's backup/fleet folders in a Shared Drive of their own")
    return out


def run_doctor(home, *, conns=None, repairs=None, reprobe=None, platform=None,
               mcpbrain_bin=None, agent_installed=None, model_present=None,
               daemon_status=None, offline: bool = False) -> tuple[int, str]:
    """Diagnose, auto-fix the idempotent local failures, report, return (code, msg).

    Pure-ish: probes and repairs are injectable. With nothing injected it reads
    the live probes and builds the real repair dispatch. Exit code is 0 when
    nothing needs user action after auto-fix, else 1.

    offline: when True and daemon_status was not explicitly injected, skip the
    live /api/status probe (_live_daemon_status) entirely instead of attempting
    it and degrading to None on failure. That probe is a real HTTP call against
    the local daemon's control API, added for the watchdog-restart-limiter
    line — every other live check here (probes.all_connections) predates it and
    is doctor's actual job, but this one is new and skippable, so offline mode
    restores a way to run doctor's other checks with zero network/socket
    attempts (e.g. from a sandboxed test, or a "just show me the rest" run).
    Defaults to False so the CLI's existing behaviour (always live) is
    unchanged; wired to `--offline` in run_doctor_main.
    """
    from mcpbrain import probes

    platform = platform or _platform()
    mcpbrain_bin = mcpbrain_bin or _mcpbrain_bin()
    if reprobe is None:
        reprobe = _reprobe
    if agent_installed is None:
        agent_installed = _agent_installed
    if model_present is None:
        from mcpbrain.embed import model_weights_cached
        model_present = lambda _home: model_weights_cached()  # noqa: E731
    if conns is None:
        conns = probes.all_connections(home)
    if repairs is None:
        repairs = _default_repairs(str(home), platform, mcpbrain_bin)
    if daemon_status is None:
        daemon_status = {} if offline else _live_daemon_status(home)

    lines: list[str] = []
    fixed = 0
    need_action = 0

    for key, disp in _DISPOSITIONS.items():
        probe = conns.get(key, {"state": "not_started", "detail": ""})
        state = probe.get("state", "not_started")
        label = disp["label"]

        if not _is_problem(key, state):
            # Distinguish "configured + healthy" (✅) from "deliberately not set
            # up" (➖). A green ✅ next to "Not connected" / "Backup off" reads as
            # working to a non-technical user, which it is not.
            if state == "not_started":
                lines.append(f"➖ {label:<16} {probe.get('detail') or 'Not set up'} "
                             f"(optional — not configured)")
            else:
                lines.append(f"✅ {label:<16} {probe.get('detail') or 'OK'}")
            continue

        if disp["kind"] == "auto" and state in _FAIL_STATES:
            # For claude needs_action: choose install vs restart based on agent presence
            if key == "claude":
                if not agent_installed(home, platform):
                    repair_key = "agent"
                else:
                    repair_key = "daemon"
            else:
                repair_key = disp["repair"]
            repair = repairs.get(repair_key)
            if repair is None:
                lines.append(f"❌ {label:<16} no repair registered for '{repair_key}'")
                need_action += 1
                continue
            try:
                repair()
                new_probe = reprobe(home, key, probe)
                new_state = new_probe.get("state", state)
            except Exception as exc:  # noqa: BLE001
                lines.append(f"❌ {label:<16} {probe.get('detail')} → repair failed: {exc}")
                need_action += 1
                continue
            if not _is_problem(key, new_state):
                action = "re-registering agent" if repair_key == "agent" else "restarting"
                lines.append(f"❌ {label:<16} {probe.get('detail')} → {action}... ✅ fixed")
                fixed += 1
            else:
                lines.append(f"❌ {label:<16} {probe.get('detail')} → repair did not fix it; "
                             f"run {disp.get('guided', 'mcpbrain setup')}")
                need_action += 1
            continue

        if key == "records" and state == "not_started":
            repair = repairs.get("records")
            if repair is None:
                lines.append(f"❌ {label:<16} no repair registered for 'records'")
                need_action += 1
                continue
            try:
                repair()
                new_probe = reprobe(home, "records", probe)
                if not _is_problem("records", new_probe.get("state", state)):
                    lines.append(f"❌ {label:<16} not created → creating... ✅ fixed")
                    fixed += 1
                else:
                    lines.append(f"❌ {label:<16} could not create records repo")
                    need_action += 1
            except Exception as exc:  # noqa: BLE001
                lines.append(f"❌ {label:<16} records repo create failed: {exc}")
                need_action += 1
            continue

        # guided (incl. claude not_started = plugin not connected)
        remedy = disp.get("guided", "see the mcpbrain wizard")
        lines.append(f"⚠️  {label:<16} {probe.get('detail')} → {remedy}")
        need_action += 1

    # Embedder weights: the local bge-small model must be cached on disk or
    # `mcpbrain mcp-server` dies at startup with onnxruntime NO_SUCHFILE — which
    # the user only ever sees as "unable to connect to the MCP server". Cheap
    # offline presence check; auto-repair warms the embedder (re-downloads +
    # verifies it loads). Needs network only when the weights are actually gone.
    if model_present(home):
        lines.append(f"✅ {'Embedder':<16} model weights cached")
    else:
        repair = repairs.get("embedder")
        try:
            if repair is not None:
                repair()
            healed = model_present(home)
        except Exception as exc:  # noqa: BLE001
            lines.append(f"❌ {'Embedder':<16} weights missing → re-download failed: "
                         f"{exc} (needs network; rerun mcpbrain doctor when online)")
            need_action += 1
        else:
            if healed:
                lines.append(f"❌ {'Embedder':<16} weights missing → downloading... ✅ fixed")
                fixed += 1
            else:
                lines.append(f"❌ {'Embedder':<16} weights missing → re-download did not "
                             f"land (needs network; rerun mcpbrain doctor when online)")
                need_action += 1

    # Baseline bootstrap: re-runnable import of the org snapshot + shared-drive
    # ingest caches. Injected so tests don't hit the network; a down daemon or an
    # unreachable fleet is a graceful skip (➖), never an actionable fault.
    baseline = repairs.get("baseline")
    if baseline is None:
        lines.append(f"➖ {'Baseline':<16} not checked")
    else:
        try:
            res = baseline() or {}
            st = res.get("status", "unknown")
            # done/skipped -> ✅. degraded (no transport yet) and pending (curator
            # hasn't published / fleet_secret not distributed) are expected waiting
            # states on a fresh install -> ➖, not an actionable fault. Only a hard
            # error is ❌.
            glyph = ("✅" if st in ("done", "skipped")
                     else "❌" if st == "error"
                     else "➖")
            if res.get("reason") == "restore pending":
                # Held on purpose (see the Restore line), not a failure: an
                # import would fill the empty store the pending restore needs.
                glyph = "➖"
            lines.append(f"{glyph} {'Baseline':<16} bootstrap {st}"
                         + (f" ({res['reason']})" if res.get("reason") else ""))
        except Exception as exc:  # noqa: BLE001 — never fatal
            lines.append(f"➖ {'Baseline':<16} skipped ({exc})")

    # Watchdog restart limiter. The daemon self-restarts on a 30-min stall but
    # gives up after 3 restarts in 6 hours and stays up "visibly stuck" — which
    # is only visible if something says so. Skipped entirely when the daemon
    # isn't reachable (the Daemon line already covers that).
    if daemon_status:
        wd_exits = int(daemon_status.get("watchdog_exits") or 0)
        if daemon_status.get("watchdog_limit_reached"):
            lines.append(f"❌ {'Watchdog':<16} {wd_exits} self-restarts in the last 6 h — "
                         f"restart limit reached, daemon left running for diagnosis; "
                         f"check the daemon log")
            need_action += 1
        elif wd_exits:
            lines.append(f"✅ {'Watchdog':<16} {wd_exits} self-restart(s) in the last 6 h "
                         f"(recovered)")
        else:
            lines.append(f"✅ {'Watchdog':<16} no stall restarts")
        gu_line = google_unavailable_line(daemon_status)
        if gu_line:
            lines.append(gu_line)
        for fn, actionable in ((restore_pending_line, True), (restore_error_line, True),
                               (prune_held_line, False)):
            extra = fn(daemon_status)
            if extra:
                lines.append(extra)
                need_action += int(actionable)

    for line in backup_extra_lines(home):
        lines.append(line)

    lines.append(arch_line())
    lines.append(tenant_line())

    # Connector registration: not probe-driven through _DISPOSITIONS (same as
    # embedder/baseline above), so it gets its own explicit repair dispatch.
    # A "⚠️" line means an actionable problem (missing/malformed/stale entry);
    # "➖"/"✅" need no repair. Re-check after repairing so the report reflects
    # the POST-repair state, mirroring the embedder block's `healed` idiom.
    conn_lines = connector_lines(mcpbrain_bin=mcpbrain_bin)
    if any(line.startswith("⚠️") for line in conn_lines):
        connector_repair = repairs.get("connector")
        if connector_repair is not None:
            try:
                connector_repair()
            except Exception:  # noqa: BLE001 — a diagnostic must not break doctor
                pass
            conn_lines = connector_lines(mcpbrain_bin=mcpbrain_bin)
            if any(line.startswith("⚠️") for line in conn_lines):
                need_action += 1
            else:
                # Mirror the embedder block fully: a repair that actually worked
                # is reported as fixed, not silently folded into "0 fixed, 0 need
                # your action" — which is what the summary said before.
                fixed += 1
    lines.extend(conn_lines)

    drift_line = version_drift_line(home)
    if drift_line is not None:
        lines.append(drift_line)

    # OCR availability. Without tesseract, scanned/image-only PDFs are indexed
    # with an empty text layer and nothing says so outside a per-file log line
    # during ingestion — which is how this stayed off on every install for
    # months. A warning, not an error: everything except scanned-PDF text works
    # without it, and `mcpbrain doctor --repair` installs it.
    try:
        from mcpbrain import ocr
        if ocr.tesseract_available():
            lines.append(f"✅ {'OCR':<16} tesseract available (scanned PDFs readable)")
        else:
            lines.append(f"⚠️  {'OCR':<16} tesseract missing — scanned PDFs index "
                         f"with no text; run 'mcpbrain doctor --repair'")
    except Exception as exc:  # noqa: BLE001 — a diagnostic must not break doctor
        lines.append(f"⚠️  {'OCR':<16} could not check tesseract ({exc})")

    # Chunks whose embed passage exceeds the embedder window (512 tokens ≈
    # 2,000 chars). They are embedded across windows (embed_chunk_passages), so
    # no tail is lost -- but only once re-embedded: a chunk embedded before
    # that change keeps its truncated vector until the one-shot oversize heal
    # (daemon._oversize_heal_reset, meta `oversize_heal`) resets it. Measured on
    # the PREFIXED passage (embed.passage_over_window via
    # Store.count_passages_over_window), the same measure the heal and the
    # embedder act on, so a chunk that only crosses the window with its
    # context prefix is counted too.
    from mcpbrain.store import Store
    from mcpbrain.embed import EMBED_WINDOW_CHARS
    # "brain.sqlite3" — the same filename config.store_path() builds under
    # app_dir(); spelled relative to the injected `home` because run_doctor is
    # home-parameterised (tests pass a tmp_path). It said "b.sqlite3" for a
    # while, which exists nowhere: the read-only handle raised OperationalError,
    # the `except Exception` below swallowed it into "skipped", and the chunk
    # window + repair-state lines never printed on any real install.
    store = Store(Path(home) / "brain.sqlite3", dim=4, read_only=True)
    try:
        from mcpbrain import config as _cfg
        oversize, left = store.count_passages_over_window(
            EMBED_WINDOW_CHARS, use_prefix=_cfg.contextual_retrieval_enabled(home))
        text = f"{oversize} chunk(s) longer than one window"
        if not oversize:
            lines.append(f"✅ {'Chunk window':<16} {text}")
        else:
            # ✅ only once the heal is done AND nothing over the window is
            # still waiting for its (windowed) embedding.
            try:
                heal = json.loads(store.get_meta("oversize_heal") or "{}")
            except ValueError:
                heal = {}
            if isinstance(heal, dict) and heal.get("state") == "done" and not left:
                lines.append(f"✅ {'Chunk window':<16} {text}, embedded across windows")
            else:
                tail = f" ({left} left)" if left else ""
                lines.append(f"⚠️ {'Chunk window':<16} {text} — re-embed pending{tail}")
    except Exception as exc:  # noqa: BLE001 — never fatal
        lines.append(f"➖ {'Chunk window':<16} skipped ({exc})")

    # Repair progress (spec 3, bin/repair.py): content-free chunks and Drive
    # files whose chunks predate the current chunker. Surfaced here so "is the
    # repair done?" is answerable without running the CLI.
    try:
        from mcpbrain.chunking import CHUNKER_VERSION, PRIOR_CHUNKER_VERSION
        empty = store.count_content_free()
        stale = len(store.stale_chunker_ids(table_version=CHUNKER_VERSION,
                                            other_version=PRIOR_CHUNKER_VERSION,
                                            limit=100_000))
        lines.append(f"{'✅' if not empty else '⚠️'} content-free chunks: {empty}")
        lines.append(f"{'✅' if not stale else '⚠️'} Items awaiting re-chunk: {stale}")
    except Exception as exc:  # noqa: BLE001 — never fatal
        lines.append(f"➖ {'Repair state':<16} skipped ({exc})")

    # Sync queue backlog (spec: presence IS pending, so this is a fact, not an
    # estimate). oldest_discovered_at is deliberate: it exposes the
    # tail-starvation risk accepted with newest-first ordering — a backlog
    # that is not shrinking shows as an age that climbs.
    try:
        q = store.sync_queue_stats()
        lines.append(sync_queue_line(q["pending"], q["oldest_discovered_at"]))
        if q["failing"]:
            detail = ", ".join(f"{f['ref_id']} ({f['attempts']} attempts: "
                               f"{f['last_error']})" for f in q["failing"])
            lines.append(f"⚠️ {'Sync failures':<16} "
                         f"{len(q['failing'])} items retrying — {detail}")
    except Exception as exc:  # noqa: BLE001 — never fatal
        lines.append(f"➖ {'Sync queue':<16} skipped ({exc})")

    # mcpbrain's own backup/fleet folders found inside a drive whose stored
    # chunks look like real documents: the purge refused to delete them
    # (ingest_cache.purge_infrastructure). Silent otherwise.
    try:
        lines.extend(infra_refused_lines(store))
    except Exception as exc:  # noqa: BLE001 — never fatal
        lines.append(f"➖ {'Infra drives':<16} skipped ({exc})")

    # Bi-temporal back-pointers whose target row is gone. Surfaced because
    # foreign_key_check is STRUCTURALLY BLIND to any of these columns that does
    # not declare a REFERENCES clause -- which is every store that has not been
    # rebuilt. Residue predates FK enforcement and cannot be produced by
    # current code (tests/test_dangling_invalidators.py pins that), so a
    # NON-ZERO count here on an already-rebuilt store means something
    # reintroduced writes with foreign_keys OFF, and is worth investigating
    # rather than just sweeping. Repair: `bin/optimise_store.py --nullify-dangling`.
    try:
        dangling = store.count_dangling_invalidators()
        lines.append(f"{'✅' if not dangling else '⚠️'} dangling invalidator "
                     f"pointers: {dangling}")
    except Exception as exc:  # noqa: BLE001 — never fatal
        lines.append(f"➖ {'Invalidators':<16} skipped ({exc})")

    # Store integrity. Costs ~19s on a 1.9 GB store and is worth every second:
    # foreign_key_check above is structurally blind to a damaged b-tree, which is
    # how the 2026-09-10 sync_cursors corruption stayed invisible for hours.
    lines.append(integrity_line(home))
    lines.append(reflow_line(store))
    lines.append(ingestion_cleanup_line(store))

    # Scheduled tasks: inferred from enrichment, never auto. Stated honestly.
    enr = conns.get("enrichment", {}).get("state", "not_started")
    enr_already_counted = enr in _FAIL_STATES  # already counted in the loop above
    if enr == "ok":
        lines.append("✅ Scheduled tasks  enrichment fresh ⇒ enrich task firing")
    else:
        lines.append("⚠️  Scheduled tasks  not directly checkable → "
                     "run /mcpbrain:install in Claude Code to recreate the "
                     "enrich/meeting-packs/gardener/reference-gardener tasks")
        if not enr_already_counted:
            need_action += 1

    header = (f"mcpbrain doctor — {datetime.now(timezone.utc):%Y-%m-%d %H:%M} UTC   "
              f"(home: {home})")
    summary = f"{fixed} fixed automatically, {need_action} need your action (see ↑)."
    message = "\n".join([header, "", *lines, "", summary])
    return (1 if need_action else 0), message


def _true_os_arch() -> str:
    """Best-effort native OS architecture, even when the running interpreter is
    itself emulated (e.g. an x64 Python launched via WOW64 on an ARM64 Windows
    box reports AMD64 from platform.machine() same as the OS would report).

    Windows: PROCESSOR_ARCHITEW6432 is set by WOW64 ONLY when the current
    process is emulated, and holds the true native arch (e.g. "ARM64") in
    that case; PROCESSOR_ARCHITECTURE is the native arch when not emulated.
    macOS: an x86_64 interpreter under Rosetta on Apple Silicon reports
    "x86_64" from platform.machine(); `sysctl.proc_translated == 1` means the
    process is translated, so the true hardware arch is arm64.
    Other: platform.machine().
    """
    import os
    import platform
    import sys

    if os.name == "nt":
        return (os.environ.get("PROCESSOR_ARCHITEW6432")
                or os.environ.get("PROCESSOR_ARCHITECTURE")
                or platform.machine())
    if sys.platform == "darwin" and _is_rosetta_translated():
        return "arm64"
    return platform.machine()


def _is_rosetta_translated() -> bool:
    """True iff this process runs under Rosetta 2 (translated x86_64 on Apple
    Silicon). `sysctl.proc_translated` is 1 when translated, 0 native, absent on
    Intel Macs. Best-effort — any error means 'not translated'."""
    import subprocess
    try:
        out = subprocess.run(["sysctl", "-n", "sysctl.proc_translated"],
                             capture_output=True, text=True, timeout=2)
        return out.returncode == 0 and out.stdout.strip() == "1"
    except (OSError, subprocess.SubprocessError):
        return False


_ARCH_NORM = {"arm64": "ARM64", "aarch64": "ARM64", "amd64": "X64", "x64": "X64", "x86_64": "X64"}


def google_unavailable_line(daemon_status: dict | None) -> str | None:
    """⚠️ while the running daemon is retrying a Google build that failed
    transiently, else None.

    The Google probe checks the TOKEN, which can be perfectly fine while the
    daemon itself could not reach Google at start-up: live 2026-10-09 that
    left sync and backup off for three days under a green "Google Verified".
    The daemon retries on its own, so this is a warning, not an action item.
    """
    gu = (daemon_status or {}).get("google_unavailable")
    if not gu:
        return None
    attempts = int(gu.get("attempts") or 0)
    affects = ", ".join(gu.get("affects") or [])
    line = (f"⚠️  {'Google':<16} unreachable since {gu.get('since') or 'start-up'}, "
            f"retrying ({attempts} attempt{'s' if attempts != 1 else ''})")
    if affects:
        line += f" — {affects} waiting"
    if gu.get("last_error"):
        line += f"; last error: {gu['last_error']}"
    return line


def restore_pending_line(daemon_status: dict | None) -> str | None:
    """⚠️ (and an action item) while the daemon holds sync for a pending restore.

    Set when Google was unreachable as the daemon started on an empty store
    with backup configured. Sync and backups are held so the store stays empty
    and the snapshot is never overwritten; the daemon retries on its own.
    """
    rp = (daemon_status or {}).get("restore_pending")
    if not rp:
        return None
    since = rp.get("since") or "start-up"
    line = (f"⚠️  {'Restore':<16} restore pending since {since}: mcpbrain is holding sync "
            f"so your backup is not overwritten — restart the daemon while online")
    if rp.get("restart_budget_spent"):
        line += " (automatic restarts used up)"
    return line


def restore_error_line(daemon_status: dict | None) -> str | None:
    """❌ after a NON-transient restore-on-first-run failure (wrong key,
    corrupt snapshot): the daemon carried on without the snapshot."""
    err = (daemon_status or {}).get("restore_error")
    if not err:
        return None
    return (f"❌ {'Restore':<16} restore-on-first-run failed: {err} — the store was not "
            f"restored; run 'mcpbrain restore --check'")


def prune_held_line(daemon_status: dict | None) -> str | None:
    """⚠️ while the snapshot prune holds off (newest drastically smaller)."""
    ph = (daemon_status or {}).get("prune_held")
    if not ph:
        return None
    return (f"⚠️  {'Backup':<16} old snapshots kept: the newest is "
            f"{ph.get('newest_bytes', 0):,} bytes vs {ph.get('largest_kept_bytes', 0):,} "
            f"— pruning paused so a good snapshot stays restorable")


_DISCARD_SHOWN_S = 7 * 86400
_DELETE_FAILURE_MIN = 3


def _discard_reason(raw) -> str:
    """Plain-English reason for a discarded local backup file (the uploader's
    internal reason strings are for the log, not for a person)."""
    r = str(raw or "").lower()
    if "mismatched on drive" in r:
        return "the upload kept failing its check"
    if any(k in r for k in ("corrupt", "sha256", "missing", "gap")):
        return "a backup file on this computer was damaged"
    return "it could not be read"


def backup_extra_lines(home, now: float | None = None) -> list[str]:
    """Extra ⚠️ Backup lines read from LOCAL files only (works with the daemon
    down; never calls Drive): a damaged local backup the daemon discarded in
    the last 7 days, and old backup files Drive refuses to let mcpbrain remove.
    Informational: neither needs the user to run a command."""
    import json
    import time

    now = time.time() if now is None else now
    out: list[str] = []
    try:
        state = json.loads((Path(home) / "backup_state.json").read_text())
        disc = state.get("last_discard") if isinstance(state, dict) else None
        at = float(disc["at"]) if isinstance(disc, dict) else None
    except (OSError, ValueError, KeyError, TypeError):
        at = disc = None
    if at is not None and 0 <= now - at <= _DISCARD_SHOWN_S:
        from mcpbrain.probes import _ago
        reason = _discard_reason(disc.get("reason"))
        out.append(f"⚠️  {'Backup':<16} a damaged local backup was discarded "
                   f"{_ago(now - at)} ({reason}); a fresh full backup was started")
    try:
        # Read the JSON directly: backup_uploader.load_journal sets an
        # unreadable journal aside, and doctor must have no side effects.
        import json
        j = json.loads((Path(home) / "backup" / "journal.json").read_text())
        fails = (j.get("delete_failures") if isinstance(j, dict) else None) or {}
        n = sum(1 for v in fails.values()
                if isinstance(v, dict) and (v.get("count") or 0) >= _DELETE_FAILURE_MIN)
    except Exception:  # noqa: BLE001 -- a diagnostic must never break doctor
        n = 0
    if n:
        out.append(f"⚠️  {'Backup':<16} {n} old backup file(s) Drive will not let "
                   f"mcpbrain remove (check the backup folder's permissions)")
    return out


def tenant_line() -> str:
    """One line naming the tenant this build belongs to, or flagging that it has none."""
    from mcpbrain import tenant
    prof = tenant.profile()
    if prof is None:
        return (f"⚠️  {'Tenant':<16} NOT CONFIGURED — fleet, backup upload and "
                f"auto-update are disabled (docs/FORKING.md)")
    return f"✅ {'Tenant':<16} {prof.display_name} ({prof.tenant_id})"


def arch_line(os_arch: str | None = None) -> str:
    """One doctor line: OS arch vs interpreter wheel platform. os_arch defaults
    to the TRUE OS architecture (via _true_os_arch, which sees through WOW64
    emulation on Windows).

    An x64 interpreter running on an ARM64 OS is EXPECTED (that's exactly the
    emulated path Task 1/4 harden on Windows via WOW64, not a fault) —
    reported as ok/"emulated — expected" rather than a MISMATCH. (macOS
    Rosetta emulation is not covered — _true_os_arch has no macOS-specific
    detection.) Any other disagreement between OS arch and interpreter arch
    (e.g. a genuinely broken pairing) is still flagged, preserving the
    original mismatch-detection this function existed for.

    Uses sysconfig.get_platform() rather than platform.machine() for the
    interpreter side: platform.machine() reflects the OS's reported machine
    type (which WOW64/Rosetta can mask), while sysconfig.get_platform()
    reflects the actual wheel/ABI the running interpreter was built for
    (e.g. 'win-amd64', 'macosx-14.0-arm64', 'linux-x86_64') — the thing that
    actually determines whether emulation is in play."""
    import sysconfig

    os_arch = os_arch if os_arch is not None else _true_os_arch()
    interp = sysconfig.get_platform()          # e.g. 'win-amd64', 'macosx-14.0-arm64'
    interp_arch = interp.rsplit("-", 1)[-1]
    os_n = _ARCH_NORM.get(os_arch.lower(), os_arch.upper())
    interp_n = _ARCH_NORM.get(interp_arch.lower(), interp_arch.upper())
    emulated = os_n == "ARM64" and interp_n == "X64"
    agree = os_n == interp_n
    if emulated:
        glyph, state = "✅", "emulated — expected"
    elif agree:
        glyph, state = "✅", "ok"
    else:
        glyph, state = "⚠️", "MISMATCH (emulated interpreter?)"
    return f"{glyph} {'Architecture':<16} OS={os_arch} interpreter={interp} → {state}"


# How many integrity problems doctor prints before summarising the rest. A badly
# corrupted store can report thousands; the goal is a legible signal plus enough
# detail to name the broken table.
_INTEGRITY_SHOWN = 5


def _run_integrity_check(home) -> list[str]:
    """`PRAGMA integrity_check` over the store, as a list of problems ([] == ok).

    FULL integrity_check, never `quick_check`. quick_check is roughly twice as
    fast (9s vs 19s on a 1.9 GB store) and would have missed the 2026-09-10
    corruption completely: per SQLite's docs it "does not verify UNIQUE
    constraints and does not verify that index content matches table content",
    which is exactly the two classes that fired there ("wrong # of entries in
    index sqlite_autoindex_sync_cursors_1", "NULL value in sync_cursors.source").
    Ten seconds in an on-demand diagnostic is not worth a blind spot.

    Opened read-only through sqlite3 directly rather than through Store: this must
    work on a store too damaged for Store's own init/migrations to run, which is
    precisely when it matters.
    """
    import sqlite3
    path = Path(home) / "brain.sqlite3"
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    try:
        rows = con.execute("PRAGMA integrity_check").fetchall()
    finally:
        con.close()
    problems = [r[0] for r in rows if r and r[0] and r[0] != "ok"]
    return problems


def integrity_line(home, *, check=None) -> str:
    """One doctor line for store integrity.

    Nothing else in the system ran this. On 2026-09-10 `sync_cursors` was
    physically corrupted and the only symptom was the daemon raising "database
    disk image is malformed" whenever something read a cursor — hours later.
    doctor reported `foreign_key_check` but never `integrity_check`, so a store
    with a broken b-tree looked healthy.
    """
    check = check or _run_integrity_check
    try:
        problems = check(home)
    except Exception as exc:  # noqa: BLE001 — a diagnostic must never be fatal
        return f"➖ {'Integrity':<16} skipped ({exc})"
    if not problems:
        return f"✅ {'Integrity':<16} integrity_check ok"
    shown = "; ".join(problems[:_INTEGRITY_SHOWN])
    more = ""
    if len(problems) > _INTEGRITY_SHOWN:
        more = f" (+{len(problems) - _INTEGRITY_SHOWN} more of {len(problems)})"
    return (f"❌ {'Integrity':<16} {len(problems)} problem(s): {shown}{more} — "
            f"content may still be intact; check per-table counts before restoring, "
            f"and see the store-corruption incident in docs/HISTORY.md")


_REFLOW_SEED_BLOCKED = ("no_recent_backup", "disabled", "error")


def reflow_line(store) -> str:
    """One doctor line for the background reflow (extraction-fidelity,
    2026-09-24): halted / blocked / progress (n of N owners) / idle.

    A halt means apply_reflow found a dangling reference and rolled back --
    investigate, then `bin/reflow.py resume --yes`. "Blocked" means work
    remains but the seed's last run was gated (no backup in 24h, the kill
    switch, or an error): never reported as idle, which is how an unattended
    rollout would stall unnoticed. `remaining` is computed live (bounded)."""
    try:
        st = store.reflow_status(live_remaining=True)
        halted = st["halted"]
    except Exception as exc:  # noqa: BLE001 — a diagnostic must never be fatal
        return f"➖ {'Reflow':<16} skipped ({exc})"
    if halted:
        return (f"❌ {'Reflow':<16} HALTED: {halted} — investigate, then "
                f"`python bin/reflow.py resume --yes`")
    by = st.get("by_outcome") or {}
    outcomes = ", ".join(f"{k} {v}" for k, v in sorted(by.items())) or "none yet"
    detail = (f"{st['owners_done']} of {st['total']} owners done ({outcomes}); "
              f"{st['chunks_carried']} chunks carried, "
              f"{st.get('chunks_uncovered', 0)} new text to enrich, "
              f"{st.get('chunks_inherited_unenriched', 0)} inherited unenriched")
    if st.get("owners_text_differed"):
        # Carried anyway (spec §3: nearest-mapped); counted so a normaliser
        # that silently drops text shows up as a number, not nothing.
        detail += f"; {st['owners_text_differed']} owner(s) whose text differed"
    # remaining INCLUDES held owners (Store.reflow_stats), so pending counts
    # them as work; held is the subset the loop guard keeps out of the seed.
    pending = st["queued"] + (st["remaining"] or 0)
    held = st.get("held") or 0
    held_note = (f"{held} owner(s) held: ordinary path did not converge "
                 f"(retried once a day)") if held else ""
    last = (st.get("last_seed") or {}).get("status")
    # Blocked = work remains (queued rows or unseeded owners) AND the last
    # seed was gated. The dashboard's reflowText applies the same rule: once
    # the backlog is done, a stale backup is not a block.
    if pending and last in _REFLOW_SEED_BLOCKED:
        return (f"⚠️ {'Reflow':<16} BLOCKED: last seed {last} — {st['queued']} queued, "
                f"{st['remaining'] or 0} owner(s) waiting"
                f"{f'; {held_note}' if held_note else ''}; {detail}")
    if held:
        # Never ✅ or a plain ⏳: these owners went through the ordinary path
        # and still match the selector, so they will not finish on their own.
        return (f"⚠️ {'Reflow':<16} {held_note} — {st['queued']} queued, "
                f"{st['remaining'] or 0} owner(s) waiting; {detail}")
    if pending:
        gate = f"; last seed {last}" if last and last != "ok" else ""
        if last is None:
            gate = "; not yet seeded"
        return f"⏳ {'Reflow':<16} {st['queued']} queued; {detail}{gate}"
    return f"✅ {'Reflow':<16} idle ({detail})"


def ingestion_cleanup_line(store) -> str:
    """One doctor line for the one-shot ingestion clean-up (ruling I13):
    done / failed / deferred (no backup in 24 h) / disabled / running /
    pending. A deferral is a warning once the install HAS had a backup (until
    it runs, derived-source actions stay open); before the first backup it
    is just pending."""
    try:
        from mcpbrain import ingestion_cleanup as ic
        st = ic.status(store)
    except Exception as exc:  # noqa: BLE001 — a diagnostic must never be fatal
        return f"➖ {'Clean-up':<16} skipped ({exc})"
    state = st["state"]
    icon = {"done": "✅", "failed": "❌", "deferred_no_backup": "⚠️",
            "disabled": "➖", "running": "⏳", "pending": "⏳"}.get(state, "⚠️")
    if state == "deferred_no_backup" and st.get("last_backup") is None:
        icon = "⏳"          # a new install before its first backup: pending (I17 N6)
    if state == "done" and st.get("pending_steps"):
        # Added steps waiting on a gate read like a first run's gate.
        reason = st.get("pending_reason")
        icon = {"disabled": "➖",
                "no_backup": "⏳" if st.get("last_backup") is None else "⚠️"
                }.get(reason, "⏳")
    if state == "done" and st.get("added_error"):
        icon = "⚠️"          # added steps failed; the original run completed
    if ic.cli_claim_stale(st):
        icon = "⚠️"          # a crashed attended run (I17 N4)
    return f"{icon} {'Clean-up':<16} {ic.summary_line(st)}"


def version_drift_line(home, installed: str | None = None) -> str | None:
    """One doctor line naming any live MCP server(s) running superseded code,
    or None when there is nothing to say.

    A live MCP server executes the code it started with for its whole life —
    nothing signals it on update — so a shipped fix reaches a user only on
    their next client restart, not when the wheel lands. doctor previously
    reported only the installed version and looked green while a connected
    server ran stale code underneath it.

    Silent (None) both when no MCP server is currently running (that is not a
    drift problem — doctor's other checks already cover connectivity) and
    when every live server matches `installed`. `installed` defaults to the
    installed package version.

    The remedy names EVERY client kind, not just Desktop. A server belongs to
    whichever client spawned it, and Claude Code CLI sessions routinely outlive
    a Desktop restart by days — on 2026-09-09 two of five stale servers here
    were `claude` sessions from 7 and 6 days earlier, so restarting Desktop and
    re-running doctor left the warning standing with nothing explaining why.
    Kept platform-neutral ("quit completely", not Cmd-Q) because the same line
    ships to Windows.
    """
    if installed is None:
        import importlib.metadata
        installed = importlib.metadata.version("mcpbrain")
    recs = live_version_records(home)
    if not recs:
        return None
    stale_versions = sorted({r.get("version") for r in recs if r.get("version") != installed})
    if not stale_versions:
        return None
    stale_count = sum(1 for r in recs if r.get("version") != installed)
    return (f"⚠️  {'MCP version':<16} {stale_count} live server(s) on "
            f"{', '.join(stale_versions)}, installed is {installed} — each keeps "
            f"its start-time code until ITS OWN client restarts: quit Claude "
            f"Desktop completely (not just the window) and exit any long-running "
            f"Claude Code session")


def _agent_installed(home, platform) -> bool:
    """True when the OS login agent is registered. Best-effort; defaults True
    on platforms without a cheap check so doctor prefers a restart over a
    redundant install."""
    if platform == "darwin":
        from mcpbrain import agents
        return agents._LAUNCHD_PATH.exists()
    return True


def run_doctor_main(argv=None) -> None:
    import argparse
    from mcpbrain import config

    ap = argparse.ArgumentParser(prog="mcpbrain doctor")
    ap.add_argument("--offline", action="store_true",
                    help="skip the live daemon /api/status check (see run_doctor's "
                         "offline= docstring); the rest of doctor's checks still run")
    args = ap.parse_args(argv)

    code, msg = run_doctor(str(config.app_dir()), offline=args.offline)
    print(msg)
    sys.exit(code)
